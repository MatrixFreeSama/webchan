import json, pathlib
r=pathlib.Path(__file__).resolve().parents[1]
J=lambda n: json.loads((r/'results'/n).read_text())
node=J('node_portable.json'); b=J('browser_portable.json'); pb=J('proof_benchmark.json'); mb=J('memory_benchmark.json'); ab=J('adaptive_benchmark.json'); sb=J('structural_algebra_benchmark.json'); tb=J('topology_benchmark.json'); ib=J('ipe_benchmark.json'); eci=J('eci_benchmark.json'); beci=J('browser_eci.json'); native=J('native_eci.json'); kb=J('kernel_benchmark.json'); lb=J('layout_benchmark.json')
safe,blocking=b['safeResult'],b['blockingResult']; spd=sb['solvers']['spd']; lo=sb['solvers']['lowerTriangular']; dg=sb['solvers']['diagonal']; inc=ab['incremental']; pw=ab['piecewise']
manifest=json.loads((r/'generated'/'external_capabilities.json').read_text())
providers={p['id']:p for p in native['providers']}
def pname(i):
    for c in manifest['capabilities']:
        for p in c['providers']:
            if p['global_id']==i:return p['name']
    return 'unavailable'
text=f'''# Webchan 1.0.0 External Capability Interface — Fresh Validation Report

## Release identity

1.0.0 retains the provider-neutral **External Capability Interface (ECI)** and now adds Webchan IR **Structural Data Layout Algebra (SDLA)** downstream of Structural Iteration Algebra (SIA), without removing temporal, matrix-free, topology, IPE or incremental systems.

Authoritative chain:

`.webchan -> semantic/temporal/structural/capability proof -> Webchan IR -> internal generated C -> Clang/LLVM -> Wasm/native host boundary`

Portable core imports: **{node['imports']}**. Version ABI: **0x{node['version']:08x}**.

The pure core remains zero-import. The ECI Wasm profile imports exactly one explicit bridge: `{eci['imports'][0]['module']}.{eci['imports'][0]['name']}`.

## External Capability Interface

The universal source declares **{eci['capabilityCount']} capabilities** and **{eci['opCount']} external operations**. Capabilities are semantic names; providers remain replaceable.

Implemented selection order: semantic eligibility -> host eligibility -> authority class -> provider priority -> availability.

### Provider selection witnesses

| Capability/host | Selected provider |
|---|---|
| native filesystem.read | {pname(eci['selected']['nativeFilesystem'])} |
| native network.tcp | {pname(eci['selected']['nativeTcp'])} |
| native generic gpu.compute | {pname(eci['selected']['nativeGpu'])} |
| browser network.tcp | {pname(eci['selected']['browserTcp'])} |
| browser gpu.compute | {pname(eci['selected']['browserGpu'])} |
| WASI filesystem.read | {pname(eci['selected']['wasiFilesystem'])} |
| NIC fallback with only driver marked available | {pname(eci['selected']['nicDriverFallback'])} |

The generic native GPU capability selects `vulkan_compute` ahead of `cuda_driver` because 1.0.0's default policy prefers a general eligible C ABI before a vendor-specific C ABI. This is a policy choice, not a claim that Vulkan is universally faster or equivalent to CUDA-specific semantics.

### Explicit Wasm host boundary

The ECI test module has one import and exports the capability/provider query API plus `wc_eci_call`. A dispatch probe passed `(op=7, opcode=1, args=11,13)` through the host bridge and returned **{eci['callResult']}**, with the host receiving the exact operation/arguments.

Chromium independently instantiated the same ECI module. Browser selection chose TCP provider id **{beci['selected']['browserTcp']}**, GPU provider id **{beci['selected']['browserGpu']}**, and file provider id **{beci['selected']['browserFile']}**. Feature detection in that headless environment was: `{beci['features']}`.

### Native C ABI probe

The generated native provider catalogue contains **{native['catalogCount']}** candidates. The validation host detected **{native['availableCount']}** ABI/library/device-entry candidates. It performs real C stdio, POSIX socket and monotonic-clock operations; optional shared libraries are probed dynamically.

Detected notable entries on this host:
'''
for idx in [0,3,7,10,11,13,16,17,18,20,21,22,23,29]:
    if idx in providers:text+=f"- `{providers[idx]['name']}`: **{'detected' if providers[idx]['available'] else 'not detected'}**\n"
text+=f'''
Required native capabilities resolved on the actual detected provider mask as: `{eci['nativeRequired']}`.

A detected shared library is only an ABI-availability witness. It does not certify a physical GPU/NIC, permissions, context creation, or device success.

## Temporal-effect gates

The compiler rejects:

- a `potentially_blocking` external operation declared with `boundary direct`;
- an external operation referencing an undeclared capability;
- a capability name with no authority/provider catalogue entry;
- a release that disables the 1.0.0 authority-first/C-ABI-first/replaceable-provider/fallback policy.

Thus foreign calls do not silently bypass the existing temporal contract.

## Structural Iteration Algebra / generic kernel regression

The release executes **{kb['count']}** ordinary generic indexed kernels through Webchan IR with **{kb['imports']}** Wasm imports. The probes cover elementwise indexed work, neighborhood gather, loop-carried prefix state, bitwise permutation, a nested tiled loop and a staged radix-2 transform. The last item is a regression probe only; the compiler has no transform-named opcode.

Correctness witnesses: elementwise max error **{kb['correctness']['elementwiseErr']}**, neighbor max error **{kb['correctness']['neighborErr']}**, prefix result **{kb['correctness']['scanLast']} / {kb['correctness']['scanExpected']}**, permutation error **{kb['correctness']['permErr']}**, tiled-loop error **{kb['correctness']['tileErr']}**, staged-transform impulse error **{kb['correctness']['fftImpulseErr']}**, tone peak error **{kb['correctness']['fftPeakErr']:.3e}**, max leakage **{kb['correctness']['fftMaxLeak']:.3e}**.

Compiler negative gates reject out-of-range scatter, nonpositive steps, unknown symbols, underdeclared effect bounds and unclosed loop nests.

## Structural Data Layout Algebra

The source still contains ordinary logical arrays. Webchan IR selected a high-co-access pair as **interleaved** (`kind={lb['tmpPair']['kind']}`, score **{lb['tmpPair']['score']}**) and a moderate-co-access pair as **tiled** (`kind={lb['spectralPair']['kind']}`, tile **{lb['spectralPair']['tile']}**). Unrelated base arrays remained separate: `{lb['untouched']}`.

The logical array ABI remained exact after physical relayout: max get/set error **{lb['abiErr']}**. Generated C contains shared physical layout groups and compiler-generated per-logical-array lvalue mappings; the paired logical backing arrays are not separately materialized.

SDLA uses generic type/extent/nonalias legality plus matched-index locality profitability. No workload-specific layout directive or transform name is part of the source contract.

## Inverse Parallel Expansion regression

| Grain | Naive serialized | IPE | Speedup | Same checksum |
|---|---:|---:|---:|---|
'''
for g in ib['grains']:
    text+=f"| {g['name']} | {g['naive']['medianMs']:.3f} ms | {g['optimized']['medianMs']:.3f} ms | {g['speedup']:.3f}x | {g['semanticChecksumEqual']} |\n"
text+=f'''
The heterogeneous IPE region still refuses partition fusion and keeps causality-before-rank scheduling. The naive scheduler remains isolated to the benchmark Wasm rather than the portable core.

## Structural topology regression

- topology-pruned planning: **{tb['plans'][0]['fullExpansions']} -> {tb['plans'][0]['topoExpansions']}** expansions, **{tb['plannerBenchmark']['speedup']:.2f}x** measured, same semantic checksum **{tb['plannerBenchmark']['semanticChecksumEqual']}**;
- rank-first nontrivial route remains rank **{tb['plans'][1]['rank']}**, cost **{tb['plans'][1]['cost']}**, homotopy word **{tb['plans'][1]['homotopyWord']}**;
- graph and finite 2D simplicial-complex Betti/homology/collapse gates remain intact.

## Structural linear algebra regression

| Method | Per solve | Residual | Speedup vs Webchan generic dense |
|---|---:|---:|---:|
'''
dense=spd['methods']['dense-gaussian']['perSolveMs']
for k in ['dense-gaussian','banded-gaussian','krylov-cg','chebyshev','jacobi','gauss-seidel','weighted-jacobi']:
    v=spd['methods'][k];text+=f"| {k} | {v['perSolveMs']:.6f} ms | {v['residual']:.3e} | {dense/v['perSolveMs']:.1f}x |\n"
text+=f'''
Other exact structural collapses: lower-triangular -> forward substitution **{lo['autoVsDenseSpeedup']:.1f}x**, diagonal -> direct division **{dg['autoVsDenseSpeedup']:.1f}x**, relative only to Webchan's own generic dense fallback.

## Memory / incremental / browser regression

- matrix-free actual linear memory: **{mb['matrixFree']['memoryBytes']/1048576:.2f} MiB** vs dense **{mb['dense']['memoryBytes']/1048576:.2f} MiB**;
- incremental invalidation touched **{inc['invalidated']}/{node['taskCount']}** tasks with work fraction **{inc['workFraction']:.3f}** and semantic relative error **{inc['accumulatorRelativeError']:.3e}**;
- piecewise exact probe error **{pw['maxProbeError']}**;
- browser safe event lag **{safe['maxEventLagMs']:.3f} ms**, safe input lag **{safe['maxInputLagMs']:.3f} ms**;
- forced synchronous baseline event lag **{blocking['maxEventLagMs']:.3f} ms**.

## Honest boundary

Implemented in 1.0.0: capability declarations, external operation declarations, effect/boundary checking, provider authority catalogue, C-ABI-first resolution, browser/native/WASI host masks, compiler-emitted JSON/Webchan IR metadata, one-import Wasm ECI bridge, native C ABI detection/smoke path, browser/Node bridge validation, and inherited earlier engines.

Not claimed: a Webchan-owned network/GPU/NIC/audio/database runtime; arbitrary C/C++ header binding; full opaque-handle lifetime proofs; real CUDA execution on this validation host; usable DPDK/RDMA hardware; browser access to native drivers; or semantic equivalence among APIs that expose different capabilities.
'''
(r/'results/REPORT.md').write_text(text)
