import fs from 'node:fs';
const p=process.argv[2];
const bytes=fs.readFileSync(p);const mod=await WebAssembly.compile(bytes);const {exports:e}=await WebAssembly.instantiate(mod,{});
const n=e.wc_array_count();const meta=[];
for(let id=0;id<n;id++)meta.push({id,len:e.wc_array_len(id),type:e.wc_array_type(id),kind:e.wc_array_layout_kind(id),group:e.wc_array_layout_group(id),lane:e.wc_array_layout_lane(id),lanes:e.wc_array_layout_lanes(id),tile:e.wc_array_layout_tile(id),score:e.wc_array_layout_score(id),logicalBytes:String(e.wc_array_logical_bytes(id)),physicalShareBytes:String(e.wc_array_physical_share_bytes(id))});
// ABI transparency: logical ids remain independent even when physical storage is shared.
let abiErr=0;
for(let i=0;i<128;i++){e.wc_array_set(10,i,1000+i);e.wc_array_set(11,i,-2000-i);}
for(let i=0;i<128;i++){abiErr=Math.max(abiErr,Math.abs(e.wc_array_get(10,i)-(1000+i)),Math.abs(e.wc_array_get(11,i)-(-2000-i)));}
const tmpPair={sameGroup:meta[10].group===meta[11].group,kind:meta[10].kind,lanes:meta[10].lanes,score:meta[10].score};
const spectralPair={sameGroup:meta[8].group===meta[9].group,kind:meta[8].kind,tile:meta[8].tile,score:meta[8].score};
const untouched={samples:meta[0].kind,flags:meta[1].kind,rhs:meta[2].kind,solution:meta[3].kind};
console.log(JSON.stringify({imports:WebAssembly.Module.imports(mod).length,count:n,meta,tmpPair,spectralPair,untouched,abiErr}));
