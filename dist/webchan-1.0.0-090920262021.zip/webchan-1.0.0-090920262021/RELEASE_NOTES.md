# Webchan 1.0.0

Build: `090920262021`

This is the first release using the stable public semantic version `1.0.0`.
Historical development milestone names and numbered internal-IR branding are not part of the release identity.

## Included systems

- temporal-safe single-host-thread execution
- proof-directed structural optimization
- Structural Linear Algebra
- Structural Iteration Algebra
- Structural Data Layout Algebra
- Structural Topology
- matrix-free and structural non-materialization paths
- Inverse Parallel Expansion
- External Capability Interface
- generic bounded indexed kernels
- proof-gated gather, scatter, predication, reduction/scan structure and layout rewrites
- LLVM-backed generic bit-reverse lowering where the backend provides it
- zero-import portable core Wasm profile

## Release identity

- Release: `1.0.0`
- Build identifier: `090920262021`
- Build identifier format: `DDMMYYYYHHMM`
- Public archive name: `webchan-1.0.0-090920262021.zip`
- Internal textual representation: `Webchan IR`
- Internal representation files: `.webir`

No workload-specific FFT, butterfly, radix, stencil, sort, particle, RGB, AoS or SoA compiler opcode is introduced by this release.
