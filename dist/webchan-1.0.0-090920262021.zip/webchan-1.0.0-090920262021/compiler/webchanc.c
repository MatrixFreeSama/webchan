#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdint.h>
#include <math.h>

#define MAX_TASKS 96
#define MAX_EDGES 384
#define MAX_NAME 64
#define MAX_FUNCS 64
#define MAX_INSNS 128
#define MAX_ARRAYS 32
#define MAX_STRUCTS 32
#define MAX_ENUMS 32
#define MAX_FIELDS 24
#define MAX_CASES 32
#define MAX_MATRICES 16
#define MAX_BANDS 64
#define MAX_SOLVES 16
#define MAX_CHEB_STEPS 64
#define MAX_VFIELDS 32
#define MAX_POLY_DEG 8
#define MAX_FIELD_EXPR 512
#define MAX_PWFIELDS 16
#define MAX_SEGMENTS 16
#define MAX_TOPOLOGIES 8
#define MAX_TOPO_VERTICES 128
#define MAX_TOPO_EDGES 512
#define MAX_PLANS 16
#define MAX_PLAN_PATH 256
#define MAX_COMPLEXES 8
#define MAX_COMPLEX_EDGES 256
#define MAX_COMPLEX_FACES 256
#define MAX_IPE_REGIONS 8
#define MAX_IPE_NODES 64
#define MAX_IPE_DEPS 256
#define MAX_IPE_LOCALS 16
#define MAX_ECI_CAPABILITIES 32
#define MAX_ECI_OPS 64
#define MAX_ECI_PROVIDERS 64
#define MAX_CAP_NAME 96

typedef enum { WC_INPUT=0, WC_VISIBLE=1, WC_FRAME=2, WC_BACKGROUND=3, WC_SPECULATIVE=4 } wc_class;
typedef enum { TY_F64=0, TY_U32=1, TY_I32=2, TY_BOOL=3 } wc_type;
typedef enum { INS_AFFINE=0, INS_POLY=1, INS_CALL=2 } ins_kind;
typedef enum {
    SOLVER_DENSE_GAUSS=0,
    SOLVER_BANDED_GAUSS=1,
    SOLVER_KRYLOV_CG=2,
    SOLVER_CHEBYSHEV=3,
    SOLVER_JACOBI=4,
    SOLVER_GAUSS_SEIDEL=5,
    SOLVER_WEIGHTED_JACOBI=6,
    SOLVER_FORWARD_SUB=7,
    SOLVER_BACK_SUB=8,
    SOLVER_DIAGONAL=9
} solver_kind;
typedef enum { MEM_DENSE=0, MEM_MATRIX_FREE=1 } memory_mode;
typedef enum { VREP_MATERIALIZED=0, VREP_CONSTANT=1, VREP_AFFINE=2, VREP_POLYNOMIAL=3 } vfield_repr;
typedef enum { PWREP_MATERIALIZED=0, PWREP_COMPACT=1 } pwfield_repr;

typedef struct {
    ins_kind kind;
    uint32_t repeat;
    double a,b,c;
    char callee[MAX_NAME];
    int callee_id;
} fn_insn;

typedef struct {
    char name[MAX_NAME];
    uint32_t declared_bound;
    uint64_t computed_bound;
    fn_insn insn[MAX_INSNS];
    size_t ninsn;
    int visiting, done, structure_visiting, structure_done;
    int proof_pure, proof_affine, proof_monotone;
    double affine_a, affine_b;
    uint64_t structural_original_ops, structural_collapsed_ops;
} fn_decl;

typedef enum { ALAYOUT_SEPARATE=0, ALAYOUT_INTERLEAVED=1, ALAYOUT_TILED=2 } array_layout_kind;
typedef struct {
    char name[MAX_NAME]; wc_type type; uint32_t len;
    array_layout_kind layout_kind;
    uint8_t layout_group, layout_lane, layout_lanes;
    uint16_t layout_tile;
    uint32_t layout_score, layout_peer_mask, layout_accesses;
    uint64_t logical_bytes, physical_share_bytes;
} array_decl;

typedef struct {
    char name[MAX_NAME]; wc_type type; uint32_t len;
    char expr[MAX_FIELD_EXPR];
    double coeff[MAX_POLY_DEG+1]; int degree; int exact_proof;
    vfield_repr repr; uint32_t reconstruct_ops;
    uint64_t logical_bytes, stored_bytes, saved_bytes;
} vfield_decl;

typedef struct {
    uint32_t begin,end;
    char expr[MAX_FIELD_EXPR];
    double coeff[MAX_POLY_DEG+1]; int degree; uint32_t reconstruct_ops;
} pw_segment;

typedef struct {
    char name[MAX_NAME]; wc_type type; uint32_t len;
    pw_segment seg[MAX_SEGMENTS]; size_t nseg; int exact_partition;
    pwfield_repr repr; uint32_t max_reconstruct_ops;
    uint64_t logical_bytes, stored_bytes, saved_bytes;
} pwfield_decl;

typedef struct { char name[MAX_NAME]; wc_type type; } field_decl;
typedef struct { char name[MAX_NAME]; field_decl fields[MAX_FIELDS]; size_t nfields; } struct_decl;
typedef struct { char name[MAX_NAME]; char cases[MAX_CASES][MAX_NAME]; size_t ncases; } enum_decl;

typedef struct {
    char name[MAX_NAME]; wc_type type; uint32_t n;
    double band[MAX_BANDS]; uint8_t present[MAX_BANDS]; uint8_t mode[MAX_BANDS]; uint32_t bandwidth;
    int in_block;
    int proof_symmetric, proof_banded, proof_strict_dd, proof_spd, proof_spectrum;
    int proof_diagonal, proof_lower_triangular, proof_upper_triangular, proof_nonzero_diag;
    int proof_jacobi_convergent, proof_gs_convergent, proof_static_sparsity, proof_matrix_free_action;
    double lambda_min, lambda_max;
} matrix_decl;

typedef struct {
    char name[MAX_NAME], matrix_name[MAX_NAME], rhs_name[MAX_NAME], out_name[MAX_NAME];
    int matrix_id, rhs_id, out_id;
    double tolerance; uint32_t max_iter;
    solver_kind chosen; uint32_t unlock_bits;
    uint64_t est_dense, est_banded, est_cg, est_cheb, est_jacobi, est_gs, est_wjacobi, est_forward, est_back, est_diagonal;
    uint32_t cheb_steps, jacobi_steps, gs_steps, wjacobi_steps;
    double weighted_omega;
    double cheb_omega[MAX_CHEB_STEPS];
} solve_decl;

typedef struct {
    char name[MAX_NAME];
    int32_t shed_rank;
    uint32_t cost;
    double deadline_ms;
    wc_class cls;
    char fn_name[MAX_NAME];
    int fn_id;
    uint32_t pred_lo,pred_hi,pred_x;
} task_decl;
typedef struct { char child[MAX_NAME], parent[MAX_NAME]; } edge_decl;

typedef struct { uint16_t u,v; double cost; int32_t plan_rank; } topo_edge;
typedef struct {
    char name[MAX_NAME]; uint32_t n;
    topo_edge edge[MAX_TOPO_EDGES]; size_t nedge;
    uint32_t components, bridges, articulations, beta0, beta1;
    int32_t euler_characteristic;
    int proof_connected, proof_simply_connected, proof_contractible, proof_graph_homotopy;
    int16_t generator[MAX_TOPO_EDGES]; uint32_t free_group_rank;
} topology_decl;
typedef struct {
    char name[MAX_NAME], topology_name[MAX_NAME]; int topology_id;
    uint32_t start, goal; uint8_t active[MAX_TOPO_VERTICES];
    uint32_t path[MAX_PLAN_PATH], path_len; int32_t path_rank; double path_cost;
    uint32_t full_expansions, topo_expansions, pruned_vertices;
    int32_t homotopy_word[MAX_PLAN_PATH]; uint32_t homotopy_word_len;
} plan_decl;
typedef struct { uint16_t u,v; } simplex_edge;
typedef struct { uint16_t a,b,c; } simplex_face;
typedef struct {
    char name[MAX_NAME]; uint32_t vertices;
    simplex_edge edge[MAX_COMPLEX_EDGES]; size_t nedge;
    simplex_face face[MAX_COMPLEX_FACES]; size_t nface;
    uint32_t rank_d1, rank_d2, beta0, beta1, beta2, collapse_steps;
    int32_t euler_characteristic;
    int proof_connected, proof_contractible, proof_simply_connected, proof_euler_poincare;
} complex_decl;

typedef enum { IPE_COMPUTE=0, IPE_BARRIER=1, IPE_JOIN=2 } ipe_node_kind;
typedef struct {
    char name[MAX_NAME]; ipe_node_kind kind; char fn_name[MAX_NAME]; int fn_id;
    uint32_t begin,end; int32_t plan_rank;
} ipe_node;
typedef struct { uint16_t child,parent; } ipe_dep;
typedef struct { char name[MAX_NAME]; wc_type type; int proof_private; } ipe_local;
typedef struct {
    char name[MAX_NAME]; uint32_t workers;
    ipe_node node[MAX_IPE_NODES]; size_t nnode;
    ipe_dep dep[MAX_IPE_DEPS]; size_t ndep;
    ipe_local local[MAX_IPE_LOCALS]; size_t nlocal;
    uint16_t serial_schedule[MAX_IPE_NODES]; uint32_t serial_count;
    uint32_t compute_count, orchestration_count, spawn_count, barrier_count, join_count;
    uint32_t eliminated_orchestration, scalarized_worker_slots, fused_partitions, partition_boundaries_removed;
    uint32_t fused_begin,fused_end; int fused_fn_id; int32_t fused_rank;
    int proof_dag, proof_pure_compute, proof_orchestration_erasable, proof_worker_local_scalarizable, proof_partition_fusable, proof_rank_linearization;
} ipe_region;

#include "iteration_types.inc"

typedef enum { ECI_EFFECT_IMMEDIATE=0, ECI_EFFECT_ASYNC=1, ECI_EFFECT_POTENTIALLY_BLOCKING=2 } eci_effect;
typedef enum { ECI_BOUNDARY_DIRECT=0, ECI_BOUNDARY_ASYNC=1, ECI_BOUNDARY_EXPLICIT_BLOCKING=2 } eci_boundary;
typedef enum { ECI_PROVIDER_C_ABI=0, ECI_PROVIDER_HOST_STANDARD=1, ECI_PROVIDER_VENDOR_C_ABI=2, ECI_PROVIDER_DRIVER=3 } eci_provider_kind;
enum { ECI_HOST_NATIVE_POSIX=1u, ECI_HOST_NATIVE_WINDOWS=2u, ECI_HOST_BROWSER=4u, ECI_HOST_WASI=8u };
typedef struct { char name[MAX_CAP_NAME]; int required; eci_effect effect; } eci_capability;
typedef struct { char name[MAX_NAME]; char capability_name[MAX_CAP_NAME]; int capability_id; uint32_t opcode; eci_boundary boundary; } eci_op;
typedef struct { const char *capability; const char *name; eci_provider_kind kind; uint32_t hosts; uint32_t priority; const char *authority; } eci_provider_def;

/* Provider catalogue contains names, priorities and ABI classes only. No third-party implementation is copied into Webchan. */
static const eci_provider_def ECI_PROVIDER_CATALOG[] = {
 {"filesystem.read","c_stdio",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"ISO-C/POSIX-host"},
 {"filesystem.read","wasi_filesystem",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_WASI,10,"WASI"},
 {"filesystem.read","browser_file",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER,10,"browser-host"},
 {"network.tcp","posix_sockets",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,0,"POSIX"},
 {"network.tcp","winsock2",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_WINDOWS,0,"WinSock"},
 {"network.tcp","wasi_sockets",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_WASI,10,"WASI"},
 {"network.tcp","browser_websocket",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER,10,"browser-host"},
 {"network.http","libcurl",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"libcurl-C-ABI"},
 {"network.http","wasi_http",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_WASI,10,"WASI"},
 {"network.http","browser_fetch",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER,10,"browser-host"},
 {"gpu.compute","cuda_driver",ECI_PROVIDER_VENDOR_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"NVIDIA-CUDA-Driver-ABI"},
 {"gpu.compute","vulkan_compute",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,5,"Khronos-Vulkan-C-ABI"},
 {"gpu.compute","webgpu",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER|ECI_HOST_WASI,10,"WebGPU-host"},
 {"gpu.render","opengl",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"Khronos-OpenGL-C-ABI"},
 {"gpu.render","vulkan_graphics",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,5,"Khronos-Vulkan-C-ABI"},
 {"gpu.render","webgpu",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER|ECI_HOST_WASI,10,"WebGPU-host"},
 {"nic.packet_io","dpdk",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,0,"DPDK-C-ABI"},
 {"nic.packet_io","af_xdp",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,5,"Linux-AF_XDP"},
 {"nic.packet_io","rdma_verbs",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,10,"RDMA-verbs-C-ABI"},
 {"nic.packet_io","vendor_driver",ECI_PROVIDER_DRIVER,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,100,"explicit-vendor-driver"},
 {"database.sql","sqlite3",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"SQLite-C-ABI"},
 {"compression.deflate","zlib",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"zlib-C-ABI"},
 {"usb.device","libusb",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX|ECI_HOST_NATIVE_WINDOWS,0,"libusb-C-ABI"},
 {"audio.playback","alsa",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,0,"ALSA-C-ABI"},
 {"audio.playback","wasapi",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_NATIVE_WINDOWS,5,"Windows-host"},
 {"audio.playback","webaudio",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER,10,"browser-host"},
 {"camera.capture","v4l2",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,0,"Linux-V4L2-C-ABI"},
 {"camera.capture","mediafoundation",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_NATIVE_WINDOWS,5,"Windows-host"},
 {"camera.capture","browser_media",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER,10,"browser-host"},
 {"timer.monotonic","clock_gettime",ECI_PROVIDER_C_ABI,ECI_HOST_NATIVE_POSIX,0,"POSIX"},
 {"timer.monotonic","performance_now",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_BROWSER,10,"browser-host"},
 {"timer.monotonic","wasi_monotonic_clock",ECI_PROVIDER_HOST_STANDARD,ECI_HOST_WASI,10,"WASI"}
};
#define ECI_PROVIDER_CATALOG_COUNT (sizeof(ECI_PROVIDER_CATALOG)/sizeof(ECI_PROVIDER_CATALOG[0]))

static int effect_token(const char *v,eci_effect *out){if(!strcmp(v,"immediate"))*out=ECI_EFFECT_IMMEDIATE;else if(!strcmp(v,"asynchronous"))*out=ECI_EFFECT_ASYNC;else if(!strcmp(v,"potentially_blocking"))*out=ECI_EFFECT_POTENTIALLY_BLOCKING;else return 0;return 1;}
static const char *effect_name(eci_effect e){return e==ECI_EFFECT_IMMEDIATE?"immediate":(e==ECI_EFFECT_ASYNC?"asynchronous":"potentially_blocking");}
static int boundary_token(const char *v,eci_boundary *out){if(!strcmp(v,"direct"))*out=ECI_BOUNDARY_DIRECT;else if(!strcmp(v,"async"))*out=ECI_BOUNDARY_ASYNC;else if(!strcmp(v,"explicit_blocking"))*out=ECI_BOUNDARY_EXPLICIT_BLOCKING;else return 0;return 1;}
static const char *boundary_name(eci_boundary b){return b==ECI_BOUNDARY_DIRECT?"direct":(b==ECI_BOUNDARY_ASYNC?"async":"explicit_blocking");}
static const char *provider_kind_name(eci_provider_kind k){return k==ECI_PROVIDER_C_ABI?"c_abi":(k==ECI_PROVIDER_HOST_STANDARD?"host_standard":(k==ECI_PROVIDER_VENDOR_C_ABI?"vendor_c_abi":"driver"));}
static int find_cap(eci_capability *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}

static void trim(char *s){
    size_t n=strlen(s); while(n && isspace((unsigned char)s[n-1])) s[--n]=0;
    size_t i=0; while(s[i] && isspace((unsigned char)s[i])) i++;
    if(i) memmove(s,s+i,strlen(s+i)+1);
}
static int bool_token(const char *v){return !strcmp(v,"true");}
static int class_token(const char *v,wc_class *out){
    if(!strcmp(v,"input"))*out=WC_INPUT; else if(!strcmp(v,"visible"))*out=WC_VISIBLE;
    else if(!strcmp(v,"frame"))*out=WC_FRAME; else if(!strcmp(v,"background"))*out=WC_BACKGROUND;
    else if(!strcmp(v,"speculative"))*out=WC_SPECULATIVE; else return 0; return 1;
}
static int type_token(const char *v,wc_type *out){
    if(!strcmp(v,"f64"))*out=TY_F64; else if(!strcmp(v,"u32"))*out=TY_U32;
    else if(!strcmp(v,"i32"))*out=TY_I32; else if(!strcmp(v,"bool"))*out=TY_BOOL; else return 0; return 1;
}
static const char *type_name(wc_type t){ static const char *n[]={"f64","u32","i32","bool"}; return n[(unsigned)t<4?(unsigned)t:0]; }
static const char *ctype_name(wc_type t){ static const char *n[]={"double","uint32_t","int32_t","uint8_t"}; return n[(unsigned)t<4?(unsigned)t:0]; }
static const char *class_name(wc_class c){ static const char *n[]={"input","visible","frame","background","speculative"}; return n[(unsigned)c<5?(unsigned)c:4]; }
static int find_task(task_decl *t,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(t[i].name,name))return (int)i;return -1;}
static int find_fn(fn_decl *f,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(f[i].name,name))return (int)i;return -1;}
static int find_array(array_decl *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}
static int find_matrix(matrix_decl *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}
static int find_vfield(vfield_decl *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}
static int find_pwfield(pwfield_decl *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}
static int find_topology(topology_decl *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}
static int find_complex(complex_decl *a,size_t n,const char *name){for(size_t i=0;i<n;i++)if(!strcmp(a[i].name,name))return (int)i;return -1;}
static int find_ipe_node(ipe_region *r,const char *name){for(size_t i=0;i<r->nnode;i++)if(!strcmp(r->node[i].name,name))return (int)i;return -1;}
static const char *vfield_repr_name(vfield_repr r){switch(r){case VREP_CONSTANT:return "constant";case VREP_AFFINE:return "affine";case VREP_POLYNOMIAL:return "polynomial";default:return "materialized";}}

#include "iteration_support.inc"
#include "layout_support.inc"

typedef struct { double c[MAX_POLY_DEG+1]; int deg; int ok; } poly;
typedef struct { const char *p; } expr_parser;
static void pnorm(poly *a){while(a->deg>0 && a->c[a->deg]==0.0)a->deg--;}
static poly pzero(void){poly a={{0},0,1};return a;}
static poly pconst(double x){poly a=pzero();a.c[0]=x;return a;}
static poly pvar(void){poly a=pzero();a.deg=1;a.c[1]=1.0;return a;}
static poly padd(poly a,poly b,int sub){poly r=pzero();r.deg=a.deg>b.deg?a.deg:b.deg;for(int i=0;i<=r.deg;i++)r.c[i]=a.c[i]+(sub?-b.c[i]:b.c[i]);pnorm(&r);return r;}
static poly pmul(poly a,poly b){poly r=pzero();if(a.deg+b.deg>MAX_POLY_DEG){r.ok=0;return r;}r.deg=a.deg+b.deg;for(int i=0;i<=a.deg;i++)for(int j=0;j<=b.deg;j++)r.c[i+j]+=a.c[i]*b.c[j];pnorm(&r);return r;}
static void eskip(expr_parser *e){while(isspace((unsigned char)*e->p))e->p++;}
static poly parse_expr_rec(expr_parser *e);
static poly parse_factor(expr_parser *e){eskip(e);if(*e->p=='+'){e->p++;return parse_factor(e);}if(*e->p=='-'){e->p++;poly a=parse_factor(e);for(int i=0;i<=a.deg;i++)a.c[i]=-a.c[i];return a;}if(*e->p=='('){e->p++;poly a=parse_expr_rec(e);eskip(e);if(*e->p!=')'){a.ok=0;return a;}e->p++;return a;}if(*e->p=='i' && !(isalnum((unsigned char)e->p[1])||e->p[1]=='_')){e->p++;return pvar();}char *end=NULL;double v=strtod(e->p,&end);if(end!=e->p){e->p=end;return pconst(v);}poly bad=pzero();bad.ok=0;return bad;}
static poly parse_term(expr_parser *e){poly a=parse_factor(e);while(a.ok){eskip(e);char op=*e->p;if(op!='*'&&op!='/')break;e->p++;poly b=parse_factor(e);if(!b.ok){a.ok=0;break;}if(op=='*')a=pmul(a,b);else{pnorm(&b);if(b.deg!=0||b.c[0]==0.0){a.ok=0;break;}for(int i=0;i<=a.deg;i++)a.c[i]/=b.c[0];} }return a;}
static poly parse_expr_rec(expr_parser *e){poly a=parse_term(e);while(a.ok){eskip(e);char op=*e->p;if(op!='+'&&op!='-')break;e->p++;poly b=parse_term(e);if(!b.ok){a.ok=0;break;}a=padd(a,b,op=='-');}return a;}
static int parse_polynomial(const char *s,double coeff[MAX_POLY_DEG+1],int *degree){expr_parser e={s};poly a=parse_expr_rec(&e);eskip(&e);if(!a.ok||*e.p)return 0;pnorm(&a);for(int i=0;i<=MAX_POLY_DEG;i++)coeff[i]=a.c[i];*degree=a.deg;return 1;}
static void analyze_vfield(vfield_decl *v,memory_mode mode,uint32_t recompute_budget,uint64_t min_savings){
    uint64_t es=8u;v->logical_bytes=(uint64_t)v->len*es;v->reconstruct_ops=v->degree==0?0u:(uint32_t)(2*v->degree);uint64_t compact=(uint64_t)(v->degree+1)*8u;
    int eligible=mode==MEM_MATRIX_FREE&&v->exact_proof&&v->logical_bytes>compact&&(v->logical_bytes-compact)>=min_savings&&v->reconstruct_ops<=recompute_budget;
    if(eligible){v->repr=v->degree==0?VREP_CONSTANT:(v->degree==1?VREP_AFFINE:VREP_POLYNOMIAL);v->stored_bytes=compact;}else{v->repr=VREP_MATERIALIZED;v->stored_bytes=v->logical_bytes;}
    v->saved_bytes=v->logical_bytes-v->stored_bytes;
}
static void analyze_pwfield(pwfield_decl *v,memory_mode mode,uint32_t recompute_budget,uint64_t min_savings){
    v->logical_bytes=(uint64_t)v->len*8u; v->max_reconstruct_ops=0;
    uint64_t compact=0;
    for(size_t k=0;k<v->nseg;k++){
        pw_segment *g=&v->seg[k]; g->reconstruct_ops=g->degree==0?0u:(uint32_t)(2*g->degree);
        if(g->reconstruct_ops>v->max_reconstruct_ops)v->max_reconstruct_ops=g->reconstruct_ops;
        compact += 8u + (uint64_t)(g->degree+1)*8u; /* end + coefficients */
    }
    int eligible=mode==MEM_MATRIX_FREE&&v->exact_partition&&v->logical_bytes>compact&&(v->logical_bytes-compact)>=min_savings&&v->max_reconstruct_ops<=recompute_budget;
    v->repr=eligible?PWREP_COMPACT:PWREP_MATERIALIZED; v->stored_bytes=eligible?compact:v->logical_bytes; v->saved_bytes=v->logical_bytes-v->stored_bytes;
}
static unsigned pop3(uint32_t a,uint32_t b,uint32_t c){return __builtin_popcount(a)+__builtin_popcount(b)+__builtin_popcount(c);}
static int has_pred(const task_decl *t,int idx){if(idx<32)return (t->pred_lo>>idx)&1u;if(idx<64)return (t->pred_hi>>(idx-32))&1u;return (t->pred_x>>(idx-64))&1u;}
static void set_pred(task_decl *t,int idx){if(idx<32)t->pred_lo|=1u<<idx;else if(idx<64)t->pred_hi|=1u<<(idx-32);else t->pred_x|=1u<<(idx-64);}
static int validate_dag(task_decl *t,size_t n){
    unsigned indeg[MAX_TASKS]={0}; int q[MAX_TASKS]; size_t qh=0,qt=0,seen=0;
    for(size_t i=0;i<n;i++)indeg[i]=pop3(t[i].pred_lo,t[i].pred_hi,t[i].pred_x);
    for(size_t i=0;i<n;i++)if(!indeg[i])q[qt++]=(int)i;
    while(qh<qt){int u=q[qh++];seen++;for(size_t v=0;v<n;v++)if(has_pred(&t[v],u)&&--indeg[v]==0)q[qt++]=(int)v;}
    return seen==n;
}

static uint64_t fn_bound(fn_decl *f,size_t nf,int id,int *ok){
    fn_decl *x=&f[id]; if(x->done)return x->computed_bound; if(x->visiting){*ok=0;return 0;} x->visiting=1;
    uint64_t total=0;
    for(size_t k=0;k<x->ninsn;k++){
        fn_insn *in=&x->insn[k]; uint64_t unit=0;
        if(in->kind==INS_AFFINE) unit=2;
        else if(in->kind==INS_POLY) unit=7;
        else if(in->kind==INS_CALL){
            int cid=find_fn(f,nf,in->callee); if(cid<0){*ok=0;return 0;} in->callee_id=cid;
            unit=fn_bound(f,nf,cid,ok)+1; if(!*ok)return 0;
        }
        if(in->repeat && unit > UINT64_MAX/in->repeat){*ok=0;return 0;}
        uint64_t add=unit*(uint64_t)in->repeat; if(total>UINT64_MAX-add){*ok=0;return 0;} total+=add;
    }
    x->visiting=0; x->done=1; x->computed_bound=total;
    if(total>x->declared_bound){*ok=0;return total;}
    return total;
}


static void affine_repeat(double a,double b,uint32_t r,double *A,double *B){
    double ra=1.0, rb=0.0, ca=a, cb=b;
    uint32_t n=r;
    /* exponentiation by squaring on affine maps x -> a*x+b */
    while(n){
        if(n&1u){ rb=ca*rb+cb; ra=ca*ra; }
        cb=ca*cb+cb; ca=ca*ca; n>>=1u;
    }
    *A=ra; *B=rb;
}
static int analyze_fn_structure(fn_decl *f,size_t nf,int id){
    fn_decl *x=&f[id];
    if(x->structure_done)return 1;
    if(x->structure_visiting)return 0;
    x->structure_visiting=1;
    x->proof_pure=1; x->proof_affine=1; x->proof_monotone=1;
    double A=1.0,B=0.0; uint64_t original=0;
    for(size_t k=0;k<x->ninsn;k++){
        fn_insn *in=&x->insn[k];
        if(in->kind==INS_AFFINE){
            double ra,rb; affine_repeat(in->a,in->b,in->repeat,&ra,&rb);
            B=ra*B+rb; A=ra*A; original += (uint64_t)in->repeat*2u;
        }else if(in->kind==INS_CALL){
            int cid=in->callee_id>=0?in->callee_id:find_fn(f,nf,in->callee);
            if(cid<0||!analyze_fn_structure(f,nf,cid)){x->proof_affine=0;x->proof_monotone=0;break;}
            fn_decl *c=&f[cid]; original += (uint64_t)in->repeat*(c->structural_original_ops+1u);
            if(!c->proof_pure)x->proof_pure=0;
            if(!c->proof_affine){x->proof_affine=0;x->proof_monotone=0;continue;}
            double ra,rb; affine_repeat(c->affine_a,c->affine_b,in->repeat,&ra,&rb);
            B=ra*B+rb; A=ra*A;
        }else{
            original += (uint64_t)in->repeat*7u;
            x->proof_affine=0; x->proof_monotone=0;
        }
    }
    if(x->proof_affine){x->affine_a=A;x->affine_b=B;x->proof_monotone=(A>=0.0);x->structural_collapsed_ops=(A==1.0?0u:1u)+(B==0.0?0u:1u);}
    else x->structural_collapsed_ops=original;
    x->structural_original_ops=original;
    x->structure_visiting=0; x->structure_done=1; return 1;
}


static int topo_edge_index(topology_decl *g,uint32_t a,uint32_t b){for(size_t e=0;e<g->nedge;e++)if((g->edge[e].u==a&&g->edge[e].v==b)||(g->edge[e].u==b&&g->edge[e].v==a))return (int)e;return -1;}
static void topo_dfs_component(topology_decl *g,uint32_t s,uint8_t *vis){uint32_t st[MAX_TOPO_VERTICES],sp=0;st[sp++]=s;vis[s]=1;while(sp){uint32_t u=st[--sp];for(size_t e=0;e<g->nedge;e++){uint32_t v=UINT32_MAX;if(g->edge[e].u==u)v=g->edge[e].v;else if(g->edge[e].v==u)v=g->edge[e].u;if(v<g->n&&!vis[v]){vis[v]=1;st[sp++]=v;}}}}
static void topo_tarjan_dfs(topology_decl *g,uint32_t u,int parent_edge,uint32_t *tm,uint32_t *disc,uint32_t *low,uint8_t *arti,uint32_t *bridges){disc[u]=low[u]=++*tm;uint32_t children=0;for(size_t e=0;e<g->nedge;e++){uint32_t v=UINT32_MAX;if(g->edge[e].u==u)v=g->edge[e].v;else if(g->edge[e].v==u)v=g->edge[e].u;if(v>=g->n)continue;if(!disc[v]){children++;topo_tarjan_dfs(g,v,(int)e,tm,disc,low,arti,bridges);if(low[v]<low[u])low[u]=low[v];if(low[v]>disc[u])(*bridges)++;if(parent_edge>=0&&low[v]>=disc[u])arti[u]=1;}else if((int)e!=parent_edge&&disc[v]<low[u])low[u]=disc[v];}if(parent_edge<0&&children>1)arti[u]=1;}
static void analyze_topology(topology_decl *g){
    uint8_t vis[MAX_TOPO_VERTICES]={0};g->components=0;for(uint32_t v=0;v<g->n;v++)if(!vis[v]){g->components++;topo_dfs_component(g,v,vis);}g->beta0=g->components;g->beta1=(uint32_t)((int64_t)g->nedge-(int64_t)g->n+(int64_t)g->components);g->euler_characteristic=(int32_t)g->n-(int32_t)g->nedge;g->proof_connected=g->components==1;g->proof_simply_connected=g->proof_connected&&g->beta1==0;g->proof_contractible=g->proof_simply_connected;g->proof_graph_homotopy=1;g->free_group_rank=g->proof_connected?g->beta1:0;
    uint32_t disc[MAX_TOPO_VERTICES]={0},low[MAX_TOPO_VERTICES]={0},tm=0,bridges=0;uint8_t arti[MAX_TOPO_VERTICES]={0};for(uint32_t v=0;v<g->n;v++)if(!disc[v])topo_tarjan_dfs(g,v,-1,&tm,disc,low,arti,&bridges);g->bridges=bridges;g->articulations=0;for(uint32_t v=0;v<g->n;v++)g->articulations+=arti[v]!=0;
    for(size_t e=0;e<g->nedge;e++)g->generator[e]=0;
    if(g->proof_connected){uint8_t seen[MAX_TOPO_VERTICES]={0};uint32_t q[MAX_TOPO_VERTICES],qh=0,qt=0;seen[0]=1;q[qt++]=0;while(qh<qt){uint32_t u=q[qh++];for(size_t e=0;e<g->nedge;e++){uint32_t v=UINT32_MAX;if(g->edge[e].u==u)v=g->edge[e].v;else if(g->edge[e].v==u)v=g->edge[e].u;if(v<g->n&&!seen[v]){seen[v]=1;q[qt++]=v;g->generator[e]=-1;}}}int16_t gen=1;for(size_t e=0;e<g->nedge;e++)if(g->generator[e]==0)g->generator[e]=gen++;for(size_t e=0;e<g->nedge;e++)if(g->generator[e]==-1)g->generator[e]=0;}
}
static int pair_less(int32_t r1,double c1,int32_t r2,double c2){return r1<r2||(r1==r2&&c1<c2);}
static int run_topo_dijkstra(topology_decl *g,uint32_t start,uint32_t goal,const uint8_t *active,uint32_t *path,uint32_t *path_len,int32_t *rank_out,double *cost_out,uint32_t *expansions){
    int32_t rr[MAX_TOPO_VERTICES];double cc[MAX_TOPO_VERTICES];int32_t prev[MAX_TOPO_VERTICES];uint8_t used[MAX_TOPO_VERTICES]={0};for(uint32_t i=0;i<g->n;i++){rr[i]=INT32_MAX;cc[i]=1e300;prev[i]=-1;}rr[start]=INT32_MIN;cc[start]=0.0;*expansions=0;
    for(uint32_t it=0;it<g->n;it++){int u=-1;for(uint32_t v=0;v<g->n;v++)if((!active||active[v])&&!used[v]&&rr[v]!=INT32_MAX&&(u<0||pair_less(rr[v],cc[v],rr[u],cc[u])))u=(int)v;if(u<0)break;used[u]=1;(*expansions)++;if((uint32_t)u==goal)break;for(size_t e=0;e<g->nedge;e++){uint32_t v=UINT32_MAX;if(g->edge[e].u==(uint32_t)u)v=g->edge[e].v;else if(g->edge[e].v==(uint32_t)u)v=g->edge[e].u;if(v>=g->n||(!active?0:!active[v]))continue;int32_t nr=rr[u]>g->edge[e].plan_rank?rr[u]:g->edge[e].plan_rank;double nc=cc[u]+g->edge[e].cost;if(rr[v]==INT32_MAX||pair_less(nr,nc,rr[v],cc[v])){rr[v]=nr;cc[v]=nc;prev[v]=u;}}}
    if(rr[goal]==INT32_MAX)return 0;uint32_t tmp[MAX_PLAN_PATH],n=0;for(int32_t v=(int32_t)goal;v>=0&&n<MAX_PLAN_PATH;v=prev[v]){tmp[n++]=(uint32_t)v;if((uint32_t)v==start)break;}if(!n||tmp[n-1]!=start)return 0;*path_len=n;for(uint32_t i=0;i<n;i++)path[i]=tmp[n-1-i];*rank_out=(uint32_t)rr[goal];*cost_out=cc[goal];return 1;
}
static void plan_prune(topology_decl *g,plan_decl *p){for(uint32_t v=0;v<g->n;v++)p->active[v]=1;uint32_t deg[MAX_TOPO_VERTICES]={0};for(size_t e=0;e<g->nedge;e++){deg[g->edge[e].u]++;deg[g->edge[e].v]++;}int changed=1;while(changed){changed=0;for(uint32_t v=0;v<g->n;v++)if(p->active[v]&&v!=p->start&&v!=p->goal&&deg[v]<=1){p->active[v]=0;p->pruned_vertices++;changed=1;for(size_t e=0;e<g->nedge;e++){uint32_t w=UINT32_MAX;if(g->edge[e].u==v)w=g->edge[e].v;else if(g->edge[e].v==v)w=g->edge[e].u;if(w<g->n&&p->active[w]&&deg[w])deg[w]--;}}}}
static void analyze_plan(plan_decl *p,topology_decl *g){plan_prune(g,p);uint32_t base_path[MAX_PLAN_PATH],base_len=0;int32_t base_rank=0;double base_cost=0;uint32_t dummy=0;if(!run_topo_dijkstra(g,p->start,p->goal,NULL,base_path,&base_len,&base_rank,&base_cost,&p->full_expansions)){p->path_len=0;return;}if(!run_topo_dijkstra(g,p->start,p->goal,p->active,p->path,&p->path_len,&p->path_rank,&p->path_cost,&p->topo_expansions)){p->path_len=0;return;}p->homotopy_word_len=0;for(uint32_t k=1;k<p->path_len;k++){int ei=topo_edge_index(g,p->path[k-1],p->path[k]);if(ei<0)continue;int16_t gen=g->generator[ei];if(!gen)continue;int32_t letter=(g->edge[ei].u==p->path[k-1])?gen:-gen;if(p->homotopy_word_len&&p->homotopy_word[p->homotopy_word_len-1]==-letter)p->homotopy_word_len--;else if(p->homotopy_word_len<MAX_PLAN_PATH)p->homotopy_word[p->homotopy_word_len++]=letter;} (void)dummy;}
static int complex_find_edge(complex_decl *k,uint32_t a,uint32_t b){if(a>b){uint32_t t=a;a=b;b=t;}for(size_t e=0;e<k->nedge;e++)if(k->edge[e].u==a&&k->edge[e].v==b)return (int)e;return -1;}
static uint32_t gf2_rank(uint64_t rows[][4],uint32_t nr,uint32_t ncols){uint32_t r=0;for(uint32_t col=0;col<ncols&&r<nr;col++){uint32_t w=col>>6,b=col&63u,piv=r;while(piv<nr&&!(rows[piv][w]&(1ull<<b)))piv++;if(piv==nr)continue;if(piv!=r)for(int q=0;q<4;q++){uint64_t t=rows[piv][q];rows[piv][q]=rows[r][q];rows[r][q]=t;}for(uint32_t i=0;i<nr;i++)if(i!=r&&(rows[i][w]&(1ull<<b)))for(int q=0;q<4;q++)rows[i][q]^=rows[r][q];r++;}return r;}
static int complex_collapsible(complex_decl *k,uint32_t *steps){uint8_t va[MAX_TOPO_VERTICES]={0},ea[MAX_COMPLEX_EDGES]={0},fa[MAX_COMPLEX_FACES]={0};for(uint32_t v=0;v<k->vertices;v++)va[v]=1;for(size_t e=0;e<k->nedge;e++)ea[e]=1;for(size_t f=0;f<k->nface;f++)fa[f]=1;*steps=0;int progress=1;while(progress){progress=0;for(size_t e=0;e<k->nedge&&!progress;e++)if(ea[e]){uint32_t cnt=0,ff=0;for(size_t f=0;f<k->nface;f++)if(fa[f]){simplex_face q=k->face[f];if(complex_find_edge(k,q.a,q.b)==(int)e||complex_find_edge(k,q.a,q.c)==(int)e||complex_find_edge(k,q.b,q.c)==(int)e){cnt++;ff=f;}}if(cnt==1){fa[ff]=0;ea[e]=0;(*steps)++;progress=1;}}}
    for(size_t f=0;f<k->nface;f++)if(fa[f])return 0;progress=1;while(progress){progress=0;uint32_t deg[MAX_TOPO_VERTICES]={0};for(size_t e=0;e<k->nedge;e++)if(ea[e]){deg[k->edge[e].u]++;deg[k->edge[e].v]++;}for(uint32_t v=0;v<k->vertices&&!progress;v++)if(va[v]&&deg[v]==1){for(size_t e=0;e<k->nedge;e++)if(ea[e]&&(k->edge[e].u==v||k->edge[e].v==v)){ea[e]=0;va[v]=0;(*steps)++;progress=1;break;}}}
    uint32_t remainv=0,remaine=0;for(uint32_t v=0;v<k->vertices;v++)remainv+=va[v];for(size_t e=0;e<k->nedge;e++)remaine+=ea[e];return remainv==1&&remaine==0;}
static void analyze_complex(complex_decl *k){
    topology_decl g={0};g.n=k->vertices;for(size_t e=0;e<k->nedge;e++){g.edge[g.nedge].u=k->edge[e].u;g.edge[g.nedge].v=k->edge[e].v;g.edge[g.nedge].cost=1;g.nedge++;}analyze_topology(&g);k->rank_d1=k->vertices-g.components;
    uint64_t rows[MAX_COMPLEX_FACES][4]={{0}};for(size_t f=0;f<k->nface;f++){simplex_face q=k->face[f];int e0=complex_find_edge(k,q.a,q.b),e1=complex_find_edge(k,q.a,q.c),e2=complex_find_edge(k,q.b,q.c);if(e0>=0)rows[f][e0>>6]^=1ull<<(e0&63);if(e1>=0)rows[f][e1>>6]^=1ull<<(e1&63);if(e2>=0)rows[f][e2>>6]^=1ull<<(e2&63);}k->rank_d2=gf2_rank(rows,(uint32_t)k->nface,(uint32_t)k->nedge);k->beta0=k->vertices-k->rank_d1;k->beta1=(uint32_t)k->nedge-k->rank_d1-k->rank_d2;k->beta2=(uint32_t)k->nface-k->rank_d2;k->euler_characteristic=(int32_t)k->vertices-(int32_t)k->nedge+(int32_t)k->nface;k->proof_connected=k->beta0==1;k->proof_euler_poincare=k->euler_characteristic==(int32_t)k->beta0-(int32_t)k->beta1+(int32_t)k->beta2;k->proof_contractible=complex_collapsible(k,&k->collapse_steps);k->proof_simply_connected=k->proof_contractible;
}


static int ipe_validate_dag(ipe_region *r){
    uint32_t indeg[MAX_IPE_NODES]={0};for(size_t e=0;e<r->ndep;e++)indeg[r->dep[e].child]++;
    uint8_t used[MAX_IPE_NODES]={0};uint32_t done=0;
    while(done<r->nnode){int pick=-1;for(size_t i=0;i<r->nnode;i++)if(!used[i]&&!indeg[i]){pick=(int)i;break;}if(pick<0)return 0;used[pick]=1;done++;for(size_t e=0;e<r->ndep;e++)if(r->dep[e].parent==(uint16_t)pick&&indeg[r->dep[e].child])indeg[r->dep[e].child]--;}
    return 1;
}
static void ipe_reachability(ipe_region *r,uint8_t reach[MAX_IPE_NODES][MAX_IPE_NODES]){
    for(size_t i=0;i<r->nnode;i++)for(size_t j=0;j<r->nnode;j++)reach[i][j]=0;
    for(size_t e=0;e<r->ndep;e++)reach[r->dep[e].parent][r->dep[e].child]=1;
    for(size_t k=0;k<r->nnode;k++)for(size_t i=0;i<r->nnode;i++)if(reach[i][k])for(size_t j=0;j<r->nnode;j++)if(reach[k][j])reach[i][j]=1;
}
static int ipe_better_node(ipe_region *r,int a,int b){ipe_node *x=&r->node[a],*y=&r->node[b];if(x->plan_rank!=y->plan_rank)return x->plan_rank<y->plan_rank;if(x->begin!=y->begin)return x->begin<y->begin;return a<b;}
static int analyze_ipe(ipe_region *r,fn_decl *fns,size_t nf){
    r->proof_dag=ipe_validate_dag(r);if(!r->proof_dag)return 0;
    r->proof_pure_compute=1;r->proof_worker_local_scalarizable=1;r->compute_count=r->orchestration_count=r->spawn_count=r->barrier_count=r->join_count=0;
    for(size_t i=0;i<r->nnode;i++){ipe_node *n=&r->node[i];if(n->kind==IPE_COMPUTE){r->compute_count++;r->spawn_count++;n->fn_id=find_fn(fns,nf,n->fn_name);if(n->fn_id<0||!fns[n->fn_id].proof_pure)r->proof_pure_compute=0;}else{r->orchestration_count++;if(n->kind==IPE_BARRIER)r->barrier_count++;else if(n->kind==IPE_JOIN)r->join_count++;}}
    for(size_t i=0;i<r->nlocal;i++)if(!r->local[i].proof_private)r->proof_worker_local_scalarizable=0;
    r->proof_orchestration_erasable=r->proof_pure_compute&&r->proof_dag;
    r->eliminated_orchestration=r->proof_orchestration_erasable?(r->spawn_count+r->barrier_count+r->join_count):0;
    r->scalarized_worker_slots=r->proof_worker_local_scalarizable?(uint32_t)(r->nlocal*(r->workers>0?r->workers-1u:0u)):0;
    uint8_t reach[MAX_IPE_NODES][MAX_IPE_NODES];ipe_reachability(r,reach);
    uint16_t comp[MAX_IPE_NODES];uint32_t nc=0;for(size_t i=0;i<r->nnode;i++)if(r->node[i].kind==IPE_COMPUTE)comp[nc++]=(uint16_t)i;
    uint8_t picked[MAX_IPE_NODES]={0};r->serial_count=0;
    for(uint32_t step=0;step<nc;step++){int best=-1;for(uint32_t ci=0;ci<nc;ci++){int n=comp[ci];if(picked[n])continue;int ready=1;for(uint32_t cj=0;cj<nc;cj++){int p=comp[cj];if(!picked[p]&&p!=n&&reach[p][n]){ready=0;break;}}if(ready&&(best<0||ipe_better_node(r,n,best)))best=n;}if(best<0)return 0;picked[best]=1;r->serial_schedule[r->serial_count++]=(uint16_t)best;}
    r->proof_rank_linearization=1;
    r->proof_partition_fusable=0;r->fused_partitions=0;r->partition_boundaries_removed=0;r->fused_fn_id=-1;
    if(nc>1&&r->proof_orchestration_erasable){int fid=r->node[comp[0]].fn_id;int32_t rank=r->node[comp[0]].plan_rank;int independent=1;for(uint32_t a=0;a<nc;a++)for(uint32_t b=0;b<nc;b++)if(a!=b&&reach[comp[a]][comp[b]])independent=0;for(uint32_t a=0;a<nc;a++)if(r->node[comp[a]].fn_id!=fid||r->node[comp[a]].plan_rank!=rank)independent=0;if(independent){for(uint32_t a=0;a<nc;a++)for(uint32_t b=a+1;b<nc;b++)if(r->node[comp[b]].begin<r->node[comp[a]].begin){uint16_t t=comp[a];comp[a]=comp[b];comp[b]=t;}uint32_t begin=r->node[comp[0]].begin,end=r->node[comp[0]].end;int contiguous=begin<end;for(uint32_t a=1;a<nc;a++){if(r->node[comp[a]].begin!=end){contiguous=0;break;}end=r->node[comp[a]].end;}if(contiguous){r->proof_partition_fusable=1;r->fused_partitions=nc;r->partition_boundaries_removed=nc-1u;r->fused_begin=begin;r->fused_end=end;r->fused_fn_id=fid;r->fused_rank=rank;}}}
    return 1;
}
static const char *solver_name(solver_kind k){
    switch(k){
        case SOLVER_BANDED_GAUSS:return "banded-gaussian";
        case SOLVER_KRYLOV_CG:return "krylov-cg";
        case SOLVER_CHEBYSHEV:return "chebyshev-semi";
        case SOLVER_JACOBI:return "jacobi";
        case SOLVER_GAUSS_SEIDEL:return "gauss-seidel";
        case SOLVER_WEIGHTED_JACOBI:return "weighted-jacobi";
        case SOLVER_FORWARD_SUB:return "forward-substitution";
        case SOLVER_BACK_SUB:return "back-substitution";
        case SOLVER_DIAGONAL:return "diagonal-direct";
        default:return "dense-gaussian";
    }
}
static uint32_t solver_method_id(solver_kind k){
    switch(k){case SOLVER_DENSE_GAUSS:return 1;case SOLVER_BANDED_GAUSS:return 2;case SOLVER_KRYLOV_CG:return 3;case SOLVER_CHEBYSHEV:return 4;case SOLVER_JACOBI:return 5;case SOLVER_GAUSS_SEIDEL:return 6;case SOLVER_WEIGHTED_JACOBI:return 7;case SOLVER_FORWARD_SUB:return 8;case SOLVER_BACK_SUB:return 9;case SOLVER_DIAGONAL:return 10;default:return 1;}
}
static void analyze_matrix(matrix_decl *m){
    m->bandwidth=0; m->proof_banded=1; m->proof_symmetric=1; m->proof_static_sparsity=1; m->proof_matrix_free_action=1;
    m->proof_lower_triangular=1; m->proof_upper_triangular=1; m->proof_diagonal=1;
    for(uint32_t k=1;k<MAX_BANDS;k++) if(m->present[k]){
        m->bandwidth=k; m->proof_diagonal=0;
        if(m->mode[k]!=1)m->proof_symmetric=0;
        if(m->mode[k]==1){m->proof_lower_triangular=0;m->proof_upper_triangular=0;}
        else if(m->mode[k]==2)m->proof_lower_triangular=0;
        else if(m->mode[k]==3)m->proof_upper_triangular=0;
    }
    if(!m->present[0]){m->proof_symmetric=0;m->proof_lower_triangular=0;m->proof_upper_triangular=0;m->proof_diagonal=0;return;}
    double d=m->band[0]; m->proof_nonzero_diag=fabs(d)>1e-30;
    double radius=0.0;
    for(uint32_t k=1;k<MAX_BANDS;k++) if(m->present[k]){
        double a=fabs(m->band[k]); if(m->mode[k]==1)radius+=2.0*a;else radius+=a;
    }
    m->proof_strict_dd = m->proof_nonzero_diag && fabs(d)>radius;
    m->proof_spd = m->proof_symmetric && m->proof_strict_dd && d>0.0;
    m->proof_jacobi_convergent = m->proof_strict_dd;
    m->proof_gs_convergent = m->proof_strict_dd || m->proof_spd || m->proof_lower_triangular || m->proof_upper_triangular;
    if(m->proof_spd){m->proof_spectrum=1;m->lambda_min=d-radius;m->lambda_max=d+radius;}
}
static uint32_t contraction_steps(double q,double tol,uint32_t maxit){
    if(q<=0.0)return 1; if(q>=0.999999999)return maxit;
    uint32_t k=1; while(k<maxit && pow(q,(double)k)>tol)k++; return k;
}
static void analyze_solve(solve_decl *s,matrix_decl *m){
    uint64_t n=m->n,w=m->bandwidth; s->unlock_bits=0;
    if(m->proof_banded && (m->proof_spd||m->proof_strict_dd))s->unlock_bits|=1u;
    if(m->proof_spd)s->unlock_bits|=2u;
    if(m->proof_spectrum)s->unlock_bits|=4u;
    if(m->proof_jacobi_convergent)s->unlock_bits|=8u;
    if(m->proof_gs_convergent)s->unlock_bits|=16u;
    if(m->proof_spectrum && m->proof_nonzero_diag)s->unlock_bits|=32u;
    if(m->proof_lower_triangular&&m->proof_nonzero_diag)s->unlock_bits|=64u;
    if(m->proof_upper_triangular&&m->proof_nonzero_diag)s->unlock_bits|=128u;
    if(m->proof_diagonal&&m->proof_nonzero_diag)s->unlock_bits|=256u;
    s->est_dense=(n*n*n)/3u+n*n;
    s->est_banded=(s->unlock_bits&1u)?n*(2u*w*w+5u*w+6u):UINT64_MAX;
    uint32_t csteps=s->max_iter;
    if(m->proof_spectrum){
        double kappa=m->lambda_max/m->lambda_min, sq=sqrt(kappa), q=(sq-1.0)/(sq+1.0);
        csteps=1; if(q>0.0){while(csteps<s->max_iter&&2.0*pow(q,(double)csteps)>s->tolerance)csteps++;}
        if(csteps>MAX_CHEB_STEPS)csteps=MAX_CHEB_STEPS; s->cheb_steps=csteps;
        double dd=(m->lambda_max+m->lambda_min)*0.5,cc=(m->lambda_max-m->lambda_min)*0.5;
        for(uint32_t k=0;k<csteps;k++){double th=(2.0*(double)k+1.0)*3.14159265358979323846264338327950288/(2.0*(double)csteps);s->cheb_omega[k]=1.0/(dd-cc*cos(th));}
        if(m->band[0]!=0.0){double mu0=m->lambda_min/m->band[0],mu1=m->lambda_max/m->band[0];s->weighted_omega=2.0/(mu0+mu1);double qj=fmax(fabs(1.0-s->weighted_omega*mu0),fabs(1.0-s->weighted_omega*mu1));s->wjacobi_steps=contraction_steps(qj,s->tolerance,s->max_iter);}    
    }
    double jac_q=0.95;
    if(m->proof_strict_dd){double r=0.0;for(uint32_t k=1;k<MAX_BANDS;k++)if(m->present[k])r+=fabs(m->band[k])*(m->mode[k]==1?2.0:1.0);jac_q=r/fabs(m->band[0]);if(jac_q>=1.0)jac_q=0.999999;}
    s->jacobi_steps=contraction_steps(jac_q,s->tolerance,s->max_iter);
    /* GS commonly improves on Jacobi; use q^2 only as a profitability heuristic, never as a proof certificate. */
    s->gs_steps=contraction_steps(jac_q*jac_q,s->tolerance,s->max_iter);
    s->est_cg=(s->unlock_bits&2u)?(uint64_t)csteps*n*(4u*w+14u):UINT64_MAX;
    s->est_cheb=(s->unlock_bits&4u)?(uint64_t)csteps*n*(4u*w+10u):UINT64_MAX;
    s->est_jacobi=(s->unlock_bits&8u)?(uint64_t)s->jacobi_steps*n*(4u*w+6u):UINT64_MAX;
    s->est_gs=(s->unlock_bits&16u)?(uint64_t)s->gs_steps*n*(4u*w+8u):UINT64_MAX;
    s->est_wjacobi=(s->unlock_bits&32u)?(uint64_t)s->wjacobi_steps*n*(4u*w+7u):UINT64_MAX;
    s->est_forward=(s->unlock_bits&64u)?n*(2u*w+3u):UINT64_MAX;
    s->est_back=(s->unlock_bits&128u)?n*(2u*w+3u):UINT64_MAX;
    s->est_diagonal=(s->unlock_bits&256u)?2u*n:UINT64_MAX;
    s->chosen=SOLVER_DENSE_GAUSS;uint64_t best=s->est_dense;
#define WC_PICK(est,kind) do{if((est)<best){best=(est);s->chosen=(kind);}}while(0)
    WC_PICK(s->est_banded,SOLVER_BANDED_GAUSS);WC_PICK(s->est_cg,SOLVER_KRYLOV_CG);WC_PICK(s->est_cheb,SOLVER_CHEBYSHEV);WC_PICK(s->est_jacobi,SOLVER_JACOBI);WC_PICK(s->est_gs,SOLVER_GAUSS_SEIDEL);WC_PICK(s->est_wjacobi,SOLVER_WEIGHTED_JACOBI);WC_PICK(s->est_forward,SOLVER_FORWARD_SUB);WC_PICK(s->est_back,SOLVER_BACK_SUB);WC_PICK(s->est_diagonal,SOLVER_DIAGONAL);
#undef WC_PICK
}


static int emit_files(const char *outdir,const char *module,task_decl *tasks,size_t ntasks,fn_decl *fns,size_t nf,
    array_decl *arrays,size_t na,struct_decl *structs,size_t ns,enum_decl *enums,size_t ne,
    matrix_decl *matrices,size_t nm,solve_decl *solves,size_t nsolve,vfield_decl *vfields,size_t nv,pwfield_decl *pwfields,size_t npw,
    topology_decl *topologies,size_t ntopo,plan_decl *plans,size_t nplan,complex_decl *complexes,size_t ncomplex,ipe_region *ipes,size_t nipe,
    kernel_decl *kernels,size_t nk, eci_capability *caps,size_t ncaps,eci_op *eciops,size_t neciops,
    memory_mode mem_mode,uint32_t recompute_budget,uint64_t min_savings,uint32_t scratch_cap,
    double frame_ms,double slice_ms,double max_cont_ms,uint32_t max_step_units,uint32_t default_step_units,uint32_t active_cap,int order,double tol){
    char hp[1024],cp[1024],ip[1024],gp[1024],ep[1024],np[1024]; snprintf(hp,sizeof hp,"%s/webchan_program.h",outdir); snprintf(cp,sizeof cp,"%s/webchan_program.c",outdir); snprintf(ip,sizeof ip,"%s/program.webir",outdir); snprintf(gp,sizeof gp,"%s/procedural_fields.glsl",outdir); snprintf(ep,sizeof ep,"%s/external_capabilities.json",outdir); snprintf(np,sizeof np,"%s/webchan_eci_native.c",outdir);
    FILE *h=fopen(hp,"wb"),*c=fopen(cp,"wb"),*ir=fopen(ip,"wb"),*gl=fopen(gp,"wb"),*ej=fopen(ep,"wb"),*nc=fopen(np,"wb"); if(!h||!c||!ir||!gl||!ej||!nc){perror("emit");return 0;}
    fprintf(h,"#ifndef WEBCHAN_PROGRAM_H\n#define WEBCHAN_PROGRAM_H\n#include <stdint.h>\n"
      "#define WC_VERSION_MAJOR 1\n#define WC_VERSION_MINOR 0\n#define WC_VERSION_PATCH 0\n#define WC_BUILD_ID \"090920262021\"\n#define WC_MODULE_NAME \"%s\"\n#define WC_TASK_COUNT %zu\n#define WC_FN_COUNT %zu\n#define WC_ARRAY_COUNT %zu\n#define WC_STRUCT_COUNT %zu\n#define WC_ENUM_COUNT %zu\n#define WC_MATRIX_COUNT %zu\n#define WC_SOLVE_COUNT %zu\n#define WC_VFIELD_COUNT %zu\n#define WC_PWFIELD_COUNT %zu\n#define WC_TOPOLOGY_COUNT %zu\n#define WC_PLAN_COUNT %zu\n#define WC_COMPLEX_COUNT %zu\n#define WC_IPE_REGION_COUNT %zu\n#define WC_KERNEL_COUNT %zu\n#define WC_ECI_CAPABILITY_COUNT %zu\n#define WC_ECI_OP_COUNT %zu\n"
      "#define WC_FRAME_BUDGET_MS %.17g\n#define WC_SLICE_BUDGET_MS %.17g\n#define WC_MAX_CONTINUOUS_MS %.17g\n#define WC_MAX_STEP_UNITS %uu\n#define WC_DEFAULT_STEP_UNITS %uu\n#define WC_ACTIVE_SET_CAP %uu\n#define WC_CHEB_ORDER %d\n#define WC_CHEB_TOL %.17g\n"
      "#define WC_TEMPORAL_SAFETY_STRICT 1\n#define WC_PROGRESSIVE_DEFAULT 1\n#define WC_IMPLICIT_BARRIER_FORBIDDEN 1\n#define WC_CAUSAL_DAG_COMPILED 1\n#define WC_INPUT_FAIR_HOST_YIELD 1\n#define WC_C_BACKEND_AUTHORITATIVE 1\n#define WC_HOST_ABI_PORTABLE 1\n#define WC_GENERATED_C_INTERNAL_ONLY 1\n#define WC_TERMINATION_CHECKED 1\n#define WC_SIZED_TYPES 1\n#define WC_TEMPORAL_EFFECTS 1\n#define WC_PROOF_DIRECTED_OPT 1\n#define WC_PROFITABLE_PROOFS_ONLY 1\n#define WC_STATIC_MATRIX_PROOFS 1\n#define WC_PROOF_GUIDED_MATRIX_FREE 1\n#define WC_AUTO_AFFINE_DISCOVERY 1\n#define WC_BOUNDED_TEMP_MATERIALIZATION 1\n#define WC_INCREMENTAL_CHANGE_PROPAGATION 1\n#define WC_ADAPTIVE_PARTITION 1\n#define WC_EXACT_PIECEWISE_FIELDS 1\n#define WC_GENERAL_STRUCTURAL_PROOF 1\n#define WC_LINEAR_ALGEBRA_CAPABILITY_GRAPH 1\n#define WC_AFFINE_FUNCTION_COLLAPSE 1\n#define WC_JACOBI_PROOF_UNLOCK 1\n#define WC_GAUSS_SEIDEL_PROOF_UNLOCK 1\n#define WC_TRIANGULAR_SOLVE_COLLAPSE 1\n#define WC_STRUCTURAL_TOPOLOGY_PROOF 1\n#define WC_STRUCTURAL_ITERATION_ALGEBRA 1\n#define WC_FINITE_INDEX_SPACE_PROOF 1\n#define WC_DEPENDENCE_TOPOLOGY_BRIDGE 1\n#define WC_LOOP_TRANSFORM_PROOF_GATE 1\n#define WC_GENERIC_INDEX_KERNELS 1\n#define WC_BOUNDED_NESTED_FOR 1\n#define WC_PROVED_GATHER_SCATTER 1\n#define WC_LOOP_CARRIED_SCALARS 1\n#define WC_REDUCTION_SCAN_FOUNDATION 1\n#define WC_BITWISE_INDEX_MAPS 1\n#define WC_STRUCTURAL_DATA_LAYOUT_ALGEBRA 1\n#define WC_AUTO_LAYOUT_SELECTION 1\n#define WC_LOGICAL_PHYSICAL_ARRAY_SEPARATION 1\n#define WC_INTERLEAVED_LAYOUT_REWRITE 1\n#define WC_TILED_LAYOUT_REWRITE 1\n#define WC_TOPOLOGICAL_PLANNING 1\n#define WC_HOMOLOGY_GF2 1\n#define WC_GRAPH_FUNDAMENTAL_GROUP 1\n#define WC_PLAN_RANK 1\n#define WC_INVERSE_PARALLEL_EXPANSION 1\n#define WC_PARALLEL_ORCHESTRATION_ERASURE 1\n#define WC_RANK_GUIDED_RELINEARIZATION 1\n#define WC_PARTITION_FUSION 1\n#define WC_WILD_PROJECT_TEXTBOOK_ONLY 1\n#define WC_EXTERNAL_CAPABILITY_INTERFACE 1\n#define WC_ECI_C_ABI_FIRST 1\n#define WC_ECI_REPLACEABLE_PROVIDERS 1\n#define WC_ECI_TEMPORAL_EFFECT_CHECKING 1\n#define WC_ECI_VENDOR_FALLBACK_ONLY 1\n#define WC_MEMORY_MODE %u\n#define WC_MEMORY_RECOMPUTE_BUDGET %u\n#define WC_MEMORY_MIN_SAVINGS %lluu\n#define WC_FIELD_SCRATCH_CAP %u\n"
      "extern const int32_t wc_task_ranks[WC_TASK_COUNT];\nextern const uint32_t wc_task_costs[WC_TASK_COUNT];\nextern const double wc_task_deadlines[WC_TASK_COUNT];\nextern const uint8_t wc_task_classes[WC_TASK_COUNT];\nextern const uint8_t wc_task_fn[WC_TASK_COUNT];\nextern const uint32_t wc_task_pred_lo[WC_TASK_COUNT],wc_task_pred_hi[WC_TASK_COUNT],wc_task_pred_x[WC_TASK_COUNT];\n"
      "double wc_user_call(uint8_t,double,double,uint32_t,uint32_t);\ndouble wc_user_call_reference(uint8_t,double,double,uint32_t,uint32_t);\nuint32_t wc_user_fn_structural_bits(uint32_t);\nuint64_t wc_user_fn_original_ops(uint32_t);\nuint64_t wc_user_fn_collapsed_ops(uint32_t);\nuint32_t wc_user_fn_bound(uint32_t);\nuint32_t wc_user_array_count(void);\nuint32_t wc_user_array_len(uint32_t);\nuint32_t wc_user_array_type(uint32_t);\nuint32_t wc_user_array_layout_kind(uint32_t);\nuint32_t wc_user_array_layout_group(uint32_t);\nuint32_t wc_user_array_layout_lane(uint32_t);\nuint32_t wc_user_array_layout_lanes(uint32_t);\nuint32_t wc_user_array_layout_tile(uint32_t);\nuint32_t wc_user_array_layout_score(uint32_t);\nuint64_t wc_user_array_logical_bytes(uint32_t);\nuint64_t wc_user_array_physical_share_bytes(uint32_t);\ndouble wc_user_array_get(uint32_t,uint32_t);\nvoid wc_user_array_set(uint32_t,uint32_t,double);\nuint32_t wc_user_solve_count(void);\nuint32_t wc_user_solve(uint32_t,uint32_t);\ndouble wc_user_solve_residual(uint32_t);\nuint32_t wc_user_solve_proof_bits(uint32_t);\nuint32_t wc_user_solve_chosen(uint32_t);\nuint64_t wc_user_solve_estimated(uint32_t,uint32_t);\nuint32_t wc_user_memory_mode(void);\nvoid wc_user_memory_init(void);\nuint32_t wc_user_field_count(void);\nuint32_t wc_user_field_len(uint32_t);\nuint32_t wc_user_field_repr(uint32_t);\nuint32_t wc_user_field_proof_bits(uint32_t);\nuint32_t wc_user_field_reconstruct_ops(uint32_t);\nuint64_t wc_user_field_logical_bytes(uint32_t);\nuint64_t wc_user_field_stored_bytes(uint32_t);\nuint64_t wc_user_field_saved_bytes(uint32_t);\ndouble wc_user_field_get(uint32_t,uint32_t);\ndouble wc_user_field_checksum(uint32_t,uint32_t);\ndouble wc_user_field_pair_checksum(uint32_t,uint32_t,uint32_t);\nuint32_t wc_user_field_materialize(uint32_t,uint32_t,uint32_t);\ndouble wc_user_field_scratch_get(uint32_t);\nuint32_t wc_user_pwfield_count(void);\nuint32_t wc_user_pwfield_len(uint32_t);\nuint32_t wc_user_pwfield_repr(uint32_t);\nuint32_t wc_user_pwfield_segments(uint32_t);\nuint64_t wc_user_pwfield_logical_bytes(uint32_t);\nuint64_t wc_user_pwfield_stored_bytes(uint32_t);\nuint64_t wc_user_pwfield_saved_bytes(uint32_t);\ndouble wc_user_pwfield_get(uint32_t,uint32_t);\ndouble wc_user_pwfield_checksum(uint32_t,uint32_t);\nuint32_t wc_user_topology_count(void);\nuint32_t wc_user_topology_vertices(uint32_t);\nuint32_t wc_user_topology_edges(uint32_t);\nuint32_t wc_user_topology_beta0(uint32_t);\nuint32_t wc_user_topology_beta1(uint32_t);\nint32_t wc_user_topology_euler(uint32_t);\nuint32_t wc_user_topology_proof_bits(uint32_t);\nuint32_t wc_user_topology_bridges(uint32_t);\nuint32_t wc_user_topology_articulations(uint32_t);\nuint32_t wc_user_topology_free_group_rank(uint32_t);\nuint32_t wc_user_topology_incidence_rank(uint32_t);\nuint32_t wc_user_topology_laplacian_nullity(uint32_t);\nuint32_t wc_user_topology_laplacian_proof_bits(uint32_t);\nuint32_t wc_user_plan_count(void);\nuint32_t wc_user_plan_path_len(uint32_t);\nuint32_t wc_user_plan_path_vertex(uint32_t,uint32_t);\nint32_t wc_user_plan_rank(uint32_t);\ndouble wc_user_plan_cost(uint32_t);\nuint32_t wc_user_plan_full_expansions(uint32_t);\nuint32_t wc_user_plan_topo_expansions(uint32_t);\nuint32_t wc_user_plan_pruned_vertices(uint32_t);\nuint32_t wc_user_plan_homotopy_word_len(uint32_t);\nint32_t wc_user_plan_homotopy_letter(uint32_t,uint32_t);\nuint64_t wc_user_plan_bench(uint32_t,uint32_t,uint32_t);\nuint32_t wc_user_complex_count(void);\nuint32_t wc_user_complex_beta(uint32_t,uint32_t);\nint32_t wc_user_complex_euler(uint32_t);\nuint32_t wc_user_complex_proof_bits(uint32_t);\nuint32_t wc_user_complex_collapse_steps(uint32_t);\nuint32_t wc_user_ipe_count(void);\nuint32_t wc_user_ipe_proof_bits(uint32_t);\nuint32_t wc_user_ipe_original_nodes(uint32_t);\nuint32_t wc_user_ipe_serial_nodes(uint32_t);\nuint32_t wc_user_ipe_eliminated_orchestration(uint32_t);\nuint32_t wc_user_ipe_scalarized_worker_slots(uint32_t);\nuint32_t wc_user_ipe_fused_partitions(uint32_t);\nuint32_t wc_user_ipe_partition_boundaries_removed(uint32_t);\nuint32_t wc_user_ipe_schedule_node(uint32_t,uint32_t);\nuint64_t wc_user_ipe_bench(uint32_t,uint32_t,uint32_t);\nuint32_t wc_user_kernel_count(void);\nuint64_t wc_user_kernel_bound(uint32_t);\nuint64_t wc_user_kernel_extent(uint32_t);\nuint32_t wc_user_kernel_depth(uint32_t);\nuint32_t wc_user_kernel_proof_bits(uint32_t);\nuint32_t wc_user_kernel_transform_bits(uint32_t);\nvoid wc_user_kernel_run(uint32_t,uint32_t);\nuint32_t wc_user_sia_count(void);\nuint32_t wc_user_sia_kind(uint32_t);\nuint32_t wc_user_sia_extent(uint32_t);\nuint32_t wc_user_sia_stages(uint32_t);\nuint32_t wc_user_sia_locality(uint32_t);\nuint32_t wc_user_sia_proof_bits(uint32_t);\nuint32_t wc_user_sia_transform_bits(uint32_t);\nuint32_t wc_user_eci_capability_count(void);\nuint32_t wc_user_eci_op_count(void);\nuint32_t wc_user_eci_capability_effect(uint32_t);\nuint32_t wc_user_eci_capability_required(uint32_t);\nuint32_t wc_user_eci_provider_count(uint32_t);\nuint32_t wc_user_eci_provider_kind(uint32_t,uint32_t);\nuint32_t wc_user_eci_provider_hosts(uint32_t,uint32_t);\nuint32_t wc_user_eci_provider_priority(uint32_t,uint32_t);\nuint32_t wc_user_eci_provider_global_id(uint32_t,uint32_t);\nuint32_t wc_user_eci_select(uint32_t,uint32_t,uint32_t,uint32_t);\nuint32_t wc_user_eci_op_capability(uint32_t);\nuint32_t wc_user_eci_op_boundary(uint32_t);\nuint32_t wc_user_eci_op_opcode(uint32_t);\nuint64_t wc_user_eci_call(uint32_t,uint64_t,uint64_t);\n#endif\n",
      module,ntasks,nf,na,ns,ne,nm,nsolve,nv,npw,ntopo,nplan,ncomplex,nipe,nk,ncaps,neciops,frame_ms,slice_ms,max_cont_ms,max_step_units,default_step_units,active_cap,order,tol,(unsigned)mem_mode,recompute_budget,(unsigned long long)min_savings,scratch_cap);

    fprintf(c,"#include \"webchan_program.h\"\n#include <stdint.h>\n");
    for(size_t s=0;s<ns;s++){
        fprintf(c,"typedef struct {"); for(size_t j=0;j<structs[s].nfields;j++) fprintf(c,"%s %s;",ctype_name(structs[s].fields[j].type),structs[s].fields[j].name); fprintf(c,"} wc_struct_%s;\n",structs[s].name);
    }
    for(size_t e=0;e<ne;e++){ fprintf(c,"typedef enum {"); for(size_t j=0;j<enums[e].ncases;j++)fprintf(c,"WC_%s_%s=%zu%s",enums[e].name,enums[e].cases[j],j,j+1<enums[e].ncases?",":""); fprintf(c,"} wc_enum_%s;\n",enums[e].name); }
    emit_array_storage(c,arrays,na);
    fprintf(c,"static uint32_t wc_bitreverse32(uint32_t x){return __builtin_bitreverse32(x);}\n");
    fprintf(c,"static double wc_fabs(double x){return x<0.0?-x:x;} static double wc_sin_poly(double x){double x2=x*x;return x*(1.0+x2*(-0.16666666666666665741+x2*(0.0083333333333333297482+x2*(-0.00019841269841269616281+x2*(0.0000027557319223985892511+x2*(-0.000000025052108385441718776+x2*0.00000000016059043836821614599))))));} static double wc_cos_poly(double x){double x2=x*x;return 1.0+x2*(-0.5+x2*(0.041666666666666664354+x2*(-0.0013888888888888872994+x2*(0.000024801587301587003346+x2*(-0.00000027557319223985890653+x2*0.0000000020876756987868098979)))));} static double wc_reduce_angle(double x){const double tp=6.28318530717958647692528676655900576;double q=x/tp;int64_t k=(int64_t)(q+(q>=0.0?0.5:-0.5));return x-(double)k*tp;} static double wc_sin(double x){x=wc_reduce_angle(x);const double hp=1.57079632679489661923132169163975144;if(x>hp)x=3.14159265358979323846264338327950288-x;else if(x<-hp)x=-3.14159265358979323846264338327950288-x;return wc_sin_poly(x);} static double wc_cos(double x){return wc_sin(x+1.57079632679489661923132169163975144);}\n");
    for(size_t ki=0;ki<nk;ki++)emit_kernel_c(c,&kernels[ki],ki,arrays,na);
    fprintf(c,"uint32_t wc_user_kernel_count(void){return %zuu;}\n",nk);
    fprintf(c,"uint64_t wc_user_kernel_bound(uint32_t id){switch(id){");for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %lluu;",ki,(unsigned long long)kernels[ki].computed_bound);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_kernel_extent(uint32_t id){switch(id){");for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %lluu;",ki,(unsigned long long)kernels[ki].max_extent);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_kernel_depth(uint32_t id){switch(id){");for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",ki,kernels[ki].max_depth);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_kernel_proof_bits(uint32_t id){switch(id){");for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",ki,kernels[ki].proof_bits);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_kernel_transform_bits(uint32_t id){switch(id){");for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",ki,kernels[ki].transform_bits);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"void wc_user_kernel_run(uint32_t id,uint32_t reps){for(uint32_t r=0;r<reps;r++){switch(id){");for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:wc_kernel_%zu();break;",ki,ki);fprintf(c,"default:return;}}}\n");

    fprintf(c,"typedef struct{uint16_t u,v;double cost;int32_t rank;} wc_topo_edge_rt;\n");
    for(size_t ti=0;ti<ntopo;ti++){fprintf(c,"static const wc_topo_edge_rt wc_topo_%zu[%zu]={",ti,topologies[ti].nedge);for(size_t e=0;e<topologies[ti].nedge;e++)fprintf(c,"{%uu,%uu,%.17g,%d}%s",topologies[ti].edge[e].u,topologies[ti].edge[e].v,topologies[ti].edge[e].cost,topologies[ti].edge[e].plan_rank,e+1<topologies[ti].nedge?",":"");fprintf(c,"};\n");}
    for(size_t pi=0;pi<nplan;pi++){fprintf(c,"static const uint8_t wc_plan_active_%zu[%u]={",pi,topologies[plans[pi].topology_id].n);for(uint32_t v=0;v<topologies[plans[pi].topology_id].n;v++)fprintf(c,"%u%s",plans[pi].active[v]?1u:0u,v+1<topologies[plans[pi].topology_id].n?",":"");fprintf(c,"};\n");}
    fprintf(c,"static uint64_t wc_plan_rt(const wc_topo_edge_rt*e,uint32_t ne,uint32_t nv,uint32_t st,uint32_t go,const uint8_t*active,uint32_t reps){uint64_t checksum=0;for(uint32_t rep=0;rep<reps;rep++){int32_t rr[%u];double cc[%u];uint8_t used[%u];for(uint32_t i=0;i<nv;i++){rr[i]=2147483647;cc[i]=1e300;used[i]=0;}rr[st]=(-2147483647-1);cc[st]=0.0;uint32_t expansions=0;for(uint32_t it=0;it<nv;it++){int32_t u=-1;for(uint32_t v=0;v<nv;v++)if((!active||active[v])&&!used[v]&&rr[v]!=2147483647&&(u<0||rr[v]<rr[u]||(rr[v]==rr[u]&&cc[v]<cc[u])))u=(int32_t)v;if(u<0)break;used[u]=1;expansions++;if((uint32_t)u==go)break;for(uint32_t k=0;k<ne;k++){uint32_t v=0xffffffffu;if(e[k].u==(uint32_t)u)v=e[k].v;else if(e[k].v==(uint32_t)u)v=e[k].u;if(v>=nv||(active&&!active[v]))continue;int32_t nr=rr[u]>e[k].rank?rr[u]:e[k].rank;double nc=cc[u]+e[k].cost;if(rr[v]==2147483647||nr<rr[v]||(nr==rr[v]&&nc<cc[v])){rr[v]=nr;cc[v]=nc;}}}checksum+=(((uint64_t)(uint32_t)rr[go]<<32)^(uint64_t)(cc[go]*1000000.0))+(uint64_t)rep+1u;}return checksum;}\n",MAX_TOPO_VERTICES,MAX_TOPO_VERTICES,MAX_TOPO_VERTICES);

    for(size_t i=0;i<nf;i++){fprintf(c,"static double wc_fn_ref_%zu(double x,double t,uint32_t i,uint32_t task);\n",i);fprintf(c,"static double wc_fn_%zu(double x,double t,uint32_t i,uint32_t task);\n",i);} 
    for(size_t i=0;i<nf;i++){
        fprintf(c,"static double wc_fn_ref_%zu(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;",i);
        for(size_t k=0;k<fns[i].ninsn;k++){
            fn_insn *in=&fns[i].insn[k];
            if(in->kind==INS_AFFINE)fprintf(c,"for(uint32_t r=0;r<%uu;r++)v=v*%.17g+%.17g;",in->repeat,in->a,in->b);
            else if(in->kind==INS_POLY)fprintf(c,"for(uint32_t r=0;r<%uu;r++)v=(v+%.17g*v*v+%.17g)*%.17g;",in->repeat,in->a,in->b,in->c);
            else if(in->kind==INS_CALL)fprintf(c,"for(uint32_t r=0;r<%uu;r++)v=wc_fn_ref_%d(v,t,i,task);",in->repeat,in->callee_id);
        }
        fprintf(c,"return v;}\n");
        if(fns[i].proof_affine)fprintf(c,"static double wc_fn_%zu(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;return %.17g*v+%.17g;}\n",i,fns[i].affine_a,fns[i].affine_b);
        else{
            fprintf(c,"static double wc_fn_%zu(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;",i);
            for(size_t k=0;k<fns[i].ninsn;k++){
                fn_insn *in=&fns[i].insn[k];
                if(in->kind==INS_AFFINE)fprintf(c,"for(uint32_t r=0;r<%uu;r++)v=v*%.17g+%.17g;",in->repeat,in->a,in->b);
                else if(in->kind==INS_POLY)fprintf(c,"for(uint32_t r=0;r<%uu;r++)v=(v+%.17g*v*v+%.17g)*%.17g;",in->repeat,in->a,in->b,in->c);
                else if(in->kind==INS_CALL)fprintf(c,"for(uint32_t r=0;r<%uu;r++)v=wc_fn_%d(v,t,i,task);",in->repeat,in->callee_id);
            }
            fprintf(c,"return v;}\n");
        }
    }
    fprintf(c,"double wc_user_call(uint8_t id,double x,double t,uint32_t i,uint32_t task){switch(id){");for(size_t i=0;i<nf;i++)fprintf(c,"case %zu:return wc_fn_%zu(x,t,i,task);",i,i);fprintf(c,"default:return x;}}\n");
    fprintf(c,"double wc_user_call_reference(uint8_t id,double x,double t,uint32_t i,uint32_t task){switch(id){");for(size_t i=0;i<nf;i++)fprintf(c,"case %zu:return wc_fn_ref_%zu(x,t,i,task);",i,i);fprintf(c,"default:return x;}}\n");
    fprintf(c,"uint32_t wc_user_fn_structural_bits(uint32_t id){switch(id){");for(size_t i=0;i<nf;i++){unsigned bits=(fns[i].proof_pure?1u:0u)|(fns[i].proof_affine?2u:0u)|(fns[i].proof_monotone?4u:0u);fprintf(c,"case %zu:return %uu;",i,bits);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_fn_original_ops(uint32_t id){switch(id){");for(size_t i=0;i<nf;i++)fprintf(c,"case %zu:return %lluu;",i,(unsigned long long)fns[i].structural_original_ops);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_fn_collapsed_ops(uint32_t id){switch(id){");for(size_t i=0;i<nf;i++)fprintf(c,"case %zu:return %lluu;",i,(unsigned long long)fns[i].structural_collapsed_ops);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_fn_bound(uint32_t id){switch(id){"); for(size_t i=0;i<nf;i++)fprintf(c,"case %zu:return %uu;",i,(unsigned)(fns[i].computed_bound>0xffffffffu?0xffffffffu:fns[i].computed_bound)); fprintf(c,"default:return 0;}}\n");

    fprintf(c,"uint32_t wc_user_array_count(void){return %zuu;}\n",na);
    fprintf(c,"uint32_t wc_user_array_len(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,arrays[a].len);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_array_type(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,(unsigned)arrays[a].type);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_array_layout_kind(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,(unsigned)arrays[a].layout_kind);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_array_layout_group(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,(unsigned)arrays[a].layout_group);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_array_layout_lane(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,(unsigned)arrays[a].layout_lane);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"uint32_t wc_user_array_layout_lanes(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,(unsigned)arrays[a].layout_lanes);fprintf(c,"default:return 1u;}}\n");
    fprintf(c,"uint32_t wc_user_array_layout_tile(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,(unsigned)arrays[a].layout_tile);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"uint32_t wc_user_array_layout_score(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %uu;",a,arrays[a].layout_score);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"uint64_t wc_user_array_logical_bytes(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %lluu;",a,(unsigned long long)arrays[a].logical_bytes);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"uint64_t wc_user_array_physical_share_bytes(uint32_t id){switch(id){");for(size_t a=0;a<na;a++)fprintf(c,"case %zu:return %lluu;",a,(unsigned long long)arrays[a].physical_share_bytes);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"double wc_user_array_get(uint32_t id,uint32_t idx){switch(id){");for(size_t a=0;a<na;a++){fprintf(c,"case %zu:return idx<%uu?(double)WC_AREF_%zu(idx):0.0;",a,arrays[a].len,a);}fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"void wc_user_array_set(uint32_t id,uint32_t idx,double v){switch(id){");for(size_t a=0;a<na;a++){fprintf(c,"case %zu:if(idx<%uu)WC_AREF_%zu(idx)=(%s)v;break;",a,arrays[a].len,a,ctype_name(arrays[a].type));}fprintf(c,"default:break;}}\n");

    for(size_t v=0;v<nv;v++)if(vfields[v].repr==VREP_MATERIALIZED)fprintf(c,"static double wc_vfield_%zu[%u];\n",v,vfields[v].len);
    for(size_t v=0;v<nv;v++){
        vfield_decl *vf=&vfields[v];fprintf(c,"static double wc_vfield_eval_%zu(uint32_t i){double x=(double)i;",v);
        if(vf->degree==0)fprintf(c,"return %.17g;",vf->coeff[0]);
        else if(vf->degree==1)fprintf(c,"return %.17g*x+%.17g;",vf->coeff[1],vf->coeff[0]);
        else{fprintf(c,"double y=%.17g;",vf->coeff[vf->degree]);for(int d=vf->degree-1;d>=0;d--)fprintf(c,"y=y*x+%.17g;",vf->coeff[d]);fprintf(c,"return y;");}
        fprintf(c,"}\n");
    }
    fprintf(c,"static uint8_t wc_memory_initialized;\nstatic double wc_field_scratch[%uu];\n",scratch_cap?scratch_cap:1u);
    fprintf(c,"void wc_user_memory_init(void){if(wc_memory_initialized)return;");for(size_t v=0;v<nv;v++)if(vfields[v].repr==VREP_MATERIALIZED)fprintf(c,"for(uint32_t i=0;i<%uu;i++)wc_vfield_%zu[i]=wc_vfield_eval_%zu(i);",vfields[v].len,v,v);fprintf(c,"wc_memory_initialized=1;}\n");
    fprintf(c,"uint32_t wc_user_memory_mode(void){return %uu;}\n",(unsigned)mem_mode);
    fprintf(c,"uint32_t wc_user_field_count(void){return %zuu;}\n",nv);
    fprintf(c,"uint32_t wc_user_field_len(uint32_t id){switch(id){");for(size_t v=0;v<nv;v++)fprintf(c,"case %zu:return %uu;",v,vfields[v].len);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_field_repr(uint32_t id){switch(id){");for(size_t v=0;v<nv;v++)fprintf(c,"case %zu:return %uu;",v,(unsigned)vfields[v].repr);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_field_proof_bits(uint32_t id){return id<%zuu?1u:0u;}\n",nv);
    fprintf(c,"uint32_t wc_user_field_reconstruct_ops(uint32_t id){switch(id){");for(size_t v=0;v<nv;v++)fprintf(c,"case %zu:return %uu;",v,vfields[v].reconstruct_ops);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_field_logical_bytes(uint32_t id){switch(id){");for(size_t v=0;v<nv;v++)fprintf(c,"case %zu:return %lluu;",v,(unsigned long long)vfields[v].logical_bytes);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_field_stored_bytes(uint32_t id){switch(id){");for(size_t v=0;v<nv;v++)fprintf(c,"case %zu:return %lluu;",v,(unsigned long long)vfields[v].stored_bytes);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_field_saved_bytes(uint32_t id){switch(id){");for(size_t v=0;v<nv;v++)fprintf(c,"case %zu:return %lluu;",v,(unsigned long long)vfields[v].saved_bytes);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"double wc_user_field_get(uint32_t id,uint32_t idx){switch(id){");for(size_t v=0;v<nv;v++){if(vfields[v].repr==VREP_MATERIALIZED)fprintf(c,"case %zu:wc_user_memory_init();return idx<%uu?wc_vfield_%zu[idx]:0.0;",v,vfields[v].len,v);else fprintf(c,"case %zu:return idx<%uu?wc_vfield_eval_%zu(idx):0.0;",v,vfields[v].len,v);}fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"double wc_user_field_checksum(uint32_t id,uint32_t stride){if(!stride)stride=1;double s=0.0;uint32_t n=wc_user_field_len(id);for(uint32_t i=0;i<n;i+=stride)s+=wc_user_field_get(id,i);return s;}\n");
    fprintf(c,"double wc_user_field_pair_checksum(uint32_t a,uint32_t b,uint32_t count){uint32_t na=wc_user_field_len(a),nb=wc_user_field_len(b);uint32_t n=count;if(n>na)n=na;if(n>nb)n=nb;double s=0.0;for(uint32_t i=0;i<n;i++){double x=wc_user_field_get(a,i),y=wc_user_field_get(b,i);s+=x*0.625+y*0.375;}return s;}\n");
    fprintf(c,"uint32_t wc_user_field_materialize(uint32_t id,uint32_t start,uint32_t count){uint32_t n=wc_user_field_len(id);if(start>=n)return 0;if(count>%uu)count=%uu;if(count>n-start)count=n-start;for(uint32_t k=0;k<count;k++)wc_field_scratch[k]=wc_user_field_get(id,start+k);return count;}\n",scratch_cap,scratch_cap);
    fprintf(c,"double wc_user_field_scratch_get(uint32_t i){return i<%uu?wc_field_scratch[i]:0.0;}\n",scratch_cap);

    for(size_t v=0;v<npw;v++)if(pwfields[v].repr==PWREP_MATERIALIZED)fprintf(c,"static double wc_pwfield_%zu[%u];\n",v,pwfields[v].len);
    for(size_t v=0;v<npw;v++){pwfield_decl *pf=&pwfields[v];fprintf(c,"static double wc_pwfield_eval_%zu(uint32_t i){double x=(double)i;",v);for(size_t k=0;k<pf->nseg;k++){pw_segment *g=&pf->seg[k];fprintf(c,"%s(i<%uu){",k?"else if":"if",g->end);if(g->degree==0)fprintf(c,"return %.17g;",g->coeff[0]);else if(g->degree==1)fprintf(c,"return %.17g*x+%.17g;",g->coeff[1],g->coeff[0]);else{fprintf(c,"double y=%.17g;",g->coeff[g->degree]);for(int d=g->degree-1;d>=0;d--)fprintf(c,"y=y*x+%.17g;",g->coeff[d]);fprintf(c,"return y;");}fprintf(c,"}");}fprintf(c,"return 0.0;}\n");}
    fprintf(c,"static uint8_t wc_pw_memory_initialized;\nvoid wc_user_pw_memory_init(void){if(wc_pw_memory_initialized)return;");for(size_t v=0;v<npw;v++)if(pwfields[v].repr==PWREP_MATERIALIZED)fprintf(c,"for(uint32_t i=0;i<%uu;i++)wc_pwfield_%zu[i]=wc_pwfield_eval_%zu(i);",pwfields[v].len,v,v);fprintf(c,"wc_pw_memory_initialized=1;}\n");
    fprintf(c,"uint32_t wc_user_pwfield_count(void){return %zuu;}\n",npw);
    fprintf(c,"uint32_t wc_user_pwfield_len(uint32_t id){switch(id){");for(size_t v=0;v<npw;v++)fprintf(c,"case %zu:return %uu;",v,pwfields[v].len);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_pwfield_repr(uint32_t id){switch(id){");for(size_t v=0;v<npw;v++)fprintf(c,"case %zu:return %uu;",v,(unsigned)pwfields[v].repr);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_pwfield_segments(uint32_t id){switch(id){");for(size_t v=0;v<npw;v++)fprintf(c,"case %zu:return %zuu;",v,pwfields[v].nseg);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_pwfield_logical_bytes(uint32_t id){switch(id){");for(size_t v=0;v<npw;v++)fprintf(c,"case %zu:return %lluu;",v,(unsigned long long)pwfields[v].logical_bytes);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_pwfield_stored_bytes(uint32_t id){switch(id){");for(size_t v=0;v<npw;v++)fprintf(c,"case %zu:return %lluu;",v,(unsigned long long)pwfields[v].stored_bytes);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_pwfield_saved_bytes(uint32_t id){switch(id){");for(size_t v=0;v<npw;v++)fprintf(c,"case %zu:return %lluu;",v,(unsigned long long)pwfields[v].saved_bytes);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"double wc_user_pwfield_get(uint32_t id,uint32_t idx){switch(id){");for(size_t v=0;v<npw;v++){if(pwfields[v].repr==PWREP_MATERIALIZED)fprintf(c,"case %zu:wc_user_pw_memory_init();return idx<%uu?wc_pwfield_%zu[idx]:0.0;",v,pwfields[v].len,v);else fprintf(c,"case %zu:return idx<%uu?wc_pwfield_eval_%zu(idx):0.0;",v,pwfields[v].len,v);}fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"double wc_user_pwfield_checksum(uint32_t id,uint32_t stride){if(!stride)stride=1;double s=0.0;uint32_t n=wc_user_pwfield_len(id);for(uint32_t i=0;i<n;i+=stride)s+=wc_user_pwfield_get(id,i);return s;}\n");

    uint32_t solver_max_n=1; for(size_t mi=0;mi<nm;mi++)if(matrices[mi].n>solver_max_n)solver_max_n=matrices[mi].n;
    fprintf(c,"#define WC_SOLVER_MAX_N %uu\n",solver_max_n);
    fprintf(c,"static double wc_s_dense[WC_SOLVER_MAX_N*WC_SOLVER_MAX_N],wc_s_b[WC_SOLVER_MAX_N],wc_s_x[WC_SOLVER_MAX_N],wc_s_r[WC_SOLVER_MAX_N],wc_s_p[WC_SOLVER_MAX_N],wc_s_ap[WC_SOLVER_MAX_N];\nstatic double wc_s_last_res[%zu];\n",nsolve?nsolve:1);
    for(size_t si=0;si<nsolve;si++){fprintf(c,"static const double wc_cheb_omega_%zu[%u]={",si,solves[si].cheb_steps?solves[si].cheb_steps:1);if(solves[si].cheb_steps){for(uint32_t k=0;k<solves[si].cheb_steps;k++)fprintf(c,"%s%.17g",k?",":"",solves[si].cheb_omega[k]);}else fprintf(c,"0.0");fprintf(c,"};\n");}
    fprintf(c,"static double wc_absd(double x){return x<0?-x:x;}\n");
    fprintf(c,"static uint32_t wc_mat_n(uint32_t id){switch(id){");for(size_t mi=0;mi<nm;mi++)fprintf(c,"case %zu:return %uu;",mi,matrices[mi].n);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static uint32_t wc_mat_bw(uint32_t id){switch(id){");for(size_t mi=0;mi<nm;mi++)fprintf(c,"case %zu:return %uu;",mi,matrices[mi].bandwidth);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static double wc_mat_get(uint32_t id,uint32_t i,uint32_t j){switch(id){");
    for(size_t mi=0;mi<nm;mi++){
        matrix_decl *m=&matrices[mi];fprintf(c,"case %zu:{if(i>=%uu||j>=%uu)return 0.0;if(i==j)return %.17g;",mi,m->n,m->n,m->band[0]);
        for(uint32_t k=1;k<=m->bandwidth;k++)if(m->present[k]){
            if(m->mode[k]==1)fprintf(c,"if((i>j?i-j:j-i)==%uu)return %.17g;",k,m->band[k]);
            else if(m->mode[k]==2)fprintf(c,"if(j>i&&j-i==%uu)return %.17g;",k,m->band[k]);
            else if(m->mode[k]==3)fprintf(c,"if(i>j&&i-j==%uu)return %.17g;",k,m->band[k]);
        }
        fprintf(c,"return 0.0;}");
    }
    fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"static uint32_t wc_s_mid(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %du;",si,solves[si].matrix_id);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static uint32_t wc_s_rhs(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %du;",si,solves[si].rhs_id);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static uint32_t wc_s_out(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %du;",si,solves[si].out_id);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static double wc_s_rhs_direct(uint32_t s,uint32_t i){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return (double)WC_AREF_%d(i);",si,solves[si].rhs_id);fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"static void wc_s_out_direct(uint32_t s,uint32_t i,double v){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:WC_AREF_%d(i)=(%s)v;break;",si,solves[si].out_id,ctype_name(arrays[solves[si].out_id].type));fprintf(c,"default:break;}}\n");
    fprintf(c,"static uint32_t wc_s_maxiter(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %uu;",si,solves[si].max_iter);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static double wc_s_tol(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %.17g;",si,solves[si].tolerance);fprintf(c,"default:return 1e-8;}}\n");
    fprintf(c,"static uint32_t wc_s_cheb_steps(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %uu;",si,solves[si].cheb_steps);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"static double wc_s_cheb_omega(uint32_t s,uint32_t k){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return k<%uu?wc_cheb_omega_%zu[k]:0.0;",si,solves[si].cheb_steps,si);fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"static void wc_matvec(uint32_t mid,const double*x,double*y){uint32_t n=wc_mat_n(mid),w=wc_mat_bw(mid);for(uint32_t i=0;i<n;i++){double z=0.0;uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)z+=wc_mat_get(mid,i,j)*x[j];y[i]=z;}}\n");
    fprintf(c,"static void wc_load_rhs(uint32_t sid){uint32_t n=wc_mat_n(wc_s_mid(sid));for(uint32_t i=0;i<n;i++){wc_s_b[i]=wc_s_rhs_direct(sid,i);wc_s_x[i]=0.0;}}\n");
    fprintf(c,"static void wc_store_x(uint32_t sid){uint32_t n=wc_mat_n(wc_s_mid(sid));for(uint32_t i=0;i<n;i++)wc_s_out_direct(sid,i,wc_s_x[i]);}\n");
    fprintf(c,"static double wc_residual(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_matvec(mid,wc_s_x,wc_s_ap);double mx=0.0;for(uint32_t i=0;i<n;i++){double z=wc_absd(wc_s_rhs_direct(sid,i)-wc_s_ap[i]);if(z>mx)mx=z;}return mx;}\n");
    fprintf(c,"static uint32_t wc_dense_gauss(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++)for(uint32_t j=0;j<n;j++)wc_s_dense[i*n+j]=wc_mat_get(mid,i,j);for(uint32_t k=0;k<n;k++){uint32_t p=k;double best=wc_absd(wc_s_dense[k*n+k]);for(uint32_t i=k+1;i<n;i++){double z=wc_absd(wc_s_dense[i*n+k]);if(z>best){best=z;p=i;}}if(best<1e-30)return 0;if(p!=k){for(uint32_t j=k;j<n;j++){double z=wc_s_dense[k*n+j];wc_s_dense[k*n+j]=wc_s_dense[p*n+j];wc_s_dense[p*n+j]=z;}double z=wc_s_b[k];wc_s_b[k]=wc_s_b[p];wc_s_b[p]=z;}for(uint32_t i=k+1;i<n;i++){double f=wc_s_dense[i*n+k]/wc_s_dense[k*n+k];wc_s_dense[i*n+k]=0.0;for(uint32_t j=k+1;j<n;j++)wc_s_dense[i*n+j]-=f*wc_s_dense[k*n+j];wc_s_b[i]-=f*wc_s_b[k];}}for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];for(uint32_t j=ii+1;j<n;j++)z-=wc_s_dense[ii*n+j]*wc_s_x[j];wc_s_x[ii]=z/wc_s_dense[ii*n+ii];}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}\n");
    fprintf(c,"static uint32_t wc_banded_gauss(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)wc_s_dense[i*n+j]=wc_mat_get(mid,i,j);}for(uint32_t k=0;k<n;k++){double piv=wc_s_dense[k*n+k];if(wc_absd(piv)<1e-30)return 0;uint32_t im=k+w+1<n?k+w+1:n,jm=k+w+1<n?k+w+1:n;for(uint32_t i=k+1;i<im;i++){double f=wc_s_dense[i*n+k]/piv;wc_s_dense[i*n+k]=0.0;for(uint32_t j=k+1;j<jm;j++)wc_s_dense[i*n+j]-=f*wc_s_dense[k*n+j];wc_s_b[i]-=f*wc_s_b[k];}}for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];uint32_t jm=ii+w+1<n?ii+w+1:n;for(uint32_t j=ii+1;j<jm;j++)z-=wc_s_dense[ii*n+j]*wc_s_x[j];wc_s_x[ii]=z/wc_s_dense[ii*n+ii];}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}\n");
    fprintf(c,"static uint32_t wc_cg(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);double rs=0.0,bn=0.0;for(uint32_t i=0;i<n;i++){wc_s_r[i]=wc_s_b[i];wc_s_p[i]=wc_s_r[i];rs+=wc_s_r[i]*wc_s_r[i];bn+=wc_s_b[i]*wc_s_b[i];}double target=tol*tol;uint32_t it=0;for(;it<mi&&rs>target;it++){wc_matvec(mid,wc_s_p,wc_s_ap);double den=0.0;for(uint32_t i=0;i<n;i++)den+=wc_s_p[i]*wc_s_ap[i];if(den<=1e-30)break;double a=rs/den;double rs2=0.0;for(uint32_t i=0;i<n;i++){wc_s_x[i]+=a*wc_s_p[i];wc_s_r[i]-=a*wc_s_ap[i];rs2+=wc_s_r[i]*wc_s_r[i];}if(rs2<=target){rs=rs2;it++;break;}double beta=rs2/rs;for(uint32_t i=0;i<n;i++)wc_s_p[i]=wc_s_r[i]+beta*wc_s_p[i];rs=rs2;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}\n");
    fprintf(c,"static uint32_t wc_cheb(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),steps=wc_s_cheb_steps(sid);wc_load_rhs(sid);for(uint32_t k=0;k<steps;k++){wc_matvec(mid,wc_s_x,wc_s_ap);double om=wc_s_cheb_omega(sid,k);for(uint32_t i=0;i<n;i++)wc_s_x[i]+=om*(wc_s_b[i]-wc_s_ap[i]);}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return steps;}\n");
    fprintf(c,"static uint32_t wc_jacobi(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];wc_s_ap[i]=z/d;}for(uint32_t i=0;i<n;i++)wc_s_x[i]=wc_s_ap[i];if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}\n");
    fprintf(c,"static uint32_t wc_gs(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];wc_s_x[i]=z/d;}if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}\n");
    fprintf(c,"static double wc_s_weighted_omega(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %.17g;",si,solves[si].weighted_omega);fprintf(c,"default:return 1.0;}}\n");
    fprintf(c,"static uint32_t wc_wjacobi(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid),om=wc_s_weighted_omega(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];double target=z/d;wc_s_ap[i]=wc_s_x[i]+om*(target-wc_s_x[i]);}for(uint32_t i=0;i<n;i++)wc_s_x[i]=wc_s_ap[i];if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}\n");
    fprintf(c,"static uint32_t wc_forward(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){double z=wc_s_b[i];uint32_t j0=i>w?i-w:0;for(uint32_t j=j0;j<i;j++)z-=wc_mat_get(mid,i,j)*wc_s_x[j];double d=wc_mat_get(mid,i,i);if(wc_absd(d)<1e-30)return 0;wc_s_x[i]=z/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}\n");
    fprintf(c,"static uint32_t wc_back(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];uint32_t j1=ii+w+1<n?ii+w+1:n;for(uint32_t j=ii+1;j<j1;j++)z-=wc_mat_get(mid,ii,j)*wc_s_x[j];double d=wc_mat_get(mid,ii,ii);if(wc_absd(d)<1e-30)return 0;wc_s_x[ii]=z/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}\n");
    fprintf(c,"static uint32_t wc_diagonal(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i);if(wc_absd(d)<1e-30)return 0;wc_s_x[i]=wc_s_b[i]/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}\n");
    fprintf(c,"uint32_t wc_user_solve_count(void){return %zuu;}\n",nsolve);
    fprintf(c,"uint32_t wc_user_solve_proof_bits(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %uu;",si,solves[si].unlock_bits);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_solve_chosen(uint32_t s){switch(s){");for(size_t si=0;si<nsolve;si++)fprintf(c,"case %zu:return %uu;",si,solver_method_id(solves[si].chosen));fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_solve_estimated(uint32_t s,uint32_t method){switch(s){");for(size_t si=0;si<nsolve;si++){fprintf(c,"case %zu:switch(method){case 1:return %lluu;case 2:return %lluu;case 3:return %lluu;case 4:return %lluu;case 5:return %lluu;case 6:return %lluu;case 7:return %lluu;case 8:return %lluu;case 9:return %lluu;case 10:return %lluu;default:return 0;}",si,(unsigned long long)solves[si].est_dense,(unsigned long long)solves[si].est_banded,(unsigned long long)solves[si].est_cg,(unsigned long long)solves[si].est_cheb,(unsigned long long)solves[si].est_jacobi,(unsigned long long)solves[si].est_gs,(unsigned long long)solves[si].est_wjacobi,(unsigned long long)solves[si].est_forward,(unsigned long long)solves[si].est_back,(unsigned long long)solves[si].est_diagonal);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"double wc_user_solve_residual(uint32_t s){return s<%zuu?wc_s_last_res[s]:0.0;}\n",nsolve);
    fprintf(c,"uint32_t wc_user_solve(uint32_t s,uint32_t method){if(s>=%zuu)return 0;if(method==0)method=wc_user_solve_chosen(s);uint32_t bits=wc_user_solve_proof_bits(s);if(method==1)return wc_dense_gauss(s);if(method==2&&(bits&1u))return wc_banded_gauss(s);if(method==3&&(bits&2u))return wc_cg(s);if(method==4&&(bits&4u))return wc_cheb(s);if(method==5&&(bits&8u))return wc_jacobi(s);if(method==6&&(bits&16u))return wc_gs(s);if(method==7&&(bits&32u))return wc_wjacobi(s);if(method==8&&(bits&64u))return wc_forward(s);if(method==9&&(bits&128u))return wc_back(s);if(method==10&&(bits&256u))return wc_diagonal(s);return 0;}\n",nsolve);


    /* Structural Iteration Algebra: a shared finite-index operator view over
       linear algebra, topology, and imported dependence regions. This is not
       a workload-specific opcode and does not name application algorithms. */
    fprintf(c,"enum{WC_SIA_LINEAR_OPERATOR=1u,WC_SIA_TOPOLOGY_RELATION=2u,WC_SIA_DEPENDENCE_REGION=3u,WC_SIA_INDEX_KERNEL=4u};\n");
    fprintf(c,"uint32_t wc_user_sia_count(void){return %zuu;}\n",nm+ntopo+nipe+nk);
    fprintf(c,"uint32_t wc_user_sia_kind(uint32_t id){if(id<%zuu)return WC_SIA_LINEAR_OPERATOR;id-=%zuu;if(id<%zuu)return WC_SIA_TOPOLOGY_RELATION;id-=%zuu;if(id<%zuu)return WC_SIA_DEPENDENCE_REGION;id-=%zuu;if(id<%zuu)return WC_SIA_INDEX_KERNEL;return 0;}\n",nm,nm,ntopo,ntopo,nipe,nipe,nk);
    fprintf(c,"uint32_t wc_user_sia_extent(uint32_t id){switch(id){");
    for(size_t mi=0;mi<nm;mi++)fprintf(c,"case %zu:return %uu;",mi,matrices[mi].n);
    for(size_t ti=0;ti<ntopo;ti++)fprintf(c,"case %zu:return %uu;",nm+ti,topologies[ti].n);
    for(size_t ri=0;ri<nipe;ri++){uint64_t ex=0;for(size_t q=0;q<ipes[ri].nnode;q++)if(ipes[ri].node[q].kind==IPE_COMPUTE)ex+=(uint64_t)ipes[ri].node[q].end-ipes[ri].node[q].begin;if(ex>0xffffffffull)ex=0xffffffffull;fprintf(c,"case %zu:return %uu;",nm+ntopo+ri,(unsigned)ex);}for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",nm+ntopo+nipe+ki,(unsigned)(kernels[ki].max_extent>0xffffffffull?0xffffffffu:kernels[ki].max_extent));fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_sia_stages(uint32_t id){switch(id){");
    for(size_t mi=0;mi<nm;mi++)fprintf(c,"case %zu:return 1u;",mi);
    for(size_t ti=0;ti<ntopo;ti++)fprintf(c,"case %zu:return 1u;",nm+ti);
    for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",nm+ntopo+ri,ipes[ri].serial_count?ipes[ri].serial_count:1u);for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",nm+ntopo+nipe+ki,kernels[ki].max_depth?kernels[ki].max_depth:1u);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_sia_locality(uint32_t id){switch(id){");
    for(size_t mi=0;mi<nm;mi++)fprintf(c,"case %zu:return %uu;",mi,matrices[mi].bandwidth);
    for(size_t ti=0;ti<ntopo;ti++){uint32_t deg[MAX_TOPO_VERTICES]={0},mx=0;for(size_t e=0;e<topologies[ti].nedge;e++){deg[topologies[ti].edge[e].u]++;deg[topologies[ti].edge[e].v]++;}for(uint32_t v=0;v<topologies[ti].n;v++)if(deg[v]>mx)mx=deg[v];fprintf(c,"case %zu:return %uu;",nm+ti,mx);}
    for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",nm+ntopo+ri,ipes[ri].proof_partition_fusable?1u:0u);for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",nm+ntopo+nipe+ki,kernels[ki].locality);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_sia_proof_bits(uint32_t id){switch(id){");
    for(size_t mi=0;mi<nm;mi++){matrix_decl*m=&matrices[mi];uint32_t b=1u|2u|1024u|512u;if(m->proof_banded)b|=4u;if(m->proof_static_sparsity)b|=8u;if(m->proof_matrix_free_action)b|=16u;fprintf(c,"case %zu:return %uu;",mi,b);}
    for(size_t ti=0;ti<ntopo;ti++){uint32_t b=1u|2u|4u|8u|256u|1024u;fprintf(c,"case %zu:return %uu;",nm+ti,b);}
    for(size_t ri=0;ri<nipe;ri++){ipe_region*r=&ipes[ri];uint32_t b=1u|2u|1024u;if(r->proof_dag)b|=32u;if(r->proof_partition_fusable)b|=64u|128u;if(r->proof_rank_linearization)b|=2048u;fprintf(c,"case %zu:return %uu;",nm+ntopo+ri,b);}for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",nm+ntopo+nipe+ki,kernels[ki].proof_bits);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_sia_transform_bits(uint32_t id){switch(id){");
    for(size_t mi=0;mi<nm;mi++){matrix_decl*m=&matrices[mi];uint32_t b=0;if(m->proof_static_sparsity)b|=16u;if(m->proof_matrix_free_action)b|=8u;if(m->proof_diagonal||m->proof_lower_triangular||m->proof_upper_triangular)b|=64u;fprintf(c,"case %zu:return %uu;",mi,b);}
    for(size_t ti=0;ti<ntopo;ti++){uint32_t b=32u;fprintf(c,"case %zu:return %uu;",nm+ti,b);}
    for(size_t ri=0;ri<nipe;ri++){ipe_region*r=&ipes[ri];uint32_t b=0;if(r->proof_partition_fusable)b|=1u;if(r->proof_rank_linearization)b|=2u;if(r->proof_worker_local_scalarizable)b|=4u;fprintf(c,"case %zu:return %uu;",nm+ntopo+ri,b);}for(size_t ki=0;ki<nk;ki++)fprintf(c,"case %zu:return %uu;",nm+ntopo+nipe+ki,kernels[ki].transform_bits);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"#ifdef WC_IPE_BENCHMARK\n");
    fprintf(c,"typedef struct{uint16_t node;uint8_t fn;uint32_t begin,end;int32_t rank;} wc_ipe_desc;\nstatic volatile uint64_t wc_ipe_sched_state;\nstatic uint64_t wc_ipe_hash(double d,uint32_t i){int64_t q=(int64_t)(d*1000000000000.0);uint64_t z=(uint64_t)q^((uint64_t)i*0x9e3779b97f4a7c15ull);z^=z>>30;z*=0xbf58476d1ce4e5b9ull;z^=z>>27;z*=0x94d049bb133111ebull;return z^(z>>31);}\n__attribute__((noinline)) static double wc_ipe_eval(uint8_t fn,uint32_t i){return wc_user_call(fn,(double)(i+1u)*0.000001,0.375,i,0u);}\n");
    for(size_t ri=0;ri<nipe;ri++){ipe_region *r=&ipes[ri];fprintf(c,"static const wc_ipe_desc wc_ipe_desc_%zu[%u]={",ri,r->compute_count);uint32_t z=0;for(size_t ni=0;ni<r->nnode;ni++)if(r->node[ni].kind==IPE_COMPUTE){ipe_node *n=&r->node[ni];fprintf(c,"{%zuu,%uu,%uu,%uu,%d}%s",ni,(unsigned)n->fn_id,n->begin,n->end,n->plan_rank,++z<r->compute_count?",":"");}fprintf(c,"};\n");}
    fprintf(c,"#endif\n");
    fprintf(c,"uint32_t wc_user_ipe_count(void){return %zuu;}\n",nipe);
    fprintf(c,"uint32_t wc_user_ipe_proof_bits(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++){ipe_region *r=&ipes[ri];unsigned b=(r->proof_dag?1u:0u)|(r->proof_pure_compute?2u:0u)|(r->proof_orchestration_erasable?4u:0u)|(r->proof_worker_local_scalarizable?8u:0u)|(r->proof_partition_fusable?16u:0u)|(r->proof_rank_linearization?32u:0u);fprintf(c,"case %zu:return %uu;",ri,b);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_original_nodes(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %zuu;",ri,ipes[ri].nnode+ipes[ri].spawn_count);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_serial_nodes(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",ri,ipes[ri].proof_partition_fusable?1u:ipes[ri].serial_count);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_eliminated_orchestration(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",ri,ipes[ri].eliminated_orchestration);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_scalarized_worker_slots(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",ri,ipes[ri].scalarized_worker_slots);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_fused_partitions(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",ri,ipes[ri].fused_partitions);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_partition_boundaries_removed(uint32_t id){switch(id){");for(size_t ri=0;ri<nipe;ri++)fprintf(c,"case %zu:return %uu;",ri,ipes[ri].partition_boundaries_removed);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_ipe_schedule_node(uint32_t id,uint32_t k){switch(id){");for(size_t ri=0;ri<nipe;ri++){fprintf(c,"case %zu:switch(k){",ri);for(uint32_t k=0;k<ipes[ri].serial_count;k++)fprintf(c,"case %u:return %uu;",k,ipes[ri].serial_schedule[k]);fprintf(c,"default:return 0xffffffffu;}");}fprintf(c,"default:return 0xffffffffu;}}\n");
    fprintf(c,"#ifdef WC_IPE_BENCHMARK\nuint64_t wc_user_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){uint64_t total=0;switch(id){");
    for(size_t ri=0;ri<nipe;ri++){
        ipe_region *r=&ipes[ri];fprintf(c,"case %zu:for(uint32_t rep=0;rep<reps;rep++){uint64_t h=0;",ri);
        if(r->proof_partition_fusable){
            fprintf(c,"if(optimized){for(uint32_t i=%uu;i<%uu;i++){double v=wc_ipe_eval(%uu,i);h^=wc_ipe_hash(v,i);}}else{for(uint32_t q=0;q<%uu;q++){const wc_ipe_desc*d=&wc_ipe_desc_%zu[q];wc_ipe_sched_state^=((uint64_t)d->node<<32)^q;for(uint32_t i=d->begin;i<d->end;i++){double v=wc_ipe_eval(d->fn,i);h^=wc_ipe_hash(v,i);}wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}wc_ipe_sched_state^=%uu;}",r->fused_begin,r->fused_end,r->fused_fn_id,r->compute_count,ri,r->barrier_count+r->join_count);
        }else{
            fprintf(c,"if(!optimized)wc_ipe_sched_state^=((uint64_t)%zuu<<48)^rep;",ri);
            for(uint32_t q=0;q<r->serial_count;q++){
                ipe_node *n=&r->node[r->serial_schedule[q]];
                fprintf(c,"if(!optimized){wc_ipe_sched_state^=((uint64_t)%uu<<32)^%uu;wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}for(uint32_t i=%uu;i<%uu;i++){double v=wc_ipe_eval(%uu,i);h^=wc_ipe_hash(v,i);}",r->serial_schedule[q],q,n->begin,n->end,(unsigned)n->fn_id);
            }
            fprintf(c,"if(!optimized)wc_ipe_sched_state^=%uu;",r->barrier_count+r->join_count);
        }
        fprintf(c,"total^=h+((uint64_t)rep*0x517cc1b727220a95ull);}return total;");
    }
    fprintf(c,"default:return 0;}}\n#else\nuint64_t wc_user_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){(void)id;(void)optimized;(void)reps;return 0;}\n#endif\n");

    fprintf(c,"#ifdef WC_ECI_IMPORTS\n__attribute__((import_module(\"webchan_eci\"),import_name(\"dispatch\"))) extern uint64_t wc_eci_host_dispatch(uint32_t,uint32_t,uint64_t,uint64_t);\n#endif\n");
    fprintf(c,"uint32_t wc_user_eci_capability_count(void){return %zuu;}\n",ncaps);
    fprintf(c,"uint32_t wc_user_eci_op_count(void){return %zuu;}\n",neciops);
    fprintf(c,"uint32_t wc_user_eci_capability_effect(uint32_t id){switch(id){");for(size_t i=0;i<ncaps;i++)fprintf(c,"case %zu:return %uu;",i,(unsigned)caps[i].effect);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_eci_capability_required(uint32_t id){switch(id){");for(size_t i=0;i<ncaps;i++)fprintf(c,"case %zu:return %uu;",i,caps[i].required?1u:0u);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"static uint32_t wc_eci_local_provider_global(uint32_t cap,uint32_t k){switch(cap){");
    for(size_t ci=0;ci<ncaps;ci++){fprintf(c,"case %zu:switch(k){",ci);uint32_t lk=0;for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)if(!strcmp(ECI_PROVIDER_CATALOG[p].capability,caps[ci].name))fprintf(c,"case %u:return %zuu;",lk++,p);fprintf(c,"default:return 0xffffffffu;}");}fprintf(c,"default:return 0xffffffffu;}}\n");
    fprintf(c,"uint32_t wc_user_eci_provider_count(uint32_t cap){switch(cap){");for(size_t ci=0;ci<ncaps;ci++){uint32_t n=0;for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)if(!strcmp(ECI_PROVIDER_CATALOG[p].capability,caps[ci].name))n++;fprintf(c,"case %zu:return %uu;",ci,n);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_eci_provider_global_id(uint32_t cap,uint32_t k){return wc_eci_local_provider_global(cap,k);}\n");
    fprintf(c,"uint32_t wc_user_eci_provider_kind(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){");for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)fprintf(c,"case %zu:return %uu;",p,(unsigned)ECI_PROVIDER_CATALOG[p].kind);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_eci_provider_hosts(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){");for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)fprintf(c,"case %zu:return %uu;",p,ECI_PROVIDER_CATALOG[p].hosts);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"uint32_t wc_user_eci_provider_priority(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){");for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)fprintf(c,"case %zu:return %uu;",p,ECI_PROVIDER_CATALOG[p].priority);fprintf(c,"default:return 0xffffffffu;}}\n");
    fprintf(c,"uint32_t wc_user_eci_select(uint32_t cap,uint32_t host,uint32_t alo,uint32_t ahi){uint32_t n=wc_user_eci_provider_count(cap),best=0xffffffffu,bp=0xffffffffu,bk=0xffffffffu;for(uint32_t k=0;k<n;k++){uint32_t g=wc_user_eci_provider_global_id(cap,k);if(g==0xffffffffu)continue;uint32_t av=g<32?((alo>>g)&1u):((ahi>>(g-32))&1u);if(!av||!(wc_user_eci_provider_hosts(cap,k)&host))continue;uint32_t kind=wc_user_eci_provider_kind(cap,k),pri=wc_user_eci_provider_priority(cap,k);uint32_t authority=(kind==0u?0u:(kind==1u?1u:(kind==2u?2u:3u)));if(authority<bk||(authority==bk&&pri<bp)){bk=authority;bp=pri;best=g;}}return best;}\n");
    fprintf(c,"uint32_t wc_user_eci_op_capability(uint32_t id){switch(id){");for(size_t i=0;i<neciops;i++)fprintf(c,"case %zu:return %du;",i,eciops[i].capability_id);fprintf(c,"default:return 0xffffffffu;}}\n");
    fprintf(c,"uint32_t wc_user_eci_op_boundary(uint32_t id){switch(id){");for(size_t i=0;i<neciops;i++)fprintf(c,"case %zu:return %uu;",i,(unsigned)eciops[i].boundary);fprintf(c,"default:return 255u;}}\n");
    fprintf(c,"uint32_t wc_user_eci_op_opcode(uint32_t id){switch(id){");for(size_t i=0;i<neciops;i++)fprintf(c,"case %zu:return %uu;",i,eciops[i].opcode);fprintf(c,"default:return 0u;}}\n");
    fprintf(c,"uint64_t wc_user_eci_call(uint32_t op,uint64_t a0,uint64_t a1){if(op>=%zuu)return 0xffffffffffffffffull;\n",neciops);
    fprintf(c,"#ifdef WC_ECI_IMPORTS\nreturn wc_eci_host_dispatch(op,wc_user_eci_op_opcode(op),a0,a1);\n#else\n(void)a0;(void)a1;return 0xffffffffffffffffull;\n#endif\n}\n");

    fprintf(c,"const int32_t wc_task_ranks[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%d",i?",":"",tasks[i].shed_rank);fprintf(c,"};\n");
    fprintf(c,"const uint32_t wc_task_costs[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%uu",i?",":"",tasks[i].cost);fprintf(c,"};\n");
    fprintf(c,"const double wc_task_deadlines[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%.17g",i?",":"",tasks[i].deadline_ms);fprintf(c,"};\n");
    fprintf(c,"const uint8_t wc_task_classes[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%u",i?",":"",(unsigned)tasks[i].cls);fprintf(c,"};\n");
    fprintf(c,"const uint8_t wc_task_fn[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%u",i?",":"",(unsigned)tasks[i].fn_id);fprintf(c,"};\n");
    fprintf(c,"const uint32_t wc_task_pred_lo[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%uu",i?",":"",tasks[i].pred_lo);fprintf(c,"};\n");
    fprintf(c,"const uint32_t wc_task_pred_hi[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%uu",i?",":"",tasks[i].pred_hi);fprintf(c,"};\n");
    fprintf(c,"const uint32_t wc_task_pred_x[WC_TASK_COUNT]={");for(size_t i=0;i<ntasks;i++)fprintf(c,"%s%uu",i?",":"",tasks[i].pred_x);fprintf(c,"};\n");

    fprintf(c,"uint32_t wc_user_topology_count(void){return %zuu;}\n",ntopo);
    fprintf(c,"uint32_t wc_user_topology_vertices(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].n);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_edges(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %zuu;",i,topologies[i].nedge);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_beta0(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].beta0);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_beta1(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].beta1);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"int32_t wc_user_topology_euler(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %d;",i,topologies[i].euler_characteristic);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_proof_bits(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++){unsigned b=(topologies[i].proof_connected?1u:0u)|(topologies[i].proof_simply_connected?2u:0u)|(topologies[i].proof_contractible?4u:0u)|(topologies[i].proof_graph_homotopy?8u:0u);fprintf(c,"case %zu:return %uu;",i,b);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_bridges(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].bridges);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_articulations(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].articulations);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_free_group_rank(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].free_group_rank);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_incidence_rank(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].n-topologies[i].beta0);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_laplacian_nullity(uint32_t id){switch(id){");for(size_t i=0;i<ntopo;i++)fprintf(c,"case %zu:return %uu;",i,topologies[i].beta0);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_topology_laplacian_proof_bits(uint32_t id){return id<%zuu?7u:0u;}\n",ntopo);
    fprintf(c,"uint32_t wc_user_plan_count(void){return %zuu;}\n",nplan);
    fprintf(c,"uint32_t wc_user_plan_path_len(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %uu;",i,plans[i].path_len);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_plan_path_vertex(uint32_t id,uint32_t k){switch(id){");for(size_t i=0;i<nplan;i++){fprintf(c,"case %zu:switch(k){",i);for(uint32_t k=0;k<plans[i].path_len;k++)fprintf(c,"case %u:return %uu;",k,plans[i].path[k]);fprintf(c,"default:return 0xffffffffu;}");}fprintf(c,"default:return 0xffffffffu;}}\n");
    fprintf(c,"int32_t wc_user_plan_rank(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %d;",i,plans[i].path_rank);fprintf(c,"default:return 0xffffffffu;}}\n");
    fprintf(c,"double wc_user_plan_cost(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %.17g;",i,plans[i].path_cost);fprintf(c,"default:return 0.0;}}\n");
    fprintf(c,"uint32_t wc_user_plan_full_expansions(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %uu;",i,plans[i].full_expansions);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_plan_topo_expansions(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %uu;",i,plans[i].topo_expansions);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_plan_pruned_vertices(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %uu;",i,plans[i].pruned_vertices);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_plan_homotopy_word_len(uint32_t id){switch(id){");for(size_t i=0;i<nplan;i++)fprintf(c,"case %zu:return %uu;",i,plans[i].homotopy_word_len);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"int32_t wc_user_plan_homotopy_letter(uint32_t id,uint32_t k){switch(id){");for(size_t i=0;i<nplan;i++){fprintf(c,"case %zu:switch(k){",i);for(uint32_t k=0;k<plans[i].homotopy_word_len;k++)fprintf(c,"case %u:return %d;",k,plans[i].homotopy_word[k]);fprintf(c,"default:return 0;}");}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint64_t wc_user_plan_bench(uint32_t id,uint32_t pruned,uint32_t reps){switch(id){");for(size_t i=0;i<nplan;i++){int ti=plans[i].topology_id;fprintf(c,"case %zu:return wc_plan_rt(wc_topo_%d,%zuu,%uu,%uu,%uu,pruned?wc_plan_active_%zu:(const uint8_t*)0,reps);",i,ti,topologies[ti].nedge,topologies[ti].n,plans[i].start,plans[i].goal,i);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_complex_count(void){return %zuu;}\n",ncomplex);
    fprintf(c,"uint32_t wc_user_complex_beta(uint32_t id,uint32_t dim){switch(id){");for(size_t i=0;i<ncomplex;i++)fprintf(c,"case %zu:return dim==0?%uu:(dim==1?%uu:(dim==2?%uu:0u));",i,complexes[i].beta0,complexes[i].beta1,complexes[i].beta2);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"int32_t wc_user_complex_euler(uint32_t id){switch(id){");for(size_t i=0;i<ncomplex;i++)fprintf(c,"case %zu:return %d;",i,complexes[i].euler_characteristic);fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_complex_proof_bits(uint32_t id){switch(id){");for(size_t i=0;i<ncomplex;i++){unsigned b=(complexes[i].proof_connected?1u:0u)|(complexes[i].proof_contractible?2u:0u)|(complexes[i].proof_simply_connected?4u:0u)|(complexes[i].proof_euler_poincare?8u:0u);fprintf(c,"case %zu:return %uu;",i,b);}fprintf(c,"default:return 0;}}\n");
    fprintf(c,"uint32_t wc_user_complex_collapse_steps(uint32_t id){switch(id){");for(size_t i=0;i<ncomplex;i++)fprintf(c,"case %zu:return %uu;",i,complexes[i].collapse_steps);fprintf(c,"default:return 0;}}\n");

    fprintf(ir,"webchan-ir\nschema 1\nrelease 1.0.0\nbuild 090920262021\nmodule %s\ntarget portable-wasm\nsemantics temporal-safe-general-structural-data-layout-iteration-topology-ipe-eci-core\nbackend c-llvm-wasm\noptimization proof-directed\nproof_policy profitable-only\nmemory_mode %s\nmemory_recompute_budget %u\nmemory_min_savings_bytes %llu\nmemory_scratch_cap %u\n",module,mem_mode==MEM_MATRIX_FREE?"matrix-free":"dense",recompute_budget,(unsigned long long)min_savings,scratch_cap);
    fprintf(ir,"frame_budget_ms %.17g\nslice_budget_ms %.17g\nmax_continuous_ms %.17g\nmax_step_units %u\ndefault_step_units %u\n",frame_ms,slice_ms,max_cont_ms,max_step_units,default_step_units);
    for(size_t a=0;a<na;a++)fprintf(ir,"array %zu %s element=%s length=%u layout=%s group=%u lane=%u lanes=%u tile=%u score=%u logical_bytes=%llu physical_share_bytes=%llu proof=distinct-logical-array\n",a,arrays[a].name,type_name(arrays[a].type),arrays[a].len,array_layout_name(arrays[a].layout_kind),(unsigned)arrays[a].layout_group,(unsigned)arrays[a].layout_lane,(unsigned)arrays[a].layout_lanes,(unsigned)arrays[a].layout_tile,arrays[a].layout_score,(unsigned long long)arrays[a].logical_bytes,(unsigned long long)arrays[a].physical_share_bytes);
    emit_layout_ir(ir,arrays,na);
    for(size_t v=0;v<nv;v++){vfield_decl *vf=&vfields[v];fprintf(ir,"field %zu %s element=%s length=%u expr=\"%s\" proof=exact-polynomial degree=%d representation=%s reconstruct_ops=%u logical_bytes=%llu stored_bytes=%llu saved_bytes=%llu\n",v,vf->name,type_name(vf->type),vf->len,vf->expr,vf->degree,vfield_repr_name(vf->repr),vf->reconstruct_ops,(unsigned long long)vf->logical_bytes,(unsigned long long)vf->stored_bytes,(unsigned long long)vf->saved_bytes);if(vf->repr!=VREP_MATERIALIZED)fprintf(ir,"  unlock matrix-free-materialization because=exact-reconstructability+profitability\n");else if(mem_mode==MEM_MATRIX_FREE)fprintf(ir,"  fallback materialized because=recompute-budget-or-savings-gate\n");if(vf->degree==1)fprintf(ir,"  proof affine=verified; unlock auto-affine-reconstruction\n");}
    for(size_t v=0;v<npw;v++){pwfield_decl *pf=&pwfields[v];fprintf(ir,"piecewise_field %zu %s element=f64 length=%u segments=%zu proof=exact-domain-partition representation=%s logical_bytes=%llu stored_bytes=%llu saved_bytes=%llu\n",v,pf->name,pf->len,pf->nseg,pf->repr==PWREP_COMPACT?"piecewise-polynomial":"materialized",(unsigned long long)pf->logical_bytes,(unsigned long long)pf->stored_bytes,(unsigned long long)pf->saved_bytes);for(size_t k=0;k<pf->nseg;k++){pw_segment *g=&pf->seg[k];fprintf(ir,"  segment [%u,%u) expr=\"%s\" degree=%d reconstruct_ops=%u\n",g->begin,g->end,g->expr,g->degree,g->reconstruct_ops);}if(pf->repr==PWREP_COMPACT)fprintf(ir,"  unlock adaptive-partition+matrix-free because=exact-piecewise-reconstructability+profitability\n");else if(mem_mode==MEM_MATRIX_FREE)fprintf(ir,"  fallback materialized because=recompute-budget-or-savings-gate\n");}
    for(size_t s=0;s<ns;s++){fprintf(ir,"struct %zu %s fields=",s,structs[s].name);for(size_t j=0;j<structs[s].nfields;j++)fprintf(ir,"%s%s:%s",j?",":"",structs[s].fields[j].name,type_name(structs[s].fields[j].type));fprintf(ir,"\n");}
    for(size_t e=0;e<ne;e++){fprintf(ir,"enum %zu %s cases=",e,enums[e].name);for(size_t j=0;j<enums[e].ncases;j++)fprintf(ir,"%s%s",j?",":"",enums[e].cases[j]);fprintf(ir,"\n");}
    for(size_t mi=0;mi<nm;mi++){
        matrix_decl *m=&matrices[mi];
        fprintf(ir,"matrix %zu %s element=f64 n=%u bandwidth=%u\n",mi,m->name,m->n,m->bandwidth);
        for(uint32_t k=0;k<=m->bandwidth;k++)if(m->present[k])fprintf(ir,"  band offset=%u value=%.17g mode=%s\n",k,m->band[k],k==0?"diag":(m->mode[k]==1?"symmetric":(m->mode[k]==2?"upper":"lower")));
        fprintf(ir,"  proof symmetric=%s banded=%s static_sparsity=%s matrix_free_action=%s diagonal=%s lower_triangular=%s upper_triangular=%s nonzero_diag=%s strict_diagonal_dominance=%s spd=%s spectrum_bound=%s jacobi_convergent=%s gauss_seidel_convergent=%s lambda_min=%.17g lambda_max=%.17g\n",m->proof_symmetric?"verified":"unproven",m->proof_banded?"verified":"unproven",m->proof_static_sparsity?"verified":"unproven",m->proof_matrix_free_action?"verified":"unproven",m->proof_diagonal?"verified":"unproven",m->proof_lower_triangular?"verified":"unproven",m->proof_upper_triangular?"verified":"unproven",m->proof_nonzero_diag?"verified":"unproven",m->proof_strict_dd?"verified":"unproven",m->proof_spd?"verified":"unproven",m->proof_spectrum?"verified":"unproven",m->proof_jacobi_convergent?"verified":"unproven",m->proof_gs_convergent?"verified":"unproven",m->lambda_min,m->lambda_max);
        if(m->proof_static_sparsity)fprintf(ir,"  capability symbolic-assembly-reuse sparsity-index-reuse\n");
        if(m->proof_matrix_free_action)fprintf(ir,"  capability global-assembly-elision matrix-free-operator-action\n");
    }
    for(size_t si=0;si<nsolve;si++){
        solve_decl *sd=&solves[si];
        fprintf(ir,"solve %zu %s matrix=%s rhs=%s out=%s strategy=proof-auto tolerance=%.17g max_iter=%u unlock=0x%x chosen=%s\n",si,sd->name,sd->matrix_name,sd->rhs_name,sd->out_name,sd->tolerance,sd->max_iter,sd->unlock_bits,solver_name(sd->chosen));
        fprintf(ir,"  estimate dense-gaussian=%llu banded-gaussian=%llu krylov-cg=%llu chebyshev-semi=%llu jacobi=%llu gauss-seidel=%llu weighted-jacobi=%llu forward=%llu back=%llu diagonal=%llu cheb_steps=%u jacobi_steps=%u gs_steps=%u weighted_jacobi_steps=%u weighted_omega=%.17g\n",(unsigned long long)sd->est_dense,(unsigned long long)sd->est_banded,(unsigned long long)sd->est_cg,(unsigned long long)sd->est_cheb,(unsigned long long)sd->est_jacobi,(unsigned long long)sd->est_gs,(unsigned long long)sd->est_wjacobi,(unsigned long long)sd->est_forward,(unsigned long long)sd->est_back,(unsigned long long)sd->est_diagonal,sd->cheb_steps,sd->jacobi_steps,sd->gs_steps,sd->wjacobi_steps,sd->weighted_omega);
        if(sd->unlock_bits&1u)fprintf(ir,"  unlock banded-gaussian because=bandwidth+safe-pivot-structure-proof\n");
        if(sd->unlock_bits&2u)fprintf(ir,"  unlock krylov-cg because=spd-proof\n");
        if(sd->unlock_bits&4u)fprintf(ir,"  unlock chebyshev-semi because=positive-spectrum-bound-proof\n");
        if(sd->unlock_bits&8u)fprintf(ir,"  unlock jacobi because=convergence-proof(strict-diagonal-dominance)\n");
        if(sd->unlock_bits&16u)fprintf(ir,"  unlock gauss-seidel because=convergence-proof\n");
        if(sd->unlock_bits&32u)fprintf(ir,"  unlock weighted-jacobi because=normalized-spectrum-bound-proof\n");
        if(sd->unlock_bits&64u)fprintf(ir,"  unlock forward-substitution because=lower-triangular-proof\n");
        if(sd->unlock_bits&128u)fprintf(ir,"  unlock back-substitution because=upper-triangular-proof\n");
        if(sd->unlock_bits&256u)fprintf(ir,"  unlock diagonal-direct because=diagonal-proof\n");
        fprintf(ir,"  unlock bounds-check-elision because=sized-array-dimension-proof\n");
    }
    for(size_t ti=0;ti<ntopo;ti++){
        topology_decl *g=&topologies[ti];fprintf(ir,"topology %zu %s kind=undirected-graph vertices=%u edges=%zu\n",ti,g->name,g->n,g->nedge);
        for(size_t e=0;e<g->nedge;e++)fprintf(ir,"  edge %u %u cost=%.17g plan_rank=%d generator=%d\n",g->edge[e].u,g->edge[e].v,g->edge[e].cost,g->edge[e].plan_rank,g->generator[e]);
        fprintf(ir,"  proof connected=%s simply_connected=%s contractible=%s graph_homotopy=verified beta0=%u beta1=%u euler=%d bridges=%u articulations=%u fundamental_group=free-group(rank=%u) incidence_rank=%u laplacian_nullity=%u\n",g->proof_connected?"verified":"unproven",g->proof_simply_connected?"verified":"unproven",g->proof_contractible?"verified":"unproven",g->beta0,g->beta1,g->euler_characteristic,g->bridges,g->articulations,g->free_group_rank,g->n-g->beta0,g->beta0);
        fprintf(ir,"  proof graph_laplacian_symmetric=verified graph_laplacian_psd=verified graph_laplacian_kernel=component-indicators\n");
        fprintf(ir,"  capability spanning-forest-collapse cycle-space-proof bridge-cut-proof articulation-proof graph-homotopy-wedge-of-circles incidence-boundary-operator graph-laplacian-constructible\n");
    }
    for(size_t ci=0;ci<ncomplex;ci++){
        complex_decl *k=&complexes[ci];fprintf(ir,"complex %zu %s kind=finite-simplicial-complex vertices=%u edges=%zu faces2=%zu\n",ci,k->name,k->vertices,k->nedge,k->nface);
        fprintf(ir,"  homology field=GF(2) rank_d1=%u rank_d2=%u beta0=%u beta1=%u beta2=%u euler=%d euler_poincare=%s\n",k->rank_d1,k->rank_d2,k->beta0,k->beta1,k->beta2,k->euler_characteristic,k->proof_euler_poincare?"verified":"unproven");
        fprintf(ir,"  proof connected=%s contractible=%s simply_connected=%s elementary_collapse_steps=%u\n",k->proof_connected?"verified":"unproven",k->proof_contractible?"verified":"unproven",k->proof_simply_connected?"verified":"unproven",k->collapse_steps);
        if(k->proof_contractible)fprintf(ir,"  capability deformation-retract-to-point because=elementary-simplicial-collapse-certificate\n");
        else fprintf(ir,"  boundary fundamental_group=uncomputed; h1-zero-is-not-treated-as-simply-connected\n");
    }
    for(size_t pi=0;pi<nplan;pi++){
        plan_decl *p=&plans[pi];fprintf(ir,"plan %zu %s topology=%s start=%u goal=%u objective=lexicographic(max_plan_rank,cost) path_len=%u rank=%d cost=%.17g full_expansions=%u topo_expansions=%u pruned_vertices=%u\n",pi,p->name,p->topology_name,p->start,p->goal,p->path_len,p->path_rank,p->path_cost,p->full_expansions,p->topo_expansions,p->pruned_vertices);
        fprintf(ir,"  path=");for(uint32_t k=0;k<p->path_len;k++)fprintf(ir,"%s%u",k?"->":"",p->path[k]);fprintf(ir,"\n  homotopy_word=");for(uint32_t k=0;k<p->homotopy_word_len;k++)fprintf(ir,"%s%d",k?",":"",p->homotopy_word[k]);if(!p->homotopy_word_len)fprintf(ir,"identity");fprintf(ir,"\n");
        fprintf(ir,"  unlock topology-pruned-planning because=leaf-pruning-preserves-simple-terminal-paths; rank-policy=lower-is-preferred; aggregation=max-edge-rank\n");
    }

    fprintf(ir,"structural_iteration_algebra schema=1 scope=finite-index-operators policy=proof-first-no-algorithm-opcodes operator_count=%zu\n",nm+ntopo+nipe+nk);
    fprintf(ir,"  rule finite-domain -> bounds/dependence/locality proof -> legal transform -> profitability -> exact fallback\n");
    fprintf(ir,"  textbook transforms=algebraic-collapse,partition-fusion,legal-relinearization,sparsity-pruning,matrix-free-action,topology-pruning,scalar-replacement,bounds-elision,loop-interchange,tiling,vectorization-legality,invariant-hoisting,strength-reduction\n");
    fprintf(ir,"  ordinary-general-indexed-loop-surface=implemented; workload-specific-opcodes=forbidden\n");
    for(size_t mi=0;mi<nm;mi++){matrix_decl*m=&matrices[mi];uint32_t pb=1u|2u|1024u|512u;if(m->proof_banded)pb|=4u;if(m->proof_static_sparsity)pb|=8u;if(m->proof_matrix_free_action)pb|=16u;uint32_t tb=0;if(m->proof_static_sparsity)tb|=16u;if(m->proof_matrix_free_action)tb|=8u;if(m->proof_diagonal||m->proof_lower_triangular||m->proof_upper_triangular)tb|=64u;fprintf(ir,"  operator %zu source=matrix:%s kind=linear extent=%u stages=1 locality_radius=%u proof_bits=%u transform_bits=%u\n",mi,m->name,m->n,m->bandwidth,pb,tb);}
    for(size_t ti=0;ti<ntopo;ti++){topology_decl*g=&topologies[ti];uint32_t deg[MAX_TOPO_VERTICES]={0},mx=0;for(size_t e=0;e<g->nedge;e++){deg[g->edge[e].u]++;deg[g->edge[e].v]++;}for(uint32_t v=0;v<g->n;v++)if(deg[v]>mx)mx=deg[v];fprintf(ir,"  operator %zu source=topology:%s kind=relation extent=%u stages=1 max_local_degree=%u proof_bits=%u transform_bits=%u\n",nm+ti,g->name,g->n,mx,1u|2u|4u|8u|256u|1024u,32u);}
    for(size_t ri=0;ri<nipe;ri++){ipe_region*r=&ipes[ri];uint64_t ex=0;for(size_t q=0;q<r->nnode;q++)if(r->node[q].kind==IPE_COMPUTE)ex+=(uint64_t)r->node[q].end-r->node[q].begin;if(ex>0xffffffffull)ex=0xffffffffull;uint32_t pb=1u|2u|1024u;if(r->proof_dag)pb|=32u;if(r->proof_partition_fusable)pb|=64u|128u;if(r->proof_rank_linearization)pb|=2048u;uint32_t tb=0;if(r->proof_partition_fusable)tb|=1u;if(r->proof_rank_linearization)tb|=2u;if(r->proof_worker_local_scalarizable)tb|=4u;fprintf(ir,"  operator %zu source=ipe:%s kind=dependence-region extent=%u stages=%u proof_bits=%u transform_bits=%u\n",nm+ntopo+ri,r->name,(unsigned)ex,r->serial_count?r->serial_count:1u,pb,tb);}
    for(size_t ki=0;ki<nk;ki++){kernel_decl*k=&kernels[ki];fprintf(ir,"  operator %zu source=kernel:%s kind=index-kernel extent=%llu stages=%u locality=%u proof_bits=%u transform_bits=%u\n",nm+ntopo+nipe+ki,k->name,(unsigned long long)k->max_extent,k->max_depth?k->max_depth:1u,k->locality,k->proof_bits,k->transform_bits);}

    for(size_t ri=0;ri<nipe;ri++){
        ipe_region *r=&ipes[ri];fprintf(ir,"ipe_region %zu %s workers=%u source_model=fork-join-static-dag compute_nodes=%u orchestration_nodes=%u spawn_nodes=%u barriers=%u joins=%u worker_locals=%zu\n",ri,r->name,r->workers,r->compute_count,r->orchestration_count,r->spawn_count,r->barrier_count,r->join_count,r->nlocal);
        fprintf(ir,"  proof dag=%s pure_compute=%s orchestration_erasable=%s worker_local_scalarizable=%s rank_linearization=%s partition_fusable=%s\n",r->proof_dag?"verified":"unproven",r->proof_pure_compute?"verified":"unproven",r->proof_orchestration_erasable?"verified":"unproven",r->proof_worker_local_scalarizable?"verified":"unproven",r->proof_rank_linearization?"verified":"unproven",r->proof_partition_fusable?"verified":"unproven");
        fprintf(ir,"  erase spawn=%u barrier=%u join=%u orchestration_total=%u scalarized_worker_slots=%u partition_boundaries=%u\n",r->spawn_count,r->barrier_count,r->join_count,r->eliminated_orchestration,r->scalarized_worker_slots,r->partition_boundaries_removed);
        fprintf(ir,"  serial_schedule=");for(uint32_t k=0;k<r->serial_count;k++){ipe_node *n=&r->node[r->serial_schedule[k]];fprintf(ir,"%s%s(rank=%d)",k?"->":"",n->name,n->plan_rank);}fprintf(ir,"\n");
        if(r->proof_partition_fusable)fprintf(ir,"  unlock partition-fusion because=disjoint-contiguous-pure-equal-function-partitions range=[%u,%u) fused_partitions=%u\n",r->fused_begin,r->fused_end,r->fused_partitions);
        if(r->proof_orchestration_erasable)fprintf(ir,"  unlock parallel-orchestration-erasure because=single-host-thread+pure-compute+dependency-dag-proof\n");
        if(r->proof_worker_local_scalarizable)fprintf(ir,"  unlock worker-local-scalarization because=private-nonescaping-local-proof\n");
        fprintf(ir,"  capability preserve-dependence erase-orchestration rank-guided-linear-extension semantic-recompilation\n");
    }
    for(size_t ki=0;ki<nk;ki++){kernel_decl*k=&kernels[ki];fprintf(ir,"kernel %zu %s effect=bounded declared=%llu computed=%llu max_extent=%llu max_depth=%u proof_bits=%u transform_bits=%u read_mask=%08x write_mask=%08x\n",ki,k->name,(unsigned long long)k->declared_bound,(unsigned long long)k->computed_bound,(unsigned long long)k->max_extent,k->max_depth,k->proof_bits,k->transform_bits,k->read_mask,k->write_mask);
        fprintf(ir,"  proof finite-domain=verified bounds=verified symbols=verified dependence=verified nested=%s gather=%s scatter=%s reduction=%s scan=%s bitwise-index=%s loop-carried=%s math-intrinsic=%s\n",k->feature_nested?"yes":"no",k->feature_gather?"yes":"no",k->feature_scatter?"yes":"no",k->feature_reduction?"yes":"no",k->feature_scan?"yes":"no",k->feature_bitwise?"yes":"no",k->feature_loop_carried?"yes":"no",k->feature_math?"yes":"no");
        fprintf(ir,"  capability bounded-nested-for mutable-indexed-array gather-scatter loop-carried-scalar reduction-scan-foundation bitwise-index-map no-workload-opcodes\n");
    }
    for(size_t i=0;i<nf;i++){
        fprintf(ir,"fn %zu %s abi=(f64,f64,u32,u32)->f64 effect=bounded declared=%u computed=%llu proof_pure=%s proof_affine=%s proof_monotone=%s original_ops=%llu collapsed_ops=%llu",i,fns[i].name,fns[i].declared_bound,(unsigned long long)fns[i].computed_bound,fns[i].proof_pure?"verified":"unproven",fns[i].proof_affine?"verified":"unproven",fns[i].proof_monotone?"verified":"unproven",(unsigned long long)fns[i].structural_original_ops,(unsigned long long)fns[i].structural_collapsed_ops);
        if(fns[i].proof_affine)fprintf(ir," affine_map=(%.17g,%.17g)",fns[i].affine_a,fns[i].affine_b);fprintf(ir,"\n");
        if(fns[i].proof_affine && fns[i].structural_collapsed_ops<fns[i].structural_original_ops)fprintf(ir,"  unlock affine-function-collapse because=algebraic-composition-proof\n");
        if(fns[i].proof_pure)fprintf(ir,"  capability pure-reorderable speculative-safe common-subexpression-eligible\n");
        for(size_t k=0;k<fns[i].ninsn;k++){fn_insn *in=&fns[i].insn[k];if(in->kind==INS_AFFINE)fprintf(ir,"  repeat %u affine %.17g %.17g\n",in->repeat,in->a,in->b);else if(in->kind==INS_POLY)fprintf(ir,"  repeat %u poly %.17g %.17g %.17g\n",in->repeat,in->a,in->b,in->c);else fprintf(ir,"  call %s repeat %u\n",in->callee,in->repeat);}
    }
    for(size_t i=0;i<ntasks;i++)fprintf(ir,"node %zu %s class=%s deadline_ms=%.17g shed_rank=%d cost=%u fn=%s fn_bound=%llu pred=%08x:%08x:%08x\n",i,tasks[i].name,class_name(tasks[i].cls),tasks[i].deadline_ms,tasks[i].shed_rank,tasks[i].cost,tasks[i].fn_name,(unsigned long long)fns[tasks[i].fn_id].computed_bound,tasks[i].pred_x,tasks[i].pred_hi,tasks[i].pred_lo);
    fprintf(gl,"#version 400 core\n// Generated from Webchan IR. Generic compact field helpers; no trusted source assertions.\n");
    for(size_t v=0;v<nv;v++){vfield_decl *vf=&vfields[v];if(vf->repr==VREP_MATERIALIZED){fprintf(gl,"// field %s requires materialized host storage under the selected budget.\n",vf->name);continue;}fprintf(gl,"double wc_field_%s(uint i){double x=double(i);",vf->name);if(vf->degree==0)fprintf(gl,"return %.17g;",vf->coeff[0]);else if(vf->degree==1)fprintf(gl,"return %.17g*x+%.17g;",vf->coeff[1],vf->coeff[0]);else{fprintf(gl,"double y=%.17g;",vf->coeff[vf->degree]);for(int d=vf->degree-1;d>=0;d--)fprintf(gl,"y=y*x+%.17g;",vf->coeff[d]);fprintf(gl,"return y;");}fprintf(gl,"}\n");}
    for(size_t v=0;v<npw;v++){pwfield_decl *pf=&pwfields[v];if(pf->repr==PWREP_MATERIALIZED){fprintf(gl,"// piecewise field %s requires materialized host storage under selected budget.\n",pf->name);continue;}fprintf(gl,"double wc_piecewise_%s(uint i){double x=double(i);",pf->name);for(size_t k=0;k<pf->nseg;k++){pw_segment *g=&pf->seg[k];fprintf(gl,"%s(i<%uu){",k?"else if":"if",g->end);if(g->degree==0)fprintf(gl,"return %.17g;",g->coeff[0]);else if(g->degree==1)fprintf(gl,"return %.17g*x+%.17g;",g->coeff[1],g->coeff[0]);else{fprintf(gl,"double y=%.17g;",g->coeff[g->degree]);for(int d=g->degree-1;d>=0;d--)fprintf(gl,"y=y*x+%.17g;",g->coeff[d]);fprintf(gl,"return y;");}fprintf(gl,"}");}fprintf(gl,"return 0.0;}\n");}

    fprintf(ir,"eci policy=authority-first c-abi=preferred providers=replaceable vendor=explicit-fallback capability_count=%zu op_count=%zu\n",ncaps,neciops);
    for(size_t ci=0;ci<ncaps;ci++){
        uint32_t pc=0;for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)if(!strcmp(ECI_PROVIDER_CATALOG[p].capability,caps[ci].name))pc++;
        fprintf(ir,"capability %zu %s requirement=%s effect=%s provider_candidates=%u\n",ci,caps[ci].name,caps[ci].required?"required":"optional",effect_name(caps[ci].effect),pc);
        uint32_t lk=0;for(size_t p=0;p<ECI_PROVIDER_CATALOG_COUNT;p++)if(!strcmp(ECI_PROVIDER_CATALOG[p].capability,caps[ci].name)){const eci_provider_def *d=&ECI_PROVIDER_CATALOG[p];fprintf(ir,"  provider local=%u global=%zu name=%s kind=%s hosts=%u priority=%u authority=%s\n",lk++,p,d->name,provider_kind_name(d->kind),d->hosts,d->priority,d->authority);}
    }
    for(size_t oi=0;oi<neciops;oi++)fprintf(ir,"external_op %zu %s capability=%s opcode=%u boundary=%s temporal-proof=verified\n",oi,eciops[oi].name,eciops[oi].capability_name,eciops[oi].opcode,boundary_name(eciops[oi].boundary));

    fprintf(ir,"optimization_channel external-capability-interface=enabled c-abi-first=enabled replaceable-providers=enabled temporal-external-effects=enabled inverse-parallel-expansion=enabled orchestration-erasure=enabled rank-guided-relinearization=enabled partition-fusion=enabled wild-project=textbook-only general-structural-proof=enabled structural-iteration-algebra=enabled finite-index-space-proof=enabled dependence-topology-bridge=enabled loop-transform-proof-gate=enabled generic-index-kernels=enabled bounded-nested-for=enabled proved-gather-scatter=enabled reduction-scan-foundation=enabled bitwise-index-maps=enabled linear-algebra-capability-graph=enabled structural-topology-proof=enabled topological-planning=enabled homology-gf2=enabled graph-fundamental-group=enabled affine-function-collapse=enabled incremental-change-propagation=enabled adaptive-partition=enabled piecewise-exact=enabled wavelet=specified-not-yet-runtime low-rank=specified-not-yet-runtime higher-homotopy=specified-not-yet-runtime\n");
    fprintf(ir,"backend_hint opengl40 procedural-field-functions=%s\n",mem_mode==MEM_MATRIX_FREE?"emitted":"dense-policy-only");

    fprintf(ej,"{\n  \"schema\": \"webchan-eci-1.0\",\n  \"policy\": {\"authority_first\": true, \"c_abi_preferred\": true, \"providers_replaceable\": true, \"vendor_fallback_only\": true},\n  \"capabilities\": [\n");
    for(size_t ci=0;ci<ncaps;ci++){fprintf(ej,"    {\"id\":%zu,\"name\":\"%s\",\"required\":%s,\"effect\":\"%s\",\"providers\":[",ci,caps[ci].name,caps[ci].required?"true":"false",effect_name(caps[ci].effect));int first=1;for(size_t pi=0;pi<ECI_PROVIDER_CATALOG_COUNT;pi++)if(!strcmp(ECI_PROVIDER_CATALOG[pi].capability,caps[ci].name)){const eci_provider_def*d=&ECI_PROVIDER_CATALOG[pi];fprintf(ej,"%s{\"global_id\":%zu,\"name\":\"%s\",\"kind\":\"%s\",\"hosts\":%u,\"priority\":%u,\"authority\":\"%s\"}",first?"":",",pi,d->name,provider_kind_name(d->kind),d->hosts,d->priority,d->authority);first=0;}fprintf(ej,"]}%s\n",ci+1<ncaps?",":"");}
    fprintf(ej,"  ],\n  \"operations\": [\n");for(size_t oi=0;oi<neciops;oi++)fprintf(ej,"    {\"id\":%zu,\"name\":\"%s\",\"capability\":\"%s\",\"opcode\":%u,\"boundary\":\"%s\"}%s\n",oi,eciops[oi].name,eciops[oi].capability_name,eciops[oi].opcode,boundary_name(eciops[oi].boundary),oi+1<neciops?",":"");fprintf(ej,"  ]\n}\n");
    fprintf(nc,"/* Generated provider catalogue adapter. It contains no third-party implementation. */\n#include <stdint.h>\n#include <stddef.h>\ntypedef struct{const char*cap;const char*name;uint32_t kind,hosts,priority;} wc_eci_native_provider;\n");
    fprintf(nc,"const wc_eci_native_provider wc_eci_native_catalog[%zu]={",ECI_PROVIDER_CATALOG_COUNT);for(size_t pi=0;pi<ECI_PROVIDER_CATALOG_COUNT;pi++){const eci_provider_def*d=&ECI_PROVIDER_CATALOG[pi];fprintf(nc,"{\"%s\",\"%s\",%uu,%uu,%uu}%s",d->capability,d->name,(unsigned)d->kind,d->hosts,d->priority,pi+1<ECI_PROVIDER_CATALOG_COUNT?",":"");}fprintf(nc,"};\nconst uint32_t wc_eci_native_catalog_count=%zuu;\n",ECI_PROVIDER_CATALOG_COUNT);
    fclose(h);fclose(c);fclose(ir);fclose(gl);fclose(ej);fclose(nc);return 1;
}

int main(int argc,char **argv){
    if(argc!=3){fprintf(stderr,"usage: webchanc <input.webchan> <output-dir>\n");return 2;}
    FILE *in=fopen(argv[1],"rb"); if(!in){perror("input");return 3;}
    char module[MAX_NAME]="app"; double frame_ms=16.667,slice_ms=2.0,max_cont_ms=4.0,tol=1e-8; uint32_t max_step_units=4096,default_step_units=1024,active_cap=96; int order=32; memory_mode mem_mode=MEM_DENSE; uint32_t recompute_budget=8,scratch_cap=4096; uint64_t min_savings=4096; int memory_auto_affine=0;
    int saw_header=0,time_safe=0,progressive=0,no_barrier=0,causal=0,input_fair=0,authoritative_c=0,portable_abi=0,generated_c_internal=0,proof_directed=0,profitable_only=0,wild_textbook_only=0,ipe_enabled=0,eci_authority_first=0,eci_cabi_first=0,eci_replaceable=0,eci_vendor_fallback=0;
    task_decl tasks[MAX_TASKS]={0}; edge_decl edges[MAX_EDGES]={0}; fn_decl fns[MAX_FUNCS]={0}; array_decl arrays[MAX_ARRAYS]={0}; struct_decl structs[MAX_STRUCTS]={0}; enum_decl enums[MAX_ENUMS]={0}; matrix_decl matrices[MAX_MATRICES]={0}; solve_decl solves[MAX_SOLVES]={0}; vfield_decl vfields[MAX_VFIELDS]={0}; pwfield_decl pwfields[MAX_PWFIELDS]={0}; topology_decl topologies[MAX_TOPOLOGIES]={0}; plan_decl plans[MAX_PLANS]={0}; complex_decl complexes[MAX_COMPLEXES]={0}; ipe_region ipes[MAX_IPE_REGIONS]={0}; static kernel_decl kernels[MAX_KERNELS]; eci_capability caps[MAX_ECI_CAPABILITIES]={0}; eci_op eciops[MAX_ECI_OPS]={0};
    size_t ntasks=0,nedges=0,nf=0,na=0,ns=0,ne=0,nm=0,nsolve=0,nv=0,npw=0,ntopo=0,nplan=0,ncomplex=0,nipe=0,nk=0,ncaps=0,neciops=0; int current_fn=-1,current_matrix=-1,current_pw=-1,current_topology=-1,current_complex=-1,current_ipe=-1,current_kernel=-1; uint32_t kernel_parse_depth=0,kernel_block_depth=0; uint8_t kernel_block_stack[MAX_KERNEL_DEPTH*2]={0}; char line[1024]; unsigned lineno=0;
    while(fgets(line,sizeof line,in)){
        lineno++; trim(line); if(!line[0]||line[0]=='#')continue;
        if(current_kernel>=0){
            kernel_decl *k=&kernels[current_kernel];
            if(!strcmp(line,"endkernel")){if(kernel_block_depth||kernel_parse_depth){fprintf(stderr,"line %u: kernel has unterminated control block\n",lineno);return 124;}current_kernel=-1;continue;}
            if(k->nop>=MAX_KERNEL_OPS){fprintf(stderr,"line %u: too many kernel operations\n",lineno);return 125;}
            kernel_op *op=&k->op[k->nop];
            if(!strncmp(line,"for ",4)){char v[MAX_NAME]={0},a[MAX_KEXPR]={0},b[MAX_KEXPR]={0},st[MAX_KEXPR]={0};if(kernel_parse_depth>=MAX_KERNEL_DEPTH||kernel_block_depth>=MAX_KERNEL_DEPTH*2||!k_parse_for_line(line,v,a,b,st)){fprintf(stderr,"line %u: invalid bounded for\n",lineno);return 126;}op->kind=KOP_FOR;op->depth=(uint8_t)kernel_parse_depth;strncpy(op->name,v,MAX_NAME-1);strncpy(op->start,a,MAX_KEXPR-1);strncpy(op->end,b,MAX_KEXPR-1);strncpy(op->step,st,MAX_KEXPR-1);k->nop++;kernel_block_stack[kernel_block_depth++]=1;kernel_parse_depth++;continue;}
            if(!strcmp(line,"endfor")){if(!kernel_parse_depth||!kernel_block_depth||kernel_block_stack[kernel_block_depth-1]!=1){fprintf(stderr,"line %u: unmatched/crossed endfor\n",lineno);return 127;}op->kind=KOP_ENDFOR;op->depth=(uint8_t)kernel_parse_depth;k->nop++;kernel_block_depth--;kernel_parse_depth--;continue;}
            if(!strncmp(line,"if ",3)){if(kernel_block_depth>=MAX_KERNEL_DEPTH*2||strlen(line+3)>=MAX_KEXPR||!line[3]){fprintf(stderr,"line %u: invalid bounded predicate\n",lineno);return 132;}op->kind=KOP_IF;op->depth=(uint8_t)kernel_parse_depth;strncpy(op->expr,line+3,MAX_KEXPR-1);trim(op->expr);k->nop++;kernel_block_stack[kernel_block_depth++]=2;continue;}
            if(!strcmp(line,"endif")){if(!kernel_block_depth||kernel_block_stack[kernel_block_depth-1]!=2){fprintf(stderr,"line %u: unmatched/crossed endif\n",lineno);return 133;}op->kind=KOP_ENDIF;op->depth=(uint8_t)kernel_parse_depth;k->nop++;kernel_block_depth--;continue;}
            if(!strncmp(line,"local ",6)){for(uint32_t bi=0;bi<kernel_block_depth;bi++)if(kernel_block_stack[bi]==2){fprintf(stderr,"line %u: branch-local declarations are not yet permitted; declare before if\n",lineno);return 134;}char ty[32]={0},name[MAX_NAME]={0};int off=0;wc_type t;if(sscanf(line,"local %31s %63s = %n",ty,name,&off)!=2||off<=0||!type_token(ty,&t)||!line[off]){fprintf(stderr,"line %u: invalid kernel local\n",lineno);return 128;}op->kind=KOP_LOCAL;op->depth=(uint8_t)kernel_parse_depth;op->type=t;strncpy(op->name,name,MAX_NAME-1);strncpy(op->expr,line+off,MAX_KEXPR-1);k->nop++;continue;}
            if(!strncmp(line,"set ",4)){const char *eq=strstr(line+4," = ");if(!eq){fprintf(stderr,"line %u: invalid kernel assignment\n",lineno);return 129;}size_t ln=(size_t)(eq-(line+4));if(!ln||ln>=MAX_KEXPR||strlen(eq+3)>=MAX_KEXPR){fprintf(stderr,"line %u: oversized kernel assignment\n",lineno);return 129;}op->kind=KOP_SET;op->depth=(uint8_t)kernel_parse_depth;memcpy(op->lhs,line+4,ln);op->lhs[ln]=0;trim(op->lhs);strncpy(op->expr,eq+3,MAX_KEXPR-1);trim(op->expr);k->nop++;continue;}
            fprintf(stderr,"line %u: invalid generic kernel instruction: %s\n",lineno,line);return 130;
        }
        if(current_ipe>=0){
            if(!strcmp(line,"endparallel_region")){current_ipe=-1;continue;}
            ipe_region *r=&ipes[current_ipe];char name[MAX_NAME]={0},fnn[MAX_NAME]={0},ty[32]={0},privacy[32]={0};unsigned b=0,e=0;long rank=0;
            if(sscanf(line,"compute %63s fn %63s range %u %u plan_rank %ld",name,fnn,&b,&e,&rank)==5){if(r->nnode>=MAX_IPE_NODES||b>=e||rank<-1000000||rank>1000000||find_ipe_node(r,name)>=0){fprintf(stderr,"line %u: invalid parallel compute node\n",lineno);return 101;}ipe_node *n=&r->node[r->nnode++];strncpy(n->name,name,MAX_NAME-1);n->kind=IPE_COMPUTE;strncpy(n->fn_name,fnn,MAX_NAME-1);n->fn_id=-1;n->begin=b;n->end=e;n->plan_rank=(int32_t)rank;continue;}
            if(sscanf(line,"barrier %63s",name)==1&&!strncmp(line,"barrier ",8)){if(r->nnode>=MAX_IPE_NODES||find_ipe_node(r,name)>=0){fprintf(stderr,"line %u: invalid parallel barrier\n",lineno);return 102;}ipe_node *n=&r->node[r->nnode++];strncpy(n->name,name,MAX_NAME-1);n->kind=IPE_BARRIER;continue;}
            if(sscanf(line,"join %63s",name)==1&&!strncmp(line,"join ",5)){if(r->nnode>=MAX_IPE_NODES||find_ipe_node(r,name)>=0){fprintf(stderr,"line %u: invalid parallel join\n",lineno);return 103;}ipe_node *n=&r->node[r->nnode++];strncpy(n->name,name,MAX_NAME-1);n->kind=IPE_JOIN;continue;}
            char child[MAX_NAME]={0},parent[MAX_NAME]={0};if(sscanf(line,"pdepends %63s on %63s",child,parent)==2){int c=find_ipe_node(r,child),p=find_ipe_node(r,parent);if(c<0||p<0||c==p||r->ndep>=MAX_IPE_DEPS){fprintf(stderr,"line %u: invalid parallel dependency\n",lineno);return 104;}r->dep[r->ndep].child=(uint16_t)c;r->dep[r->ndep].parent=(uint16_t)p;r->ndep++;continue;}
            if(sscanf(line,"worker_local %63s %31s %31s",name,ty,privacy)==3){wc_type t;if(r->nlocal>=MAX_IPE_LOCALS||!type_token(ty,&t)||strcmp(privacy,"private")){fprintf(stderr,"line %u: invalid worker_local\n",lineno);return 105;}ipe_local *l=&r->local[r->nlocal++];strncpy(l->name,name,MAX_NAME-1);l->type=t;l->proof_private=1;continue;}
            fprintf(stderr,"line %u: invalid parallel region instruction: %s\n",lineno,line);return 106;
        }
        if(current_topology>=0){
            if(!strcmp(line,"endtopology")){current_topology=-1;continue;}
            topology_decl *g=&topologies[current_topology];unsigned u=0,v=0;long rank=0;double cost=0.0;if(sscanf(line,"edge %u %u cost %lf plan_rank %ld",&u,&v,&cost,&rank)==4&&u<g->n&&v<g->n&&u!=v&&cost>0.0&&rank>=-1000000&&rank<=1000000&&topo_edge_index(g,u,v)<0){if(g->nedge>=MAX_TOPO_EDGES){fprintf(stderr,"line %u: too many topology edges\n",lineno);return 81;}g->edge[g->nedge].u=u;g->edge[g->nedge].v=v;g->edge[g->nedge].cost=cost;g->edge[g->nedge].plan_rank=(int32_t)rank;g->nedge++;continue;}fprintf(stderr,"line %u: invalid topology edge\n",lineno);return 82;
        }
        if(current_complex>=0){
            if(!strcmp(line,"endcomplex")){current_complex=-1;continue;}
            complex_decl *k=&complexes[current_complex];unsigned a=0,b=0,c=0;if(sscanf(line,"simplex1 %u %u",&a,&b)==2){if(a>=k->vertices||b>=k->vertices||a==b||k->nedge>=MAX_COMPLEX_EDGES||complex_find_edge(k,a,b)>=0){fprintf(stderr,"line %u: invalid simplex1\n",lineno);return 84;}if(a>b){unsigned t=a;a=b;b=t;}k->edge[k->nedge].u=a;k->edge[k->nedge].v=b;k->nedge++;continue;}if(sscanf(line,"simplex2 %u %u %u",&a,&b,&c)==3){if(a>=k->vertices||b>=k->vertices||c>=k->vertices||a==b||a==c||b==c||k->nface>=MAX_COMPLEX_FACES){fprintf(stderr,"line %u: invalid simplex2\n",lineno);return 85;}if(complex_find_edge(k,a,b)<0||complex_find_edge(k,a,c)<0||complex_find_edge(k,b,c)<0){fprintf(stderr,"line %u: simplex2 boundary edges must be declared first\n",lineno);return 86;}k->face[k->nface].a=a;k->face[k->nface].b=b;k->face[k->nface].c=c;k->nface++;continue;}fprintf(stderr,"line %u: invalid complex simplex\n",lineno);return 87;
        }
        if(current_pw>=0){
            if(!strcmp(line,"endpiecewise")){pwfield_decl *pf=&pwfields[current_pw];if(!pf->nseg||pf->seg[0].begin!=0||pf->seg[pf->nseg-1].end!=pf->len){fprintf(stderr,"line %u: piecewise field must exactly cover [0,length)\n",lineno);return 71;}for(size_t k=1;k<pf->nseg;k++)if(pf->seg[k-1].end!=pf->seg[k].begin){fprintf(stderr,"line %u: piecewise segments must be contiguous and non-overlapping\n",lineno);return 72;}pf->exact_partition=1;current_pw=-1;continue;}
            pwfield_decl *pf=&pwfields[current_pw];if(pf->nseg>=MAX_SEGMENTS){fprintf(stderr,"line %u: too many piecewise segments\n",lineno);return 73;}unsigned begin=0,end=0;int off=0;int z=sscanf(line,"segment %u %u expr %n",&begin,&end,&off);if(z!=2||off<=0||begin>=end||end>pf->len){fprintf(stderr,"line %u: invalid piecewise segment\n",lineno);return 74;}const char *expr=line+off;while(isspace((unsigned char)*expr))expr++;pw_segment *g=&pf->seg[pf->nseg++];g->begin=begin;g->end=end;strncpy(g->expr,expr,MAX_FIELD_EXPR-1);if(!parse_polynomial(expr,g->coeff,&g->degree)){fprintf(stderr,"line %u: piecewise segment expression must be bounded polynomial in i\n",lineno);return 75;}continue;
        }
        if(current_matrix>=0){
            if(!strcmp(line,"endmatrix")){current_matrix=-1;continue;}
            matrix_decl *m=&matrices[current_matrix]; unsigned off=0; double val=0.0; char mode[32]={0};
            int z=sscanf(line,"band %u %lf %31s",&off,&val,mode);
            if(z>=2 && off<MAX_BANDS){
                if(off==0){m->present[0]=1;m->band[0]=val;m->mode[0]=0;continue;}
                if(z!=3){fprintf(stderr,"line %u: off-diagonal band requires symmetric/upper/lower mode\n",lineno);return 52;}
                uint8_t md=!strcmp(mode,"symmetric")?1:(!strcmp(mode,"upper")?2:(!strcmp(mode,"lower")?3:0));
                if(!md){fprintf(stderr,"line %u: invalid band mode\n",lineno);return 53;}
                m->present[off]=1;m->band[off]=val;m->mode[off]=md;continue;
            }
            fprintf(stderr,"line %u: invalid matrix instruction: %s\n",lineno,line);return 54;
        }
        if(strstr(line,"while ")||!strncmp(line,"while",5)){fprintf(stderr,"line %u: unbounded while is forbidden in strict Webchan\n",lineno);return 30;}
        if(current_fn>=0){
            if(!strcmp(line,"endfn")){current_fn=-1;continue;}
            fn_decl *f=&fns[current_fn]; if(f->ninsn>=MAX_INSNS){fprintf(stderr,"line %u: too many function instructions\n",lineno);return 31;}
            fn_insn *ii=&f->insn[f->ninsn]; unsigned rep=0; double a=0,b=0,c=0; char callee[MAX_NAME]={0};
            if(sscanf(line,"repeat %u affine %lf %lf",&rep,&a,&b)==3&&rep){ii->kind=INS_AFFINE;ii->repeat=rep;ii->a=a;ii->b=b;f->ninsn++;continue;}
            if(sscanf(line,"repeat %u poly %lf %lf %lf",&rep,&a,&b,&c)==4&&rep){ii->kind=INS_POLY;ii->repeat=rep;ii->a=a;ii->b=b;ii->c=c;f->ninsn++;continue;}
            if(sscanf(line,"call %63s repeat %u",callee,&rep)==2&&rep){ii->kind=INS_CALL;ii->repeat=rep;strncpy(ii->callee,callee,MAX_NAME-1);ii->callee_id=-1;f->ninsn++;continue;}
            fprintf(stderr,"line %u: invalid function instruction: %s\n",lineno,line);return 32;
        }

        if(!strncmp(line,"capability ",11)){
            if(ncaps>=MAX_ECI_CAPABILITIES){fprintf(stderr,"too many external capabilities\n");return 109;}char name[MAX_CAP_NAME]={0},req[32]={0},eff[32]={0};eci_effect ee;
            if(sscanf(line,"capability %95s %31s effect %31s",name,req,eff)!=3){fprintf(stderr,"line %u: invalid capability declaration\n",lineno);return 110;}
            int required=!strcmp(req,"required");if((!required&&strcmp(req,"optional"))||!effect_token(eff,&ee)||find_cap(caps,ncaps,name)>=0){fprintf(stderr,"line %u: invalid capability declaration\n",lineno);return 110;}
            int known=0;for(size_t pi=0;pi<ECI_PROVIDER_CATALOG_COUNT;pi++)if(!strcmp(ECI_PROVIDER_CATALOG[pi].capability,name)){known=1;break;}if(!known){fprintf(stderr,"line %u: capability has no authoritative provider catalogue entry: %s\n",lineno,name);return 111;}
            strncpy(caps[ncaps].name,name,MAX_CAP_NAME-1);caps[ncaps].required=required;caps[ncaps].effect=ee;ncaps++;continue;
        }
        if(!strncmp(line,"external_op ",12)){
            if(neciops>=MAX_ECI_OPS){fprintf(stderr,"too many external operations\n");return 112;}char name[MAX_NAME]={0},capn[MAX_CAP_NAME]={0},bound[32]={0};unsigned opcode=0;eci_boundary bb;
            if(sscanf(line,"external_op %63s capability %95s opcode %u boundary %31s",name,capn,&opcode,bound)!=4||!boundary_token(bound,&bb)){fprintf(stderr,"line %u: invalid external_op declaration\n",lineno);return 113;}
            int cid=find_cap(caps,ncaps,capn);if(cid<0){fprintf(stderr,"line %u: external_op references undeclared capability %s\n",lineno,capn);return 114;}
            for(size_t oi=0;oi<neciops;oi++)if(!strcmp(eciops[oi].name,name)){fprintf(stderr,"line %u: duplicate external_op\n",lineno);return 115;}
            eci_effect ee=caps[cid].effect;if((ee==ECI_EFFECT_POTENTIALLY_BLOCKING&&bb!=ECI_BOUNDARY_EXPLICIT_BLOCKING)||(ee==ECI_EFFECT_ASYNC&&bb==ECI_BOUNDARY_DIRECT)){fprintf(stderr,"line %u: external operation boundary violates temporal effect\n",lineno);return 116;}
            eci_op *op=&eciops[neciops++];strncpy(op->name,name,MAX_NAME-1);strncpy(op->capability_name,capn,MAX_CAP_NAME-1);op->capability_id=cid;op->opcode=opcode;op->boundary=bb;continue;
        }

        if(!strncmp(line,"kernel ",7)){
            if(nk>=MAX_KERNELS){fprintf(stderr,"too many generic kernels\n");return 121;}char name[MAX_NAME]={0};unsigned long long bound=0;if(sscanf(line,"kernel %63s effect bounded %llu",name,&bound)!=2||!bound||find_kernel(kernels,nk,name)>=0){fprintf(stderr,"line %u: invalid kernel declaration\n",lineno);return 122;}kernel_decl *k=&kernels[nk];strncpy(k->name,name,MAX_NAME-1);k->declared_bound=(uint64_t)bound;current_kernel=(int)nk;kernel_parse_depth=0;kernel_block_depth=0;nk++;continue;
        }
        if(!strncmp(line,"fn ",3)){
            if(nf>=MAX_FUNCS){fprintf(stderr,"too many functions\n");return 33;} char name[MAX_NAME]={0}; unsigned bound=0;
            if(sscanf(line,"fn %63s effect bounded %u",name,&bound)!=2||!bound){fprintf(stderr,"line %u: invalid function declaration\n",lineno);return 34;}
            if(find_fn(fns,nf,name)>=0){fprintf(stderr,"duplicate function %s\n",name);return 35;} strncpy(fns[nf].name,name,MAX_NAME-1);fns[nf].declared_bound=bound;current_fn=(int)nf;nf++;continue;
        }
        if(!strncmp(line,"piecewise_field ",16)){
            if(npw>=MAX_PWFIELDS){fprintf(stderr,"too many piecewise fields\n");return 69;}char name[MAX_NAME]={0},ty[32]={0};unsigned len=0;wc_type t;if(sscanf(line,"piecewise_field %63s %31s %u",name,ty,&len)!=3||!len||!type_token(ty,&t)||t!=TY_F64||find_pwfield(pwfields,npw,name)>=0){fprintf(stderr,"line %u: invalid piecewise field declaration\n",lineno);return 70;}pwfield_decl *pf=&pwfields[npw];strncpy(pf->name,name,MAX_NAME-1);pf->type=t;pf->len=len;current_pw=(int)npw;npw++;continue;
        }
        if(!strncmp(line,"field ",6)){
            if(nv>=MAX_VFIELDS){fprintf(stderr,"too many virtual fields\n");return 62;}char name[MAX_NAME]={0},ty[32]={0};unsigned len=0;int off=0;wc_type t;
            int z=sscanf(line,"field %63s %31s %u expr %n",name,ty,&len,&off);
            if(z!=3||off<=0||!len||!type_token(ty,&t)||t!=TY_F64||find_vfield(vfields,nv,name)>=0){fprintf(stderr,"line %u: invalid field declaration\n",lineno);return 63;}
            const char *expr=line+off;while(isspace((unsigned char)*expr))expr++;if(!*expr||strlen(expr)>=MAX_FIELD_EXPR){fprintf(stderr,"line %u: invalid/oversized field expression\n",lineno);return 64;}
            vfield_decl *vf=&vfields[nv++];strncpy(vf->name,name,MAX_NAME-1);vf->type=t;vf->len=len;strncpy(vf->expr,expr,MAX_FIELD_EXPR-1);
            if(!parse_polynomial(expr,vf->coeff,&vf->degree)){fprintf(stderr,"line %u: field expression must be a bounded polynomial in i using + - * /constant and parentheses\n",lineno);return 65;}vf->exact_proof=1;continue;
        }
        if(!strncmp(line,"array ",6)){
            if(na>=MAX_ARRAYS){fprintf(stderr,"too many arrays\n");return 36;} char name[MAX_NAME]={0},ty[32]={0}; unsigned len=0; wc_type t;
            if(sscanf(line,"array %63s %31s %u",name,ty,&len)!=3||!len||!type_token(ty,&t)||find_array(arrays,na,name)>=0){fprintf(stderr,"line %u: invalid array declaration\n",lineno);return 37;} strncpy(arrays[na].name,name,MAX_NAME-1);arrays[na].type=t;arrays[na].len=len;na++;continue;
        }
        if(!strncmp(line,"struct ",7)){
            if(ns>=MAX_STRUCTS){fprintf(stderr,"too many structs\n");return 38;} char tmp[1024];strncpy(tmp,line+7,sizeof(tmp)-1);char *tok=strtok(tmp," ");if(!tok){fprintf(stderr,"invalid struct\n");return 39;}strncpy(structs[ns].name,tok,MAX_NAME-1);
            while((tok=strtok(NULL," "))){if(structs[ns].nfields>=MAX_FIELDS){fprintf(stderr,"too many struct fields\n");return 40;}char *colon=strchr(tok,':');if(!colon){fprintf(stderr,"line %u: struct fields use name:type\n",lineno);return 41;}*colon=0;wc_type t;if(!type_token(colon+1,&t)){fprintf(stderr,"line %u: invalid struct field type\n",lineno);return 42;}field_decl *fd=&structs[ns].fields[structs[ns].nfields++];strncpy(fd->name,tok,MAX_NAME-1);fd->type=t;}
            if(!structs[ns].nfields){fprintf(stderr,"empty struct\n");return 43;}ns++;continue;
        }
        if(!strncmp(line,"enum ",5)){
            if(ne>=MAX_ENUMS){fprintf(stderr,"too many enums\n");return 44;}char tmp[1024];strncpy(tmp,line+5,sizeof(tmp)-1);char *tok=strtok(tmp," ");if(!tok){fprintf(stderr,"invalid enum\n");return 45;}strncpy(enums[ne].name,tok,MAX_NAME-1);while((tok=strtok(NULL," "))){if(enums[ne].ncases>=MAX_CASES){fprintf(stderr,"too many enum cases\n");return 46;}strncpy(enums[ne].cases[enums[ne].ncases++],tok,MAX_NAME-1);}if(!enums[ne].ncases){fprintf(stderr,"empty enum\n");return 47;}ne++;continue;
        }
        if(!strncmp(line,"parallel_region ",16)){
            if(nipe>=MAX_IPE_REGIONS){fprintf(stderr,"too many parallel regions\n");return 97;}char name[MAX_NAME]={0};unsigned workers=0;if(sscanf(line,"parallel_region %63s workers %u",name,&workers)!=2||workers<2||workers>1024){fprintf(stderr,"line %u: invalid parallel_region declaration\n",lineno);return 98;}for(size_t i=0;i<nipe;i++)if(!strcmp(ipes[i].name,name)){fprintf(stderr,"line %u: duplicate parallel region\n",lineno);return 99;}strncpy(ipes[nipe].name,name,MAX_NAME-1);ipes[nipe].workers=workers;current_ipe=(int)nipe;nipe++;continue;
        }
        if(!strncmp(line,"topology ",9)){
            if(ntopo>=MAX_TOPOLOGIES){fprintf(stderr,"too many topology declarations\n");return 78;}char name[MAX_NAME]={0};unsigned n=0;if(sscanf(line,"topology %63s nodes %u",name,&n)!=2||!n||n>MAX_TOPO_VERTICES||find_topology(topologies,ntopo,name)>=0){fprintf(stderr,"line %u: invalid topology declaration\n",lineno);return 79;}strncpy(topologies[ntopo].name,name,MAX_NAME-1);topologies[ntopo].n=n;current_topology=(int)ntopo;ntopo++;continue;
        }
        if(!strncmp(line,"complex ",8)){
            if(ncomplex>=MAX_COMPLEXES){fprintf(stderr,"too many complex declarations\n");return 83;}char name[MAX_NAME]={0};unsigned n=0;if(sscanf(line,"complex %63s vertices %u",name,&n)!=2||!n||n>MAX_TOPO_VERTICES||find_complex(complexes,ncomplex,name)>=0){fprintf(stderr,"line %u: invalid complex declaration\n",lineno);return 88;}strncpy(complexes[ncomplex].name,name,MAX_NAME-1);complexes[ncomplex].vertices=n;current_complex=(int)ncomplex;ncomplex++;continue;
        }
        if(!strncmp(line,"plan ",5)){
            if(nplan>=MAX_PLANS){fprintf(stderr,"too many plan declarations\n");return 89;}char name[MAX_NAME]={0},tn[MAX_NAME]={0},obj[64]={0};unsigned st=0,go=0;if(sscanf(line,"plan %63s topology %63s start %u goal %u objective %63s",name,tn,&st,&go,obj)!=5||strcmp(obj,"rank_then_cost")){fprintf(stderr,"line %u: invalid plan declaration\n",lineno);return 90;}int tid=find_topology(topologies,ntopo,tn);if(tid<0){fprintf(stderr,"line %u: plan references unknown topology\n",lineno);return 93;}topology_decl *g=&topologies[tid];if(st>=g->n||go>=g->n||st==go){fprintf(stderr,"line %u: plan invalid endpoints\n",lineno);return 94;}plan_decl *p=&plans[nplan++];strncpy(p->name,name,MAX_NAME-1);strncpy(p->topology_name,tn,MAX_NAME-1);p->topology_id=tid;p->start=st;p->goal=go;continue;
        }
        if(!strncmp(line,"matrix ",7)){
            if(nm>=MAX_MATRICES){fprintf(stderr,"too many matrices\n");return 55;} char name[MAX_NAME]={0},ty[32]={0}; unsigned n=0; wc_type t;
            if(sscanf(line,"matrix %63s %31s %u",name,ty,&n)!=3||!n||!type_token(ty,&t)||t!=TY_F64||find_matrix(matrices,nm,name)>=0){fprintf(stderr,"line %u: invalid matrix declaration\n",lineno);return 56;}
            strncpy(matrices[nm].name,name,MAX_NAME-1);matrices[nm].type=t;matrices[nm].n=n;current_matrix=(int)nm;nm++;continue;
        }
        if(!strncmp(line,"solve ",6)){
            if(nsolve>=MAX_SOLVES){fprintf(stderr,"too many solve declarations\n");return 57;} char name[MAX_NAME]={0},mn[MAX_NAME]={0},rhs[MAX_NAME]={0},out[MAX_NAME]={0},strategy[32]={0}; double st=0.0; unsigned mi=0;
            int z=sscanf(line,"solve %63s matrix %63s rhs %63s out %63s strategy %31s tolerance %lf max_iter %u",name,mn,rhs,out,strategy,&st,&mi);
            if(z!=7||strcmp(strategy,"proof_auto")||st<=0.0||st>=1.0||!mi){fprintf(stderr,"line %u: invalid solve declaration\n",lineno);return 58;}
            solve_decl *sd=&solves[nsolve++];strncpy(sd->name,name,MAX_NAME-1);strncpy(sd->matrix_name,mn,MAX_NAME-1);strncpy(sd->rhs_name,rhs,MAX_NAME-1);strncpy(sd->out_name,out,MAX_NAME-1);sd->tolerance=st;sd->max_iter=mi;sd->matrix_id=sd->rhs_id=sd->out_id=-1;continue;
        }
        if(!strncmp(line,"task ",5)){
            if(ntasks>=MAX_TASKS){fprintf(stderr,"too many tasks\n");return 8;} char name[MAX_NAME]={0},cls[32]={0},fnn[MAX_NAME]={0}; long rank=0; unsigned long cost=0; double deadline=0;
            int n=sscanf(line,"task %63s shed_rank %ld cost %lu deadline_ms %lf class %31s fn %63s",name,&rank,&cost,&deadline,cls,fnn);
            if(n!=6||!cost||deadline<=0){fprintf(stderr,"line %u: invalid task declaration: %s\n",lineno,line);return 9;}if(find_task(tasks,ntasks,name)>=0){fprintf(stderr,"duplicate task %s\n",name);return 10;}wc_class cc;if(!class_token(cls,&cc)){fprintf(stderr,"invalid task class\n");return 11;}
            strncpy(tasks[ntasks].name,name,MAX_NAME-1);tasks[ntasks].shed_rank=(int32_t)rank;tasks[ntasks].cost=(uint32_t)cost;tasks[ntasks].deadline_ms=deadline;tasks[ntasks].cls=cc;strncpy(tasks[ntasks].fn_name,fnn,MAX_NAME-1);tasks[ntasks].fn_id=-1;ntasks++;continue;
        }
        if(!strncmp(line,"depends ",8)){if(nedges>=MAX_EDGES){fprintf(stderr,"too many dependencies\n");return 12;}if(sscanf(line,"depends %63s on %63s",edges[nedges].child,edges[nedges].parent)!=2){fprintf(stderr,"invalid dependency\n");return 13;}nedges++;continue;}
        char key[128]={0},value[256]={0}; if(sscanf(line,"%127s %255s",key,value)<1)continue;
        if(!strcmp(key,"webchan")){if(strcmp(value,"1.0.0")){fprintf(stderr,"unsupported Webchan version\n");return 4;}saw_header=1;}
        else if(!strcmp(key,"module")){strncpy(module,value,MAX_NAME-1);}
        else if(!strcmp(key,"frame_budget_ms"))frame_ms=strtod(value,NULL); else if(!strcmp(key,"slice_budget_ms"))slice_ms=strtod(value,NULL); else if(!strcmp(key,"max_continuous_ms"))max_cont_ms=strtod(value,NULL);
        else if(!strcmp(key,"max_step_units"))max_step_units=(uint32_t)strtoul(value,NULL,10); else if(!strcmp(key,"default_step_units"))default_step_units=(uint32_t)strtoul(value,NULL,10); else if(!strcmp(key,"active_set_cap"))active_cap=(uint32_t)strtoul(value,NULL,10);
        else if(!strcmp(key,"chebyshev_order"))order=atoi(value); else if(!strcmp(key,"chebyshev_tolerance"))tol=strtod(value,NULL); else if(!strcmp(key,"memory_mode")){if(!strcmp(value,"matrix_free"))mem_mode=MEM_MATRIX_FREE;else if(!strcmp(value,"dense"))mem_mode=MEM_DENSE;else{fprintf(stderr,"invalid memory_mode\n");return 66;}} else if(!strcmp(key,"memory_auto_affine"))memory_auto_affine=bool_token(value); else if(!strcmp(key,"memory_recompute_budget"))recompute_budget=(uint32_t)strtoul(value,NULL,10); else if(!strcmp(key,"memory_min_savings_bytes"))min_savings=(uint64_t)strtoull(value,NULL,10); else if(!strcmp(key,"memory_scratch_cap"))scratch_cap=(uint32_t)strtoul(value,NULL,10);
        else if(!strcmp(key,"external_interface"))eci_authority_first=!strcmp(value,"authority_first"); else if(!strcmp(key,"c_abi_policy"))eci_cabi_first=!strcmp(value,"prefer"); else if(!strcmp(key,"provider_policy"))eci_replaceable=!strcmp(value,"replaceable"); else if(!strcmp(key,"vendor_policy"))eci_vendor_fallback=!strcmp(value,"fallback_only"); else if(!strcmp(key,"optimization"))proof_directed=!strcmp(value,"proof_directed"); else if(!strcmp(key,"wild_project_policy"))wild_textbook_only=!strcmp(value,"textbook_only"); else if(!strcmp(key,"parallel_migration"))ipe_enabled=!strcmp(value,"inverse_parallel_expansion"); else if(!strcmp(key,"proof_policy"))profitable_only=!strcmp(value,"profitable_only"); else if(!strcmp(key,"time_safety"))time_safe=!strcmp(value,"strict"); else if(!strcmp(key,"group_commit"))progressive=!strcmp(value,"progressive"); else if(!strcmp(key,"implicit_barrier"))no_barrier=!strcmp(value,"forbidden"); else if(!strcmp(key,"causal_topology"))causal=bool_token(value); else if(!strcmp(key,"yield_policy"))input_fair=!strcmp(value,"input_fair"); else if(!strcmp(key,"c_backend"))authoritative_c=!strcmp(value,"authoritative"); else if(!strcmp(key,"host_abi"))portable_abi=!strcmp(value,"portable"); else if(!strcmp(key,"generated_c"))generated_c_internal=!strcmp(value,"internal_only");
        else if(!strcmp(key,"backend")||!strcmp(key,"target")||!strcmp(key,"profile")||!strcmp(key,"app")||!strcmp(key,"execution")||!strcmp(key,"run_ahead")||!strcmp(key,"task_field_collapse")||!strcmp(key,"degradation")||!strcmp(key,"pending_state")||!strcmp(key,"deferred_repair")||!strcmp(key,"active_set")||!strcmp(key,"external_blocking")||!strcmp(key,"speculation")||!strcmp(key,"gc")||!strcmp(key,"atomic_group")||!strcmp(key,"layout_placeholder")||!strcmp(key,"dom_commit")||!strcmp(key,"termination")||!strcmp(key,"type_system")||!strcmp(key,"temporal_effects")||!strcmp(key,"change_propagation")||!strcmp(key,"nonsmooth_strategy")||!strcmp(key,"piecewise_policy")||!strcmp(key,"wavelet_policy")||!strcmp(key,"topology_policy")||!strcmp(key,"homology_policy")||!strcmp(key,"planning_policy")||!strcmp(key,"plan_rank_policy")||!strcmp(key,"parallel_semantics")||!strcmp(key,"orchestration_policy")||!strcmp(key,"partition_policy")){/* contract word */}
        else {fprintf(stderr,"unknown Webchan directive: %s\n",key);return 16;}
    }
    fclose(in); if(current_fn>=0){fprintf(stderr,"unterminated function\n");return 48;} if(current_matrix>=0){fprintf(stderr,"unterminated matrix\n");return 59;} if(current_pw>=0){fprintf(stderr,"unterminated piecewise field\n");return 76;} if(current_topology>=0){fprintf(stderr,"unterminated topology\n");return 91;} if(current_complex>=0){fprintf(stderr,"unterminated complex\n");return 92;} if(current_ipe>=0){fprintf(stderr,"unterminated parallel region\n");return 107;} if(current_kernel>=0){fprintf(stderr,"unterminated generic kernel\n");return 131;}
    if(!saw_header||ntasks==0||nf==0||frame_ms<=0||slice_ms<=0||slice_ms>=frame_ms||max_cont_ms<=0||max_cont_ms>=frame_ms||max_step_units<32||default_step_units<1||default_step_units>max_step_units||active_cap<16||order<4||order>64||recompute_budget<1||scratch_cap<16||scratch_cap>65536){fprintf(stderr,"invalid Webchan config\n");return 5;}
    if(!time_safe||!progressive||!no_barrier||!causal||!input_fair||!authoritative_c||!portable_abi||!generated_c_internal||!proof_directed||!profitable_only||!wild_textbook_only||!ipe_enabled||!eci_authority_first||!eci_cabi_first||!eci_replaceable||!eci_vendor_fallback||(mem_mode==MEM_MATRIX_FREE&&!memory_auto_affine)){fprintf(stderr,"Webchan 1.0.0 hard contract violated\n");return 6;}
    int ok=1;for(size_t i=0;i<nf;i++){if(!fns[i].ninsn){fprintf(stderr,"function %s has empty body\n",fns[i].name);return 49;}fn_bound(fns,nf,(int)i,&ok);if(!ok){fprintf(stderr,"temporal/termination check failed at function %s (declared=%u computed=%llu); recursion cycles and underestimated bounds are forbidden\n",fns[i].name,fns[i].declared_bound,(unsigned long long)fns[i].computed_bound);return 50;}}
    for(size_t i=0;i<nf;i++){if(!analyze_fn_structure(fns,nf,(int)i)){fprintf(stderr,"structural proof failed due to cyclic function dependency at %s\n",fns[i].name);return 77;}}
    for(size_t i=0;i<nk;i++){char ke[256];if(!kernels[i].nop||!analyze_kernel(&kernels[i],arrays,na,ke,sizeof ke)){fprintf(stderr,"generic kernel analysis failed: %s\n",kernels[i].nop?ke:"empty kernel");return 132;}}
    analyze_data_layout(arrays,na,kernels,nk);
    for(size_t i=0;i<nipe;i++){if(!analyze_ipe(&ipes[i],fns,nf)){fprintf(stderr,"parallel region %s failed dependency/purity analysis\n",ipes[i].name);return 108;}}
    for(size_t i=0;i<nv;i++)analyze_vfield(&vfields[i],mem_mode,recompute_budget,min_savings); for(size_t i=0;i<npw;i++)analyze_pwfield(&pwfields[i],mem_mode,recompute_budget,min_savings);
    for(size_t i=0;i<nm;i++){analyze_matrix(&matrices[i]);}
    for(size_t i=0;i<nsolve;i++){solve_decl *sd=&solves[i];int mid=find_matrix(matrices,nm,sd->matrix_name),rid=find_array(arrays,na,sd->rhs_name),oid=find_array(arrays,na,sd->out_name);if(mid<0||rid<0||oid<0){fprintf(stderr,"solve %s references unknown matrix/array\n",sd->name);return 60;}matrix_decl *m=&matrices[mid];if(arrays[rid].type!=TY_F64||arrays[oid].type!=TY_F64||arrays[rid].len!=m->n||arrays[oid].len!=m->n){fprintf(stderr,"solve %s dimension/type mismatch\n",sd->name);return 61;}sd->matrix_id=mid;sd->rhs_id=rid;sd->out_id=oid;analyze_solve(sd,m);}
    for(size_t i=0;i<ntopo;i++)analyze_topology(&topologies[i]);
    for(size_t i=0;i<ncomplex;i++)analyze_complex(&complexes[i]);
    for(size_t i=0;i<nplan;i++){int tid=plans[i].topology_id;topology_decl *g=&topologies[tid];analyze_plan(&plans[i],g);if(!plans[i].path_len){fprintf(stderr,"plan %s has no valid route\n",plans[i].name);return 95;}}
    for(size_t i=0;i<ntasks;i++){int id=find_fn(fns,nf,tasks[i].fn_name);if(id<0){fprintf(stderr,"task %s references unknown function %s\n",tasks[i].name,tasks[i].fn_name);return 51;}tasks[i].fn_id=id;}
    for(size_t e=0;e<nedges;e++){int c=find_task(tasks,ntasks,edges[e].child),p=find_task(tasks,ntasks,edges[e].parent);if(c<0||p<0||c==p){fprintf(stderr,"invalid dependency %s on %s\n",edges[e].child,edges[e].parent);return 14;}set_pred(&tasks[c],p);}if(!validate_dag(tasks,ntasks)){fprintf(stderr,"causal topology contains a cycle\n");return 15;}
    if(!emit_files(argv[2],module,tasks,ntasks,fns,nf,arrays,na,structs,ns,enums,ne,matrices,nm,solves,nsolve,vfields,nv,pwfields,npw,topologies,ntopo,plans,nplan,complexes,ncomplex,ipes,nipe,kernels,nk,caps,ncaps,eciops,neciops,mem_mode,recompute_budget,min_savings,scratch_cap,frame_ms,slice_ms,max_cont_ms,max_step_units,default_step_units,active_cap,order,tol))return 7;return 0;
}
