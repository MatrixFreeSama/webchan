# Webchan 1.0.0 External Capability Interface — Fresh Validation Report

## Release identity

1.0.0 retains the provider-neutral **External Capability Interface (ECI)** and now adds Webchan IR **Structural Data Layout Algebra (SDLA)** downstream of Structural Iteration Algebra (SIA), without removing temporal, matrix-free, topology, IPE or incremental systems.

Authoritative chain:

`.webchan -> semantic/temporal/structural/capability proof -> Webchan IR -> internal generated C -> Clang/LLVM -> Wasm/native host boundary`

Portable core imports: **0**. Version ABI: **0x00010000**.

The pure core remains zero-import. The ECI Wasm profile imports exactly one explicit bridge: `webchan_eci.dispatch`.

## External Capability Interface

The universal source declares **12 capabilities** and **12 external operations**. Capabilities are semantic names; providers remain replaceable.

Implemented selection order: semantic eligibility -> host eligibility -> authority class -> provider priority -> availability.

### Provider selection witnesses

| Capability/host | Selected provider |
|---|---|
| native filesystem.read | c_stdio |
| native network.tcp | posix_sockets |
| native generic gpu.compute | vulkan_compute |
| browser network.tcp | browser_websocket |
| browser gpu.compute | webgpu |
| WASI filesystem.read | wasi_filesystem |
| NIC fallback with only driver marked available | vendor_driver |

The generic native GPU capability selects `vulkan_compute` ahead of `cuda_driver` because 1.0.0's default policy prefers a general eligible C ABI before a vendor-specific C ABI. This is a policy choice, not a claim that Vulkan is universally faster or equivalent to CUDA-specific semantics.

### Explicit Wasm host boundary

The ECI test module has one import and exports the capability/provider query API plus `wc_eci_call`. A dispatch probe passed `(op=7, opcode=1, args=11,13)` through the host bridge and returned **25**, with the host receiving the exact operation/arguments.

Chromium independently instantiated the same ECI module. Browser selection chose TCP provider id **6**, GPU provider id **12**, and file provider id **2**. Feature detection in that headless environment was: `{'fetch': True, 'websocket': True, 'webgpu': False}`.

### Native C ABI probe

The generated native provider catalogue contains **32** candidates. The validation host detected **12** ABI/library/device-entry candidates. It performs real C stdio, POSIX socket and monotonic-clock operations; optional shared libraries are probed dynamically.

Detected notable entries on this host:
- `c_stdio`: **detected**
- `posix_sockets`: **detected**
- `libcurl`: **detected**
- `cuda_driver`: **not detected**
- `vulkan_compute`: **detected**
- `opengl`: **detected**
- `dpdk`: **not detected**
- `af_xdp`: **detected**
- `rdma_verbs`: **not detected**
- `sqlite3`: **detected**
- `zlib`: **detected**
- `libusb`: **detected**
- `alsa`: **detected**
- `clock_gettime`: **detected**

Required native capabilities resolved on the actual detected provider mask as: `{'filesystem.read': 0, 'timer.monotonic': 29}`.

A detected shared library is only an ABI-availability witness. It does not certify a physical GPU/NIC, permissions, context creation, or device success.

## Temporal-effect gates

The compiler rejects:

- a `potentially_blocking` external operation declared with `boundary direct`;
- an external operation referencing an undeclared capability;
- a capability name with no authority/provider catalogue entry;
- a release that disables the 1.0.0 authority-first/C-ABI-first/replaceable-provider/fallback policy.

Thus foreign calls do not silently bypass the existing temporal contract.

## Structural Iteration Algebra / generic kernel regression

The release executes **6** ordinary generic indexed kernels through Webchan IR with **0** Wasm imports. The probes cover elementwise indexed work, neighborhood gather, loop-carried prefix state, bitwise permutation, a nested tiled loop and a staged radix-2 transform. The last item is a regression probe only; the compiler has no transform-named opcode.

Correctness witnesses: elementwise max error **0**, neighbor max error **0**, prefix result **524800 / 524800**, permutation error **0**, tiled-loop error **0**, staged-transform impulse error **0**, tone peak error **1.164e-06**, max leakage **2.240e-07**.

Compiler negative gates reject out-of-range scatter, nonpositive steps, unknown symbols, underdeclared effect bounds and unclosed loop nests.

## Structural Data Layout Algebra

The source still contains ordinary logical arrays. Webchan IR selected a high-co-access pair as **interleaved** (`kind=1`, score **64**) and a moderate-co-access pair as **tiled** (`kind=2`, tile **16**). Unrelated base arrays remained separate: `{'samples': 0, 'flags': 0, 'rhs': 0, 'solution': 0}`.

The logical array ABI remained exact after physical relayout: max get/set error **0**. Generated C contains shared physical layout groups and compiler-generated per-logical-array lvalue mappings; the paired logical backing arrays are not separately materialized.

SDLA uses generic type/extent/nonalias legality plus matched-index locality profitability. No workload-specific layout directive or transform name is part of the source contract.

## Inverse Parallel Expansion regression

| Grain | Naive serialized | IPE | Speedup | Same checksum |
|---|---:|---:|---:|---|
| fine | 64.800 ms | 63.488 ms | 1.021x | True |
| medium | 60.832 ms | 61.949 ms | 0.982x | True |
| coarse | 66.078 ms | 65.353 ms | 1.011x | True |

The heterogeneous IPE region still refuses partition fusion and keeps causality-before-rank scheduling. The naive scheduler remains isolated to the benchmark Wasm rather than the portable core.

## Structural topology regression

- topology-pruned planning: **59 -> 10** expansions, **7.76x** measured, same semantic checksum **True**;
- rank-first nontrivial route remains rank **-5**, cost **2**, homotopy word **[1]**;
- graph and finite 2D simplicial-complex Betti/homology/collapse gates remain intact.

## Structural linear algebra regression

| Method | Per solve | Residual | Speedup vs Webchan generic dense |
|---|---:|---:|---:|
| dense-gaussian | 6.796773 ms | 4.441e-16 | 1.0x |
| banded-gaussian | 0.008093 ms | 4.441e-16 | 839.8x |
| krylov-cg | 0.029196 ms | 4.635e-09 | 232.8x |
| chebyshev | 0.025168 ms | 6.008e-09 | 270.1x |
| jacobi | 0.081630 ms | 8.143e-09 | 83.3x |
| gauss-seidel | 0.056628 ms | 8.647e-09 | 120.0x |
| weighted-jacobi | 0.095658 ms | 8.143e-09 | 71.1x |

Other exact structural collapses: lower-triangular -> forward substitution **832.6x**, diagonal -> direct division **1769.8x**, relative only to Webchan's own generic dense fallback.

## Memory / incremental / browser regression

- matrix-free actual linear memory: **8.38 MiB** vs dense **99.81 MiB**;
- incremental invalidation touched **3/11** tasks with work fraction **0.309** and semantic relative error **1.919e-15**;
- piecewise exact probe error **0**;
- browser safe event lag **4.500 ms**, safe input lag **4.900 ms**;
- forced synchronous baseline event lag **314.900 ms**.

## Honest boundary

Implemented in 1.0.0: capability declarations, external operation declarations, effect/boundary checking, provider authority catalogue, C-ABI-first resolution, browser/native/WASI host masks, compiler-emitted JSON/Webchan IR metadata, one-import Wasm ECI bridge, native C ABI detection/smoke path, browser/Node bridge validation, and inherited earlier engines.

Not claimed: a Webchan-owned network/GPU/NIC/audio/database runtime; arbitrary C/C++ header binding; full opaque-handle lifetime proofs; real CUDA execution on this validation host; usable DPDK/RDMA hardware; browser access to native drivers; or semantic equivalence among APIs that expose different capabilities.
