#ifndef WEBCHAN_PROGRAM_H
#define WEBCHAN_PROGRAM_H
#include <stdint.h>
#define WC_VERSION_MAJOR 1
#define WC_VERSION_MINOR 0
#define WC_VERSION_PATCH 0
#define WC_BUILD_ID "090920262021"
#define WC_MODULE_NAME "universal_temporal_core"
#define WC_TASK_COUNT 11
#define WC_FN_COUNT 4
#define WC_ARRAY_COUNT 4
#define WC_STRUCT_COUNT 1
#define WC_ENUM_COUNT 1
#define WC_MATRIX_COUNT 1
#define WC_SOLVE_COUNT 1
#define WC_VFIELD_COUNT 3
#define WC_PWFIELD_COUNT 1
#define WC_TOPOLOGY_COUNT 0
#define WC_PLAN_COUNT 0
#define WC_COMPLEX_COUNT 0
#define WC_IPE_REGION_COUNT 0
#define WC_KERNEL_COUNT 0
#define WC_ECI_CAPABILITY_COUNT 0
#define WC_ECI_OP_COUNT 0
#define WC_FRAME_BUDGET_MS 16.667000000000002
#define WC_SLICE_BUDGET_MS 2
#define WC_MAX_CONTINUOUS_MS 4
#define WC_MAX_STEP_UNITS 2048u
#define WC_DEFAULT_STEP_UNITS 512u
#define WC_ACTIVE_SET_CAP 96u
#define WC_CHEB_ORDER 32
#define WC_CHEB_TOL 1e-08
#define WC_TEMPORAL_SAFETY_STRICT 1
#define WC_PROGRESSIVE_DEFAULT 1
#define WC_IMPLICIT_BARRIER_FORBIDDEN 1
#define WC_CAUSAL_DAG_COMPILED 1
#define WC_INPUT_FAIR_HOST_YIELD 1
#define WC_C_BACKEND_AUTHORITATIVE 1
#define WC_HOST_ABI_PORTABLE 1
#define WC_GENERATED_C_INTERNAL_ONLY 1
#define WC_TERMINATION_CHECKED 1
#define WC_SIZED_TYPES 1
#define WC_TEMPORAL_EFFECTS 1
#define WC_PROOF_DIRECTED_OPT 1
#define WC_PROFITABLE_PROOFS_ONLY 1
#define WC_STATIC_MATRIX_PROOFS 1
#define WC_PROOF_GUIDED_MATRIX_FREE 1
#define WC_AUTO_AFFINE_DISCOVERY 1
#define WC_BOUNDED_TEMP_MATERIALIZATION 1
#define WC_INCREMENTAL_CHANGE_PROPAGATION 1
#define WC_ADAPTIVE_PARTITION 1
#define WC_EXACT_PIECEWISE_FIELDS 1
#define WC_GENERAL_STRUCTURAL_PROOF 1
#define WC_LINEAR_ALGEBRA_CAPABILITY_GRAPH 1
#define WC_AFFINE_FUNCTION_COLLAPSE 1
#define WC_JACOBI_PROOF_UNLOCK 1
#define WC_GAUSS_SEIDEL_PROOF_UNLOCK 1
#define WC_TRIANGULAR_SOLVE_COLLAPSE 1
#define WC_STRUCTURAL_TOPOLOGY_PROOF 1
#define WC_STRUCTURAL_ITERATION_ALGEBRA 1
#define WC_FINITE_INDEX_SPACE_PROOF 1
#define WC_DEPENDENCE_TOPOLOGY_BRIDGE 1
#define WC_LOOP_TRANSFORM_PROOF_GATE 1
#define WC_GENERIC_INDEX_KERNELS 1
#define WC_BOUNDED_NESTED_FOR 1
#define WC_PROVED_GATHER_SCATTER 1
#define WC_LOOP_CARRIED_SCALARS 1
#define WC_REDUCTION_SCAN_FOUNDATION 1
#define WC_BITWISE_INDEX_MAPS 1
#define WC_STRUCTURAL_DATA_LAYOUT_ALGEBRA 1
#define WC_AUTO_LAYOUT_SELECTION 1
#define WC_LOGICAL_PHYSICAL_ARRAY_SEPARATION 1
#define WC_INTERLEAVED_LAYOUT_REWRITE 1
#define WC_TILED_LAYOUT_REWRITE 1
#define WC_TOPOLOGICAL_PLANNING 1
#define WC_HOMOLOGY_GF2 1
#define WC_GRAPH_FUNDAMENTAL_GROUP 1
#define WC_PLAN_RANK 1
#define WC_INVERSE_PARALLEL_EXPANSION 1
#define WC_PARALLEL_ORCHESTRATION_ERASURE 1
#define WC_RANK_GUIDED_RELINEARIZATION 1
#define WC_PARTITION_FUSION 1
#define WC_WILD_PROJECT_TEXTBOOK_ONLY 1
#define WC_EXTERNAL_CAPABILITY_INTERFACE 1
#define WC_ECI_C_ABI_FIRST 1
#define WC_ECI_REPLACEABLE_PROVIDERS 1
#define WC_ECI_TEMPORAL_EFFECT_CHECKING 1
#define WC_ECI_VENDOR_FALLBACK_ONLY 1
#define WC_MEMORY_MODE 0
#define WC_MEMORY_RECOMPUTE_BUDGET 6
#define WC_MEMORY_MIN_SAVINGS 4096u
#define WC_FIELD_SCRATCH_CAP 4096
extern const int32_t wc_task_ranks[WC_TASK_COUNT];
extern const uint32_t wc_task_costs[WC_TASK_COUNT];
extern const double wc_task_deadlines[WC_TASK_COUNT];
extern const uint8_t wc_task_classes[WC_TASK_COUNT];
extern const uint8_t wc_task_fn[WC_TASK_COUNT];
extern const uint32_t wc_task_pred_lo[WC_TASK_COUNT],wc_task_pred_hi[WC_TASK_COUNT],wc_task_pred_x[WC_TASK_COUNT];
double wc_user_call(uint8_t,double,double,uint32_t,uint32_t);
double wc_user_call_reference(uint8_t,double,double,uint32_t,uint32_t);
uint32_t wc_user_fn_structural_bits(uint32_t);
uint64_t wc_user_fn_original_ops(uint32_t);
uint64_t wc_user_fn_collapsed_ops(uint32_t);
uint32_t wc_user_fn_bound(uint32_t);
uint32_t wc_user_array_count(void);
uint32_t wc_user_array_len(uint32_t);
uint32_t wc_user_array_type(uint32_t);
uint32_t wc_user_array_layout_kind(uint32_t);
uint32_t wc_user_array_layout_group(uint32_t);
uint32_t wc_user_array_layout_lane(uint32_t);
uint32_t wc_user_array_layout_lanes(uint32_t);
uint32_t wc_user_array_layout_tile(uint32_t);
uint32_t wc_user_array_layout_score(uint32_t);
uint64_t wc_user_array_logical_bytes(uint32_t);
uint64_t wc_user_array_physical_share_bytes(uint32_t);
double wc_user_array_get(uint32_t,uint32_t);
void wc_user_array_set(uint32_t,uint32_t,double);
uint32_t wc_user_solve_count(void);
uint32_t wc_user_solve(uint32_t,uint32_t);
double wc_user_solve_residual(uint32_t);
uint32_t wc_user_solve_proof_bits(uint32_t);
uint32_t wc_user_solve_chosen(uint32_t);
uint64_t wc_user_solve_estimated(uint32_t,uint32_t);
uint32_t wc_user_memory_mode(void);
void wc_user_memory_init(void);
uint32_t wc_user_field_count(void);
uint32_t wc_user_field_len(uint32_t);
uint32_t wc_user_field_repr(uint32_t);
uint32_t wc_user_field_proof_bits(uint32_t);
uint32_t wc_user_field_reconstruct_ops(uint32_t);
uint64_t wc_user_field_logical_bytes(uint32_t);
uint64_t wc_user_field_stored_bytes(uint32_t);
uint64_t wc_user_field_saved_bytes(uint32_t);
double wc_user_field_get(uint32_t,uint32_t);
double wc_user_field_checksum(uint32_t,uint32_t);
double wc_user_field_pair_checksum(uint32_t,uint32_t,uint32_t);
uint32_t wc_user_field_materialize(uint32_t,uint32_t,uint32_t);
double wc_user_field_scratch_get(uint32_t);
uint32_t wc_user_pwfield_count(void);
uint32_t wc_user_pwfield_len(uint32_t);
uint32_t wc_user_pwfield_repr(uint32_t);
uint32_t wc_user_pwfield_segments(uint32_t);
uint64_t wc_user_pwfield_logical_bytes(uint32_t);
uint64_t wc_user_pwfield_stored_bytes(uint32_t);
uint64_t wc_user_pwfield_saved_bytes(uint32_t);
double wc_user_pwfield_get(uint32_t,uint32_t);
double wc_user_pwfield_checksum(uint32_t,uint32_t);
uint32_t wc_user_topology_count(void);
uint32_t wc_user_topology_vertices(uint32_t);
uint32_t wc_user_topology_edges(uint32_t);
uint32_t wc_user_topology_beta0(uint32_t);
uint32_t wc_user_topology_beta1(uint32_t);
int32_t wc_user_topology_euler(uint32_t);
uint32_t wc_user_topology_proof_bits(uint32_t);
uint32_t wc_user_topology_bridges(uint32_t);
uint32_t wc_user_topology_articulations(uint32_t);
uint32_t wc_user_topology_free_group_rank(uint32_t);
uint32_t wc_user_topology_incidence_rank(uint32_t);
uint32_t wc_user_topology_laplacian_nullity(uint32_t);
uint32_t wc_user_topology_laplacian_proof_bits(uint32_t);
uint32_t wc_user_plan_count(void);
uint32_t wc_user_plan_path_len(uint32_t);
uint32_t wc_user_plan_path_vertex(uint32_t,uint32_t);
int32_t wc_user_plan_rank(uint32_t);
double wc_user_plan_cost(uint32_t);
uint32_t wc_user_plan_full_expansions(uint32_t);
uint32_t wc_user_plan_topo_expansions(uint32_t);
uint32_t wc_user_plan_pruned_vertices(uint32_t);
uint32_t wc_user_plan_homotopy_word_len(uint32_t);
int32_t wc_user_plan_homotopy_letter(uint32_t,uint32_t);
uint64_t wc_user_plan_bench(uint32_t,uint32_t,uint32_t);
uint32_t wc_user_complex_count(void);
uint32_t wc_user_complex_beta(uint32_t,uint32_t);
int32_t wc_user_complex_euler(uint32_t);
uint32_t wc_user_complex_proof_bits(uint32_t);
uint32_t wc_user_complex_collapse_steps(uint32_t);
uint32_t wc_user_ipe_count(void);
uint32_t wc_user_ipe_proof_bits(uint32_t);
uint32_t wc_user_ipe_original_nodes(uint32_t);
uint32_t wc_user_ipe_serial_nodes(uint32_t);
uint32_t wc_user_ipe_eliminated_orchestration(uint32_t);
uint32_t wc_user_ipe_scalarized_worker_slots(uint32_t);
uint32_t wc_user_ipe_fused_partitions(uint32_t);
uint32_t wc_user_ipe_partition_boundaries_removed(uint32_t);
uint32_t wc_user_ipe_schedule_node(uint32_t,uint32_t);
uint64_t wc_user_ipe_bench(uint32_t,uint32_t,uint32_t);
uint32_t wc_user_kernel_count(void);
uint64_t wc_user_kernel_bound(uint32_t);
uint64_t wc_user_kernel_extent(uint32_t);
uint32_t wc_user_kernel_depth(uint32_t);
uint32_t wc_user_kernel_proof_bits(uint32_t);
uint32_t wc_user_kernel_transform_bits(uint32_t);
void wc_user_kernel_run(uint32_t,uint32_t);
uint32_t wc_user_sia_count(void);
uint32_t wc_user_sia_kind(uint32_t);
uint32_t wc_user_sia_extent(uint32_t);
uint32_t wc_user_sia_stages(uint32_t);
uint32_t wc_user_sia_locality(uint32_t);
uint32_t wc_user_sia_proof_bits(uint32_t);
uint32_t wc_user_sia_transform_bits(uint32_t);
uint32_t wc_user_eci_capability_count(void);
uint32_t wc_user_eci_op_count(void);
uint32_t wc_user_eci_capability_effect(uint32_t);
uint32_t wc_user_eci_capability_required(uint32_t);
uint32_t wc_user_eci_provider_count(uint32_t);
uint32_t wc_user_eci_provider_kind(uint32_t,uint32_t);
uint32_t wc_user_eci_provider_hosts(uint32_t,uint32_t);
uint32_t wc_user_eci_provider_priority(uint32_t,uint32_t);
uint32_t wc_user_eci_provider_global_id(uint32_t,uint32_t);
uint32_t wc_user_eci_select(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t wc_user_eci_op_capability(uint32_t);
uint32_t wc_user_eci_op_boundary(uint32_t);
uint32_t wc_user_eci_op_opcode(uint32_t);
uint64_t wc_user_eci_call(uint32_t,uint64_t,uint64_t);
#endif
