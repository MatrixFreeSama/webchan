#include <stdint.h>
#include "webchan_program.h"
#define WC_EXPORT(name) __attribute__((export_name(name)))
#define WC_STATUS_BLOCKED 0u
#define WC_STATUS_READY 1u
#define WC_STATUS_DONE 2u
static uint32_t wc_status[WC_TASK_COUNT],wc_progress[WC_TASK_COUNT],wc_done_count_v,wc_seed_v,wc_last_invalidated_v;static double wc_accum_v,wc_task_accum[WC_TASK_COUNT];
static int pred_done(uint32_t task){uint32_t lo=wc_task_pred_lo[task],hi=wc_task_pred_hi[task],xx=wc_task_pred_x[task];for(uint32_t i=0;i<WC_TASK_COUNT;i++){uint32_t bit=i<32?((lo>>i)&1u):(i<64?((hi>>(i-32))&1u):((xx>>(i-64))&1u));if(bit&&wc_status[i]!=WC_STATUS_DONE)return 0;}return 1;}
static void refresh_ready(void){for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(wc_status[i]==WC_STATUS_BLOCKED&&pred_done(i))wc_status[i]=WC_STATUS_READY;}
static int better(uint32_t a,uint32_t b){if(wc_task_classes[a]!=wc_task_classes[b])return wc_task_classes[a]<wc_task_classes[b];if(wc_task_deadlines[a]!=wc_task_deadlines[b])return wc_task_deadlines[a]<wc_task_deadlines[b];if(wc_task_ranks[a]!=wc_task_ranks[b])return wc_task_ranks[a]<wc_task_ranks[b];return a<b;}
static int pick_ready(void){int best=-1;for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(wc_status[i]==WC_STATUS_READY&&(best<0||better(i,(uint32_t)best)))best=(int)i;return best;}
WC_EXPORT("wc_reset") void wc_reset(uint32_t seed){wc_seed_v=seed?seed:1u;wc_accum_v=0.0;wc_done_count_v=0;wc_last_invalidated_v=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++){wc_status[i]=WC_STATUS_BLOCKED;wc_progress[i]=0;wc_task_accum[i]=0.0;}refresh_ready();}
static int direct_dep(uint32_t child,uint32_t parent){if(child>=WC_TASK_COUNT||parent>=WC_TASK_COUNT)return 0;if(parent<32)return (wc_task_pred_lo[child]>>parent)&1u;if(parent<64)return (wc_task_pred_hi[child]>>(parent-32))&1u;return (wc_task_pred_x[child]>>(parent-64))&1u;}
WC_EXPORT("wc_invalidate") uint32_t wc_invalidate(uint32_t root){if(root>=WC_TASK_COUNT)return 0;uint8_t mark[WC_TASK_COUNT];for(uint32_t i=0;i<WC_TASK_COUNT;i++)mark[i]=0;mark[root]=1;for(uint32_t pass=0;pass<WC_TASK_COUNT;pass++){int changed=0;for(uint32_t c=0;c<WC_TASK_COUNT;c++)if(!mark[c])for(uint32_t p=0;p<WC_TASK_COUNT;p++)if(mark[p]&&direct_dep(c,p)){mark[c]=1;changed=1;break;}if(!changed)break;}uint32_t n=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(mark[i]){n++;if(wc_status[i]==WC_STATUS_DONE&&wc_done_count_v)wc_done_count_v--;wc_accum_v-=wc_task_accum[i];wc_task_accum[i]=0.0;wc_progress[i]=0;wc_status[i]=WC_STATUS_BLOCKED;}wc_last_invalidated_v=n;refresh_ready();return n;}
WC_EXPORT("wc_last_invalidated_count") uint32_t wc_last_invalidated_count(void){return wc_last_invalidated_v;}
WC_EXPORT("wc_remaining_work") uint64_t wc_remaining_work(void){uint64_t r=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++)r+=(uint64_t)(wc_task_costs[i]-wc_progress[i]);return r;}
static uint32_t step_internal(uint32_t budget,double t,int clamp){if(clamp&&budget>WC_MAX_STEP_UNITS)budget=WC_MAX_STEP_UNITS;if(!budget)budget=1;uint32_t used=0;while(used<budget&&wc_done_count_v<WC_TASK_COUNT){refresh_ready();int p=pick_ready();if(p<0)break;uint32_t task=(uint32_t)p,left=wc_task_costs[task]-wc_progress[task],n=budget-used;if(n>left)n=left;uint32_t start=wc_progress[task];double local=0.0;for(uint32_t j=0;j<n;j++){uint32_t idx=start+j;double x=(double)(idx+1u)/(double)(wc_task_costs[task]+1u)+(double)(wc_seed_v&255u)*0.000001;local+=wc_user_call(wc_task_fn[task],x,t,idx,task);}wc_accum_v+=local;wc_task_accum[task]+=local;wc_progress[task]+=n;used+=n;if(wc_progress[task]>=wc_task_costs[task]){wc_status[task]=WC_STATUS_DONE;wc_done_count_v++;refresh_ready();}}return used;}
WC_EXPORT("wc_step") uint32_t wc_step(uint32_t budget,double t){return step_internal(budget,t,1);}WC_EXPORT("wc_done") uint32_t wc_done(void){return wc_done_count_v==WC_TASK_COUNT;}WC_EXPORT("wc_done_count") uint32_t wc_done_count(void){return wc_done_count_v;}WC_EXPORT("wc_task_count") uint32_t wc_task_count(void){return WC_TASK_COUNT;}WC_EXPORT("wc_task_status") uint32_t wc_task_status(uint32_t i){return i<WC_TASK_COUNT?wc_status[i]:255u;}WC_EXPORT("wc_task_progress") uint32_t wc_task_progress(uint32_t i){return i<WC_TASK_COUNT?wc_progress[i]:0u;}WC_EXPORT("wc_task_cost") uint32_t wc_task_cost_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_costs[i]:0u;}WC_EXPORT("wc_task_rank") int32_t wc_task_rank_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_ranks[i]:2147483647;}WC_EXPORT("wc_task_class") uint32_t wc_task_class_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_classes[i]:255u;}WC_EXPORT("wc_task_fn") uint32_t wc_task_fn_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_fn[i]:255u;}WC_EXPORT("wc_fn_bound") uint32_t wc_fn_bound_export(uint32_t i){return wc_user_fn_bound(i);}WC_EXPORT("wc_eval_fn") double wc_eval_fn(uint32_t id,double x,double t,uint32_t i,uint32_t task){return wc_user_call((uint8_t)id,x,t,i,task);}WC_EXPORT("wc_eval_fn_reference") double wc_eval_fn_reference(uint32_t id,double x,double t,uint32_t i,uint32_t task){return wc_user_call_reference((uint8_t)id,x,t,i,task);}WC_EXPORT("wc_fn_structural_bits") uint32_t wc_fn_structural_bits(uint32_t id){return wc_user_fn_structural_bits(id);}WC_EXPORT("wc_fn_original_ops") uint64_t wc_fn_original_ops(uint32_t id){return wc_user_fn_original_ops(id);}WC_EXPORT("wc_fn_collapsed_ops") uint64_t wc_fn_collapsed_ops(uint32_t id){return wc_user_fn_collapsed_ops(id);}WC_EXPORT("wc_accumulator") double wc_accumulator(void){return wc_accum_v;}WC_EXPORT("wc_max_step_units") uint32_t wc_max_step_units(void){return WC_MAX_STEP_UNITS;}WC_EXPORT("wc_default_step_units") uint32_t wc_default_step_units(void){return WC_DEFAULT_STEP_UNITS;}WC_EXPORT("wc_active_set_cap") uint32_t wc_active_set_cap(void){return WC_ACTIVE_SET_CAP;}WC_EXPORT("wc_version") uint32_t wc_version(void){return ((WC_VERSION_MAJOR&0xffu)<<16)|((WC_VERSION_MINOR&0xffu)<<8)|(WC_VERSION_PATCH&0xffu);}WC_EXPORT("wc_contract_bits") uint32_t wc_contract_bits(void){return 0x00ffffffu;}
WC_EXPORT("wc_array_count") uint32_t wc_array_count(void){return wc_user_array_count();}WC_EXPORT("wc_array_len") uint32_t wc_array_len(uint32_t id){return wc_user_array_len(id);}WC_EXPORT("wc_array_type") uint32_t wc_array_type(uint32_t id){return wc_user_array_type(id);}WC_EXPORT("wc_array_layout_kind") uint32_t wc_array_layout_kind(uint32_t id){return wc_user_array_layout_kind(id);}WC_EXPORT("wc_array_layout_group") uint32_t wc_array_layout_group(uint32_t id){return wc_user_array_layout_group(id);}WC_EXPORT("wc_array_layout_lane") uint32_t wc_array_layout_lane(uint32_t id){return wc_user_array_layout_lane(id);}WC_EXPORT("wc_array_layout_lanes") uint32_t wc_array_layout_lanes(uint32_t id){return wc_user_array_layout_lanes(id);}WC_EXPORT("wc_array_layout_tile") uint32_t wc_array_layout_tile(uint32_t id){return wc_user_array_layout_tile(id);}WC_EXPORT("wc_array_layout_score") uint32_t wc_array_layout_score(uint32_t id){return wc_user_array_layout_score(id);}WC_EXPORT("wc_array_logical_bytes") uint64_t wc_array_logical_bytes(uint32_t id){return wc_user_array_logical_bytes(id);}WC_EXPORT("wc_array_physical_share_bytes") uint64_t wc_array_physical_share_bytes(uint32_t id){return wc_user_array_physical_share_bytes(id);}WC_EXPORT("wc_array_get") double wc_array_get(uint32_t id,uint32_t idx){return wc_user_array_get(id,idx);}WC_EXPORT("wc_array_set") void wc_array_set(uint32_t id,uint32_t idx,double v){wc_user_array_set(id,idx,v);}
#ifdef WC_BENCHMARK_UNSAFE
WC_EXPORT("wc_benchmark_blocking_all") double wc_benchmark_blocking_all(uint32_t seed,double t){wc_reset(seed);while(!wc_done())step_internal(0xffffffffu,t,0);return wc_accum_v;}
#endif

WC_EXPORT("wc_bench_fn_chain") double wc_bench_fn_chain(uint32_t id,uint32_t reference,uint32_t reps){double v=0.125;for(uint32_t r=0;r<reps;r++){if(reference)v=wc_user_call_reference((uint8_t)id,v,0.375,r&255u,3u);else v=wc_user_call((uint8_t)id,v,0.375,r&255u,3u);}return v;}
WC_EXPORT("wc_solve_count") uint32_t wc_solve_count(void){return wc_user_solve_count();}
WC_EXPORT("wc_solve") uint32_t wc_solve(uint32_t sid,uint32_t method){return wc_user_solve(sid,method);}
WC_EXPORT("wc_solve_residual") double wc_solve_residual(uint32_t sid){return wc_user_solve_residual(sid);}
WC_EXPORT("wc_solve_proof_bits") uint32_t wc_solve_proof_bits(uint32_t sid){return wc_user_solve_proof_bits(sid);}
WC_EXPORT("wc_solve_chosen") uint32_t wc_solve_chosen(uint32_t sid){return wc_user_solve_chosen(sid);}
WC_EXPORT("wc_solve_estimated") uint64_t wc_solve_estimated(uint32_t sid,uint32_t method){return wc_user_solve_estimated(sid,method);}
WC_EXPORT("wc_memory_mode") uint32_t wc_memory_mode(void){return wc_user_memory_mode();}
WC_EXPORT("wc_memory_init") void wc_memory_init(void){wc_user_memory_init();}
WC_EXPORT("wc_field_count") uint32_t wc_field_count(void){return wc_user_field_count();}
WC_EXPORT("wc_field_len") uint32_t wc_field_len(uint32_t id){return wc_user_field_len(id);}
WC_EXPORT("wc_field_repr") uint32_t wc_field_repr(uint32_t id){return wc_user_field_repr(id);}
WC_EXPORT("wc_field_proof_bits") uint32_t wc_field_proof_bits(uint32_t id){return wc_user_field_proof_bits(id);}
WC_EXPORT("wc_field_reconstruct_ops") uint32_t wc_field_reconstruct_ops(uint32_t id){return wc_user_field_reconstruct_ops(id);}
WC_EXPORT("wc_field_logical_bytes") uint64_t wc_field_logical_bytes(uint32_t id){return wc_user_field_logical_bytes(id);}
WC_EXPORT("wc_field_stored_bytes") uint64_t wc_field_stored_bytes(uint32_t id){return wc_user_field_stored_bytes(id);}
WC_EXPORT("wc_field_saved_bytes") uint64_t wc_field_saved_bytes(uint32_t id){return wc_user_field_saved_bytes(id);}
WC_EXPORT("wc_field_get") double wc_field_get(uint32_t id,uint32_t idx){return wc_user_field_get(id,idx);}
WC_EXPORT("wc_field_checksum") double wc_field_checksum(uint32_t id,uint32_t stride){return wc_user_field_checksum(id,stride);}
WC_EXPORT("wc_field_materialize") uint32_t wc_field_materialize(uint32_t id,uint32_t start,uint32_t count){return wc_user_field_materialize(id,start,count);}
WC_EXPORT("wc_field_scratch_get") double wc_field_scratch_get(uint32_t i){return wc_user_field_scratch_get(i);}

WC_EXPORT("wc_field_pair_checksum") double wc_field_pair_checksum(uint32_t a,uint32_t b,uint32_t count){return wc_user_field_pair_checksum(a,b,count);}

WC_EXPORT("wc_piecewise_field_count") uint32_t wc_piecewise_field_count(void){return wc_user_pwfield_count();}
WC_EXPORT("wc_piecewise_field_len") uint32_t wc_piecewise_field_len(uint32_t id){return wc_user_pwfield_len(id);}
WC_EXPORT("wc_piecewise_field_repr") uint32_t wc_piecewise_field_repr(uint32_t id){return wc_user_pwfield_repr(id);}
WC_EXPORT("wc_piecewise_field_segments") uint32_t wc_piecewise_field_segments(uint32_t id){return wc_user_pwfield_segments(id);}
WC_EXPORT("wc_piecewise_field_logical_bytes") uint64_t wc_piecewise_field_logical_bytes(uint32_t id){return wc_user_pwfield_logical_bytes(id);}
WC_EXPORT("wc_piecewise_field_stored_bytes") uint64_t wc_piecewise_field_stored_bytes(uint32_t id){return wc_user_pwfield_stored_bytes(id);}
WC_EXPORT("wc_piecewise_field_saved_bytes") uint64_t wc_piecewise_field_saved_bytes(uint32_t id){return wc_user_pwfield_saved_bytes(id);}
WC_EXPORT("wc_piecewise_field_get") double wc_piecewise_field_get(uint32_t id,uint32_t i){return wc_user_pwfield_get(id,i);}
WC_EXPORT("wc_piecewise_field_checksum") double wc_piecewise_field_checksum(uint32_t id,uint32_t stride){return wc_user_pwfield_checksum(id,stride);}


WC_EXPORT("wc_topology_count") uint32_t wc_topology_count(void){return wc_user_topology_count();}
WC_EXPORT("wc_topology_vertices") uint32_t wc_topology_vertices(uint32_t id){return wc_user_topology_vertices(id);}
WC_EXPORT("wc_topology_edges") uint32_t wc_topology_edges(uint32_t id){return wc_user_topology_edges(id);}
WC_EXPORT("wc_topology_beta0") uint32_t wc_topology_beta0(uint32_t id){return wc_user_topology_beta0(id);}
WC_EXPORT("wc_topology_beta1") uint32_t wc_topology_beta1(uint32_t id){return wc_user_topology_beta1(id);}
WC_EXPORT("wc_topology_euler") int32_t wc_topology_euler(uint32_t id){return wc_user_topology_euler(id);}
WC_EXPORT("wc_topology_proof_bits") uint32_t wc_topology_proof_bits(uint32_t id){return wc_user_topology_proof_bits(id);}
WC_EXPORT("wc_topology_bridges") uint32_t wc_topology_bridges(uint32_t id){return wc_user_topology_bridges(id);}
WC_EXPORT("wc_topology_articulations") uint32_t wc_topology_articulations(uint32_t id){return wc_user_topology_articulations(id);}
WC_EXPORT("wc_topology_free_group_rank") uint32_t wc_topology_free_group_rank(uint32_t id){return wc_user_topology_free_group_rank(id);}
WC_EXPORT("wc_topology_incidence_rank") uint32_t wc_topology_incidence_rank(uint32_t id){return wc_user_topology_incidence_rank(id);}
WC_EXPORT("wc_topology_laplacian_nullity") uint32_t wc_topology_laplacian_nullity(uint32_t id){return wc_user_topology_laplacian_nullity(id);}
WC_EXPORT("wc_topology_laplacian_proof_bits") uint32_t wc_topology_laplacian_proof_bits(uint32_t id){return wc_user_topology_laplacian_proof_bits(id);}
WC_EXPORT("wc_plan_count") uint32_t wc_plan_count(void){return wc_user_plan_count();}
WC_EXPORT("wc_plan_path_len") uint32_t wc_plan_path_len(uint32_t id){return wc_user_plan_path_len(id);}
WC_EXPORT("wc_plan_path_vertex") uint32_t wc_plan_path_vertex(uint32_t id,uint32_t k){return wc_user_plan_path_vertex(id,k);}
WC_EXPORT("wc_plan_rank") int32_t wc_plan_rank(uint32_t id){return wc_user_plan_rank(id);}
WC_EXPORT("wc_plan_cost") double wc_plan_cost(uint32_t id){return wc_user_plan_cost(id);}
WC_EXPORT("wc_plan_full_expansions") uint32_t wc_plan_full_expansions(uint32_t id){return wc_user_plan_full_expansions(id);}
WC_EXPORT("wc_plan_topo_expansions") uint32_t wc_plan_topo_expansions(uint32_t id){return wc_user_plan_topo_expansions(id);}
WC_EXPORT("wc_plan_pruned_vertices") uint32_t wc_plan_pruned_vertices(uint32_t id){return wc_user_plan_pruned_vertices(id);}
WC_EXPORT("wc_plan_homotopy_word_len") uint32_t wc_plan_homotopy_word_len(uint32_t id){return wc_user_plan_homotopy_word_len(id);}
WC_EXPORT("wc_plan_homotopy_letter") int32_t wc_plan_homotopy_letter(uint32_t id,uint32_t k){return wc_user_plan_homotopy_letter(id,k);}
WC_EXPORT("wc_plan_bench") uint64_t wc_plan_bench(uint32_t id,uint32_t pruned,uint32_t reps){return wc_user_plan_bench(id,pruned,reps);}
WC_EXPORT("wc_complex_count") uint32_t wc_complex_count(void){return wc_user_complex_count();}
WC_EXPORT("wc_complex_beta") uint32_t wc_complex_beta(uint32_t id,uint32_t dim){return wc_user_complex_beta(id,dim);}
WC_EXPORT("wc_complex_euler") int32_t wc_complex_euler(uint32_t id){return wc_user_complex_euler(id);}
WC_EXPORT("wc_complex_proof_bits") uint32_t wc_complex_proof_bits(uint32_t id){return wc_user_complex_proof_bits(id);}
WC_EXPORT("wc_complex_collapse_steps") uint32_t wc_complex_collapse_steps(uint32_t id){return wc_user_complex_collapse_steps(id);}

WC_EXPORT("wc_ipe_count") uint32_t wc_ipe_count(void){return wc_user_ipe_count();}
WC_EXPORT("wc_ipe_proof_bits") uint32_t wc_ipe_proof_bits(uint32_t id){return wc_user_ipe_proof_bits(id);}
WC_EXPORT("wc_ipe_original_nodes") uint32_t wc_ipe_original_nodes(uint32_t id){return wc_user_ipe_original_nodes(id);}
WC_EXPORT("wc_ipe_serial_nodes") uint32_t wc_ipe_serial_nodes(uint32_t id){return wc_user_ipe_serial_nodes(id);}
WC_EXPORT("wc_ipe_eliminated_orchestration") uint32_t wc_ipe_eliminated_orchestration(uint32_t id){return wc_user_ipe_eliminated_orchestration(id);}
WC_EXPORT("wc_ipe_scalarized_worker_slots") uint32_t wc_ipe_scalarized_worker_slots(uint32_t id){return wc_user_ipe_scalarized_worker_slots(id);}
WC_EXPORT("wc_ipe_fused_partitions") uint32_t wc_ipe_fused_partitions(uint32_t id){return wc_user_ipe_fused_partitions(id);}
WC_EXPORT("wc_ipe_partition_boundaries_removed") uint32_t wc_ipe_partition_boundaries_removed(uint32_t id){return wc_user_ipe_partition_boundaries_removed(id);}
WC_EXPORT("wc_ipe_schedule_node") uint32_t wc_ipe_schedule_node(uint32_t id,uint32_t k){return wc_user_ipe_schedule_node(id,k);}
WC_EXPORT("wc_ipe_bench") uint64_t wc_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){return wc_user_ipe_bench(id,optimized,reps);}

WC_EXPORT("wc_kernel_count") uint32_t wc_kernel_count(void){return wc_user_kernel_count();}
WC_EXPORT("wc_kernel_bound") uint64_t wc_kernel_bound(uint32_t id){return wc_user_kernel_bound(id);}
WC_EXPORT("wc_kernel_extent") uint64_t wc_kernel_extent(uint32_t id){return wc_user_kernel_extent(id);}
WC_EXPORT("wc_kernel_depth") uint32_t wc_kernel_depth(uint32_t id){return wc_user_kernel_depth(id);}
WC_EXPORT("wc_kernel_proof_bits") uint32_t wc_kernel_proof_bits(uint32_t id){return wc_user_kernel_proof_bits(id);}
WC_EXPORT("wc_kernel_transform_bits") uint32_t wc_kernel_transform_bits(uint32_t id){return wc_user_kernel_transform_bits(id);}
WC_EXPORT("wc_kernel_run") void wc_kernel_run(uint32_t id,uint32_t reps){wc_user_kernel_run(id,reps);}

WC_EXPORT("wc_eci_capability_count") uint32_t wc_eci_capability_count(void){return wc_user_eci_capability_count();}
WC_EXPORT("wc_eci_op_count") uint32_t wc_eci_op_count(void){return wc_user_eci_op_count();}
WC_EXPORT("wc_eci_capability_effect") uint32_t wc_eci_capability_effect(uint32_t id){return wc_user_eci_capability_effect(id);}
WC_EXPORT("wc_eci_capability_required") uint32_t wc_eci_capability_required(uint32_t id){return wc_user_eci_capability_required(id);}
WC_EXPORT("wc_eci_provider_count") uint32_t wc_eci_provider_count(uint32_t id){return wc_user_eci_provider_count(id);}
WC_EXPORT("wc_eci_provider_kind") uint32_t wc_eci_provider_kind(uint32_t id,uint32_t k){return wc_user_eci_provider_kind(id,k);}
WC_EXPORT("wc_eci_provider_hosts") uint32_t wc_eci_provider_hosts(uint32_t id,uint32_t k){return wc_user_eci_provider_hosts(id,k);}
WC_EXPORT("wc_eci_provider_priority") uint32_t wc_eci_provider_priority(uint32_t id,uint32_t k){return wc_user_eci_provider_priority(id,k);}
WC_EXPORT("wc_eci_provider_global_id") uint32_t wc_eci_provider_global_id(uint32_t id,uint32_t k){return wc_user_eci_provider_global_id(id,k);}
WC_EXPORT("wc_eci_select") uint32_t wc_eci_select(uint32_t cap,uint32_t host,uint32_t alo,uint32_t ahi){return wc_user_eci_select(cap,host,alo,ahi);}
WC_EXPORT("wc_eci_op_capability") uint32_t wc_eci_op_capability(uint32_t id){return wc_user_eci_op_capability(id);}
WC_EXPORT("wc_eci_op_boundary") uint32_t wc_eci_op_boundary(uint32_t id){return wc_user_eci_op_boundary(id);}
WC_EXPORT("wc_eci_op_opcode") uint32_t wc_eci_op_opcode(uint32_t id){return wc_user_eci_op_opcode(id);}
WC_EXPORT("wc_eci_call") uint64_t wc_eci_call(uint32_t op,uint64_t a0,uint64_t a1){return wc_user_eci_call(op,a0,a1);}
