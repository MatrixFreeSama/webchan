# Webchan 1.0.0

**Build:** `090920262021`  
**Language version:** `1.0.0`  
**Source extension:** `.webchan`  
**Compiler IR extension:** `.webir`

Webchan is an experimental **single-host-thread, proof-directed systems and numerical language** that compiles through its own semantic and structural analysis into internal C, then uses Clang/LLVM as the low-level backend for WebAssembly or native host integration.

Its central idea is simple:

> **Do not execute, store, synchronize, or materialize work that can be proved unnecessary.**

Webchan is therefore not designed around one algorithm family. The compiler reasons about **finite work, dependence, locality, algebraic structure, topology, data layout, and external effects**. A matrix, a bounded indexed kernel, a graph, and an imported fork-join region are different source objects, but they can contribute evidence to the same structural optimizer.

This README is a practical tutorial. It starts with a program that really compiles, then builds up to indexed kernels, structural linear algebra, topology, matrix-free fields, Inverse Parallel Expansion, and external capabilities.

---

## Table of contents

1. [What Webchan is](#1-what-webchan-is)
2. [Release scope and important boundaries](#2-release-scope-and-important-boundaries)
3. [Toolchain and directory layout](#3-toolchain-and-directory-layout)
4. [Quick start](#4-quick-start)
5. [Your first Webchan program](#5-your-first-webchan-program)
6. [How compilation works](#6-how-compilation-works)
7. [Core data forms](#7-core-data-forms)
8. [Bounded functions](#8-bounded-functions)
9. [Tasks, dependencies, and temporal execution](#9-tasks-dependencies-and-temporal-execution)
10. [Generic bounded indexed kernels](#10-generic-bounded-indexed-kernels)
11. [Predication and conditional local updates](#11-predication-and-conditional-local-updates)
12. [Structural Data Layout Algebra](#12-structural-data-layout-algebra)
13. [Matrix-free fields and piecewise fields](#13-matrix-free-fields-and-piecewise-fields)
14. [Structural linear algebra](#14-structural-linear-algebra)
15. [Structural topology and planning](#15-structural-topology-and-planning)
16. [Finite simplicial complexes](#16-finite-simplicial-complexes)
17. [Inverse Parallel Expansion](#17-inverse-parallel-expansion)
18. [External Capability Interface](#18-external-capability-interface)
19. [Generated files and runtime ABI](#19-generated-files-and-runtime-abi)
20. [Writing fast Webchan](#20-writing-fast-webchan)
21. [Safety model](#21-safety-model)
22. [Validation and regression testing](#22-validation-and-regression-testing)
23. [Common compiler errors](#23-common-compiler-errors)
24. [Current limitations](#24-current-limitations)
25. [Where to read next](#25-where-to-read-next)

---

# 1. What Webchan is

Webchan has four layers of responsibility.

```text
.webchan source
      ↓
semantic + termination + temporal checking
      ↓
structural proof and profitability analysis
      ↓
Webchan IR (.webir)
      ↓
internal generated C
      ↓
Clang / LLVM
      ↓
Wasm or native host integration
```

The language owns the first three layers. Clang/LLVM is deliberately used for instruction selection, register allocation, machine-level optimization, and final code generation.

The main structural domains in 1.0.0 are:

- **Structural Iteration Algebra (SIA)**: finite index domains, loop dependence, locality, gather/scatter structure, reduction/scan structure, and legality of loop transforms.
- **Structural Data Layout Algebra (SDLA)**: separates logical arrays from physical storage and can choose separate, interleaved, or tiled layouts after proof and profitability analysis.
- **Structural Linear Algebra**: detects properties such as diagonal, triangular, banded, symmetric, SPD, and diagonally dominant structure to select or collapse solver work.
- **Structural Topology**: proves graph components, cuts, cycles, Betti numbers, graph homotopy properties, and selected finite-complex properties.
- **Inverse Parallel Expansion (IPE)**: imports a finite parallel dependence description as evidence, then removes nonsemantic orchestration when a legal serial representation is proved.
- **External Capability Interface (ECI)**: declares semantic external abilities without hard-wiring Webchan to one vendor library or driver.

These are **property systems**, not application recognizers. The compiler does not need to know that a program is an FFT, a simulation, a renderer, a graph problem, or a signal-processing problem.

---

# 2. Release scope and important boundaries

Webchan 1.0.0 is a real compiler prototype with an executable Wasm runtime and a large regression suite, but it is not presented as an ecosystem-complete replacement for C, Rust, JavaScript, or general production toolchains.

## Implemented language forms

- scalar types: `f64`, `u32`, `i32`, `bool`;
- fixed-size arrays;
- structs and enums;
- bounded user functions;
- tasks and finite dependency DAGs;
- bounded nested indexed kernels;
- local scalar state inside kernels;
- statically proved indexed reads and writes;
- arithmetic and bitwise index maps;
- generic `if ... endif` predication inside kernels;
- static matrices and proof-directed solves;
- exact polynomial virtual fields;
- exact piecewise-polynomial fields;
- finite undirected graphs;
- finite simplicial complexes through dimension 2;
- finite imported fork-join/IPE regions;
- provider-neutral external capabilities.

## Deliberate boundaries

Webchan 1.0.0 does **not** claim:

- arbitrary unbounded `while` loops;
- recursive call cycles;
- unrestricted pointer alias mutation;
- dynamic heap/region/slice semantics comparable to mature systems languages;
- a complete package/module ecosystem;
- arbitrary floating-point reassociation;
- a cross-backend fused-multiply-add language contract;
- complete fundamental-group decision for arbitrary finite 2-complexes;
- higher homotopy groups;
- automatic recognition of every profitable data layout;
- a built-in FFT, stencil, sorting, rendering, simulation, or other workload opcode.

A missing proof never grants permission to guess. The compiler either keeps an exact fallback or rejects an operation whose safety cannot be established.

---

# 3. Toolchain and directory layout

The release was validated with:

```text
Clang 17.0.0
Node.js 22.16.0
Chromium 144.0.7559.96
GCC/cc 14.2.0
```

Equivalent recent toolchains may work, but the checked-in validation results correspond to the versions above.

## Repository layout

```text
compiler/                 Webchan compiler source
runtime/                  Webchan portable runtime
examples/                 complete example programs
host/                     Node/browser/native host probes
tests/                    regression and negative tests
docs/                     design and semantic documents
generated/                generated files from the main example
results/                  validation and benchmark reports
build_and_test.sh          full release build + regression entry point
README.md                  this tutorial
RELEASE_NOTES.md           release identity and included systems
```

---

# 4. Quick start

From the release root:

```bash
./build_and_test.sh
```

This compiles the Webchan compiler, compiles example programs, produces Wasm modules, runs Node/browser/native probes, executes positive and negative regression tests, validates the results, and refreshes `SHA256SUMS.txt`.

A successful release build ends with validation success and a zero process exit code.

If you only want the compiler:

```bash
cc -O2 -std=c11 compiler/webchanc.c -lm -o build/webchanc
```

The command-line interface is intentionally small:

```text
webchanc <input.webchan> <output-dir>
```

Example:

```bash
mkdir -p my_generated
./build/webchanc examples/universal.webchan my_generated
```

This produces, among other files:

```text
my_generated/program.webir
my_generated/webchan_program.c
my_generated/webchan_program.h
my_generated/procedural_fields.glsl
my_generated/external_capabilities.json
my_generated/webchan_eci_native.c
```

---

# 5. Your first Webchan program

A Webchan file contains more contract information than a traditional hello-world program because the compiler is expected to prove a bounded execution model rather than silently assume one.

The following is a minimal, actually compilable 1.0.0 program:

```text
webchan 1.0.0
module hello_webchan

target portable_wasm
profile universal
backend c_llvm_wasm
c_backend authoritative
generated_c internal_only
host_abi portable
execution single_host_thread

time_safety strict
frame_budget_ms 16.667
slice_budget_ms 2.0
max_continuous_ms 4.0
max_step_units 2048
default_step_units 512
yield_policy input_fair
group_commit progressive
implicit_barrier forbidden
causal_topology true
active_set_cap 16
chebyshev_order 4
chebyshev_tolerance 1e-8

optimization proof_directed
proof_policy profitable_only
wild_project_policy textbook_only
parallel_migration inverse_parallel_expansion

external_interface authority_first
c_abi_policy prefer
provider_policy replaceable
vendor_policy fallback_only

memory_mode dense
memory_recompute_budget 1
memory_scratch_cap 16

fn affine_demo effect bounded 8
repeat 1 affine 2.0 1.0
endfn

task main_task shed_rank 0 cost 1 deadline_ms 10 class visible fn affine_demo
```

Compile it:

```bash
mkdir -p out
./build/webchanc hello.webchan out
```

The most useful first file to inspect is:

```bash
cat out/program.webir
```

You should see the compiler-derived bound and structural proof for `affine_demo`, followed by the task node.

## What each block means

### `webchan 1.0.0`

Selects the language version. The 1.0.0 compiler rejects a mismatched language header.

### Backend declarations

```text
target portable_wasm
backend c_llvm_wasm
c_backend authoritative
generated_c internal_only
```

These state that Webchan semantics belong to Webchan, generated C is an internal lowering format, and Clang/LLVM is the authoritative low-level backend for this profile.

### Temporal contract

```text
time_safety strict
frame_budget_ms 16.667
slice_budget_ms 2.0
max_continuous_ms 4.0
```

These numbers describe the execution envelope used by the runtime and validation model. They are not decorative comments.

### Proof policy

```text
optimization proof_directed
proof_policy profitable_only
```

A transform requires legality proof first, then a profitability decision. A legal but unprofitable transform need not be performed.

### Bounded function

```text
fn affine_demo effect bounded 8
repeat 1 affine 2.0 1.0
endfn
```

The function declares an upper work bound. The compiler computes its own bound and rejects the program if the declaration is too small or if a recursive cycle makes termination unprovable.

### Task

```text
task main_task shed_rank 0 cost 1 deadline_ms 10 class visible fn affine_demo
```

A task binds a proved function to temporal metadata. Tasks are later connected by `depends` relationships into a DAG.

---

# 6. How compilation works

For a typical program, Webchan performs this sequence:

1. Parse declarations and hard-contract directives.
2. Check the language version and required execution policies.
3. Prove function termination and upper work bounds.
4. Analyze generic kernels for finite loop domains, symbol validity, and array bounds.
5. Derive iteration/dependence/locality structure.
6. Derive data-layout candidates and select only legal/profitable physical rewrites.
7. Analyze imported IPE regions for acyclicity, purity, privatization, and fusion opportunities.
8. Analyze virtual fields and matrix-free profitability.
9. Prove matrix structure and choose legal solver paths.
10. Analyze finite topology and finite simplicial complexes.
11. Resolve plans and external capability metadata.
12. Validate the task dependency DAG.
13. Emit Webchan IR, generated C/header files, capability metadata, and procedural-field output.
14. Let Clang/LLVM perform low-level code generation.

A useful mental model is:

```text
source meaning
    ↓
proof of what is legal
    ↓
proof/estimate of what is profitable
    ↓
physical representation
    ↓
machine code
```

Webchan deliberately keeps these stages separate. “Fast” is not allowed to mean “semantically guessed.”

---

# 7. Core data forms

## Scalar types

```text
f64
u32
i32
bool
```

These are the scalar types implemented in the current core.

## Fixed-size arrays

```text
array samples f64 1024
array flags u32 256
```

Array extent is part of the compile-time structure. This matters because generic kernel indexing is interval-proved against the declared extent.

Arrays are **logical objects**. Their physical storage can later be rewritten by SDLA while preserving logical indexing semantics.

## Structs

```text
struct Point x:f64 y:f64 weight:f64
```

Fields use `name:type` syntax.

## Enums

```text
enum Phase idle running done
```

The current struct/enum surface is intentionally small. It establishes real language types without pretending that 1.0.0 already contains a mature generic ADT ecosystem.

---

# 8. Bounded functions

A user function has this form:

```text
fn fast_affine effect bounded 160
repeat 60 affine 1.0000001192092896 0.00000037
endfn
```

The current bounded function body supports repeated affine operations, repeated polynomial operations, and bounded calls to other functions.

## Affine repetition

```text
repeat 60 affine A B
```

represents repeated application of an affine map.

Because composition of affine maps is itself affine, the structural optimizer can derive a collapsed map when legal and useful.

## Polynomial repetition

```text
repeat 32 poly a b c
```

is a bounded polynomial operation form used by the current prototype.

## Bounded calls

```text
fn shape_field effect bounded 420
repeat 32 poly 0.0000013 0.0000007 0.9999997
call fast_affine repeat 1
endfn
```

The compiler builds a function dependency graph, computes transitive work bounds, and rejects recursive cycles.

### Important rule

This is invalid in spirit even if written indirectly:

```text
A calls B
B calls A
```

Webchan 1.0.0 rejects recursive call cycles because the current execution contract requires statically bounded termination.

---

# 9. Tasks, dependencies, and temporal execution

Functions describe bounded computation. Tasks place computation into a temporal DAG.

```text
task input_event   shed_rank -1000 cost 30000 deadline_ms 4  class input   fn light_mix
task visible_model shed_rank  -500 cost 90000 deadline_ms 12 class visible fn shape_field

depends visible_model on input_event
```

## `shed_rank`

Lower values are more protected under overload. Larger values are easier to defer or shed according to the runtime policy.

It is not a mathematical priority inside every algorithm. It is task scheduling metadata.

## `cost`

A declared work/cost estimate used by the execution model.

## `deadline_ms`

Temporal target for that task.

## `class`

The current runtime recognizes task classes such as input, visible, frame, speculative, and background according to the source/runtime definitions.

## `depends`

```text
depends child on parent
```

builds the causal DAG. Cycles are rejected.

The runtime works from the ready frontier rather than inventing an implicit global barrier.

---

# 10. Generic bounded indexed kernels

This is the most conventional-looking numerical part of Webchan 1.0.0.

A kernel is a finite indexed computation with a declared upper work bound:

```text
kernel elementwise_affine effect bounded 10000
for i from 0 to len(kernel_in) step 1
set kernel_out[i] = 1.75 * kernel_in[i] + 0.25
endfor
endkernel
```

## Loop form

```text
for <index> from <start> to <end> step <positive-step>
    ...
endfor
```

The loop is half-open:

```text
[start, end)
```

The compiler requires a positive, statically provable step and a finite domain.

## Local scalars

```text
local f64 acc = 0.0
local u32 half = 1 << stage
```

Kernel locals can carry state across loop iterations when the structure is legal.

## Assignment

Array write:

```text
set output[i] = expression
```

Local update:

```text
set acc = acc + input[i]
```

## Nested loops

```text
kernel tiled_copy effect bounded 10000
for block from 0 to len(kernel_in) step 32
for lane from 0 to 32 step 1
set kernel_out[block + lane] = kernel_in[block + lane]
endfor
endfor
endkernel
```

The compiler records nesting depth and dependence/locality information.

## Neighbor/gather access

```text
kernel local_neighbor_relation effect bounded 10000
for i from 1 to 1023 step 1
set kernel_out[i] = 0.25 * kernel_in[i - 1]
                  + 0.5  * kernel_in[i]
                  + 0.25 * kernel_in[i + 1]
endfor
endkernel
```

All three reads must be proven in bounds over the whole loop domain.

## Prefix/scan-shaped state

```text
kernel prefix_state effect bounded 10000
local f64 acc = 0.0
for i from 0 to len(kernel_in) step 1
set acc = acc + kernel_in[i]
set kernel_scan[i] = acc
endfor
endkernel
```

The compiler recognizes loop-carried dependence. Recognition does **not** automatically authorize floating-point reassociation.

## Bitwise index maps

```text
kernel bitwise_permutation effect bounded 10000
for i from 0 to len(kernel_in) step 1
set kernel_perm[bit_reverse32(i) >> 22] = kernel_in[i]
endfor
endkernel
```

Current generic kernel expressions support arithmetic together with bitwise operations such as:

```text
<<
>>
&
|
^
```

and the generic `bit_reverse32()` operation.

When the low-level backend provides an appropriate bit-reverse intrinsic, Webchan can lower this generic operation to that backend capability. There is no workload-specific transform name involved.

## Portable math functions

Implemented kernel functions include:

```text
sin(x)
cos(x)
sqrt(x)
fabs(x)
len(array)
bit_reverse32(x)
```

`PI` is also available in kernel expressions.

The portable zero-import `sin`/`cos` implementation is a deterministic bounded numerical approximation. It is **not specified as a correctly rounded libm replacement**.

---

# 11. Predication and conditional local updates

Generic bounded kernels support lexical predication:

```text
if condition
    set array[index] = value
endif
```

This is a general finite conditional update, not an algorithm-specific branch.

A representative pattern is:

```text
kernel conditional_update effect bounded 10000
for i from 0 to len(values) step 1
local f64 x = values[i]
if x > 0.0
set output[i] = x
endif
endfor
endkernel
```

### Current restriction

Declare locals **before** entering an `if` block. Branch-local declarations are intentionally not accepted yet.

Valid:

```text
local f64 x = input[i]
if x > 0.0
set output[i] = x
endif
```

Not currently accepted:

```text
if input[i] > 0.0
local f64 x = input[i]
set output[i] = x
endif
```

This restriction keeps lexical lifetime and proof behavior explicit in the current implementation.

---

# 12. Structural Data Layout Algebra

One of Webchan's most important rules is:

> **Source-level logical layout is not automatically the final physical layout.**

Suppose the program declares:

```text
array real f64 4096
array imag f64 4096
```

and ordinary kernels repeatedly access:

```text
real[i]
imag[i]
```

The programmer has declared two logical arrays. The programmer has **not** commanded the compiler to use two separate physical allocations.

After legality analysis, SDLA can consider candidates such as:

```text
separate
interleaved
tiled-interleaved
scalarized
non-materialized
```

For a legal high-coaccess pair, physical storage may become conceptually:

```text
real0 imag0 real1 imag1 real2 imag2 ...
```

while source semantics remain:

```text
real[i]
imag[i]
```

## Why this matters

Physical layout affects:

- cache-line utilization;
- memory traffic;
- locality between fields;
- vectorization opportunities;
- amount and lifetime of materialized data.

## What triggers layout decisions

The current proof system considers generic structural evidence such as:

- same type;
- same extent;
- nonaliasing logical arrays;
- matched-index co-access;
- locality score;
- profitability threshold.

It does **not** accept source hints named after workloads such as `fft_layout`, `complex_layout`, `particle_layout`, `AoS`, or `SoA`.

## Stable logical ABI

Runtime array inspection functions continue to observe logical arrays even when they share physical storage. This separation is intentional.

---

# 13. Matrix-free fields and piecewise fields

Webchan can represent some large logical fields without automatically materializing every value.

Enable matrix-free memory policy:

```text
memory_mode matrix_free
memory_auto_affine true
memory_recompute_budget 6
memory_min_savings_bytes 4096
memory_scratch_cap 4096
```

## Exact polynomial virtual field

```text
field vertex_x f64 4000000 expr 7.0 + 3.2 * i
```

Logically, this is a field of four million values.

If exact reconstruction is proven and the recomputation/storage profitability gate approves it, the compiler can store the generating representation rather than all four million values.

Another example:

```text
field vertex_y f64 4000000 expr 1.0 + 0.5 * i + 0.000001 * i * i
```

## Why a field may remain materialized

A mathematically reconstructable field can still be rejected for virtual storage if recomputation is judged too expensive relative to the configured budget.

So Webchan distinguishes:

```text
can reconstruct exactly
```

from:

```text
should reconstruct on demand
```

The first is legality. The second is profitability.

## Piecewise fields

For discontinuous or piecewise structure:

```text
piecewise_field profile f64 4000000
segment 0 1000000 expr 1.0 + 0.00001*i
segment 1000000 2000000 expr 100.0 - 0.00002*i
segment 2000000 3000000 expr -40.0 + 0.000003*i*i
segment 3000000 4000000 expr 7.0
endpiecewise
```

Segments are half-open and must be contiguous, non-overlapping, and cover the full domain exactly. A gap is a semantic error, not merely a missed optimization.

---

# 14. Structural linear algebra

Webchan can describe a static matrix structurally rather than beginning with an opaque dense allocation.

## Symmetric band matrix

```text
array rhs f64 256
array solution f64 256

matrix A f64 256
band 0 4.0
band 1 -1.0 symmetric
endmatrix

solve primary_linear matrix A rhs rhs out solution strategy proof_auto tolerance 1e-8 max_iter 64
```

The compiler derives matrix properties and allows only solver paths whose preconditions are proved.

The current solver family includes paths corresponding to:

- dense Gaussian fallback;
- banded Gaussian;
- conjugate gradient;
- Chebyshev semi-iteration;
- Jacobi;
- Gauss-Seidel;
- weighted Jacobi;
- forward substitution;
- back substitution;
- diagonal direct solve.

These are backend/runtime strategy choices, not workload-specific source opcodes.

## Nonsymmetric diagonally dominant operator

```text
matrix B f64 256
band 0 4.0
band 1 -1.0 lower
band 2 -0.25 upper
endmatrix

solve nonsym_iterative matrix B rhs rhs out solution strategy proof_auto tolerance 1e-8 max_iter 96
```

If SPD cannot be proved, methods requiring SPD are not licensed. Other proved structure may still unlock a convergent method.

## Triangular collapse

```text
matrix L f64 256
band 0 3.0
band 1 -0.5 lower
endmatrix
```

A proved lower-triangular system can collapse to forward substitution rather than carrying generic iterative machinery.

## Diagonal collapse

```text
matrix D f64 256
band 0 2.0
endmatrix
```

A diagonal system reduces to independent divisions.

That is the general pattern of Webchan structural optimization:

```text
generic-looking problem
        ↓
proved special structure
        ↓
strictly smaller exact computation
```

---

# 15. Structural topology and planning

Webchan treats finite graph topology as a proof domain rather than as a special mapping or robotics subsystem.

## Declare a graph

```text
topology G nodes 4
edge 0 1 cost 0.2 plan_rank 5
edge 1 3 cost 0.2 plan_rank 5
edge 0 2 cost 1.0 plan_rank -5
edge 2 3 cost 1.0 plan_rank -5
endtopology
```

Rules include:

- graph is undirected;
- endpoints must be in range;
- self-edges are rejected;
- duplicate undirected edges are rejected;
- cost must be positive;
- `plan_rank` is signed and bounded by the implementation.

## Compiler-derived graph properties

The current topology engine can derive:

- connected components;
- `beta0`;
- bridges;
- articulation vertices;
- Euler characteristic;
- cycle rank / `beta1`;
- free-group rank for connected graph homotopy;
- tree/contractibility/simple-connectivity certificates at graph level.

For a connected finite graph:

```text
beta1 = E - V + 1
```

and the graph has homotopy type of a wedge of `beta1` circles.

## Rank-first planning

```text
plan route topology G start 0 goal 3 objective rank_then_cost
```

The current objective is lexicographic:

```text
min ( max edge.plan_rank on path,
      sum edge.cost on path )
```

Lower rank is preferred. Cost breaks ties after the minimax rank objective.

The compiler may remove topology that is proved irrelevant to the requested terminals before search, provided the optimum is preserved.

---

# 16. Finite simplicial complexes

Webchan 1.0.0 supports finite complexes with vertices, 1-simplices, and 2-simplices.

## Filled triangle

```text
complex filled_triangle vertices 3
simplex1 0 1
simplex1 1 2
simplex1 0 2
simplex2 0 1 2
endcomplex
```

A `simplex2` is accepted only if all three boundary edges already exist.

The current engine computes exact homology over GF(2):

```text
beta0
beta1
beta2
```

from the ranks of the boundary maps.

## Important soundness rule

For an arbitrary finite 2-complex:

```text
H1 = 0
```

is **not** treated as a proof that the complex is simply connected.

The implementation only marks contractibility/simple connectivity as verified when it has a supported certificate, such as an elementary simplicial collapse to a point.

This is an example of a broader Webchan rule: being unable to prove a true statement is preferable to silently claiming a stronger theorem than the implementation possesses.

---

# 17. Inverse Parallel Expansion

IPE handles a different problem from ordinary multithreaded execution.

It accepts a finite parallel-semantics description as evidence:

```text
parallel_region region workers 4
worker_local scratch f64 private

compute a fn fast_affine range 0 256 plan_rank 0
compute b fn fast_affine range 256 512 plan_rank 0

barrier all_done
pdepends all_done on a
pdepends all_done on b

join region_join
pdepends region_join on all_done
endparallel_region
```

The compiler then asks:

1. Is the dependence graph finite and acyclic?
2. Are compute functions proved pure enough for reordering?
3. Is worker-local state truly private/non-escaping under the supported model?
4. Are partitions disjoint and compatible?
5. Which orchestration objects are semantic, and which merely express a schedule?

When proof succeeds, Webchan can:

- erase nonsemantic spawn/barrier/join machinery;
- choose a legal serial causal order;
- scalarize supported private worker-local state;
- fuse compatible partitions;
- remove partition boundaries.

This is why the feature is called **Inverse Parallel Expansion**. It is not “run a parallel runtime with one worker.” It tries to recover the underlying computation from the orchestration description.

### `plan_rank` inside IPE

`plan_rank` only chooses among nodes that are already causally ready. It never overrides a dependency.

---

# 18. External Capability Interface

Webchan should not reimplement every operating-system, network, GPU, database, compression, USB, audio, camera, and vendor stack.

ECI separates the **semantic capability** from the **provider**.

## Declare a capability

```text
capability network.tcp optional effect potentially_blocking
capability gpu.compute optional effect asynchronous
capability compression.deflate optional effect immediate
```

## Declare an operation

```text
external_op tcp_recv capability network.tcp opcode 1 boundary explicit_blocking
external_op gpu_dispatch capability gpu.compute opcode 1 boundary async
external_op deflate capability compression.deflate opcode 1 boundary direct
```

The source asks for `gpu.compute`, not `cuda_driver`.

Provider selection is handled through the provider catalogue and host profile.

## Effect rules

### Immediate

May use:

```text
boundary direct
```

### Asynchronous

Must not silently use the direct critical path. Use:

```text
boundary async
```

or another explicitly stronger boundary supported by the contract.

### Potentially blocking

Must use:

```text
boundary explicit_blocking
```

A potentially blocking operation declared as direct is rejected before C lowering.

## Core Wasm vs ECI Wasm

The ordinary portable core can remain **zero-import**.

The ECI-enabled Wasm profile uses one explicit host dispatch surface:

```text
webchan_eci.dispatch(op_id, opcode, arg0, arg1)
```

This keeps foreign behavior visible at the module boundary instead of burying a large foreign runtime inside the core.

---

# 19. Generated files and runtime ABI

Running:

```bash
./build/webchanc input.webchan out
```

creates several files.

## `program.webir`

Human-readable compiler output describing proven bounds, structural properties, selected capabilities, layout decisions, solver choices, topology information, and other lowering metadata.

This is the best file to inspect when asking:

> “What did the Webchan compiler prove?”

## `webchan_program.c`

Internal generated backend code.

This file is **not** the language semantics and is not intended to become the human-facing programming surface.

## `webchan_program.h`

Generated runtime-facing ABI declarations.

## `procedural_fields.glsl`

Generated procedural-field material for supported graphics/procedural use paths.

## `external_capabilities.json`

Capability/provider metadata for ECI-enabled builds.

## `webchan_eci_native.c`

Generated native-side ECI adapter/probe material.

---

## Building a zero-import Wasm module manually

After generating a program:

```bash
clang \
  --target=wasm32 \
  -O3 \
  -ffast-math \
  -fno-builtin \
  -nostdlib \
  -Wl,--no-entry \
  -Wl,--export-memory \
  -Wl,--strip-all \
  -Iout \
  runtime/webchan_core.c \
  out/webchan_program.c \
  -o build/my_program.wasm
```

The release validation uses this portable zero-import core profile.

Inspect the module:

```bash
node tests/wasm_introspect.mjs build/my_program.wasm build/my_program_abi.json
cat build/my_program_abi.json
```

Run through the included Node host:

```bash
node host/node_runner.mjs build/my_program.wasm
```

### About `-ffast-math`

The shipped portable build script uses the flag above as part of its validated backend configuration. This does not mean Webchan's proof system is allowed to invent arbitrary source-level floating-point associativity. Source/IR legality and backend floating-point policy are distinct layers. If your application needs a different numerical contract, treat that as a deliberate build/profile decision and validate it accordingly.

---

# 20. Writing fast Webchan

Webchan performance work should begin with **structure**, not with workload names.

## 20.1 Give the compiler finite domains

Good:

```text
for i from 0 to len(a) step 1
```

Bad for the current language model:

```text
while unknown_condition
```

Finite domains unlock bound proof, locality analysis, and dependence reasoning.

## 20.2 Keep indexed relationships explicit

This:

```text
out[i] = a[i] + b[i]
```

contains useful locality evidence.

Hiding the same relationship behind opaque foreign mutation would remove proof opportunities.

## 20.3 Do not manually force a physical layout unless semantics require it

Declare logical arrays naturally:

```text
array x f64 N
array y f64 N
```

If matched-index locality proves that interleaving is profitable, SDLA can choose it.

Manual flattening can still be useful when the flattened structure is itself the program's semantic data model, but it should not be required merely to compensate for a compiler layout blind spot.

## 20.4 Prefer proved matrix structure over dense assembly

If the operator is banded, triangular, diagonal, or exactly reconstructable, express that structure. Do not assemble a dense object merely because a traditional API expects one.

## 20.5 Treat intermediate materialization as a cost

Temporary arrays, assembled matrices, copied partitions, and retained states all consume memory traffic and create more observable intermediate state.

When Webchan can prove that an intermediate can be reconstructed, fused, scalarized, or removed, less physical state may be preferable.

## 20.6 Separate legality from profitability

A transform can be mathematically legal and still be slower on a particular machine.

Webchan's intended order is:

```text
prove legality
    ↓
estimate profitability
    ↓
transform or keep fallback
```

## 20.7 Benchmark honestly

For language comparisons:

- use the same hardware;
- use release optimization for every language;
- state native/Wasm/VM lanes explicitly;
- do not put Python or another coordinator inside timed regions;
- verify outputs/checksums;
- use repeated measurements and medians;
- do not advertise “less work” as the same benchmark unless the semantic reduction is explicitly part of the comparison;
- do not lock competitors to intentionally poor algorithms or backends.

Webchan's compiler must not contain a workload-specific branch just to win a benchmark.

---

# 21. Safety model

Webchan uses several safety dimensions that should not be conflated.

## 21.1 Bounds safety

Generic kernel array indices are interval-proved against fixed array extents before lowering.

An unprovable or out-of-range write is rejected.

## 21.2 Termination and temporal safety

Bounded functions and kernels carry finite work evidence. Recursive call cycles and unbounded strict-path loops are rejected in 1.0.0.

This targets a class of failures that ordinary memory safety does not solve: a memory-safe program can still monopolize a browser main thread for too long.

## 21.3 Causal safety

Task and IPE dependency cycles are rejected. Rank metadata never licenses a dependency violation.

## 21.4 Capability/effect safety

Potentially blocking foreign work must be explicitly marked as blocking. Asynchronous work cannot silently masquerade as an immediate direct call.

## 21.5 Structural non-materialization

Webchan may avoid materializing a matrix, temporary field, or redundant state when exact reconstruction/elimination is proved and profitable.

This can reduce the amount and lifetime of recoverable intermediate information in memory.

It is important to use the correct security language:

> **Non-materialization is attack-surface reduction, not cryptographic encryption.**

A value that never exists in memory cannot be dumped from that memory location, but an attacker may still inspect inputs, outputs, machine code, registers, timing, or reimplement the mathematics. Use real cryptography when confidentiality requires cryptography.

---

# 22. Validation and regression testing

The authoritative release check is:

```bash
./build_and_test.sh
```

The test suite includes positive execution tests and compiler rejection tests.

Important negative cases include:

```text
invalid_cycle.webchan
invalid_while.webchan
invalid_recursion.webchan
invalid_bound.webchan
invalid_array.webchan
invalid_trusted_proof.webchan
invalid_memory_contract.webchan
invalid_piecewise_gap.webchan
invalid_topology_duplicate.webchan
invalid_complex_boundary.webchan
invalid_parallel_cycle.webchan
invalid_worker_local.webchan
invalid_eci_blocking.webchan
invalid_eci_unknown.webchan
invalid_kernel_oob.webchan
invalid_kernel_zero_step.webchan
invalid_kernel_symbol.webchan
invalid_kernel_bound.webchan
invalid_kernel_unclosed.webchan
```

Negative tests are important because a proof-oriented compiler is defined partly by what it refuses to assume.

After a full release build, inspect:

```text
results/VALIDATION.txt
results/REPORT.md
results/TOOLCHAIN.txt
results/compiler_negative.txt
```

The root `SHA256SUMS.txt` covers release files after the build script refreshes the tree.

---

# 23. Common compiler errors

## `unsupported Webchan version`

Your file does not begin with the supported header:

```text
webchan 1.0.0
```

## `invalid Webchan config`

One or more required execution values are missing or outside the accepted range, for example an invalid slice/frame relationship or too-small configured limits.

Start from the minimal program in this README or `examples/universal.webchan` rather than deleting contract directives at random.

## `Webchan 1.0.0 hard contract violated`

A required release policy was changed, such as proof-directed optimization, temporal safety, textbook-only wild-project policy, or ECI authority/provider policy.

## `temporal/termination check failed`

Typical causes:

- declared function bound is smaller than the compiler-computed bound;
- recursive call cycle;
- unsupported unbounded execution structure.

## `generic kernel ... write index out of proof range`

The compiler cannot prove every possible write index is inside the array.

Example mistake:

```text
array x f64 1024
for i from 0 to 1024 step 1
set x[i + 1] = 0.0
endfor
```

At `i = 1023`, the write becomes `x[1024]`, which is outside the array.

## `generic kernel ... expression failed symbol/bounds proof`

An expression references an unknown symbol, an unsupported expression form, or an array access whose interval cannot be proved.

## `branch-local declarations are not yet permitted`

Move the `local` declaration before the `if` and only assign inside the branch.

## `parallel region ... failed dependency/purity analysis`

The IPE graph may be cyclic, reference invalid nodes/functions, or fail the supported purity/private-state proof required for orchestration removal.

## `external blocking boundary rejection`

A potentially blocking capability operation was declared without `explicit_blocking`.

---

# 24. Current limitations

Webchan 1.0.0 is intentionally conservative. Important missing or incomplete areas include:

- general strings/text library;
- dynamic heap ownership/borrowing model;
- slices and arbitrary pointer graphs;
- mature modules/packages/generics;
- general pattern matching and recursive ADTs;
- production-scale error handling;
- general unbounded loops;
- recursive call cycles;
- arbitrary dynamic graph construction;
- arbitrary low-rank discovery;
- complete high-dimensional topology machinery;
- persistent homology and Morse theory;
- automatic geometry-to-complex construction;
- a universal cost model for all layout transformations;
- guaranteed optimal SIMD/vectorization;
- a cross-backend exact fused-multiply-add source primitive;
- full foreign-function signature generation from C headers.

These are boundaries, not hidden promises.

The design rule for future growth is the same as for 1.0.0:

```text
add a general semantic capability
        ↓
prove its legality
        ↓
connect it to existing structural domains
        ↓
optimize without workload-specific special cases
```

---

# 25. Where to read next

After this README, the most useful documents are:

- `docs/LANGUAGE_SPEC.md` — implemented language surface and grammar notes.
- `docs/WEBCHAN_CONTRACT.md` — hard semantic and safety rules.
- `docs/WEBCHAN_MANIFESTO.md` — consolidated project doctrine.
- `docs/STRUCTURAL_ITERATION_ALGEBRA.md` — finite index domains, dependence, locality, and transform proof gates.
- `docs/STRUCTURAL_DATA_LAYOUT_ALGEBRA.md` — logical arrays versus physical layout selection.
- `docs/STRUCTURAL_LINEAR_ALGEBRA.md` — matrix/operator structural proof system.
- `docs/STRUCTURAL_TOPOLOGY.md` — graph topology, homology, homotopy, and proof boundaries.
- `docs/TOPOLOGICAL_PLANNING.md` — topology pruning and rank/cost planning.
- `docs/INVERSE_PARALLEL_EXPANSION.md` — dependency recovery and orchestration erasure.
- `docs/EXTERNAL_CAPABILITY_INTERFACE.md` — provider-neutral external interfaces.
- `docs/MATRIX_FREE_MEMORY.md` — structural memory elimination and reconstruction policy.
- `examples/universal.webchan` — the broadest executable source example in the release.
- `results/REPORT.md` — measured release validation report.

---

# Final mental model

If you remember only one picture, use this one:

```text
                    Webchan source
                         │
             ┌───────────┴───────────┐
             │                       │
       semantic meaning         finite contracts
             │                       │
             └───────────┬───────────┘
                         ↓
                 structural proofs
        ┌────────────────┼────────────────┐
        │                │                │
   linear algebra     iteration        topology
        │                │                │
        └───────── data layout ───────────┘
                         │
                dependence / IPE
                         │
                external effects / ECI
                         ↓
                legal transformations
                         ↓
               profitability selection
                         ↓
              generated backend program
                         ↓
                    Clang / LLVM
                         ↓
                 WebAssembly / host
```

Webchan's job is not to replace every theorem, operating-system API, device driver, or machine-code optimizer.

Its job is to make **structure explicit enough to prove which work must exist, which work may move, which state must be stored, which state may disappear, and which external effects require a boundary**.

That is the programming model of Webchan 1.0.0.
