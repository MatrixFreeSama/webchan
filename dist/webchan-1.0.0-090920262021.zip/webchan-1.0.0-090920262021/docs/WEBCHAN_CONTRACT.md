# Webchan earlier release Hard Contract

1. `.webchan` is the language source; generated C is internal-only backend material.
2. Semantic checking and Webchan IR construction occur before C lowering.
3. Portable-core execution must not depend on HTML/DOM/JavaScript semantics.
4. The reference portable core may have zero imports.
5. C/LLVM is authoritative while semantically faithful and performance-competitive.
6. C semantics do not define Webchan semantics.
7. Causal DAG must be acyclic.
8. Only causally ready tasks may run.
9. Implicit barriers are forbidden.
10. Progressive completion is the default.
11. Atomic grouping is explicit-only.
12. Continuous Webchan-controlled host-thread occupation is bounded by the runtime entry contract.
13. Oversized host step requests are clamped inside Wasm.
14. Input fairness must be preserved by the host adapter.
15. Rank/deadline/class cannot violate causality.
16. PENDING and UNAVAILABLE are semantically distinct.
17. Deferred repair is required for temporary incomplete results.
18. Active physical working set must be independently boundable from logical history size.
19. Speculative run-ahead must be disposable and may not delay critical work.
20. Approximation requires an explicit tolerance/error contract.
21. Chebyshev/task-field collapse may not be applied merely because tasks are independent.
22. Known discontinuities must be partitioned or handled exact; no forced global smooth fit.
23. Incremental invalidation may only recompute the dependency cone of the changed node.
24. Unaffected completed tasks remain valid across local invalidation.
25. Invalidated task contributions must not be double-counted.
26. Matrix-free memory is explicit opt-in.
27. Storage may disappear only after reconstructability proof/certificate and profitability check.
28. Exact affine/polynomial representations may be selected automatically.
29. Piecewise compact representation requires exact full-domain coverage with no gaps/overlap.
30. Recompute budget and minimum-savings gates remain enforceable.
31. Temporary materialization has a hard scratch cap.
32. Failing a performance proof falls back to an exact generic path when safety does not require rejection.
33. Users cannot force mathematical optimizer facts through an unverified `proof` assertion.
34. Termination/call-cycle checks happen before backend generation.
35. Unbounded strict-path `while` is rejected in an earlier development milestone.
36. Sized array dimensions are checked before solver specialization.
37. Proof-directed numerical transforms must retain a generic exact fallback.
38. SPD/spectrum eligibility must be compiler derived under the implemented proof domain.
39. Structural speedups must report their baseline.
40. Semantic equivalence must be checked by residual/checksum/probe/error bounds as appropriate.
41. Failure-cliff and negative-gate tests are required for release claims.
42. Application names may not be used as optimizer preconditions in the general core.
43. OpenGL/other host code generation is a backend placement, not a language semantic.
44. GPU performance may not be claimed without a real execution measurement.
45. Wavelet and arbitrary automatic discontinuity discovery remain non-implemented architecture in an earlier development milestone and must not be reported as runtime features.
46. Runtime is the last line of defense, not the first: static proof/checking is preferred when possible.
47. Proof exists to establish safety or remove work/storage/checks, not as an end in itself.
48. Profitability follows proof: legal does not mean mandatory.
49. Webchan semantics first, backend lowering second.
50. The implementation status boundary in `WEBCHAN_MANIFESTO.md` is normative for release claims.

## Structural Algebra Addendum

- The compiler recognizes structural properties, not application labels.
- Linear algebra is a capability library, not a special application mode.
- Ordinary function IR may emit proof certificates for purity, affine composition, and monotonicity.
- A proved affine function chain may collapse before C lowering; a reference path must remain testable in release validation.
- Matrix/operator proofs may include static sparsity, exact matrix-free action, diagonal/triangular form, strict diagonal dominance, SPD and bounded spectrum.
- Jacobi requires a sound convergence certificate before it is callable as a proof-unlocked method.
- Gauss-Seidel requires a sound convergence certificate before it is callable as a proof-unlocked method.
- Weighted Jacobi parameters must be derived from proved spectral information, not arbitrary hidden tuning.
- Lower triangular structure may collapse to forward substitution; upper triangular to back substitution; diagonal to direct division.
- Global dense assembly may be removed only when an exact compact operator action is proved.
- Proof unlock never forces a transform; profitability decides among all proved-legal paths.
- If LLVM independently performs the same local optimization, Webchan must not claim a unique runtime speedup.
- Low-rank, general equality-saturation, arbitrary Newton basin proof and wavelet runtime remain non-implemented unless a release explicitly validates them.

## Structural Topology and Planning Addendum

51. Structural topology is a core compiler proof domain, not a host-side map/pathfinding wrapper.
52. Graph topology proofs must be derived from declared finite structure before C lowering.
53. `beta0`, `beta1`, bridges, articulation points and graph Euler characteristic must be exact for the supported graph model.
54. For a connected graph, fundamental-group rank may be derived from graph cycle rank; arbitrary 2-complex fundamental groups are not silently inferred.
55. A graph may be marked simply connected only when the graph proof domain establishes a connected acyclic structure.
56. Simplicial homology is computed from boundary operators; an earlier development milestone uses exact GF(2) arithmetic.
57. `H1=0` is never by itself promoted to a general 2-complex simple-connectivity certificate.
58. `contractible` / `simply_connected` for the current 2-complex engine requires a stronger certificate such as elementary collapse to a point.
59. Every accepted 2-simplex must have its full 1-simplex boundary declared.
60. `plan_rank` belongs to the Rank Family but is distinct from `shed_rank`.
61. Lower rank means more preferred/protected in both rank domains.
62. an earlier development milestone path rank is the maximum edge `plan_rank`; total path cost is the secondary objective.
63. Topology validity, causality and safety precede rank and cost.
64. Topology pruning may remove only states proved irrelevant to every simple start-goal route under the declared static topology.
65. Full and topology-pruned planners must preserve the same rank/cost optimum.
66. Signed plan ranks must not introduce negative-cycle semantics; the minimax aggregation is normative for an earlier development milestone.
67. Graph homotopy words are emitted relative to a compiler-selected maximal-tree basis and must be reduced by inverse cancellation.
68. Higher homotopy, arbitrary homeomorphism recognition and arbitrary finite-2-complex fundamental-group decision remain non-implemented unless a later release explicitly validates them.
69. Topological proofs may unlock planning/search/state collapse, but do not force it when profitability is poor.
70. Structural Topology and Structural Linear Algebra are peer libraries in the same General Structural Proof Optimizer.


## an earlier development milestone Inverse Parallel Expansion Addendum

71. IPE is a compiler/Webchan IR transform, not a host-side one-thread wrapper around a parallel runtime.
72. A `parallel_region` must be a finite DAG before orchestration elimination is considered.
73. Compute nodes must be proved pure under the current effect system before automatic reordering/orchestration erasure.
74. Barrier/join/spawn erasure preserves dependence constraints even when the runtime objects disappear.
75. `plan_rank` selects only among causally ready compute nodes; it never violates a dependency.
76. Private worker-local state may scalarize only when the language proves nonescape/private status under the supported region model.
77. Partition fusion requires disjoint contiguous ranges, the same proved-pure function, mutual independence and compatible rank.
78. Failed fusion proof leaves the compute nodes separate; it does not reject an otherwise valid region.
79. Cyclic parallel dependency graphs are rejected.
80. The release benchmark must compare naive serialized orchestration against the IPE representation with a semantic-equivalence witness.
81. The compiler hard contract requires `wild_project_policy textbook_only`.
82. Webchan may absorb textbook concepts but may not vendor/copy another project's optimizer, scheduler, project-specific IR or runtime as its implementation.
83. Toolchain backends remain explicitly external tools and do not define Webchan semantics.
84. Arbitrary races, externally visible synchronization and dynamic unbounded task creation are outside an earlier development milestone automatic IPE claims.
85. Floating-point reduction reassociation requires a future explicit arithmetic semantics contract; it is not inferred from parallelism alone.

## 1.0.0 ECI hard contract

A 1.0.0 release source must keep:

```text
external_interface authority_first
c_abi_policy prefer
provider_policy replaceable
vendor_policy fallback_only
```

The portable core remains allowed to be zero-import. A capability-enabled Wasm build must expose external work through explicit imports rather than hiding a foreign runtime inside the core.

Foreign/provider effects are checked before lowering. Potentially blocking operations may not silently enter the critical direct path.

The textbook-only wild-project rule applies to ECI as well: API names, specifications and ABI contracts may be used; implementation source from external runtimes/drivers is not vendored into Webchan.

## Structural Iteration Algebra extension

67. Finite indexed repetition is a peer structural proof domain; no workload-specific algorithm opcode may substitute for a structural proof.
68. Linear algebra, topology and IPE must be able to project compatible evidence into one finite-index operator capability graph.
69. Fusion, reordering, pruning, bounds elimination, scalar replacement and matrix-free lowering require structural legality evidence before profitability is considered.
70. A user-facing algorithm name such as FFT, sort, stencil, graph traversal or transform is not an optimization capability.
71. The compiler must distinguish the implemented SIA proof bridge from the not-yet-complete ordinary arbitrary indexed-loop source surface.
72. Future reduction/scan reassociation requires an exact or explicitly declared numerical semantics contract; floating-point associativity is never invented.
