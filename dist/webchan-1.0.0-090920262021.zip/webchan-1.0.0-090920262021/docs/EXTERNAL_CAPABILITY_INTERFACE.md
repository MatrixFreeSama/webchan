# Webchan 1.0.0 External Capability Interface (ECI)

## Purpose

ECI keeps Webchan out of the business of reimplementing operating-system, device, network, GPU, storage and vendor interfaces. Webchan owns the **semantic capability**, proof/effect metadata and provider-selection rule. The authoritative external project or platform owns the implementation.

Core rule:

`semantic capability -> authoritative provider catalogue -> host availability -> provider selection -> ABI lowering`

ECI is not a compatibility runtime and is not a vendor SDK bundled into Webchan.

## Source model

```text
external_interface authority_first
c_abi_policy prefer
provider_policy replaceable
vendor_policy fallback_only

capability network.tcp optional effect potentially_blocking
capability gpu.compute optional effect asynchronous
capability compression.deflate optional effect immediate

external_op tcp_recv capability network.tcp opcode 1 boundary explicit_blocking
external_op gpu_dispatch capability gpu.compute opcode 1 boundary async
external_op deflate capability compression.deflate opcode 1 boundary direct
```

A program declares **what external ability it needs**, not the library that must provide it.

## Effects and temporal boundaries

ECI has three implemented effect classes:

- `immediate`: may use `boundary direct`.
- `asynchronous`: must not be declared `direct`; use `async` or a stronger explicit boundary.
- `potentially_blocking`: must use `explicit_blocking`.

This rule is checked before C generation. A `potentially_blocking` TCP receive declared as `direct` is rejected.

The effect classification is a Webchan property. It does not claim that every operation of a provider has identical blocking behavior. Future per-operation catalogues may refine it.

## Provider authority order

For an eligible host, 1.0.0 resolver compares candidates by authority class first, provider priority second:

1. stable/general C ABI;
2. host standard interface;
3. vendor C ABI;
4. explicit low-level/vendor driver fallback.

This is a default policy, not a claim that a generic API always outperforms a vendor API. A future capability can be more specific when vendor-specific semantics are required.

Examples in the current catalogue include:

- filesystem: C stdio / WASI filesystem / browser file host;
- TCP: POSIX sockets / WinSock / WASI sockets / browser WebSocket;
- HTTP: libcurl / WASI HTTP / browser fetch;
- GPU compute: Vulkan compute / CUDA Driver / WebGPU;
- GPU rendering: OpenGL / Vulkan / WebGPU;
- packet I/O: DPDK / AF_XDP / RDMA verbs / explicit vendor driver;
- SQL: SQLite C ABI;
- compression: zlib C ABI;
- USB: libusb C ABI;
- audio: ALSA / WASAPI / WebAudio;
- camera: V4L2 / Media Foundation / browser media;
- monotonic timing: `clock_gettime` / browser `performance.now` / WASI monotonic clock.

The catalogue stores names and ABI/effect metadata only. It vendors no implementation code from these systems.

## Core vs capability build

The ordinary `webchan_core.wasm` remains provider-free and can have zero imports.

When external operations are needed, the ECI build imports exactly one host dispatch surface in 1.0.0:

```text
webchan_eci.dispatch(op_id, opcode, arg0, arg1)
```

Browser/Wasm hosts implement that bridge using the selected host provider. Native applications may instead use direct C ABI adapters and do not need to route native calls through JavaScript.

A zero-import core and an ECI-enabled module therefore have deliberately different ABI profiles.

## Host masks

1.0.0 defines four provider host families:

- native POSIX;
- native Windows;
- browser;
- WASI.

Hardware/vendor availability is separate from host eligibility. For example, a CUDA provider may be eligible on a native host but unavailable because no NVIDIA driver is installed.

## Native validation

The release contains a native C probe generated from the same provider catalogue. In the validation environment it performs real host operations for C stdio, POSIX sockets and the monotonic clock, and probes dynamic C ABI availability for optional libraries. A detected shared library means the interface is present enough to resolve symbols; it does not prove a physical device, permissions, or a working GPU context.

## Soundness boundaries

1.0.0 does **not** claim:

- that Webchan reimplements POSIX, WinSock, WebGPU, CUDA, Vulkan, DPDK or any driver;
- that a provider being loadable means a device is usable;
- that a generic provider and a vendor-specific provider have identical semantics;
- that all native libraries are safe to call on the critical host thread;
- automatic generation of arbitrary FFI signatures from C headers;
- complete lifetime/alias verification for opaque foreign objects;
- automatic sandbox escape from browser Wasm;
- direct browser access to native GPU or NIC drivers.

ECI's job is to preserve a small stable semantic boundary while delegating device/platform work to its authority.
