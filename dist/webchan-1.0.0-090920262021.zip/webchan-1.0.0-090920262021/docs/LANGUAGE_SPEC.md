# Webchan earlier release Implemented Language Surface

This is the implemented prototype surface, not a claim of ecosystem completeness.

## Header and hard-contract directives

Source begins with:

```text
webchan 1.2
```

The prototype also accepts the temporal, backend, proof, memory, non-smooth, topology and planning contract directives used by `examples/universal.webchan`.

## Data

Implemented core data forms:

- scalar types: `f64`, `u32`, `i32`, `bool`;
- fixed-size arrays;
- structs;
- enums;
- exact polynomial virtual fields;
- exact piecewise-polynomial fields;
- static band matrices;
- finite undirected topology graphs;
- finite simplicial complexes up to dimension 2.

## Functions

Bounded user functions currently support:

- repeated affine operation;
- repeated polynomial operation;
- bounded function call.

Recursive call cycles and unbounded strict-path `while` are rejected by the current checker.

## Tasks

```text
task name shed_rank R cost C deadline_ms D class visible fn f
```

`depends child on parent` builds the causal DAG.

Lower `shed_rank` means more protected under overload; larger values are easier to shed/defer.

## Structural linear algebra

```text
matrix A f64 256
band 0 4.0
band 1 -1.0 symmetric
endmatrix

solve s matrix A rhs rhs out solution strategy proof_auto tolerance 1e-8 max_iter 64
```

Proof-auto may legally select among:

1. dense Gaussian fallback
2. banded Gaussian
3. Krylov-CG
4. Chebyshev semi-iteration
5. Jacobi
6. Gauss-Seidel
7. weighted Jacobi
8. forward substitution
9. back substitution
10. diagonal direct

These IDs are ABI details, not workload-specific source opcodes.

## Matrix-free memory

`memory_mode matrix_free` is explicit opt-in. Exact virtual fields may become constant/affine/polynomial compact representations only after proof and profitability gates.

## Piecewise fields

```text
piecewise_field name f64 N
segment begin end expr polynomial-in-i
...
endpiecewise
```

Segments are half-open, contiguous, non-overlapping and must cover the whole domain exactly.

## Structural topology graphs

```text
topology G nodes N
edge u v cost C plan_rank R
...
endtopology
```

Rules:

- graph is undirected;
- `0 <= u,v < N`, `u != v`;
- duplicate undirected edges are rejected;
- `cost > 0`;
- `plan_rank` is signed and currently bounded to `[-1_000_000, 1_000_000]`.

Compiler-derived graph properties include components, bridges, articulation vertices, Euler characteristic, `beta0`, `beta1`, graph homotopy/free-group rank and tree/simple-connectivity certificates.

## Automatic planning

```text
plan route topology G start S goal T objective rank_then_cost
```

The an earlier development milestone objective is exactly:

```text
min ( max edge.plan_rank , sum edge.cost )
```

lexicographically.

The compiler may topology-prune terminal-irrelevant leaves before planning. The emitted plan includes path, rank, cost, expansion counts, pruned-vertex count and reduced graph-homotopy word.

## Finite simplicial complexes

```text
complex K vertices N
simplex1 a b
simplex1 b c
simplex1 a c
simplex2 a b c
endcomplex
```

A 2-simplex is accepted only after all three boundary 1-simplices exist.

an earlier development milestone computes exact GF(2) homology in dimensions 0, 1 and 2. Elementary collapse-to-point may certify contractibility/simple connectivity.

## Current boundary

Not complete in an earlier development milestone:

- strings and full text library;
- dynamic heap/regions/slices;
- packages/modules/generics/pattern matching;
- arbitrary structurally recursive ADTs;
- full error-handling ecosystem;
- wavelet runtime;
- arbitrary low-rank discovery;
- complete fundamental-group decision for arbitrary finite 2-complexes;
- higher homotopy groups;
- persistent homology/Morse theory;
- automatic geometry-to-complex construction.

No user-side `proof true` syntax exists. Optimization certificates are compiler-derived.

---

## an earlier development milestone Parallel-Semantics Import and IPE

Required release directives:

```text
wild_project_policy textbook_only
parallel_migration inverse_parallel_expansion
parallel_semantics dependency_preserving
orchestration_policy prove_then_erase
partition_policy proof_fuse
```

Finite static region grammar:

```text
parallel_region <name> workers <2..1024>
worker_local <name> <scalar-type> private
compute <node> fn <function> range <begin> <end> plan_rank <signed-int>
barrier <node>
join <node>
pdepends <child> on <parent>
endparallel_region
```

Rules:

- node names are unique within a region;
- compute ranges are nonempty;
- `pdepends` references already declared nodes in an earlier development milestone syntax;
- the complete region graph must be acyclic;
- compute functions must exist and be proved pure before automatic orchestration erasure;
- `plan_rank` is lower-first but never overrides dependencies;
- `worker_local` scalarization is currently limited to explicitly `private` declarations;
- partition fusion is optional and proof-gated, not required for region validity.

## 1.0.0 External Capability Interface

Release contract directives:

```text
external_interface authority_first
c_abi_policy prefer
provider_policy replaceable
vendor_policy fallback_only
```

Capability declaration:

```text
capability <dotted-name> required|optional effect immediate|asynchronous|potentially_blocking
```

External operation declaration:

```text
external_op <name> capability <dotted-name> opcode <u32> boundary direct|async|explicit_blocking
```

Static temporal rules:

- `potentially_blocking` requires `explicit_blocking`;
- `asynchronous` may not use `direct`;
- `immediate` may use `direct`;
- the capability must exist in the compiler's authority/provider catalogue;
- operations may reference only previously declared capabilities.

Provider names are deliberately absent from ordinary operation syntax. A program requests `gpu.compute`, not `cuda_driver` or `webgpu`.

## Structural Iteration Algebra and generic indexed kernels

Webchan IR contains the implemented Structural Iteration Algebra bridge and an executable ordinary source surface for finite indexed kernels. Existing matrices, topology graphs and IPE dependence regions are projected into the same finite-index operator capability graph.

Generic syntax:

```text
kernel <name> effect bounded <N>
  for <index> from <start> to <end> step <positive-step>
    local <f64|u32|i32|bool> <name> = <expression>
    set <array>[<index-expression>] = <expression>
    set <local> = <expression>
  endfor
endkernel
```

Rules:

1. Every loop bound and step must be statically range-provable; a step must be positive.
2. The compiler computes a finite work bound and rejects a kernel whose declared `effect bounded N` is smaller.
3. Every array read and write index is interval-proved inside the declared array extent before lowering.
4. Loop indices and integer locals may participate in arithmetic, division/modulo by proved nonzero constants, shifts and bitwise maps.
5. Nested loops, loop-carried locals, gather/scatter-shaped access and reduction/scan dependence classes are represented in SIA. Recognition does not itself authorize reassociation or reordering.
6. Mutation through unproved pointers/aliases is not part of this kernel surface.
7. Missing dependence/disjointness proof disables a transform or rejects an unsafe access; it never licenses guessed independence.
8. Workload names are not part of parser, Webchan IR or lowering dispatch. There is no FFT/butterfly/stencil/sort opcode.

Implemented portable kernel functions include `sin`, `cos`, `sqrt`, `fabs`, `len(array)` and `bit_reverse32`. The zero-import `sin`/`cos` lowering is a deterministic bounded numerical approximation and is not specified as a correctly rounded replacement for a platform libm.


## Structural Data Layout Algebra

There is intentionally no source syntax such as `interleaved`, `soa`, `aos`, `complex_layout` or `fft_layout`. Ordinary `array` declarations retain logical semantics. After generic kernel proof, Webchan IR derives compatible layout groups from access relations and lowers them to separate, element-interleaved or tiled physical storage when the profitability gate approves.

The public logical array ABI is stable across this transformation. Bounds are proved against logical extents before physical index lowering. Distinct logical arrays do not become source aliases merely because internal backing storage is shared.

Layout metadata is introspectable through `wc_array_layout_kind/group/lane/lanes/tile/score` and logical/physical byte queries. These functions expose compiler decisions for validation; they are not user hints.
