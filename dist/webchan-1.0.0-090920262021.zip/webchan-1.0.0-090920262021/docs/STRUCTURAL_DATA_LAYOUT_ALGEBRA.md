# Structural Data Layout Algebra (SDLA)

## Status

Implemented in Webchan 1.0.0 / Webchan IR.

SDLA is a compiler-owned physical storage transformation layer. It is not a container library, an FFT facility, a source-level struct wrapper, or a user-selected benchmark switch.

The source program keeps ordinary logical arrays:

```text
array x f64 N
array y f64 N
```

The compiler proves whether those logical arrays may share a physical layout and then lowers every kernel access, solver access and exported array ABI access through the chosen physical mapping. Logical array IDs, lengths, element types and values do not change.

## Why it exists

SIA proved iteration structure, but a legal iteration order can still be slowed by a poor relationship between computation topology and data topology. SDLA adds the missing question:

> Which physically stored ordering minimizes the traffic required by the already-proved access relation?

The optimization target is therefore:

```text
operator topology
+ iteration topology
+ data topology
-> legality proof
-> candidate layout cost
-> physical rewrite
```

## Implemented candidates

### Separate / SoA-like storage

Always legal. Each logical array owns a contiguous physical allocation.

Chosen when no sufficiently strong cross-array locality proof exists.

### Element interleaving / AoS-like storage

Multiple same-type, same-length logical arrays share one physical allocation:

```text
x0 y0 x1 y1 x2 y2 ...
```

The compiler selects this only when matched-index co-access evidence is high enough to pass the profitability gate.

### Tiled interleaving

Moderate co-access uses blocked field storage instead of forcing either full SoA or full AoS:

```text
x[0:T] y[0:T] | x[T:2T] y[T:2T] | ...
```

The current textbook heuristic uses an approximately 128-byte per-field block, scaled by element width. This is a profitability heuristic, not semantic proof.

### Scalarized bridge

Kernel locals with bounded lifetime already lower to local scalar state. SDLA records this as the scalarized endpoint rather than forcing them into memory arrays.

### Non-materialized bridge

Exact reconstructable fields and matrix-free operators can have no stored array at all. SDLA treats this as the zero-materialization endpoint already supplied by Webchan's matrix-free proof system.

## Legality proofs

A multi-array physical rewrite requires all of the following:

- identical element type;
- identical logical extent;
- distinct logical arrays, therefore no source-level pointer aliasing;
- bounded indexed accesses already accepted by SIA;
- matched-index locality evidence derived from ordinary kernel accesses;
- no change to logical array identity or public ABI semantics.

The compiler never asks the user to assert a trusted `noalias`, `interleaved`, `complex`, `FFT`, `particle`, `RGB`, or similar workload claim.

## Profitability evidence

The compiler collects array access relations from generic kernel statements. Accesses to compatible logical arrays at the same canonical index increase their co-access score. Adjacent statements at the same index also contribute because the corresponding values have short reuse distance.

Current selection policy:

- no strong relation -> separate;
- moderate matched-index locality -> tiled;
- high matched-index locality -> element-interleaved.

The score is emitted in Webchan IR and available through the runtime introspection ABI. The heuristic may evolve without changing language semantics.

## Physical rewrite

Generated C contains a shared physical storage object for each selected group and per-logical-array lvalue mappings. For an interleaved pair the mapping is equivalent to:

```c
physical[logical_index * 2 + lane]
```

For tiled groups it is equivalent to:

```c
tile_base + lane_block + offset_inside_tile
```

The mapping is used consistently by:

- generic indexed kernels;
- solver input/output paths;
- `wc_array_get`;
- `wc_array_set`;
- native and Wasm builds.

Thus the transformation is real storage lowering rather than metadata around unchanged arrays.

## Safety relation

SDLA does not weaken bounds safety. Logical index proofs are performed before layout lowering. The physical address formula is compiler-generated from a proved logical index and fixed layout metadata.

It also reduces the need for user-visible aliasing: distinct Webchan arrays remain distinct semantically even when the compiler chooses shared backing storage.

## Relationship to SIA, linear algebra and topology

SDLA is downstream of structural proof and upstream of final C/LLVM lowering:

```text
.webchan
  -> semantic / temporal / bounds proof
  -> Structural Iteration Algebra
  -> Structural Linear Algebra / Structural Topology / IPE evidence
  -> Structural Data Layout Algebra
  -> physical storage rewrite
  -> C / LLVM / Wasm or native
```

A matrix-free operator can therefore choose non-materialization, a local tuple can scalarize, a multi-field neighborhood can tile, and a tightly paired field can interleave under one structural optimization architecture.

## Explicit non-goals

Webchan IR does not claim:

- perfect cache modeling;
- profile-guided layout selection;
- arbitrary pointer-object graph relayout;
- transparent ABI relayout for external raw pointers;
- unrestricted heterogeneous-type packing;
- guaranteed performance improvement for every legal rewrite.

A legal transformation that fails the profitability gate remains separate storage.
