# Structural Iteration Algebra in Webchan 1.0.0

## Purpose

Structural Iteration Algebra (SIA) is the shared proof layer for **finite indexed repetition**. It sits between ordinary semantic checking and the existing Structural Linear Algebra / Structural Topology / IPE passes.

It exists because many workloads are not adequately described by either "a matrix" or "a graph" alone. They are better described as:

`finite index domain + access relation + dependence relation + local operator + stage order`

No application or algorithm name is part of the optimizer contract.

Core rule:

`finite index structure -> prove bounds/dependence/locality -> choose legal transform -> profitability -> exact fallback`

## 1. Why this is a root layer

The existing system already recognizes three fragments of the same mathematics:

- a band matrix describes a local relation between row and column indices;
- a topology graph describes a finite adjacency relation between vertices;
- an IPE region describes a finite dependence relation between compute ranges.

SIA lifts those into one finite-index operator view. This makes the following textbook transformations part of one capability graph instead of isolated tricks:

- loop/range fusion;
- legal re-linearization / topological scheduling;
- scalar replacement and privatization collapse;
- bounds-check elision from sized-domain proofs;
- sparse-work pruning;
- matrix-free operator action;
- algebraic composition/collapse;
- topology pruning;
- future loop interchange, tiling, vectorization and reduction/scan recognition when their proofs exist.

## 2. Current implemented source + proof bridge

Webchan IR emits `structural_iteration_algebra`. It now accepts both ordinary generic indexed kernels and the previously proved matrix/topology/IPE structures. All four sources lower into the same finite-index capability graph.

### Ordinary generic indexed kernels

The implemented 1.0.0 source surface is deliberately small and structural:

```text
kernel <name> effect bounded <N>
for <i> from <start> to <end> step <positive-step>
local <type> <name> = <expression>
set <array>[<proved-index>] = <expression>
set <local> = <expression>
endfor
endkernel
```

The compiler proves finite trip counts, symbol ranges and every indexed access before C/LLVM lowering. Nested bounded loops, loop-carried locals, affine/arithmetic index expressions, bitwise index expressions, gather/scatter-shaped access, and the reduction/scan dependence foundation are implemented. An unavailable proof rejects the source or removes an optimization; it never creates guessed independence.

The portable numerical expression surface also lowers `sin`, `cos`, `sqrt`, `fabs`, `len(array)` and `bit_reverse32` without introducing a workload-labelled opcode. The zero-import sine/cosine helpers are deterministic bounded-kernel approximations, not a claim of correctly rounded full-libm semantics.

Existing structural declarations continue to enter the same graph:

### Linear operators

A static matrix contributes:

- finite extent `n`;
- locality radius from bandwidth when proved;
- static sparsity;
- matrix-free action;
- sized bounds;
- linear-operator identity.

This allows Structural Linear Algebra to be viewed as a specialized library over a more general finite-index operator.

### Topological relations

A finite graph contributes:

- finite vertex domain;
- local adjacency relation;
- static sparse relation;
- exact graph topology proofs;
- maximum local degree metadata.

This gives Structural Topology a direct bridge to indexed local computation and future graph-neighborhood kernels.

### Dependence regions

An IPE region contributes:

- finite range extent;
- stage count / legal serial schedule;
- DAG proof;
- partition independence/fusion proof when available;
- rank-guided legal re-linearization;
- scalarizable private state.

This is the compiler-theory side of the same operator model.

## 3. Proof bits

The generated ABI exposes `wc_user_sia_*` metadata. Proof bits are compiler evidence, not user assertions.

Current bit meanings:

| Bit | Meaning |
|---:|---|
| 0 | finite domain |
| 1 | bounded execution domain |
| 2 | local access/relation |
| 3 | static sparsity/relation |
| 4 | matrix-free action |
| 5 | dependence DAG |
| 6 | partition independence proved |
| 7 | partition fusion proved |
| 8 | topology-structured relation |
| 9 | linear operator |
| 10 | sized/bounds proof |
| 11 | legal rank-guided re-linearization |

Transform bits currently expose already-implemented generic transformations:

| Bit | Transformation |
|---:|---|
| 0 | partition fusion |
| 1 | legal re-linearization |
| 2 | worker/private scalar replacement |
| 3 | matrix-free action |
| 4 | static-sparsity pruning/reuse |
| 5 | topology pruning |
| 6 | direct structural collapse (diagonal/triangular class) |

## 4. Relationship to textbook linear algebra

SIA treats a matrix action as an indexed operator rather than requiring a materialized global matrix.

Textbook correspondences include:

- permutation matrices -> index permutations;
- diagonal/block-diagonal matrices -> independent local transforms;
- band/sparse matrices -> bounded-neighborhood relations;
- products of operators -> stage composition;
- Kronecker/tensor products -> factored index spaces;
- iterative methods -> repeated operator action with loop-carried state;
- reductions such as dot products/norms -> associative or explicitly ordered accumulation domains.

Webchan must prove the legal structure before deleting, reordering or fusing work.

## 5. Relationship to textbook topology

Topological structure supplies the shape of legal communication/dependence:

- vertices -> index states;
- edges -> local relations;
- connected components -> independent domains;
- bridges/articulation points -> cut structure;
- spanning trees -> redundant-cycle collapse basis;
- DAGs -> legal stage orders;
- matchings/color classes -> future conflict-free simultaneous local updates;
- quotient/collapse -> smaller equivalent state spaces when certified.

This is why topology is not merely a planner subsystem. It can become a proof source for indexed computation.

## 6. Relationship to compiler loop theory

The approved textbook family is conventional dependence-based loop optimization:

- finite induction domains;
- dependence graphs;
- affine and eventually bitwise index maps;
- alias/disjointness proofs;
- fusion/fission;
- interchange;
- strip-mining/tiling;
- unrolling;
- vectorization legality;
- loop-invariant code motion;
- strength reduction;
- reduction and scan recognition.

These are **classes of transformations**, not imported compiler implementations.

## 7. Implemented boundary

The ordinary **generic index kernel** surface is implemented in 1.0.0/Webchan IR. The implemented contract includes:

- statically proved **bounded nested for** domains;
- mutable indexed reads and writes with compile-time range checking;
- general proved gather and scatter-shaped accesses;
- loop-carried scalar state;
- reduction and scan dependence recognition as a foundation for later transforms;
- arithmetic/affine and bitwise index maps;
- nested/staged local operators expressed only through the generic constructs above;
- generated native/Wasm C lowering with proved bounds checks elided from the hot kernel;
- Webchan IR and ABI metadata for finite-domain, access, dependence and transform legality.

The boundary remains intentionally strict. 1.0.0 does **not** claim unbounded `while`, arbitrary pointer aliasing, arbitrary opaque side effects inside kernels, automatically safe floating-point reassociation, or a complete polyhedral optimizer for every symbolic access map. Unsupported or unproved cases fall back conservatively or are rejected.

A real staged radix-2 transform is retained only as a regression probe. It compiles and executes through the same generic kernel path used by elementwise, neighborhood, prefix-state, permutation and tiled-loop probes. No transform-specific parser rule or lowering exists.

## 8. Anti-specialization rule

No transform may be unlocked by an algorithm label.

Forbidden design pattern:

`if algorithm == FFT -> special lowering`

Required design pattern:

`if finite domain + proved index relation + proved dependence/locality + legal algebraic transform -> generic lowering`

The same rule applies to sorting networks, stencils, graph kernels, wavelets, multigrid, finite-element local assembly, reductions, scans and future structured transforms.

## 9. Long-term target

The intended mature path is:

`ordinary bounded indexed code`

`-> index/dependence extraction`

`-> SIA finite-index operator graph`

`-> Structural Linear Algebra + Structural Topology + IPE proof libraries`

`-> fusion/reorder/prune/matrix-free/tile/vectorize when legal`

`-> C/LLVM lowering`

`-> exact fallback if a proof or profitability gate fails`

This keeps the language general while allowing highly structured numerical programs to expose their real mathematics to the compiler.


## Data-topology bridge

Webchan IR sends proved array access relations to Structural Data Layout Algebra after SIA has established logical bounds and dependence. SDLA may alter physical storage order, but it cannot change SIA's logical array identities, index domains or numerical dependence semantics.
