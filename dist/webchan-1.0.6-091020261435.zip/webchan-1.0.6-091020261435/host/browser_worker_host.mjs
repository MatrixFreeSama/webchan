/* Optional off-main-thread profile. Non-blocking main-thread semantics do not
   depend on this worker; it is an extra throughput profile. */
import {WebchanBrowserRuntime,browserHttpProvider} from './browser_runtime.mjs';
let rt=null;
self.onmessage=async ev=>{
  const m=ev.data;
  try{
    if(m.type==='init'){
      rt=new WebchanBrowserRuntime({wasm:m.wasm,manifest:m.manifest});rt.registerProvider('network.http',browserHttpProvider);await rt.init();self.postMessage({type:'ready'});return;
    }
    if(!rt)throw new Error('worker not initialized');
    if(m.type==='kernel'){const result=await rt.runKernelResponsive(m.id,m.options||{});self.postMessage({type:'kernel_done',id:m.id,result});return;}
    if(m.type==='event'){const ok=rt.enqueueEvent(m.eventType,BigInt(m.a0||0),BigInt(m.a1||0));self.postMessage({type:'event_ack',ok});return;}
  }catch(e){self.postMessage({type:'error',message:String(e.stack||e)});}
};
