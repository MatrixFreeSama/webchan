/* Webchan 1.0.6 browser host runtime.
   Generic async ECI, bounded streams/backpressure, event ingress, responsive
   kernel scheduling, incremental UTF-8 and coalesced DOM commits. */

const defer = (() => {
  if (typeof window !== 'undefined' && typeof MessageChannel !== 'undefined') {
    const q=[]; const ch=new MessageChannel(); ch.port1.onmessage=()=>{const r=q.shift(); if(r)r();};
    return () => new Promise(r=>{q.push(r);ch.port2.postMessage(0);});
  }
  return () => new Promise(r=>setTimeout(r,0));
})();

function clamp(x,a,b){ return Math.max(a,Math.min(b,x)); }
function f64Bits(v){const b=new ArrayBuffer(8),d=new DataView(b);d.setFloat64(0,Number(v),true);return d.getBigUint64(0,true);}
function packForType(type,v){
  if(type===0) return f64Bits(v);       // f64
  if(type===2) return BigInt.asUintN(32,BigInt(Math.trunc(Number(v)))); // i32 payload bits
  if(type===5) return BigInt.asUintN(64,BigInt(v));                    // u64
  return BigInt.asUintN(32,BigInt(Math.trunc(Number(v))));             // u32/bool/u8
}

export class IncrementalUTF8 {
  constructor(){this.decoder=new TextDecoder('utf-8',{fatal:true});this.closed=false;}
  push(bytes){if(this.closed)throw new Error('decoder closed');return this.decoder.decode(bytes,{stream:true});}
  finish(){if(this.closed)return '';this.closed=true;return this.decoder.decode();}
}

export class IncrementalLineFramer {
  constructor(){this.tail='';this.closed=false;}
  push(text){if(this.closed)throw new Error('framer closed');this.tail+=String(text);const parts=this.tail.split('\n');this.tail=parts.pop();return parts.map(x=>x.endsWith('\r')?x.slice(0,-1):x);}
  finish(){if(this.closed)return [];this.closed=true;const x=this.tail;this.tail='';return x.length?[x.endsWith('\r')?x.slice(0,-1):x]:[];}
}

/* Incremental Server-Sent Events framing. This is protocol-generic infrastructure:
   arbitrary event/data/id fields are emitted without application semantics. */
export class IncrementalSSE {
  constructor(){this.lines=new IncrementalLineFramer();this.resetEvent();}
  resetEvent(){this.event='message';this.data=[];this.id=null;this.retry=null;}
  _line(line,out){if(line===''){if(this.data.length||this.id!==null||this.event!=='message'){out.push({event:this.event,data:this.data.join('\n'),id:this.id,retry:this.retry});}this.resetEvent();return;}if(line.startsWith(':'))return;const k=line.indexOf(':');const field=k<0?line:line.slice(0,k),value=k<0?'':(line[k+1]===' '?line.slice(k+2):line.slice(k+1));if(field==='data')this.data.push(value);else if(field==='event')this.event=value||'message';else if(field==='id')this.id=value;else if(field==='retry'&&/^\d+$/.test(value))this.retry=Number(value);}
  push(text){const out=[];for(const line of this.lines.push(text))this._line(line,out);return out;}
  finish(){const out=[];for(const line of this.lines.finish())this._line(line,out);if(this.data.length||this.id!==null||this.event!=='message'){out.push({event:this.event,data:this.data.join('\n'),id:this.id,retry:this.retry});this.resetEvent();}return out;}
}

export class WebchanBrowserRuntime {
  constructor({wasm,manifest=null,providers={}}={}){
    this.wasm=wasm;this.manifest=manifest;this.providers=new Map(Object.entries(providers));
    this.instance=null;this.exports=null;this.memory=null;this.nextRequest=1n;this.requests=new Map();
    this.domQueue=new Map();this.domScheduled=false;this.stats={asyncStarted:0,asyncCompleted:0,asyncCancelled:0,backpressureWaits:0,domWritesQueued:0,domWritesCommitted:0};
  }
  registerProvider(key,fn){this.providers.set(key,fn);return this;}
  _op(op){return this.manifest?.operations?.find(x=>x.id===Number(op))||{id:Number(op),name:String(op),capability:'unknown',opcode:0,boundary:'direct'};}
  _providerFor(op){return this.providers.get(op.name)||this.providers.get(op.capability)||null;}
  _imports(){
    return {webchan_eci:{
      dispatch:(op,opcode,a0,a1)=>this._dispatch(Number(op),Number(opcode),a0,a1),
      async_start:(op,opcode,pool,tok,a0,a1)=>this._asyncStart(Number(op),Number(opcode),Number(pool),tok,a0,a1),
      async_cancel:req=>this._asyncCancel(req)
    }};
  }
  async init(){
    let bytes=this.wasm;
    if(typeof bytes==='string') bytes=await (await fetch(bytes)).arrayBuffer();
    if(bytes instanceof Response) bytes=await bytes.arrayBuffer();
    const result=await WebAssembly.instantiate(bytes,this._imports());
    this.instance=result.instance||result;this.exports=this.instance.exports;this.memory=this.exports.memory;
    return this;
  }
  _dispatch(opId,opcode,a0,a1){
    const op=this._op(opId),fn=this._providerFor(op);
    if(!fn){
      if(op.capability==='timer.monotonic' && typeof performance!=='undefined') return BigInt(Math.floor(performance.now()*1000));
      return 0xffffffffffffffffn;
    }
    const r=fn({runtime:this,op,opcode,arg0:a0,arg1:a1,signal:null});
    if(r&&typeof r.then==='function') throw new Error(`direct ECI provider returned Promise: ${op.name}`);
    return typeof r==='bigint'?r:BigInt(r??0);
  }
  _asyncStart(opId,opcode,pool,tok,a0,a1){
    const op=this._op(opId),fn=this._providerFor(op);if(!fn)return 0n;
    const id=this.nextRequest++,controller=new AbortController();
    const rec={id,op,pool,tok,controller};this.requests.set(id,rec);this.stats.asyncStarted++;
    Promise.resolve().then(()=>fn({runtime:this,op,opcode,arg0:a0,arg1:a1,signal:controller.signal,requestId:id}))
      .then(v=>{if(!this.requests.has(id))return;const type=this.exports.wc_future_value_type(pool);const bits=packForType(type,v?.value??v??0);if(this.exports.wc_future_resolve_bits(pool,tok,bits)){this.stats.asyncCompleted++;this.enqueueEvent(3,BigInt(pool),tok);}this.requests.delete(id);})
      .catch(err=>{if(!this.requests.has(id))return;const type=this.exports.wc_future_error_type(pool),code=err?.name==='AbortError'?1:2;this.exports.wc_future_fail_bits(pool,tok,packForType(type,code));this.enqueueEvent(4,BigInt(pool),tok);this.requests.delete(id);});
    return id;
  }
  _asyncCancel(req){
    req=BigInt(req);const r=this.requests.get(req);if(!r)return 0;r.controller.abort();this.exports.wc_future_cancel(r.pool,r.tok);this.requests.delete(req);this.stats.asyncCancelled++;return 1;
  }
  async runKernelResponsive(id,{budget,targetMs,maxContinuousMs,onSlice}={}){
    const e=this.exports;if(!e.wc_kernel_resumable(id))throw new Error(`kernel ${id} is not compiler-resumable`);
    e.wc_kernel_resume_reset(id);let b=budget||e.wc_default_step_units();const cap=e.wc_max_step_units();
    const target=targetMs??e.wc_slice_budget_ms_x1000()/1000;const ceiling=maxContinuousMs??e.wc_max_continuous_ms_x1000()/1000;
    let slices=0,totalUnits=0,maxSlice=0;const t0=performance.now();
    while(!e.wc_kernel_resume_done(id)){
      const s=performance.now(),used=e.wc_kernel_resume(id,b),dt=performance.now()-s;slices++;totalUnits+=used;maxSlice=Math.max(maxSlice,dt);onSlice?.({used,ms:dt,budget:b,cursor:e.wc_kernel_resume_cursor(id)});
      if(dt>0.02)b=clamp(Math.floor(b*(target/dt)*0.85),1,cap);else b=clamp(b*2,1,cap);
      /* Every generated slice returns to the browser. The ceiling governs when
         a host yield is mandatory; yielding every slice also preserves input fairness. */
      if(dt>=ceiling || !e.wc_kernel_resume_done(id)) await defer();
    }
    return {slices,totalUnits,maxSliceMs:maxSlice,totalMs:performance.now()-t0,targetMs:target,maxContinuousMs:ceiling};
  }
  async writeStream(id,bytes,{wait=true}={}){
    const e=this.exports;bytes=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);let off=0;const high=e.wc_stream_high_watermark(),low=e.wc_stream_low_watermark();
    while(off<bytes.length){
      const state=e.wc_stream_state(id);if(state!==0)throw new Error(`stream ${id} is not writable (state ${state})`);
      if(e.wc_stream_size(id)>=high){if(!wait)return off;this.stats.backpressureWaits++;do{await defer();if(e.wc_stream_state(id)!==0)throw new Error(`stream ${id} closed while backpressured`);}while(e.wc_stream_size(id)>low);continue;}
      const span=e.wc_stream_write_span(id);if(!span){if(!wait)return off;this.stats.backpressureWaits++;await defer();continue;}
      const room=high-e.wc_stream_size(id),n=Math.min(span,room,bytes.length-off);if(!n){continue;}const ptr=Number(e.wc_stream_write_ptr(id));new Uint8Array(this.memory.buffer,ptr,n).set(bytes.subarray(off,off+n));
      if(!e.wc_stream_write_commit(id,n))throw new Error('stream write commit rejected');off+=n;
    }
    return off;
  }
  readStream(id,maxBytes=1<<20){
    const e=this.exports,out=[];let total=0;
    while(total<maxBytes){const span=e.wc_stream_read_span(id);if(!span)break;const n=Math.min(span,maxBytes-total),ptr=Number(e.wc_stream_read_ptr(id));out.push(new Uint8Array(this.memory.buffer,ptr,n).slice());e.wc_stream_read_consume(id,n);total+=n;}
    const r=new Uint8Array(total);let p=0;for(const x of out){r.set(x,p);p+=x.length;}return r;
  }
  async pumpReadableStream(readable,streamId,{signal}={}){
    const reader=readable.getReader();try{for(;;){if(signal?.aborted)throw new DOMException('Aborted','AbortError');const {value,done}=await reader.read();if(done)break;if(value?.length)await this.writeStream(streamId,value);}this.exports.wc_stream_close(streamId);}catch(e){if(e?.name==='AbortError'){this.exports.wc_stream_cancel(streamId);try{await reader.cancel(e)}catch{}}else this.exports.wc_stream_fail(streamId);throw e;}finally{reader.releaseLock();}
  }
  enqueueEvent(type,a0=0n,a1=0n){return this.exports.wc_event_push(type,BigInt(a0),BigInt(a1));}
  drainEvents(handler,limit=64){let n=0,e=this.exports;while(n<limit&&e.wc_event_count()){const ev={type:e.wc_event_peek_type(),a0:e.wc_event_peek_a0(),a1:e.wc_event_peek_a1()};handler(ev);e.wc_event_consume();n++;}return n;}
  subscribeEvent(target,event,type,{map}={}){const el=typeof target==='string'?document.querySelector(target):target;if(!el)throw new Error(`event target not found: ${target}`);const fn=ev=>{let a0=0n,a1=0n;if(map){const v=map(ev);if(Array.isArray(v)){a0=BigInt(v[0]??0);a1=BigInt(v[1]??0);}else a0=BigInt(v??0);}return this.enqueueEvent(type,a0,a1);};el.addEventListener(event,fn);return()=>el.removeEventListener(event,fn);}
  _domKey(target,kind,name=''){return `${typeof target==='string'?target:'@'+(target.__wcDomId??(target.__wcDomId=Math.random().toString(36).slice(2)))}|${kind}|${name}`;}
  queueText(target,value){this._queueDOM(target,'text','',String(value));}
  queueAttribute(target,name,value){this._queueDOM(target,'attr',name,value==null?null:String(value));}
  queueProperty(target,name,value){this._queueDOM(target,'prop',name,value);}
  _queueDOM(target,kind,name,value){this.domQueue.set(this._domKey(target,kind,name),{target,kind,name,value});this.stats.domWritesQueued++;if(!this.domScheduled){this.domScheduled=true;(typeof requestAnimationFrame==='function'?requestAnimationFrame:setTimeout)(()=>this.commitDOM());}}
  commitDOM(){let n=0;for(const m of this.domQueue.values()){const el=typeof m.target==='string'?document.querySelector(m.target):m.target;if(!el)continue;if(m.kind==='text')el.textContent=m.value;else if(m.kind==='attr'){if(m.value==null)el.removeAttribute(m.name);else el.setAttribute(m.name,m.value);}else el[m.name]=m.value;n++;}this.domQueue.clear();this.domScheduled=false;this.stats.domWritesCommitted+=n;return n;}
}

/* Standard browser HTTP provider convention for ECI network.http opcode 1:
   arg0 = Webchan text id containing a UTF-8 URL; arg1 = bounded stream id.
   The Future resolves to HTTP status after the response body has been pumped
   through the bounded stream with backpressure. */
export function browserHttpProvider({runtime,arg0,arg1,signal}){
  const e=runtime.exports,textId=Number(arg0),streamId=Number(arg1),len=e.wc_text_len(textId),ptr=Number(e.wc_text_ptr(textId));
  const url=new TextDecoder().decode(new Uint8Array(runtime.memory.buffer,ptr,len));
  return fetch(url,{signal}).then(async r=>{if(r.body)await runtime.pumpReadableStream(r.body,streamId,{signal});else e.wc_stream_close(streamId);return r.status;});
}
