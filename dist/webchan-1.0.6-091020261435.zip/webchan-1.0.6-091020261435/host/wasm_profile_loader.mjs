/* Generic WebAssembly profile selector for Webchan packaging.
   It treats module validation/compilation as the authority: no UA sniffing and no browser-name tables. */
export async function instantiateBestWebchanProfile({scalarBytes, simd128Bytes, imports = {}, forceScalar = false}) {
  if (!scalarBytes) throw new Error('scalar fallback bytes are required');
  if (!forceScalar && simd128Bytes) {
    try {
      const module = await WebAssembly.compile(simd128Bytes);
      const instance = await WebAssembly.instantiate(module, imports);
      return { profile: 'simd128', module, instance, fallbackUsed: false };
    } catch (_) {
      // A rejected optional profile is ordinary capability fallback, not an application error.
    }
  }
  const module = await WebAssembly.compile(scalarBytes);
  const instance = await WebAssembly.instantiate(module, imports);
  return { profile: 'scalar', module, instance, fallbackUsed: !forceScalar && !!simd128Bytes };
}
