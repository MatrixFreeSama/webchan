/* Browser form of the generic Webchan Wasm profile selector. */
(function (g) {
  async function instantiateBestWebchanProfile(opts) {
    const scalarBytes = opts.scalarBytes, simd128Bytes = opts.simd128Bytes;
    const imports = opts.imports || {}, forceScalar = !!opts.forceScalar;
    if (!scalarBytes) throw new Error('scalar fallback bytes are required');
    if (!forceScalar && simd128Bytes) {
      try {
        const module = await WebAssembly.compile(simd128Bytes);
        const instance = await WebAssembly.instantiate(module, imports);
        return { profile: 'simd128', module, instance, fallbackUsed: false };
      } catch (_) {}
    }
    const module = await WebAssembly.compile(scalarBytes);
    const instance = await WebAssembly.instantiate(module, imports);
    return { profile: 'scalar', module, instance, fallbackUsed: !forceScalar && !!simd128Bytes };
  }
  g.WebchanWasmProfiles = { instantiateBestWebchanProfile };
})(globalThis);
