#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <dlfcn.h>

typedef struct{const char*cap;const char*name;uint32_t kind,hosts,priority;} wc_eci_native_provider;
extern const wc_eci_native_provider wc_eci_native_catalog[];
extern const uint32_t wc_eci_native_catalog_count;

static int can_dlopen(const char *a,const char *b){void*h=dlopen(a,RTLD_LAZY|RTLD_LOCAL);if(!h&&b)h=dlopen(b,RTLD_LAZY|RTLD_LOCAL);if(!h)return 0;dlclose(h);return 1;}
static int probe_provider(const char *n){
  if(!strcmp(n,"c_stdio")){FILE*f=tmpfile();if(!f)return 0;fputs("webchan",f);rewind(f);char b[8]={0};int ok=fread(b,1,7,f)==7&&!memcmp(b,"webchan",7);fclose(f);return ok;}
  if(!strcmp(n,"posix_sockets")){int s=socket(AF_INET,SOCK_STREAM,0);if(s<0)return 0;close(s);return 1;}
  if(!strcmp(n,"clock_gettime")){struct timespec ts;return clock_gettime(CLOCK_MONOTONIC,&ts)==0;}
  if(!strcmp(n,"zlib"))return can_dlopen("libz.so.1","libz.so");
  if(!strcmp(n,"sqlite3"))return can_dlopen("libsqlite3.so.0","libsqlite3.so");
  if(!strcmp(n,"vulkan_compute")||!strcmp(n,"vulkan_graphics"))return can_dlopen("libvulkan.so.1","libvulkan.so");
  if(!strcmp(n,"opengl"))return can_dlopen("libGL.so.1","libGL.so");
  if(!strcmp(n,"cuda_driver"))return can_dlopen("libcuda.so.1","libcuda.so");
  if(!strcmp(n,"libcurl"))return can_dlopen("libcurl.so.4","libcurl.so");
  if(!strcmp(n,"libusb"))return can_dlopen("libusb-1.0.so.0","libusb-1.0.so");
  if(!strcmp(n,"alsa"))return can_dlopen("libasound.so.2","libasound.so");
  if(!strcmp(n,"rdma_verbs"))return can_dlopen("libibverbs.so.1","libibverbs.so");
  if(!strcmp(n,"dpdk"))return can_dlopen("librte_eal.so.24","librte_eal.so");
  if(!strcmp(n,"af_xdp"))return can_dlopen("libbpf.so.1","libbpf.so");
  if(!strcmp(n,"v4l2"))return access("/dev/video0",F_OK)==0;
  return 0;
}
int main(void){uint32_t lo=0,hi=0,available=0;printf("{\"host\":\"native-posix\",\"catalogCount\":%u,\"providers\":[",wc_eci_native_catalog_count);for(uint32_t i=0;i<wc_eci_native_catalog_count;i++){int ok=probe_provider(wc_eci_native_catalog[i].name);if(ok){available++;if(i<32)lo|=1u<<i;else hi|=1u<<(i-32);}printf("%s{\"id\":%u,\"name\":\"%s\",\"available\":%s}",i?",":"",i,wc_eci_native_catalog[i].name,ok?"true":"false");}printf("],\"availableCount\":%u,\"availableLo\":%u,\"availableHi\":%u}\n",available,lo,hi);return 0;}
