#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo "usage: build_wasm_profiles.sh <generated-dir> <output-prefix> [core|eci]" >&2
  exit 2
fi
GEN=$(cd "$1" && pwd)
OUT=$2
MODE=${3:-core}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
[[ -f "$GEN/webchan_program.c" && -f "$GEN/webchan_program.h" && -f "$GEN/target_profiles.json" ]] || { echo "generated directory is incomplete" >&2; exit 3; }
EXTRA=()
if [[ "$MODE" == eci ]]; then EXTRA=(-DWC_ECI_IMPORTS=1); elif [[ "$MODE" != core ]]; then echo "mode must be core or eci" >&2; exit 4; fi
COMMON=(--target=wasm32 -O3 -ffast-math -fno-builtin -nostdlib -Wl,--no-entry -Wl,--export-memory -Wl,--strip-all)
mkdir -p "$(dirname "$OUT")"
clang "${EXTRA[@]}" "${COMMON[@]}" -mno-simd128 -I"$GEN" "$ROOT/runtime/webchan_core.c" "$GEN/webchan_program.c" -o "$OUT.scalar.wasm"
clang "${EXTRA[@]}" "${COMMON[@]}" -msimd128 -I"$GEN" "$ROOT/runtime/webchan_core.c" "$GEN/webchan_program.c" -o "$OUT.simd128.wasm"
cp "$OUT.scalar.wasm" "$OUT.wasm"
B=$(basename "$OUT")
printf '%s\n' "scalar=$B.scalar.wasm" "simd128=$B.simd128.wasm" "compatibility=$B.wasm"
