# Scalar Loop Housekeeping Probe Audit — Webchan 1.0.4

This audit records the probe chain that admitted the 1.0.4 change. The compiler implementation itself contains no motivating workload identity. The admitted mechanisms are classical Housekeeping Optimization only: induction-variable simplification/canonicalization, exact unsigned modular sentinel induction, and profitability-gated selective outlining.

## Admission chain

- **Origin probe:** a fixed-trip `u32` loop used a redundant derived induction `i = base + j`. The large whole-kernel path was already competitive, while repeatedly invoked short scalar work exposed a code-shape loss.
- **Cross-domain witness:** a separate `u32` mixing kernel with unrelated constants reproduced the benefit from eliminating the redundant induction relation.
- **Negative witnesses:** Gray-code/non-affine indexing, mutation of the affine base, runtime/local loop bounds, tiny kernels and oversized kernels either reject canonicalization or reject outlining.
- **Wrap witness:** starts near `UINT32_MAX`, including `0xfffffffe` and `0xffffffff`, remain bit-exact through modulo-`u32` wrap.

## Fresh Chromium A/B

Both paths are scalar Wasm. The 1.0.4 origin artifact is rebuilt by the release compiler with `-mno-simd128`.

| Session | 1M scalar chunk 1.0.3 | 1M scalar chunk 1.0.4 | Reduction | 400M whole 1.0.3 | 400M whole 1.0.4 | Whole delta |
|---|---:|---:|---:|---:|---:|---:|
| A | 1.0325 ms | **0.7875 ms** | **23.7%** | 286.95 ms | 289.75 ms | +0.98% |
| B | 1.0192 ms | **0.7917 ms** | **22.3%** | 293.40 ms | 290.35 ms | -1.04% |

The short-loop reduction repeats in both independent sessions. The whole-kernel delta changes sign and stays near one percent, so the release treats it as neutral/noise rather than claiming a whole-kernel speedup.

## Compiler proof gates

The implemented canonicalization requires all of the following:

1. source induction starts at zero;
2. unit stride;
3. independently compile-time-fixed positive trip count below `2^32`;
4. derived local is `u32`;
5. exact syntactic affine relation `base + iv` or `iv + base`;
6. base is a prior `u32` local and is loop-invariant;
7. original induction has no remaining semantic use;
8. derived local is not subsequently overwritten.

If these are proved, exact modulo-`u32` sentinel induction may be emitted. Otherwise the original exact loop remains. Outlining is a separate generic profitability gate and is never implied by legality.

## Anti-specialization result

`tests/optimization_provenance_gate.py` scans the optimizer source for motivating application, browser, competitor and benchmark identities. The release also checks that the provenance manifest classifies this change as Housekeeping and leaves the Luxury list unchanged.

## Claim boundary

This audit establishes a generic lowering defect and a conservative classical repair. It does not claim universal speed superiority, and it does not admit a new Webchan Luxury Optimization.
