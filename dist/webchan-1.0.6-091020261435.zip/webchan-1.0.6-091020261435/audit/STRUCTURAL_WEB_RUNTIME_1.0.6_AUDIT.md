# Webchan 1.0.6 Structural Web Runtime Audit

Release: `1.0.6`
Build: `091020261435`

## Structural equivalence

- Ordinary diagonal kernel receives the full typed linear passport and the same solver unlock mask as the equivalent declared diagonal matrix.
- Ordinary symmetric three-point stencil receives a banded linear passport and the same solver unlock mask as the equivalent declared band matrix.
- Nonlinear `x*x+1` witness receives no linear passport.
- Passport decisions are independent of kernel/matrix names.

## Topology bridge

Each release topology produces a graph-Laplacian linear passport with bits `0x189`: linear, symmetric, static sparsity and matrix-free action. Laplacian nullity equals `beta0`. SPD/strict-DD/positive-spectrum permissions remain absent and solver unlock remains zero without a stronger grounding proof.

## Resumable kernels

The structural probe compares the synchronous and resumable outputs bit-for-bit. A 256-element kernel executed through a budget of 17 work units required 16 resume calls and produced exact output parity.

Chromium heavy-kernel probing uses 2,000,000 arithmetic iterations. The responsive path yields between slices and retains browser event continuity; the synchronous path is retained as a blocking comparison.

## Stream/backpressure

The runtime stream capacity is 65,536 bytes. The stress probe transfers 200,000 bytes while the producer outruns the consumer. Peak occupancy stops at the 49,152-byte high-water mark and backpressure waits are observed.

## Async lifecycle

- Future enters pending state before request completion.
- Host completion resolves the exact `u64` result.
- Cancellation reaches the provider `AbortController`.
- Cancelled state is terminal against stale completion.
- Source-level `eci_async` and `eci_cancel` use the same ABI.

## Incremental text

A UTF-8 code point split as `E4 B8` and `AD` is reconstructed correctly. Malformed UTF-8 is rejected. SSE fields split across arbitrary chunk boundaries are reconstructed incrementally.

## Active set and events

The event mailbox is bounded by the configured active-set cap of 96. A 300-event stress input accepts 96 and records 204 explicit overflow events while preserving FIFO order for accepted events.

## Deferred repair

Repeated invalidation of the same completed leaf adds the dirty state once. The repair commit reopens that task once, clears the dirty set and recomputation restores the previous accumulator within floating-point roundoff (`~1.2e-16` relative error in the release probe).

## DOM batching

Chromium queues 1,000 writes to one text node before commit. Coalescing produces one committed write with final text `999`.

## Worker profile

The optional Chromium Worker executes the 2,000,000-unit heavy kernel through 978 slices. During the probe the main page timer continues firing and its measured maximum gap is below 10 ms in the recorded run. Worker placement is optional; responsive main-thread execution does not depend on it.

## Provenance

No new Luxury Optimization entry is introduced. The release broadens the applicability and runtime realization of the existing eight Luxury mechanisms. Optimizer predicates remain free of motivating application and competitor identities.
