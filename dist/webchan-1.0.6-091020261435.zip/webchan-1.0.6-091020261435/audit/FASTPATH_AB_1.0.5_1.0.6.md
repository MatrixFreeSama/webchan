# Fast-path A/B: Webchan 1.0.5 vs 1.0.6

Date: 2026-09-10

Purpose: check whether 1.0.6 structural-passport/resumable/runtime additions regress the inherited synchronous scalar hot path.

## Method

The exact `tests/profile_parity.webchan` source from the 1.0.5 release was compiled twice:

- 1.0.5 compiler + 1.0.5 runtime;
- 1.0.6 compiler + 1.0.6 runtime.

Both modules were built with Clang `-O3 -mno-simd128`. Disassembly found zero SIMD instruction lines in each module. Both modules were instantiated in the same Chromium process. Each sample executed kernel 0 for 20,000 repetitions after warmup; version order alternated across nine samples.

The semantic parity check after seven repetitions reported zero mismatching array elements.

## Results

1.0.5 samples, ms:

`81.7, 88.2, 81.1, 82.3, 80.1, 84.8, 80.8, 81.2, 83.1`

Median: **81.7 ms**

1.0.6 samples, ms:

`86.4, 82.9, 81.3, 80.7, 79.3, 79.4, 86.6, 80.8, 80.1`

Median: **80.8 ms**

Ratio `1.0.6 / 1.0.5`: **0.988984**.

Output mismatch: **0**.

Temporary scalar Wasm SHA-256 values:

- 1.0.5: `73c0d7866380767a9b576fdf5c762ca7ea007f72939e879515d7c8fdac577483`
- 1.0.6: `7bc2a4c85398be241d158e20f8a58ccbe1602b3a70f787cf653d2606fb6d5062`

1.0.5 release ZIP used for the baseline:

`16d07eb3faf5feb836839cea67fb170cece2fe2ad1341d2db903b03e354482b7`

## Interpretation

This probe shows no measured regression in the inherited synchronous fast path. It does not claim that 1.0.6 is universally 1.1% faster. The observed difference is small enough to treat as parity/noise; the important result is that the new resumable path was added beside, rather than in front of, the old hot path.
