# Webchan 1.0.5 Minimal Web Surface Audit

Release: `1.0.5`  
Build: `091020261329`

## Scope

This release changes source spelling and frontend inference only. The 1.0.4 optimization/runtime layer is not upgraded.

## Explicit vs minimal source

The paired regression sources are:

- `tests/surface/explicit.webchan`
- `tests/surface/minimal.webchan`

Measured source size:

| Form | Nonblank lines | Bytes |
|---|---:|---:|
| Explicit | 48 | 1198 |
| Minimal | 13 | 227 |

The release gate requires byte equality for seven generated files plus both Wasm profiles. The current result is:

- generated files: `7/7` byte-identical;
- scalar Wasm: byte-identical;
- SIMD128 Wasm: byte-identical.

Because the final Wasm modules are identical for the paired program, the concise surface cannot add execution-time work to that program.

## Lower-layer freeze

`docs/LOWER_LAYER_SHA256_1.0.4.txt` records the 1.0.4 hashes of ten lower-layer files. The 1.0.5 build runs `sha256sum -c` over this list. All ten pass.

Frozen areas include the portable runtime, iteration optimizer, data-layout optimizer, application support, target-profile build tool, and profile loaders.

## Legacy explicit-source comparison

A pristine 1.0.4 compiler and the 1.0.5 compiler were separately used to compile the same 1.0.4 explicit housekeeping probe.

Results:

- generated `webchan_program.c`: byte-identical;
- procedural GLSL: byte-identical;
- ECI capability JSON: byte-identical;
- ECI native adapter: byte-identical;
- generated header, Webchan IR, and target-profile manifest: equal after normalizing only release/build identity fields.

The raw record is `audit/LEGACY_EXPLICIT_EQUIVALENCE.json`.

## Surface coverage

`tests/surface/forms.webchan` independently exercises:

- omitted `webchan` header;
- omitted `module` declaration;
- inferred kernel bound;
- inferred function bound;
- `for ... in ... by ...`;
- typed `let`;
- direct assignment;
- nested `if/else/end`;
- bounded `while/end`;
- uniform kernel/function `end`;
- `entry` shorthand.

It resolves into the existing IR, including module `app`, a finite kernel bound, a finite function bound, and the standard visible root task.

## Optimization provenance

The optimizer inventory remains:

- Housekeeping Optimization: 20 entries;
- Luxury Optimization: 8 entries.

1.0.5 adds no entry to either list.
