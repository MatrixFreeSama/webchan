# Post-fix No-SIMD Four-Way Probe — Webchan 1.0.4

This is retained **probe evidence only**. It did not define or tune the 1.0.4 optimizer. The compiler change had already been derived from generic Housekeeping Optimization proofs and negative witnesses. The opponent implementations are not shipped as Webchan implementation material; only their measured result JSON and artifact hashes are retained here.

All three Wasm lanes were disassembled before the run and contained **zero SIMD instruction lines**. JavaScript used the normal Chromium/V8 engine rather than an artificially disabled JIT.

Two independent headless Chromium sessions used the same 400,000,000-iteration whole workload, the same 400 × 1,000,000 cooperative segmentation, and the same 240-card frame-pressure page.

| Engine | 400M synchronous, median of session means | 400×1M cooperative, median | 8M/frame compute, median | observed FPS, median |
|---|---:|---:|---:|---:|
| webchan | 298.50 ms | 864.95 ms | 6.473 ms | 59.35 |
| javascript | 320.32 ms | 900.40 ms | 6.377 ms | 58.13 |
| moonbit | 385.50 ms | 991.85 ms | 7.870 ms | 57.48 |
| wa | 777.62 ms | 1665.45 ms | 15.407 ms | 39.14 |

The post-fix probe therefore no longer reproduces the earlier “short scalar lane falls behind both JavaScript and MoonBit” ordering. Webchan remains competitive in the whole lane and, in both independent sessions, completes the cooperative lane before the retained controls. Frame-level ordering remains noisy near the 60 Hz cap, so this audit does not convert small FPS differences into a universal language claim.

## Artifact identities

- `webchan104_scalar` SHA-256: `9e5d8d89435684e7db0bac3ba6ae248d8e4ea384f9131904203e35d5f6b760f4`
- `moonbit_scalar_control` SHA-256: `2a80b94967eac4802535eea29e8de5962074c8dea9b46bde3c39ed11034b3cdc`
- `wa_optimized_control` SHA-256: `6dd22c11c84ff8738315dce6ca137c4f925105e3fda86d7f61672737466214ef`

## Independence boundary

The competitor binaries/sources are intentionally **not copied into the Webchan release tree**. Their hashes identify the external controls. The only files retained in this release are measurement JSON and this audit note. No opponent implementation or distinctive optimizer enters the compiler.
