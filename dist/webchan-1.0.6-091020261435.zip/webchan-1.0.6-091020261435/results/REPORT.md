# Webchan 1.0.6 Fresh Validation Report

Build: `091020261435`

## Summary

- Validation: **234 PASS / 0 FAIL**
- Negative compiler gates: **30/30**
- Housekeeping Optimization entries: **20**
- Luxury Optimization entries: **8**
- Housekeeping IV probes: **30/30**

## Minimal Web Surface retained

The 1.0.5 concise and explicit forms remain equivalent in 1.0.6: **7/7 generated files byte-identical**, scalar Wasm byte-identical = **True**, SIMD128 Wasm byte-identical = **True**. Source shrinks from 48 to 13 nonblank lines in the reference pair.

## Structural Passport

- Diagonal ordinary-kernel bits: `0x1ff`
- Stencil ordinary-kernel bits: `0x1fd`
- Nonlinear negative bits: `0x0`
- Resumable parity probe: 16 calls for 256 work units, exact-bit output parity verified.

Declared and ordinary forms receive the same solver permissions only when their proved properties match. The nonlinear witness receives no linear passport.

## Topology to linear proof bridge

All release graph Laplacians export typed linear bits `0x189` (linear + symmetric + static sparsity + matrix-free action). Their nullity equals topology `beta0`. SPD, strict diagonal dominance, positive-spectrum and solver permissions remain ungranted for the ungrounded Laplacian.

## Bounded web runtime

The stream stress probe transfers 200,000 bytes with a capacity of 65536 bytes. Peak occupancy is **49152 bytes** and backpressure waits = **4**.

Async start/completion/cancellation, stale-completion rejection, split UTF-8 decoding, incremental SSE framing and active-set-bounded FIFO event ingress all pass.

Deferred repair: first invalidation adds 1 dirty task(s), a repeated invalidation adds 0, and repair restores the previous result with relative error **1.199e-16**.

## Chromium

Responsive heavy kernel:

- total units: 2000000
- slices: 978
- maximum measured slice: 0.400 ms
- responsive event-gap probe: 10.700 ms
- direct synchronous event-gap probe: 35.400 ms
- DOM writes queued: 1000
- DOM writes committed after coalescing: 1

Optional Worker profile:

- total units: 2000000
- slices: 978
- main-page timer ticks while Worker ran: 1015
- main-page maximum measured gap: 5.200 ms

## Boundary

The responsive host measures time at compiler-generated resume boundaries. It is cooperative, not arbitrary preemptive interruption of a Wasm instruction. Opaque runtime data is not guessed into stronger mathematical structure. Proof failure remains an exact generic fallback.
