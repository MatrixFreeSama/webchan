#include "webchan_program.h"
#include <stdint.h>
static uint32_t wc_layout_group_0[8192];
#define WC_AREF_0(i) wc_layout_group_0[((((uint32_t)(i))>>5u)*64u)+0u+(((uint32_t)(i))&31u)]
#define WC_AREF_1(i) wc_layout_group_0[((((uint32_t)(i))>>5u)*64u)+32u+(((uint32_t)(i))&31u)]
/* General Application Semantics: bounded storage, no hidden host heap, no protocol-specific code. */
static uint64_t wc_f64_bits(double v){union{double d;uint64_t u;}q;q.d=v;return q.u;}static double wc_bits_f64(uint64_t v){union{double d;uint64_t u;}q;q.u=v;return q.d;}
uint32_t wc_user_region_count(void){return 0u;}
uint32_t wc_user_region_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_region_used(uint32_t id){switch(id){default:return 0;}}
void wc_user_region_reset(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_region_alloc(uint32_t id,uint32_t n,uint32_t align){if(!align)align=1u;if(align&(align-1u))return 0xffffffffu;switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_region_read8(uint32_t id,uint32_t off){switch(id){default:return 0;}}
uint32_t wc_user_region_write8(uint32_t id,uint32_t off,uint32_t v){switch(id){default:return 0;}}
uint64_t wc_user_region_ptr(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_text_count(void){return 0u;}
uint32_t wc_user_text_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_text_len(uint32_t id){switch(id){default:return 0;}}
void wc_user_text_clear(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_text_resize(uint32_t id,uint32_t n){switch(id){default:return 0;}}
uint32_t wc_user_text_get(uint32_t id,uint32_t off){switch(id){default:return 0;}}
uint32_t wc_user_text_set(uint32_t id,uint32_t off,uint32_t v){switch(id){default:return 0;}}
uint32_t wc_user_text_append_byte(uint32_t id,uint32_t v){switch(id){default:return 0;}}
uint32_t wc_user_text_append_text(uint32_t dst,uint32_t src){if(dst==src)return 0;switch(dst){default:return 0;}}
static uint32_t wc_utf8_valid_buf(const uint8_t*s,uint32_t n){uint32_t i=0;while(i<n){uint32_t c=s[i++];if(c<0x80u)continue;uint32_t need=0,min=0;if((c&0xe0u)==0xc0u){need=1;min=0x80u;c&=0x1fu;}else if((c&0xf0u)==0xe0u){need=2;min=0x800u;c&=0x0fu;}else if((c&0xf8u)==0xf0u){need=3;min=0x10000u;c&=0x07u;}else return 0;if(i+need>n)return 0;for(uint32_t k=0;k<need;k++){uint32_t d=s[i++];if((d&0xc0u)!=0x80u)return 0;c=(c<<6)|(d&0x3fu);}if(c<min||c>0x10ffffu||(c>=0xd800u&&c<=0xdfffu))return 0;}return 1u;}
uint32_t wc_user_text_utf8_valid(uint32_t id){switch(id){default:return 0;}}
int32_t wc_user_text_find_byte(uint32_t id,uint32_t start,uint32_t b){switch(id){default:return -1;}}
uint64_t wc_user_text_ptr(uint32_t id){switch(id){default:return 0;}}
static uint32_t wc_text_bounds(uint32_t id,uint32_t off,uint32_t n){uint32_t len=wc_user_text_len(id);return off<=len&&n<=len-off;}
uint32_t wc_user_text_write_u32_le(uint32_t id,uint32_t off,uint32_t v){if(!wc_text_bounds(id,off,4u))return 0;switch(id){default:return 0;}}
uint32_t wc_user_text_read_u32_le(uint32_t id,uint32_t off,uint32_t*out){if(!out||!wc_text_bounds(id,off,4u))return 0;switch(id){default:return 0;}}
uint32_t wc_user_text_write_f64_le(uint32_t id,uint32_t off,double v){if(!wc_text_bounds(id,off,8u))return 0;union{double d;uint64_t u;}q;q.d=v;switch(id){default:return 0;}}
uint32_t wc_user_text_read_f64_le(uint32_t id,uint32_t off,double*out){if(!out||!wc_text_bounds(id,off,8u))return 0;union{double d;uint64_t u;}q;q.u=0;switch(id){default:return 0;}}
uint32_t wc_user_vector_count(void){return 0u;}
uint32_t wc_user_vector_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_vector_len(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_vector_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
void wc_user_vector_clear(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_vector_push(uint32_t id,double v){switch(id){default:return 0;}}
uint32_t wc_user_vector_pop(uint32_t id,double*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_vector_set(uint32_t id,uint32_t idx,double v){switch(id){default:return 0;}}
double wc_user_vector_get(uint32_t id,uint32_t idx){switch(id){default:return 0.0;}}
uint32_t wc_user_vector_push_bits(uint32_t id,uint64_t v){switch(id){default:return 0;}}
uint32_t wc_user_vector_pop_bits(uint32_t id,uint64_t*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_vector_set_bits(uint32_t id,uint32_t idx,uint64_t v){switch(id){default:return 0;}}
uint64_t wc_user_vector_get_bits(uint32_t id,uint32_t idx){switch(id){default:return 0;}}
static uint64_t wc_map_hash(uint64_t x){x^=x>>30;x*=0xbf58476d1ce4e5b9ull;x^=x>>27;x*=0x94d049bb133111ebull;return x^(x>>31);}
uint32_t wc_user_map_count(void){return 0u;}
uint32_t wc_user_map_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_map_size(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_map_key_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_map_value_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
void wc_user_map_clear(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_map_put(uint32_t id,double kd,double vd){switch(id){default:return 0;}}
uint32_t wc_user_map_get(uint32_t id,double kd,double*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_map_remove(uint32_t id,double kd){switch(id){default:return 0;}}
uint32_t wc_user_map_put_bits(uint32_t id,uint64_t key,uint64_t vb){switch(id){default:return 0;}}
uint32_t wc_user_map_get_bits(uint32_t id,uint64_t key,uint64_t*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_map_remove_bits(uint32_t id,uint64_t key){switch(id){default:return 0;}}
uint32_t wc_user_result_count(void){return 0u;}
uint32_t wc_user_result_ok_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_result_err_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_result_tag(uint32_t id){switch(id){default:return 0;}}
void wc_user_result_clear(uint32_t id){switch(id){default:break;}}
void wc_user_result_set_ok(uint32_t id,double v){switch(id){default:break;}}
void wc_user_result_set_err(uint32_t id,double v){switch(id){default:break;}}
double wc_user_result_value(uint32_t id){switch(id){default:return 0.0;}}
void wc_user_result_set_ok_bits(uint32_t id,uint64_t v){switch(id){default:break;}}
void wc_user_result_set_err_bits(uint32_t id,uint64_t v){switch(id){default:break;}}
uint64_t wc_user_result_value_bits(uint32_t id){switch(id){default:return 0;}}
static uint32_t wc_tok_idx(uint64_t t){return (uint32_t)t;}static uint32_t wc_tok_gen(uint64_t t){return (uint32_t)(t>>32);}static uint64_t wc_tok_make(uint32_t i,uint32_t g){return ((uint64_t)g<<32)|i;}
uint32_t wc_user_future_pool_count(void){return 0u;}
uint32_t wc_user_future_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_future_value_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_future_error_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint64_t wc_user_future_create(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_future_state(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_resolve(uint32_t id,uint64_t tok,double v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_fail(uint32_t id,uint64_t tok,double v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_cancel(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_release(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
double wc_user_future_value(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0.0;}}
double wc_user_future_error(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0.0;}}
uint32_t wc_user_future_resolve_bits(uint32_t id,uint64_t tok,uint64_t v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_fail_bits(uint32_t id,uint64_t tok,uint64_t v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint64_t wc_user_future_value_bits(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint64_t wc_user_future_error_bits(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_handle_pool_count(void){return 0u;}
uint32_t wc_user_handle_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_handle_capability(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint64_t wc_user_handle_acquire(uint32_t id,uint64_t raw){switch(id){default:return 0;}}
uint64_t wc_user_handle_value(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_handle_release(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_state_machine_count(void){return 0u;}
uint32_t wc_user_state_machine_states(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_state_machine_events(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_state_machine_state(uint32_t id){switch(id){default:return 0xffffffffu;}}
void wc_user_state_machine_reset(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_state_machine_dispatch(uint32_t id,uint32_t ev){switch(id){default:return 0xffffffffu;}}
static uint32_t wc_bitreverse32(uint32_t x){return __builtin_bitreverse32(x);}
static double wc_fabs(double x){return x<0.0?-x:x;} static double wc_sin_poly(double x){double x2=x*x;return x*(1.0+x2*(-0.16666666666666665741+x2*(0.0083333333333333297482+x2*(-0.00019841269841269616281+x2*(0.0000027557319223985892511+x2*(-0.000000025052108385441718776+x2*0.00000000016059043836821614599))))));} static double wc_cos_poly(double x){double x2=x*x;return 1.0+x2*(-0.5+x2*(0.041666666666666664354+x2*(-0.0013888888888888872994+x2*(0.000024801587301587003346+x2*(-0.00000027557319223985890653+x2*0.0000000020876756987868098979)))));} static double wc_reduce_angle(double x){const double tp=6.28318530717958647692528676655900576;double q=x/tp;int64_t k=(int64_t)(q+(q>=0.0?0.5:-0.5));return x-(double)k*tp;} static double wc_sin(double x){x=wc_reduce_angle(x);const double hp=1.57079632679489661923132169163975144;if(x>hp)x=3.14159265358979323846264338327950288-x;else if(x<-hp)x=-3.14159265358979323846264338327950288-x;return wc_sin_poly(x);} static double wc_cos(double x){return wc_sin(x+1.57079632679489661923132169163975144);}
static void wc_kernel_0(void){for(uint32_t i=(uint32_t)(0);i<(uint32_t)(4096);i+=(uint32_t)(1)){uint32_t x=(uint32_t)(WC_AREF_0(i));WC_AREF_1(i)=(uint32_t)((x * 33) ^ 1515870810);}}
static uint32_t wc_kernel_cursor_0=0u;static uint8_t wc_kernel_done_0=0u;
static void wc_kernel_resume_reset_0(void){wc_kernel_cursor_0=0u;wc_kernel_done_0=0u;}
static uint32_t wc_kernel_resume_done_0(void){return wc_kernel_done_0;}
static uint32_t wc_kernel_resume_cursor_0(void){return wc_kernel_cursor_0;}
static uint32_t wc_kernel_resume_0(uint32_t budget){if(wc_kernel_done_0)return 0u;if(!budget)budget=1u;uint32_t used=0u;for(;used<budget&&wc_kernel_cursor_0<4096u;used++){uint32_t i=wc_kernel_cursor_0;uint32_t x=(uint32_t)(WC_AREF_0(i));WC_AREF_1(i)=(uint32_t)((x * 33) ^ 1515870810);wc_kernel_cursor_0+=1u;}if(wc_kernel_cursor_0>=4096u)wc_kernel_done_0=1u;return used;}
uint32_t wc_user_kernel_count(void){return 1u;}
uint64_t wc_user_kernel_bound(uint32_t id){switch(id){case 0:return 8192u;default:return 0;}}
uint64_t wc_user_kernel_extent(uint32_t id){switch(id){case 0:return 4096u;default:return 0;}}
uint32_t wc_user_kernel_depth(uint32_t id){switch(id){case 0:return 1u;default:return 0;}}
uint32_t wc_user_kernel_proof_bits(uint32_t id){switch(id){case 0:return 1667u;default:return 0;}}
uint32_t wc_user_kernel_transform_bits(uint32_t id){switch(id){case 0:return 156u;default:return 0;}}
void wc_user_kernel_run(uint32_t id,uint32_t reps){for(uint32_t r=0;r<reps;r++){switch(id){case 0:wc_kernel_0();break;default:return;}}}
uint32_t wc_user_kernel_resumable(uint32_t id){switch(id){case 0:return 1u;default:return 0;}}
void wc_user_kernel_resume_reset(uint32_t id){switch(id){case 0:wc_kernel_resume_reset_0();break;default:break;}}
uint32_t wc_user_kernel_resume(uint32_t id,uint32_t budget){switch(id){case 0:return wc_kernel_resume_0(budget);default:return 0xffffffffu;}}
uint32_t wc_user_kernel_resume_done(uint32_t id){switch(id){case 0:return wc_kernel_resume_done_0();default:return 0u;}}
uint32_t wc_user_kernel_resume_cursor(uint32_t id){switch(id){case 0:return wc_kernel_resume_cursor_0();default:return 0u;}}
uint32_t wc_user_kernel_structural_bits(uint32_t id){switch(id){case 0:return 0u;default:return 0;}}
uint32_t wc_user_kernel_operator_bandwidth(uint32_t id){switch(id){case 0:return 0u;default:return 0;}}
uint32_t wc_user_kernel_operator_src(uint32_t id){switch(id){case 0:return 4294967295u;default:return 0xffffffffu;}}
uint32_t wc_user_kernel_operator_dst(uint32_t id){switch(id){case 0:return 4294967295u;default:return 0xffffffffu;}}
uint32_t wc_user_kernel_solver_unlock_bits(uint32_t id){switch(id){case 0:return 0u;default:return 0;}}
typedef struct{uint16_t u,v;double cost;int32_t rank;} wc_topo_edge_rt;
static uint64_t wc_plan_rt(const wc_topo_edge_rt*e,uint32_t ne,uint32_t nv,uint32_t st,uint32_t go,const uint8_t*active,uint32_t reps){uint64_t checksum=0;for(uint32_t rep=0;rep<reps;rep++){int32_t rr[128];double cc[128];uint8_t used[128];for(uint32_t i=0;i<nv;i++){rr[i]=2147483647;cc[i]=1e300;used[i]=0;}rr[st]=(-2147483647-1);cc[st]=0.0;uint32_t expansions=0;for(uint32_t it=0;it<nv;it++){int32_t u=-1;for(uint32_t v=0;v<nv;v++)if((!active||active[v])&&!used[v]&&rr[v]!=2147483647&&(u<0||rr[v]<rr[u]||(rr[v]==rr[u]&&cc[v]<cc[u])))u=(int32_t)v;if(u<0)break;used[u]=1;expansions++;if((uint32_t)u==go)break;for(uint32_t k=0;k<ne;k++){uint32_t v=0xffffffffu;if(e[k].u==(uint32_t)u)v=e[k].v;else if(e[k].v==(uint32_t)u)v=e[k].u;if(v>=nv||(active&&!active[v]))continue;int32_t nr=rr[u]>e[k].rank?rr[u]:e[k].rank;double nc=cc[u]+e[k].cost;if(rr[v]==2147483647||nr<rr[v]||(nr==rr[v]&&nc<cc[v])){rr[v]=nr;cc[v]=nc;}}}checksum+=(((uint64_t)(uint32_t)rr[go]<<32)^(uint64_t)(cc[go]*1000000.0))+(uint64_t)rep+1u;}return checksum;}
static double wc_fn_ref_0(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_0(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_ref_0(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<1u;r++)v=v*1+0;return v;}
static double wc_fn_0(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;return 1*v+0;}
double wc_user_call(uint8_t id,double x,double t,uint32_t i,uint32_t task){switch(id){case 0:return wc_fn_0(x,t,i,task);default:return x;}}
double wc_user_call_reference(uint8_t id,double x,double t,uint32_t i,uint32_t task){switch(id){case 0:return wc_fn_ref_0(x,t,i,task);default:return x;}}
uint32_t wc_user_fn_structural_bits(uint32_t id){switch(id){case 0:return 7u;default:return 0;}}
uint64_t wc_user_fn_original_ops(uint32_t id){switch(id){case 0:return 2u;default:return 0;}}
uint64_t wc_user_fn_collapsed_ops(uint32_t id){switch(id){case 0:return 0u;default:return 0;}}
uint32_t wc_user_fn_bound(uint32_t id){switch(id){case 0:return 2u;default:return 0;}}
uint32_t wc_user_array_count(void){return 2u;}
uint32_t wc_user_array_len(uint32_t id){switch(id){case 0:return 4096u;case 1:return 4096u;default:return 0;}}
uint32_t wc_user_array_type(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;default:return 255u;}}
uint32_t wc_user_array_layout_kind(uint32_t id){switch(id){case 0:return 2u;case 1:return 2u;default:return 255u;}}
uint32_t wc_user_array_layout_group(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;default:return 255u;}}
uint32_t wc_user_array_layout_lane(uint32_t id){switch(id){case 0:return 0u;case 1:return 1u;default:return 0u;}}
uint32_t wc_user_array_layout_lanes(uint32_t id){switch(id){case 0:return 2u;case 1:return 2u;default:return 1u;}}
uint32_t wc_user_array_layout_tile(uint32_t id){switch(id){case 0:return 32u;case 1:return 32u;default:return 0u;}}
uint32_t wc_user_array_layout_score(uint32_t id){switch(id){case 0:return 8u;case 1:return 8u;default:return 0u;}}
int32_t wc_user_array_layout_profit(uint32_t id){switch(id){case 0:return 6;case 1:return 6;default:return 0;}}
uint32_t wc_user_array_layout_phase_coverage(uint32_t id){switch(id){case 0:return 1000u;case 1:return 1000u;default:return 0u;}}
uint32_t wc_user_array_layout_stream_ratio(uint32_t id){switch(id){case 0:return 1000u;case 1:return 1000u;default:return 0u;}}
uint32_t wc_user_array_layout_reason_bits(uint32_t id){switch(id){case 0:return 139u;case 1:return 139u;default:return 0u;}}
uint64_t wc_user_array_logical_bytes(uint32_t id){switch(id){case 0:return 16384u;case 1:return 16384u;default:return 0u;}}
uint64_t wc_user_array_physical_share_bytes(uint32_t id){switch(id){case 0:return 16384u;case 1:return 16384u;default:return 0u;}}
double wc_user_array_get(uint32_t id,uint32_t idx){switch(id){case 0:return idx<4096u?(double)WC_AREF_0(idx):0.0;case 1:return idx<4096u?(double)WC_AREF_1(idx):0.0;default:return 0.0;}}
void wc_user_array_set(uint32_t id,uint32_t idx,double v){switch(id){case 0:if(idx<4096u)WC_AREF_0(idx)=(uint32_t)v;break;case 1:if(idx<4096u)WC_AREF_1(idx)=(uint32_t)v;break;default:break;}}
uint64_t wc_user_array_get_bits(uint32_t id,uint32_t idx){switch(id){case 0:return idx<4096u?(uint64_t)WC_AREF_0(idx):0;case 1:return idx<4096u?(uint64_t)WC_AREF_1(idx):0;default:return 0;}}
void wc_user_array_set_bits(uint32_t id,uint32_t idx,uint64_t v){switch(id){case 0:if(idx<4096u)WC_AREF_0(idx)=(uint32_t)v;break;case 1:if(idx<4096u)WC_AREF_1(idx)=(uint32_t)v;break;default:break;}}
static uint8_t wc_memory_initialized;
static double wc_field_scratch[4096u];
void wc_user_memory_init(void){if(wc_memory_initialized)return;wc_memory_initialized=1;}
uint32_t wc_user_memory_mode(void){return 0u;}
uint32_t wc_user_field_count(void){return 0u;}
uint32_t wc_user_field_len(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_field_repr(uint32_t id){switch(id){default:return 255u;}}
uint32_t wc_user_field_proof_bits(uint32_t id){return id<0u?1u:0u;}
uint32_t wc_user_field_reconstruct_ops(uint32_t id){switch(id){default:return 0;}}
uint64_t wc_user_field_logical_bytes(uint32_t id){switch(id){default:return 0;}}
uint64_t wc_user_field_stored_bytes(uint32_t id){switch(id){default:return 0;}}
uint64_t wc_user_field_saved_bytes(uint32_t id){switch(id){default:return 0;}}
double wc_user_field_get(uint32_t id,uint32_t idx){switch(id){default:return 0.0;}}
double wc_user_field_checksum(uint32_t id,uint32_t stride){if(!stride)stride=1;double s=0.0;uint32_t n=wc_user_field_len(id);for(uint32_t i=0;i<n;i+=stride)s+=wc_user_field_get(id,i);return s;}
double wc_user_field_pair_checksum(uint32_t a,uint32_t b,uint32_t count){uint32_t na=wc_user_field_len(a),nb=wc_user_field_len(b);uint32_t n=count;if(n>na)n=na;if(n>nb)n=nb;double s=0.0;for(uint32_t i=0;i<n;i++){double x=wc_user_field_get(a,i),y=wc_user_field_get(b,i);s+=x*0.625+y*0.375;}return s;}
uint32_t wc_user_field_materialize(uint32_t id,uint32_t start,uint32_t count){uint32_t n=wc_user_field_len(id);if(start>=n)return 0;if(count>4096u)count=4096u;if(count>n-start)count=n-start;for(uint32_t k=0;k<count;k++)wc_field_scratch[k]=wc_user_field_get(id,start+k);return count;}
double wc_user_field_scratch_get(uint32_t i){return i<4096u?wc_field_scratch[i]:0.0;}
static uint8_t wc_pw_memory_initialized;
void wc_user_pw_memory_init(void){if(wc_pw_memory_initialized)return;wc_pw_memory_initialized=1;}
uint32_t wc_user_pwfield_count(void){return 0u;}
uint32_t wc_user_pwfield_len(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_pwfield_repr(uint32_t id){switch(id){default:return 255u;}}
uint32_t wc_user_pwfield_segments(uint32_t id){switch(id){default:return 0;}}
uint64_t wc_user_pwfield_logical_bytes(uint32_t id){switch(id){default:return 0;}}
uint64_t wc_user_pwfield_stored_bytes(uint32_t id){switch(id){default:return 0;}}
uint64_t wc_user_pwfield_saved_bytes(uint32_t id){switch(id){default:return 0;}}
double wc_user_pwfield_get(uint32_t id,uint32_t idx){switch(id){default:return 0.0;}}
double wc_user_pwfield_checksum(uint32_t id,uint32_t stride){if(!stride)stride=1;double s=0.0;uint32_t n=wc_user_pwfield_len(id);for(uint32_t i=0;i<n;i+=stride)s+=wc_user_pwfield_get(id,i);return s;}
#define WC_SOLVER_MAX_N 1u
static double wc_s_dense[WC_SOLVER_MAX_N*WC_SOLVER_MAX_N],wc_s_b[WC_SOLVER_MAX_N],wc_s_x[WC_SOLVER_MAX_N],wc_s_r[WC_SOLVER_MAX_N],wc_s_p[WC_SOLVER_MAX_N],wc_s_ap[WC_SOLVER_MAX_N];
static double wc_s_last_res[1];
static double wc_absd(double x){return x<0?-x:x;}
static uint32_t wc_mat_n(uint32_t id){switch(id){default:return 0;}}
static uint32_t wc_mat_bw(uint32_t id){switch(id){default:return 0;}}
static double wc_mat_get(uint32_t id,uint32_t i,uint32_t j){switch(id){default:return 0.0;}}
static uint32_t wc_s_mid(uint32_t s){switch(s){default:return 0;}}
static uint32_t wc_s_rhs(uint32_t s){switch(s){default:return 0;}}
static uint32_t wc_s_out(uint32_t s){switch(s){default:return 0;}}
static double wc_s_rhs_direct(uint32_t s,uint32_t i){switch(s){default:return 0.0;}}
static void wc_s_out_direct(uint32_t s,uint32_t i,double v){switch(s){default:break;}}
static uint32_t wc_s_maxiter(uint32_t s){switch(s){default:return 0;}}
static double wc_s_tol(uint32_t s){switch(s){default:return 1e-8;}}
static uint32_t wc_s_cheb_steps(uint32_t s){switch(s){default:return 0;}}
static double wc_s_cheb_omega(uint32_t s,uint32_t k){switch(s){default:return 0.0;}}
static void wc_matvec(uint32_t mid,const double*x,double*y){uint32_t n=wc_mat_n(mid),w=wc_mat_bw(mid);for(uint32_t i=0;i<n;i++){double z=0.0;uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)z+=wc_mat_get(mid,i,j)*x[j];y[i]=z;}}
static void wc_load_rhs(uint32_t sid){uint32_t n=wc_mat_n(wc_s_mid(sid));for(uint32_t i=0;i<n;i++){wc_s_b[i]=wc_s_rhs_direct(sid,i);wc_s_x[i]=0.0;}}
static void wc_store_x(uint32_t sid){uint32_t n=wc_mat_n(wc_s_mid(sid));for(uint32_t i=0;i<n;i++)wc_s_out_direct(sid,i,wc_s_x[i]);}
static double wc_residual(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_matvec(mid,wc_s_x,wc_s_ap);double mx=0.0;for(uint32_t i=0;i<n;i++){double z=wc_absd(wc_s_rhs_direct(sid,i)-wc_s_ap[i]);if(z>mx)mx=z;}return mx;}
static uint32_t wc_dense_gauss(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++)for(uint32_t j=0;j<n;j++)wc_s_dense[i*n+j]=wc_mat_get(mid,i,j);for(uint32_t k=0;k<n;k++){uint32_t p=k;double best=wc_absd(wc_s_dense[k*n+k]);for(uint32_t i=k+1;i<n;i++){double z=wc_absd(wc_s_dense[i*n+k]);if(z>best){best=z;p=i;}}if(best<1e-30)return 0;if(p!=k){for(uint32_t j=k;j<n;j++){double z=wc_s_dense[k*n+j];wc_s_dense[k*n+j]=wc_s_dense[p*n+j];wc_s_dense[p*n+j]=z;}double z=wc_s_b[k];wc_s_b[k]=wc_s_b[p];wc_s_b[p]=z;}for(uint32_t i=k+1;i<n;i++){double f=wc_s_dense[i*n+k]/wc_s_dense[k*n+k];wc_s_dense[i*n+k]=0.0;for(uint32_t j=k+1;j<n;j++)wc_s_dense[i*n+j]-=f*wc_s_dense[k*n+j];wc_s_b[i]-=f*wc_s_b[k];}}for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];for(uint32_t j=ii+1;j<n;j++)z-=wc_s_dense[ii*n+j]*wc_s_x[j];wc_s_x[ii]=z/wc_s_dense[ii*n+ii];}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_banded_gauss(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)wc_s_dense[i*n+j]=wc_mat_get(mid,i,j);}for(uint32_t k=0;k<n;k++){double piv=wc_s_dense[k*n+k];if(wc_absd(piv)<1e-30)return 0;uint32_t im=k+w+1<n?k+w+1:n,jm=k+w+1<n?k+w+1:n;for(uint32_t i=k+1;i<im;i++){double f=wc_s_dense[i*n+k]/piv;wc_s_dense[i*n+k]=0.0;for(uint32_t j=k+1;j<jm;j++)wc_s_dense[i*n+j]-=f*wc_s_dense[k*n+j];wc_s_b[i]-=f*wc_s_b[k];}}for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];uint32_t jm=ii+w+1<n?ii+w+1:n;for(uint32_t j=ii+1;j<jm;j++)z-=wc_s_dense[ii*n+j]*wc_s_x[j];wc_s_x[ii]=z/wc_s_dense[ii*n+ii];}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_cg(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);double rs=0.0,bn=0.0;for(uint32_t i=0;i<n;i++){wc_s_r[i]=wc_s_b[i];wc_s_p[i]=wc_s_r[i];rs+=wc_s_r[i]*wc_s_r[i];bn+=wc_s_b[i]*wc_s_b[i];}double target=tol*tol;uint32_t it=0;for(;it<mi&&rs>target;it++){wc_matvec(mid,wc_s_p,wc_s_ap);double den=0.0;for(uint32_t i=0;i<n;i++)den+=wc_s_p[i]*wc_s_ap[i];if(den<=1e-30)break;double a=rs/den;double rs2=0.0;for(uint32_t i=0;i<n;i++){wc_s_x[i]+=a*wc_s_p[i];wc_s_r[i]-=a*wc_s_ap[i];rs2+=wc_s_r[i]*wc_s_r[i];}if(rs2<=target){rs=rs2;it++;break;}double beta=rs2/rs;for(uint32_t i=0;i<n;i++)wc_s_p[i]=wc_s_r[i]+beta*wc_s_p[i];rs=rs2;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static uint32_t wc_cheb(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),steps=wc_s_cheb_steps(sid);wc_load_rhs(sid);for(uint32_t k=0;k<steps;k++){wc_matvec(mid,wc_s_x,wc_s_ap);double om=wc_s_cheb_omega(sid,k);for(uint32_t i=0;i<n;i++)wc_s_x[i]+=om*(wc_s_b[i]-wc_s_ap[i]);}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return steps;}
static uint32_t wc_jacobi(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];wc_s_ap[i]=z/d;}for(uint32_t i=0;i<n;i++)wc_s_x[i]=wc_s_ap[i];if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static uint32_t wc_gs(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];wc_s_x[i]=z/d;}if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static double wc_s_weighted_omega(uint32_t s){switch(s){default:return 1.0;}}
static uint32_t wc_wjacobi(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid),om=wc_s_weighted_omega(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];double target=z/d;wc_s_ap[i]=wc_s_x[i]+om*(target-wc_s_x[i]);}for(uint32_t i=0;i<n;i++)wc_s_x[i]=wc_s_ap[i];if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static uint32_t wc_forward(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){double z=wc_s_b[i];uint32_t j0=i>w?i-w:0;for(uint32_t j=j0;j<i;j++)z-=wc_mat_get(mid,i,j)*wc_s_x[j];double d=wc_mat_get(mid,i,i);if(wc_absd(d)<1e-30)return 0;wc_s_x[i]=z/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_back(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];uint32_t j1=ii+w+1<n?ii+w+1:n;for(uint32_t j=ii+1;j<j1;j++)z-=wc_mat_get(mid,ii,j)*wc_s_x[j];double d=wc_mat_get(mid,ii,ii);if(wc_absd(d)<1e-30)return 0;wc_s_x[ii]=z/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_diagonal(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i);if(wc_absd(d)<1e-30)return 0;wc_s_x[i]=wc_s_b[i]/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
uint32_t wc_user_solve_count(void){return 0u;}
uint32_t wc_user_solve_proof_bits(uint32_t s){switch(s){default:return 0;}}
uint32_t wc_user_solve_chosen(uint32_t s){switch(s){default:return 0;}}
uint64_t wc_user_solve_estimated(uint32_t s,uint32_t method){switch(s){default:return 0;}}
double wc_user_solve_residual(uint32_t s){return s<0u?wc_s_last_res[s]:0.0;}
uint32_t wc_user_solve(uint32_t s,uint32_t method){if(s>=0u)return 0;if(method==0)method=wc_user_solve_chosen(s);uint32_t bits=wc_user_solve_proof_bits(s);if(method==1)return wc_dense_gauss(s);if(method==2&&(bits&1u))return wc_banded_gauss(s);if(method==3&&(bits&2u))return wc_cg(s);if(method==4&&(bits&4u))return wc_cheb(s);if(method==5&&(bits&8u))return wc_jacobi(s);if(method==6&&(bits&16u))return wc_gs(s);if(method==7&&(bits&32u))return wc_wjacobi(s);if(method==8&&(bits&64u))return wc_forward(s);if(method==9&&(bits&128u))return wc_back(s);if(method==10&&(bits&256u))return wc_diagonal(s);return 0;}
enum{WC_SIA_LINEAR_OPERATOR=1u,WC_SIA_TOPOLOGY_RELATION=2u,WC_SIA_DEPENDENCE_REGION=3u,WC_SIA_INDEX_KERNEL=4u};
uint32_t wc_user_sia_count(void){return 1u;}
uint32_t wc_user_sia_kind(uint32_t id){if(id<0u)return WC_SIA_LINEAR_OPERATOR;id-=0u;if(id<0u)return WC_SIA_TOPOLOGY_RELATION;id-=0u;if(id<0u)return WC_SIA_DEPENDENCE_REGION;id-=0u;if(id<1u){switch(id){case 0:return WC_SIA_INDEX_KERNEL;default:return 0;}}return 0;}
uint32_t wc_user_sia_extent(uint32_t id){switch(id){case 0:return 4096u;default:return 0;}}
uint32_t wc_user_sia_stages(uint32_t id){switch(id){case 0:return 1u;default:return 0;}}
uint32_t wc_user_sia_locality(uint32_t id){switch(id){case 0:return 0u;default:return 0;}}
uint32_t wc_user_sia_proof_bits(uint32_t id){switch(id){case 0:return 1027u;default:return 0;}}
uint32_t wc_user_sia_transform_bits(uint32_t id){switch(id){case 0:return 0u;default:return 0;}}
#ifdef WC_IPE_BENCHMARK
typedef struct{uint16_t node;uint8_t fn;uint32_t begin,end;int32_t rank;} wc_ipe_desc;
static volatile uint64_t wc_ipe_sched_state;
static uint64_t wc_ipe_hash(double d,uint32_t i){int64_t q=(int64_t)(d*1000000000000.0);uint64_t z=(uint64_t)q^((uint64_t)i*0x9e3779b97f4a7c15ull);z^=z>>30;z*=0xbf58476d1ce4e5b9ull;z^=z>>27;z*=0x94d049bb133111ebull;return z^(z>>31);}
__attribute__((noinline)) static double wc_ipe_eval(uint8_t fn,uint32_t i){return wc_user_call(fn,(double)(i+1u)*0.000001,0.375,i,0u);}
#endif
uint32_t wc_user_ipe_count(void){return 0u;}
uint32_t wc_user_ipe_proof_bits(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_original_nodes(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_serial_nodes(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_eliminated_orchestration(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_scalarized_worker_slots(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_fused_partitions(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_partition_boundaries_removed(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_ipe_schedule_node(uint32_t id,uint32_t k){switch(id){default:return 0xffffffffu;}}
#ifdef WC_IPE_BENCHMARK
uint64_t wc_user_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){uint64_t total=0;switch(id){default:return 0;}}
#else
uint64_t wc_user_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){(void)id;(void)optimized;(void)reps;return 0;}
#endif
#ifdef WC_ECI_IMPORTS
__attribute__((import_module("webchan_eci"),import_name("dispatch"))) extern uint64_t wc_eci_host_dispatch(uint32_t,uint32_t,uint64_t,uint64_t);
__attribute__((import_module("webchan_eci"),import_name("async_start"))) extern uint64_t wc_eci_host_async_start(uint32_t,uint32_t,uint32_t,uint64_t,uint64_t,uint64_t);
__attribute__((import_module("webchan_eci"),import_name("async_cancel"))) extern uint32_t wc_eci_host_async_cancel(uint64_t);
#endif
uint32_t wc_user_eci_capability_count(void){return 0u;}
uint32_t wc_user_eci_op_count(void){return 0u;}
uint32_t wc_user_eci_capability_effect(uint32_t id){switch(id){default:return 255u;}}
uint32_t wc_user_eci_capability_required(uint32_t id){switch(id){default:return 0u;}}
static uint32_t wc_eci_local_provider_global(uint32_t cap,uint32_t k){switch(cap){default:return 0xffffffffu;}}
uint32_t wc_user_eci_provider_count(uint32_t cap){switch(cap){default:return 0;}}
uint32_t wc_user_eci_provider_global_id(uint32_t cap,uint32_t k){return wc_eci_local_provider_global(cap,k);}
uint32_t wc_user_eci_provider_kind(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){case 0:return 0u;case 1:return 1u;case 2:return 1u;case 3:return 0u;case 4:return 0u;case 5:return 1u;case 6:return 1u;case 7:return 0u;case 8:return 1u;case 9:return 1u;case 10:return 2u;case 11:return 0u;case 12:return 1u;case 13:return 0u;case 14:return 0u;case 15:return 1u;case 16:return 0u;case 17:return 0u;case 18:return 0u;case 19:return 3u;case 20:return 0u;case 21:return 0u;case 22:return 0u;case 23:return 0u;case 24:return 1u;case 25:return 1u;case 26:return 0u;case 27:return 1u;case 28:return 1u;case 29:return 0u;case 30:return 1u;case 31:return 1u;case 32:return 1u;case 33:return 1u;case 34:return 1u;case 35:return 1u;case 36:return 1u;case 37:return 1u;case 38:return 1u;case 39:return 1u;case 40:return 1u;case 41:return 0u;case 42:return 1u;case 43:return 1u;case 44:return 1u;default:return 255u;}}
uint32_t wc_user_eci_provider_hosts(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){case 0:return 3u;case 1:return 8u;case 2:return 4u;case 3:return 1u;case 4:return 2u;case 5:return 8u;case 6:return 4u;case 7:return 3u;case 8:return 8u;case 9:return 4u;case 10:return 3u;case 11:return 3u;case 12:return 12u;case 13:return 3u;case 14:return 3u;case 15:return 12u;case 16:return 1u;case 17:return 1u;case 18:return 1u;case 19:return 3u;case 20:return 3u;case 21:return 3u;case 22:return 3u;case 23:return 1u;case 24:return 2u;case 25:return 4u;case 26:return 1u;case 27:return 2u;case 28:return 4u;case 29:return 1u;case 30:return 4u;case 31:return 8u;case 32:return 4u;case 33:return 4u;case 34:return 4u;case 35:return 4u;case 36:return 4u;case 37:return 4u;case 38:return 4u;case 39:return 4u;case 40:return 4u;case 41:return 1u;case 42:return 2u;case 43:return 4u;case 44:return 8u;default:return 0u;}}
uint32_t wc_user_eci_provider_priority(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){case 0:return 0u;case 1:return 10u;case 2:return 10u;case 3:return 0u;case 4:return 0u;case 5:return 10u;case 6:return 10u;case 7:return 0u;case 8:return 10u;case 9:return 10u;case 10:return 0u;case 11:return 5u;case 12:return 10u;case 13:return 0u;case 14:return 5u;case 15:return 10u;case 16:return 0u;case 17:return 5u;case 18:return 10u;case 19:return 100u;case 20:return 0u;case 21:return 0u;case 22:return 0u;case 23:return 0u;case 24:return 5u;case 25:return 10u;case 26:return 0u;case 27:return 5u;case 28:return 10u;case 29:return 0u;case 30:return 10u;case 31:return 10u;case 32:return 10u;case 33:return 10u;case 34:return 10u;case 35:return 10u;case 36:return 10u;case 37:return 10u;case 38:return 10u;case 39:return 10u;case 40:return 10u;case 41:return 0u;case 42:return 5u;case 43:return 10u;case 44:return 10u;default:return 0xffffffffu;}}
uint32_t wc_user_eci_select(uint32_t cap,uint32_t host,uint32_t alo,uint32_t ahi){uint32_t n=wc_user_eci_provider_count(cap),best=0xffffffffu,bp=0xffffffffu,bk=0xffffffffu;for(uint32_t k=0;k<n;k++){uint32_t g=wc_user_eci_provider_global_id(cap,k);if(g==0xffffffffu)continue;uint32_t av=g<32?((alo>>g)&1u):((ahi>>(g-32))&1u);if(!av||!(wc_user_eci_provider_hosts(cap,k)&host))continue;uint32_t kind=wc_user_eci_provider_kind(cap,k),pri=wc_user_eci_provider_priority(cap,k);uint32_t authority=(kind==0u?0u:(kind==1u?1u:(kind==2u?2u:3u)));if(authority<bk||(authority==bk&&pri<bp)){bk=authority;bp=pri;best=g;}}return best;}
uint32_t wc_user_eci_op_capability(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_eci_op_boundary(uint32_t id){switch(id){default:return 255u;}}
uint32_t wc_user_eci_op_opcode(uint32_t id){switch(id){default:return 0u;}}
uint64_t wc_user_eci_call(uint32_t op,uint64_t a0,uint64_t a1){if(op>=0u)return 0xffffffffffffffffull;
#ifdef WC_ECI_IMPORTS
return wc_eci_host_dispatch(op,wc_user_eci_op_opcode(op),a0,a1);
#else
(void)a0;(void)a1;return 0xffffffffffffffffull;
#endif
}
uint64_t wc_user_eci_async_begin(uint32_t op,uint32_t pool,uint64_t tok,uint64_t a0,uint64_t a1){if(op>=0u||wc_user_eci_op_boundary(op)!=1u||wc_user_future_state(pool,tok)!=1u)return 0;
#ifdef WC_ECI_IMPORTS
return wc_eci_host_async_start(op,wc_user_eci_op_opcode(op),pool,tok,a0,a1);
#else
(void)pool;(void)tok;(void)a0;(void)a1;return 0;
#endif
}
uint32_t wc_user_eci_async_cancel(uint64_t req){if(!req)return 0;
#ifdef WC_ECI_IMPORTS
return wc_eci_host_async_cancel(req);
#else
(void)req;return 0;
#endif
}
const int32_t wc_task_ranks[WC_TASK_COUNT]={0};
const uint32_t wc_task_costs[WC_TASK_COUNT]={1u};
const double wc_task_deadlines[WC_TASK_COUNT]={16.667000000000002};
const uint8_t wc_task_classes[WC_TASK_COUNT]={1};
const uint8_t wc_task_fn[WC_TASK_COUNT]={0};
const uint32_t wc_task_pred_lo[WC_TASK_COUNT]={0u};
const uint32_t wc_task_pred_hi[WC_TASK_COUNT]={0u};
const uint32_t wc_task_pred_x[WC_TASK_COUNT]={0u};
uint32_t wc_user_topology_count(void){return 0u;}
uint32_t wc_user_topology_vertices(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_edges(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_beta0(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_beta1(uint32_t id){switch(id){default:return 0;}}
int32_t wc_user_topology_euler(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_proof_bits(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_bridges(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_articulations(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_free_group_rank(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_incidence_rank(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_laplacian_nullity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_topology_laplacian_proof_bits(uint32_t id){return id<0u?7u:0u;}
uint32_t wc_user_topology_laplacian_linear_bits(uint32_t id){return id<0u?(1u|8u|128u|256u):0u;}
uint32_t wc_user_plan_count(void){return 0u;}
uint32_t wc_user_plan_path_len(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_plan_path_vertex(uint32_t id,uint32_t k){switch(id){default:return 0xffffffffu;}}
int32_t wc_user_plan_rank(uint32_t id){switch(id){default:return 0xffffffffu;}}
double wc_user_plan_cost(uint32_t id){switch(id){default:return 0.0;}}
uint32_t wc_user_plan_full_expansions(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_plan_topo_expansions(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_plan_pruned_vertices(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_plan_homotopy_word_len(uint32_t id){switch(id){default:return 0;}}
int32_t wc_user_plan_homotopy_letter(uint32_t id,uint32_t k){switch(id){default:return 0;}}
uint64_t wc_user_plan_bench(uint32_t id,uint32_t pruned,uint32_t reps){switch(id){default:return 0;}}
uint32_t wc_user_complex_count(void){return 0u;}
uint32_t wc_user_complex_beta(uint32_t id,uint32_t dim){switch(id){default:return 0;}}
int32_t wc_user_complex_euler(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_complex_proof_bits(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_complex_collapse_steps(uint32_t id){switch(id){default:return 0;}}
