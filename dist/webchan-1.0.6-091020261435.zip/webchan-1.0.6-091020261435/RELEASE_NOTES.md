# Webchan 1.0.6

Build: `091020261435`

## Release theme

**Structural Web Runtime Unification.**

1.0.6 keeps the 1.0.5 Minimal Web Surface and connects two proof/execution paths that were previously incomplete: cross-representation structural permissions and responsive heavy-web execution.

## Compiler

- Added a typed Structural Passport for ordinary indexed kernels.
- Equivalent diagonal and banded linear kernels can inherit the same solver unlock set as declared matrix forms.
- Nonlinear expressions are conservatively rejected from the linear namespace.
- Generic SIA facts and typed linear proof bits are kept separate.
- Added a typed topology-Laplacian linear bridge: linear, symmetric, static-sparse and matrix-free are proved; positive-semidefinite/nullity evidence is retained; SPD remains unproven without additional grounding evidence.
- Added resumable companion code generation for eligible finite kernels while retaining the existing synchronous fast path.
- Added source lowering for generic `eci_async` and `eci_cancel`.

## Runtime and browser host

- Added fixed-capacity byte streams with high/low watermark backpressure.
- Added bounded event mailbox tied to the active-set limit.
- Added async ECI start/cancel/completion integration with Future generation tokens.
- Added incremental UTF-8, line and SSE framing.
- Added coalesced DOM text/attribute/property commit queue.
- Added deferred invalidation/repair dirty-set coalescing.
- Added adaptive responsive-kernel host execution using work-unit budgets plus observed wall-clock slice timing.
- Added an optional browser Worker host profile.
- Added a generic browser HTTP provider convention that pumps response bodies through bounded streams.

## Compatibility

- The 1.0.5 Minimal Web Surface remains accepted.
- Older explicit directives and terminators remain accepted.
- Scalar and SIMD128 target-profile selection remains semantically equivalent.
- The synchronous `wc_kernel_run()` fast path remains available.
- No AI-, chat-, browser-benchmark-, JavaScript-, MoonBit-, Wa- or product-specific optimizer branch was added.

## Validation

The release includes inherited regressions plus new 1.0.6 gates. Final authoritative counts are written by the release build into `results/VALIDATION.txt`.

Dedicated 1.0.6 probes cover structural-passport equivalence, nonlinear rejection, resumable parity, topology-to-linear proof transfer, streams/backpressure, async cancellation, stale completion, incremental UTF-8/SSE, event mailbox bounds, deferred repair, Chromium DOM/responsive execution, and the optional Worker host.

A separate same-source scalar Chromium A/B measured the old synchronous fast path at `81.7 ms` median for 1.0.5 and `80.8 ms` for 1.0.6, with zero output mismatch. This is recorded as a regression probe, not as a universal speed claim.

## Optimization provenance

Housekeeping Optimization: **20 entries**.

Luxury Optimization: **8 entries**.

No new Luxury category is introduced. 1.0.6 expands the proof coverage and runtime realization of existing Webchan mechanisms.
