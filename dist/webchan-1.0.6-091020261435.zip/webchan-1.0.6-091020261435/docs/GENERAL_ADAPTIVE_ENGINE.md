# Webchan a pre-release milestone General Adaptive Structure Engine

## Goal

Handle both smooth and non-smooth workloads without application labels. The compiler and runtime reason about **causality, locality, continuity, reconstructability, and cost**.

## Generic dispatch model

```text
work/data
  |
  +-- exact discrete dependency structure -> incremental change propagation
  |
  +-- globally exact affine/polynomial -> exact compact field
  |
  +-- piecewise exact regions -> adaptive partition + local compact fields
  |
  +-- smooth region with explicit tolerance -> local Chebyshev candidate (architecture)
  |
  +-- localized multi-scale sparse changes -> wavelet candidate (architecture)
  |
  +-- unknown / unprofitable -> exact generic fallback
```

No branch says `if workload == chat`, `if renderer`, or `if AI`.

## Incremental change propagation

`wc_invalidate(root)` computes the transitive successor cone from the compiled predecessor bitsets. Only marked nodes are reset. Their previous accumulator contributions are removed before recomputation, preserving numerical semantics up to floating-point reordering.

This implements a general change-propagation rule:

`changed source -> dependency cone -> local recompute`

rather than:

`changed source -> full program recompute`.

## Exact piecewise fields

Syntax:

```text
piecewise_field discontinuous_profile f64 4000000
segment 0 1000000 expr 1.0 + 0.00001*i
segment 1000000 2000000 expr 100.0 - 0.00002*i
segment 2000000 3000000 expr -40.0 + 0.000003*i*i
segment 3000000 4000000 expr 7.0
endpiecewise
```

Compiler checks:

- first segment begins at zero;
- last segment ends at field length;
- intervals are contiguous and non-overlapping;
- every local expression is exactly representable in the current bounded polynomial proof domain;
- reconstruction cost respects the configured budget;
- saved bytes exceed the configured threshold.

If those checks pass under `memory_mode matrix_free`, the dense storage can disappear. If they fail for profitability, materialized storage remains legal. Invalid partitions are rejected because they change semantics rather than merely missing an optimization.

## Why this handles non-smoothness

A discontinuity is a boundary between regions. Webchan does not ask one global polynomial to cross it. Each region keeps a local exact representation. The same principle extends naturally to local Chebyshev and wavelet representations in later versions.

## Piecewise Chebyshev architecture

Not implemented as a runtime transform in a pre-release milestone. The approved future rule is:

1. partition at proved/detected discontinuities;
2. establish smoothness/error contract inside each region;
3. construct a local Chebyshev representation;
4. validate/certify local error;
5. fall back exact on any failing region.

## Wavelet architecture

Wavelets are approved for localized multi-scale structure because a local discontinuity changes a local/sparse subset of coefficients rather than contaminating one global polynomial. a pre-release milestone does not claim a wavelet runtime benchmark.

## Relationship to temporal safety

Incremental computation reduces *total work*. Bounded `wc_step` limits *continuous occupation*. They are complementary:

- incremental engine: avoid recomputing unaffected work;
- temporal scheduler: prevent the remaining affected work from monopolizing the host thread.

## Relationship to matrix-free memory

Adaptive partition can also remove storage. A piecewise field stores region boundaries and coefficients, reconstructs demanded values, then discards or caches them. This is the non-smooth counterpart to exact affine/polynomial matrix-free fields.
