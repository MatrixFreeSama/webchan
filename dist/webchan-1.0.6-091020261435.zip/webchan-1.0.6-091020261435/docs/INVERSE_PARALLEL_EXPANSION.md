# Webchan earlier release Inverse Parallel Expansion (IPE)

## Purpose

IPE is a source-to-Webchan IR semantic recompilation pass for moving programs that were organized for parallel hardware onto Webchan's single-host-thread execution model.

It does **not** serialize a worker runtime. It recovers the dependence semantics first and then proves which parallel-orchestration structures have no observable meaning on the target execution model.

Core rule:

> Preserve dependence. Erase orchestration.

The source parallel structure is evidence about ordering and independence, not baggage that must survive lowering.

## Supported an earlier development milestone source model

```text
parallel_region region_name workers 8
worker_local scratch f64 private
compute shard0 fn f range 0 1024 plan_rank 0
compute shard1 fn f range 1024 2048 plan_rank 0
barrier all_done
pdepends all_done on shard0
pdepends all_done on shard1
join region_join
pdepends region_join on all_done
endparallel_region
```

The model is a finite static fork-join DAG. The compiler supports:

- compute nodes with a bounded index range and ordinary Webchan function;
- explicit dependence edges;
- barrier nodes;
- join nodes;
- private worker-local declarations;
- signed `plan_rank` on compute nodes.

There is no application label and no source-language dependency on pthreads, OpenMP, CUDA, Java executors, browser workers or another project's runtime.

## Proof stages

### 1. DAG proof

The region is rejected if the imported dependence graph is cyclic.

### 2. Pure-compute proof

Orchestration erasure requires compute functions to be proved pure by the existing General Structural Proof Optimizer. A side-effecting/unknown compute path is not silently reordered.

### 3. Orchestration-erasure proof

For a single-host-thread target, proved-pure computation and an acyclic dependence graph allow `spawn`, `barrier` and `join` bookkeeping to disappear as runtime operations while their ordering constraints remain in the reduced dependence relation.

### 4. Rank-guided linear extension

After orchestration removal, there are often several legal topological orders. Webchan chooses among currently causally ready compute nodes by:

1. lower `plan_rank` first;
2. lower source range start as deterministic tie-break;
3. stable node order as final tie-break.

Rank cannot violate causality.

### 5. Worker-local scalarization

A `worker_local ... private` declaration has no address escape in the current an earlier development milestone region language. Once worker multiplicity is erased, replicated worker slots collapse to one serial slot. The compiler reports the number of removed replicated slots.

### 6. Partition fusion

A stronger transform is unlocked only if all participating compute partitions are proved:

- pure;
- mutually independent;
- the same function;
- non-overlapping and exactly contiguous;
- the same `plan_rank`.

Then the parallel partition boundaries are non-semantic and the region is regenerated as one natural serial range.

This is not a hard-coded `parallel_for` opcode. It is derived from the finite fork-join DAG and range/function properties.

## Webchan IR certificate

Webchan IR emits records such as:

```text
ipe_region ...
  proof dag=verified pure_compute=verified
        orchestration_erasable=verified
        worker_local_scalarizable=verified
        rank_linearization=verified
        partition_fusable=verified
  erase spawn=... barrier=... join=...
  serial_schedule=...
  unlock partition-fusion because=...
  unlock parallel-orchestration-erasure because=...
  unlock worker-local-scalarization because=...
```

## Semantic boundary

IPE preserves the program's declared dependence and per-index compute semantics. It does not claim that arbitrary concurrent programs with races, observable lock timing, external atomics or host-visible worker identity can be collapsed safely.

Those require stronger future effect/alias/concurrency proofs and are not silently accepted in an earlier development milestone.

## Why this is more than serialization

Naive migration:

```text
parallel source
-> worker/task runtime
-> run worker 0
-> run worker 1
-> ...
```

IPE:

```text
parallel source
-> dependence proof
-> erase parallel-only runtime structure
-> choose a legal rank-aware serial order
-> fuse non-semantic partitions when proved
-> feed the result to existing Webchan structural optimizers
```

The resulting serial program is synthesized from semantics, rather than being the parallel runtime executed with `P=1`.
