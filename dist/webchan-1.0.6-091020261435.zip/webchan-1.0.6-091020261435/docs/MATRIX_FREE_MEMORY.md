# Proof-Guided Matrix-Free Memory

## Contract

Matrix-free memory is opt-in. `memory_mode dense` is the default.

When enabled, a field may lose its materialized backing storage only after Webchan proves an exact reconstruction and the transformation passes the configured profitability gates.

```text
memory_mode matrix_free
memory_auto_affine true
memory_recompute_budget 6
memory_min_savings_bytes 4096
memory_scratch_cap 4096
```

## Current field grammar

```text
field <name> f64 <length> expr <polynomial expression in i>
```

The current exact expression grammar supports numeric constants, `i`, parentheses, unary `+/-`, addition, subtraction, multiplication, and division by a nonzero constant. Maximum canonical degree is eight.

The source does not declare a representation. The compiler canonicalizes the polynomial and classifies it as:

- degree 0: constant;
- degree 1: affine;
- degree 2..8: polynomial;
- otherwise: not accepted by the current exact field grammar.

Whether a proved field is actually virtualized is a second decision. A high-degree field may be exactly reconstructable yet remain materialized because its reconstruction work exceeds `memory_recompute_budget`.

## Memory lifetime

Long-lived form:

```text
compact proof-certified representation
```

Demanded window:

```text
index -> reconstruct -> consume
```

Optional bounded temporary materialization:

```text
wc_field_materialize(field, start, count)
```

`count` is clamped to `memory_scratch_cap`. Scratch storage is reusable and cannot grow with logical field size.

## Exactness

For the current polynomial field domain, dense and matrix-free twins are generated from the same canonical polynomial evaluation. Validation checks point probes, whole-field checksums, and bounded scratch output.

Approximate Chebyshev field compression is intentionally not silently enabled in a pre-release milestone. It will require an explicit approximation tolerance and an error certificate.

## Rendering placement

The field abstraction is host-neutral. A CPU consumer can request values or a bounded window without materializing the whole field. A graphics backend can eventually lower a proved field to a shader function driven by `gl_VertexID`, eliminating a vertex buffer when legal and profitable.

The compiler emits `generated/procedural_fields.glsl` with GLSL 4.00 helper functions for fields that actually passed the matrix-free proof/profitability gate. Materialized fallbacks are explicitly left as host-storage requirements. The validation environment has no OpenGL driver/shader validator, so this artifact is code-generation evidence, not an OpenGL performance claim.

## a pre-release milestone non-smooth extension

a pre-release milestone adds exact `piecewise_field` regions. The compiler verifies complete non-overlapping domain coverage and proves each region in the same bounded polynomial domain. Under matrix-free mode, a compact field stores boundaries plus local coefficients rather than every value.

This is deliberately not presented as global Chebyshev compression. A known discontinuity is a partition boundary. Smooth/affine/polynomial reasoning stays local to a region.

A piecewise field may still remain materialized if the recomputation/savings gates reject compaction.
