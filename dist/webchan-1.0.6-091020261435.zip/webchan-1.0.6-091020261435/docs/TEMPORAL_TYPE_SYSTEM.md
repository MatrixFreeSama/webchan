# Temporal and Proof Types

Webchan a pre-release milestone retains the an early pre-release milestone static discipline:

- bounded `repeat` is accepted;
- unbounded `while` is rejected in strict code;
- recursive call cycles are conservatively rejected;
- declared work effects must dominate compiler-computed work;
- sized arrays are checked before code generation.

a pre-release milestone adds a second static layer: **proof facts as optimization capabilities**.

A fact such as `SPD(A)` is not a runtime Boolean and is not accepted from user assertion. It is compiler evidence. Transformations can require capabilities:

```text
CG                 requires SPD(A)
Chebyshev           requires spectrum(A) subset [a,b], a>0
Banded Gaussian     requires banded(A) + SPD(A)
Bounds-check elision requires len(rhs)=len(out)=n(A)
```

Failure to obtain a capability generally removes an optimization rather than making the entire program ill-typed.
