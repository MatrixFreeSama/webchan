# Webchan Wild-Project Policy

Webchan is intentionally maintained as a **wild independent project**.

## Hard rule

Only textbook-level ideas may cross the project boundary.

Allowed conceptual inputs include broadly taught ideas such as:

- dependence DAGs and topological ordering;
- fork-join semantics;
- work/span reasoning;
- barrier and synchronization elimination when proved redundant;
- loop/partition fusion;
- scalar replacement and privatization collapse;
- common-subexpression and partial-evaluation ideas;
- standard numerical linear algebra;
- standard graph theory, homology and elementary topology;
- classical approximation and iterative methods.

Forbidden as implementation input:

- copying another compiler/runtime's source code;
- importing another project's private or project-specific IR design as Webchan's semantic core;
- vendoring a competitor's scheduler and renaming it;
- benchmark-specific compatibility shims that secretly execute another language/runtime;
- translating a project-specific optimization pass line-for-line.

External software may still be used as a **toolchain** where explicitly declared, such as Clang/LLVM lowering, Chromium for browser validation, or Node for host validation. Toolchain use does not define Webchan semantics.

## Outbound rule

Webchan documentation should describe its mechanisms in general mathematical/compiler terms. It should not require knowledge of another project to explain how an optimization works.

The implementation should remain auditable from `.webchan -> Webchan IR -> internal C -> Wasm` without an opaque imported optimizer runtime.

## an earlier development milestone compiler contract

Source must declare:

```text
wild_project_policy textbook_only
parallel_migration inverse_parallel_expansion
```

The compiler rejects release-contract configurations that disable the textbook-only wild-project policy.
