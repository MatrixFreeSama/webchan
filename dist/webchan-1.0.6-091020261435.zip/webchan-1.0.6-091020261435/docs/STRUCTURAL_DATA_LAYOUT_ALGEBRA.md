# Structural Data Layout Algebra (SDLA)

## Status

Implemented. SDLA schema 2 is the Webchan 1.0.2 access-phase profitability model.

SDLA is a compiler-owned physical storage transformation. It is not a container library, a browser optimization mode, an FFT/stencil facility, a benchmark switch, or a user-selected AoS/SoA wrapper.

Source programs keep logical arrays:

```text
array x f64 N
array y f64 N
```

Logical identity never changes. The compiler may only rewrite physical storage after legality proof and a separate profitability decision.

## Candidate space

The implemented physical candidates remain deliberately small and general:

1. **separate**: each logical array is contiguous;
2. **interleaved**: matched elements from compatible logical arrays share an element-major physical group;
3. **tiled**: compatible arrays are grouped by finite power-of-two field blocks;
4. **scalarized bridge**: bounded kernel locals stay scalar when lifetime proof permits it;
5. **non-materialized bridge**: exact reconstructable/matrix-free values can avoid stored arrays entirely.

There is no source syntax for `soa`, `aos`, `interleave`, `complex`, `rgb`, `particle`, `fft`, `web`, or similar workload labels.

## Legality and profitability are different gates

A physical grouping can be legal and still be rejected.

Legality requires compatible type/extent, distinct logical arrays, bounded accepted indexed accesses, and compiler-owned nonalias semantics. Profitability then asks whether the physical rewrite is likely to reduce total traffic/address work for the proved access relation.

The `separate` candidate is always the safe profitability baseline.

## Access phases

Schema 2 partitions ordinary bounded kernel execution into generic phases. A top-level bounded loop/while region forms a phase; nested loops remain inside that phase. Scalar regions are also represented without application names.

For every compatible array pair the compiler derives:

- matched-index references in one operation;
- matched-index references in adjacent operations;
- phases in which both arrays are active;
- phases in which only one member is active;
- overlap/union coverage;
- how much of each array's indexing is a conservative linear stream of active induction variables.

A pair used together in every phase is materially different from a pair that happens to meet at the same index in only two out of four long passes. Schema 1 could not distinguish those cases reliably.

## Contiguous-stream evidence

The stream recognizer is intentionally conservative. A direct induction index or a linear `+/-` expression of active induction variables can contribute contiguous-stream evidence. Multiplication, division, modulo, bit permutations, function calls and local indirection do not get that proof for free.

For large, mostly unit-stride working sets, interleaving/tiled candidates pay an increasing profitability penalty because they can destroy the simplest contiguous/vectorizable stream and require extra address arithmetic. This is a cost decision, not a semantic prohibition: sufficiently tight and complete co-access can still win.

## Working-set evidence

Logical bytes feed a finite working-set tier used only by the generic cost model. The tier changes candidate cost; it does not change array semantics, expose a cache size in the language, or identify a particular CPU model.

## Tiled address lowering

The current tile basis is a power-of-two field block derived from element width. Accepted tiled layouts lower index division/remainder to shift/mask arithmetic:

```text
tile = i >> shift
offset = i & (tile_size - 1)
```

This preserves the logical mapping while reducing generic address work in hot loops.

## Decision witnesses

Read-only runtime/IR introspection exposes why a decision happened:

- raw matched-index locality score;
- signed profitability score;
- phase coverage in permille;
- stream ratio in permille;
- reason bits;
- final kind/group/lane/tile.

Rejected legal candidates are emitted as `layout_reject` records in Webchan IR. This makes a bad decision debuggable without adding a source hint to override the compiler.

## Relationship to existing Webchan acceleration regions

SDLA remains downstream of structural proof and upstream of C/LLVM lowering:

```text
bounded source
  -> temporal/bounds/dependence proof
  -> Structural Iteration Algebra
  -> structural linear algebra / topology / IPE evidence
  -> SDLA access-phase profitability
  -> physical storage lowering
  -> C / LLVM / Wasm or native
```

It therefore reuses the existing finite-work, locality, active-working-set and proof-directed infrastructure. 1.0.2 does not introduce a second application-specific optimizer.

## Non-goals

SDLA 2.0 does not claim perfect cache simulation, profile-guided optimization, arbitrary object-graph relayout, raw-pointer ABI rewriting, universal hardware constants, or guaranteed speedup for every legal rewrite. When evidence is insufficient or estimated cost is unfavorable, the compiler keeps separate storage.
