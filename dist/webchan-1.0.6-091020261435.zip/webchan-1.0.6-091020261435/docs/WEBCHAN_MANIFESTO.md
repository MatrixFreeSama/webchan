# Webchan General Manifesto

**Status:** project doctrine consolidated through Webchan 1.0.4, including General Application Semantics, SDLA access-phase profitability, adaptive Wasm target profiles, optimization provenance, and classical scalar-loop housekeeping.

Webchan is a general single-host-thread language and Wasm execution model built around **temporal safety, structurally justified work deletion, and memory/computation substitution**. Browser workloads are an important host profile, not the semantic definition of the language.

This document intentionally records the project's accumulated design ideas in one place so later versions do not quietly erase earlier performance or safety principles.

---

## 1. Identity

1. **Webchan is its own language.** `.webchan` is the source language. Generated C is internal backend material, not user semantics.
2. **Webchan is not an HTML/JavaScript wrapper.** A browser adapter may package a compiled Webchan program into HTML, but the language core and portable Wasm remain independent.
3. **Webchan is not a C syntax skin.** Semantic analysis, rejection, proof, representation selection, scheduling, and Webchan IR construction happen before C lowering.
4. **C/LLVM is the authoritative backend while it remains semantically faithful and performance-competitive.** Mature serial optimization is an asset, not an ideological enemy.
5. **Do not reinvent serial execution. Govern it.** Webchan decides what work exists, when it is legal to run, when it can disappear, and how long it may occupy a host thread. LLVM decides how the remaining low-level instructions execute efficiently.
6. **A direct Wasm backend is evidence-driven, not ceremonial.** Build one only if C/LLVM demonstrably blocks semantics, Wasm capabilities, or stable performance.
7. **A portable core should be able to have zero mandatory imports.** Host capabilities are profiles layered around the core.
8. **One compiled Wasm core should be reusable across browser and non-browser hosts when host capabilities permit.**
9. **Single-host-thread-first does not mean single-thread-only forever.** The core guarantee concerns bounded occupation and predictable cooperation with a host thread. Parallel host profiles may exist without weakening that invariant.
10. **Webchan's primary enemy is blocked time.** Wheelchair's historic design target is spatial hardware under-utilization; Webchan's target is temporal execution-window waste and host-thread monopolization.
11. **Webchan is AOT-first and does not depend on a Webchan-layer JIT.** A host engine may internally JIT Wasm, but that is below the language semantic boundary.
12. **Mature low-level serial machinery should be exploited, not reimplemented:** SSA optimization, register allocation, inlining, instruction scheduling, modern out-of-order execution, cache locality, vectorization/SIMD, and Wasm lowering belong below Webchan IR when they preserve semantics.

---

## 2. Perfect Serialization

Webchan embraces the strongest mature ideas of sequential execution rather than fighting them.

13. **Causal order is the authority.** A compiled DAG determines which work is legally ready.
14. **Only the ready frontier may run.** `Ready = causally satisfied` comes before priority.
15. **Critical-path work runs first.** Input and immediately visible work outrank background and speculative work.
16. **Task ordering may be out-of-source-order when causality permits.** Serial execution does not require source-order execution.
17. **No implicit global barrier.** Unrelated work must not wait merely because it appears in the same source region.
18. **Atomic/join behavior is explicit-only.** When consistency genuinely requires simultaneous visibility, the program must request an explicit atomic group.
19. **Progressive completion is the default.** Ready results may commit independently.
20. **Surplus-Time Run-Ahead is allowed.** Spare budget may precompute likely next-stage work.
21. **Speculative work is disposable.** Input changes may invalidate it without making current critical work wait.
22. **Speculation can never steal the critical time window.**
23. **Task Field Collapse is legal only when a common mathematical structure exists.** Mere independence is not proof of interpolability.
24. **Perfect Serialization is a composition, not a slogan:**

`causal ordering + critical-path first + run-ahead + task collapse + latency budget + ranked degradation + progressive commit + deferred repair + adaptive working set`

---

## 3. Temporal Safety

25. **Webchan-controlled work must have bounded continuous host-thread occupation.**
26. **A host may request an absurdly large step; the Wasm core must clamp it internally.** Safety cannot depend on a polite caller.
27. **Input-Fair Yield is stronger than merely yielding.** Continuations must not monopolize the scheduler while timers/input starve.
28. **No continuation monopoly.** A chain of immediately resumed continuations is a form of hidden blocking.
29. **Deadline is first-class metadata.**
30. **Work class is first-class metadata.** Input, visible, frame, background, and speculative classes are semantically distinct.
31. **`shed_rank` is first-class metadata.** Larger values mean easier to defer/shed; strongly negative values are protected.
32. **Rank never overrides causality.**
33. **PENDING is not UNAVAILABLE.** Temporary incompleteness and permanent absence are distinct runtime states even when a UI chooses the same placeholder text.
34. **Deferred Repair is mandatory for PENDING work.**
35. **Repair should be local.** Do not trigger a global reconstruction when only a local placeholder changed.
36. **Stable placeholder geometry is preferred.** Deferred completion must avoid unnecessary global layout shifts.
37. **Runtime is the last line of defense, not the first.** Prefer: static proof -> compile-time guard -> bounded runtime -> overload degradation.
38. **External blocking is an explicit unsafe boundary.** Browser, OS, GPU driver, FFI, filesystem, or host stalls cannot be hidden inside an absolute language guarantee.
39. **Do not promise universal 60 FPS.** Promise bounded Webchan-controlled occupation and measured responsiveness under the specified host contract.

---

## 4. Working-Set Discipline

40. **Logical history does not imply live physical state.**
41. **Active Working Set has a hard/adaptive bound.**
42. **Large logical UI/data histories may freeze/unload old physical representations while preserving logical state.**
43. **Rehydrate on demand.**
44. **Failure cliffs matter more than a single winning point.** Every working-set benchmark must search for the point where responsiveness collapses.
45. **Adaptive shedding should respond before the failure cliff, not after it.**
46. **DOM/UI mutation is batched where a browser profile exists.**
47. **Incremental/differential recomputation is preferred to whole-state regeneration.**

---

## 5. Proof Is an Optimization Permission System

48. **Webchan does not prove for prestige.** Proof exists to eliminate work, remove runtime checks, select a cheaper legal algorithm, or remove storage.
49. **Prove only what can delete work or establish a hard safety invariant.**
50. **A proof unlocks an optimization; it does not force it.** Profitability is a second gate.
51. **Proof failure is not ordinary program failure.** Fall back to the exact/generic path unless the property is required for safety.
52. **Users may not assert trusted mathematical facts merely to force an optimization.** The compiler must derive evidence from source structure or a separately defined verified boundary.
53. **Termination checking is valuable because it establishes finite execution structure, not because Webchan seeks to become a theorem prover.**
54. **Sized/indexed information is valuable when it deletes checks, bounds work, or enables representation/algorithm specialization.**
55. **Dependency analysis is both a proof tool and a scheduling tool.**
56. **Full cubical/dependent proof-assistant semantics are not a default goal.** Adopt them only if they unlock concrete Webchan optimizations or safety invariants with acceptable complexity.
57. **Proof-Directed Optimization pipeline:** discover candidate -> derive/check evidence -> unlock legal transforms -> estimate benefit -> transform -> validate/fallback.
58. **Proof and cost are coupled.** A valuable proof has positive expected benefit after proof cost.
59. **Algorithm Collapse is preferred to micro-optimization when structure permits.** Deleting an O(n^3) generic path is more valuable than polishing a few instructions in it.

---

## 6. Numerical Structure

60. **Gaussian elimination is the generic exact fallback, not the universal preferred path.**
61. **Proved band structure may unlock band-local elimination.**
62. **Proved SPD may unlock Cholesky/CG-class methods and remove unnecessary pivot machinery when the exact preconditions are satisfied.**
63. **Proved positive spectral bounds may unlock Chebyshev iteration.**
64. **Krylov methods are interpreted structurally: work occurs in a growing subspace rather than blindly repeating a generic solve.**
65. **Chebyshev is a smooth/spectral accelerator, not a universal approximation hammer.**
66. **Approximation must have an explicit tolerance/error contract.** Exact semantics may not be silently replaced by approximate semantics.
67. **Task-field Chebyshev must have an error gate and exact fallback.**
68. **Where global smoothness fails, partition before approximating.** Never fit one global high-order smooth representation across a known discontinuity merely to preserve one algorithm.

---


## 6A. General Structural Proof and Structural Algebra

69A. **Linear algebra is the first mature structural proof library, not the definition of the language.** Webchan recognizes properties, not application names.
69B. **General Structural Proof Optimizer:** ordinary functions, dataflow graphs, fields, matrices, state transforms, and host-neutral operators may all contribute properties to one capability graph.
69C. **Structural equivalence outranks syntactic similarity.** A transform is legal only when the compiler proves exact equivalence or an explicit approximation certificate.
69D. **Purity is an optimization capability.** Proved pure deterministic work may be reordered, speculated, shared, memoized, or common-subexpression-eliminated when profitability permits.
69E. **Affine composition is a reusable algebraic property.** A chain of affine maps may collapse to one affine map; if LLVM already performs the same machine optimization, Webchan records parity rather than claiming a false speedup.
69F. **Monotonicity is a reusable property.** Future search, filtering, ordering, and threshold transforms may consume the same proof without introducing an application-specific opcode.
69G. **Static sparsity is a reusable property.** Once proved, symbolic assembly/index structures may be reused across repeated numerical phases when numerical values change but topology does not.
69H. **Exact matrix-free operator action is a reusable property.** If `A*x` can be reconstructed exactly from compact source structure, a consumer may avoid assembling/storing the full global operator.
69I. **Jacobi is proof-unlocked, never blindly selected.** Strict diagonal dominance or another sound convergence certificate must precede its use.
69J. **Gauss-Seidel is proof-unlocked, never blindly selected.** SPD, strict diagonal dominance, or triangular structure may establish convergence/finite-collapse cases.
69K. **Weighted Jacobi requires stronger spectral information.** Relaxation parameters are derived from verified normalized spectrum bounds, not hand-tuned guesses.
69L. **Triangular proof collapses iteration to substitution.** Lower triangular -> forward substitution; upper triangular -> back substitution.
69M. **Diagonal proof collapses all global solver machinery to independent scalar division.**
69N. **A proved property may unlock several algorithms simultaneously.** A separate cost model chooses among legal methods.
69O. **A faster-looking method is not legal merely because a benchmark likes it.** Proof precedes profitability.
69P. **Global assembly is not sacred.** If static sparsity and exact local/operator action are proved, repeated symbolic assembly or full materialization may be deleted.
69Q. **Newton-Raphson is not a special keyword in the structural optimizer.** A Jacobian gains acceleration only through properties such as static sparsity, symmetry, SPD, matrix-free action, low-rank change, or reusable factor structure.
69R. **Ordinary programs may inherit numerical-algebra accelerations when their IR proves the same structure.** The capability graph is property-driven, not domain-driven.
69S. **Backend overlap is measured honestly.** If LLVM already removes the same local work, Webchan does not count the optimization as an independent runtime victory.
69T. **The highest-value Webchan proofs are those that change asymptotic work, memory traffic, global assembly, or recomputation scope.**

## 6B. Structural Topology Proof and Rank-Guided Planning

69U. **Topology is a peer structural proof domain to linear algebra.** Webchan proves finite combinatorial structure because the proof can collapse search/state/planning work, not because the language seeks proof-theory prestige.
69V. **Topology recognition is property-driven, not application-driven.** There is no semantic branch for maps, robots, games, UI, chat, workflows, or simulation. A finite graph or simplicial complex receives the same proofs regardless of its origin.
69W. **Connected components are first-class structural evidence.** Planning or propagation may not cross a component boundary that does not exist.
69X. **Bridge and articulation proofs are planning capabilities.** Mandatory cuts and structurally fragile junctions may be preserved, prioritized, or used to prune alternatives.
69Y. **For finite graphs, cycle rank is exact:** `beta1 = E - V + beta0`. It is both the first Betti number and the rank of the free fundamental group for each connected graph component after maximal-tree contraction.
69Z. **Graph homotopy uses a theorem, not a similarity heuristic.** A connected finite graph is homotopy-equivalent to a wedge of `beta1` circles.
69AA. **A connected finite graph is simply connected exactly when its cycle rank is zero.** In that case it is a tree and is contractible.
69AB. **Finite simplicial-complex homology is computed from boundary operators.** an earlier development milestone uses exact GF(2) ranks for `d1` and `d2` and derives `beta0`, `beta1`, `beta2`.
69AC. **Euler-Poincare is a cross-check certificate.** `chi = V-E+F = beta0-beta1+beta2` for the supported 2-complex representation.
69AD. **Homology is not silently promoted to homotopy.** `H1=0` is not a general proof of simple connectivity for a 2-complex.
69AE. **Elementary simplicial collapse is a strong certificate.** If the compiler collapses a finite complex to a point by free-face pairs, `contractible` and `simply_connected` may be marked verified.
69AF. **General fundamental-group triviality for arbitrary finite 2-complexes is not promised.** Conservative `unproven` is preferable to an unsound optimization permission.
69AG. **Higher homotopy groups are an approved future proof library, not an implemented an earlier development milestone runtime capability.**
69AH. **Homotopy-class metadata for graphs is exact under a compiler-selected maximal-tree basis.** Non-tree edges become free generators; adjacent inverse letters reduce.
69AI. **Planning is topology first, rank second, cost third.** Rank cannot fabricate reachability, bypass causality, or override safety.
69AJ. **`shed_rank` and `plan_rank` form one Rank Family but have different domains.** Lower values mean more protected/preferred in both; `shed_rank` governs temporal degradation, while `plan_rank` governs structural route/state choice.
69AK. **Path rank is minimax, not additive.** an earlier development milestone minimizes the maximum edge `plan_rank` on a path, then total cost. Signed ranks therefore remain well-founded without negative-cycle pathologies.
69AL. **Topology-pruned planning must preserve semantics.** an earlier development milestone terminal-preserving leaf pruning removes only vertices proved unable to lie on any simple start-goal path.
69AM. **Homotopy-class collapse is preferable to enumerating equivalent routes.** Future multi-class planners should retain a small set of representatives rather than a combinatorial cloud of path variants.
69AN. **A deformation retract is a search-space deletion permission.** If a state/geometry space is proved to retract to a smaller skeleton, planning should occur on the skeleton and lift back only when needed.
69AO. **Topology and linear algebra may share evidence.** Graph Laplacians, incidence/boundary matrices, sparse operators, and dependency graphs are legitimate cross-domain objects in the same General Structural Proof Graph.
69AP. **Topology changes invalidate proofs locally when possible.** Incremental change propagation should eventually recompute only affected components, cycles, homology blocks, or planning representatives.
69AQ. **No topology benchmark may claim a speedup by changing the chosen rank/cost optimum.** Full and pruned planners must agree on the planning objective.

## 7. General Non-Smooth Strategy

69. **No application-specific recognizer is required.** The compiler should recognize mathematical/dataflow structure, not labels such as chat, editor, simulation, or renderer.
70. **Exact discrete core first.** Discrete branches, topology changes, token/state transitions, and hard discontinuities remain exact.
71. **Incremental Change Propagation is a primary non-smooth accelerator.** A local source/state change invalidates only its dependency cone.
72. **Unchanged completed work remains valid.** Do not recompute unaffected subgraphs.
73. **Adaptive Domain Partition is the default response to localized nonsmoothness.** Split at structural boundaries, keep local regions simple.
74. **Piecewise Chebyshev is permitted inside smooth regions.** It must not cross a discontinuity unless an explicit error certificate proves the resulting representation valid.
75. **Wavelet/multi-resolution representations are an approved general channel for localized changes and sparse multi-scale structure.** Their implementation must earn its place with benchmarks and exact/approximate error contracts.
76. **Dirty-region/damage-tracking is the rendering/dataflow projection of the same dependency principle, not a separate application hack.**
77. **Quadtree/interval hierarchy/AMR-like local refinement are acceptable when the problem has spatial or index locality.**
78. **ENO/WENO/TVD are domain-specific numerical options for discontinuous PDE-like data, not default UI or general-language transforms.**
79. **Unknown/nonclassifiable structure falls back to exact generic execution.**

---

## 8. Matrix-Free Memory

80. **Matrix-free memory is explicit opt-in.** The compiler must not silently trade huge recomputation for modest memory savings.
81. **Prove it can be regenerated, then stop storing it.**
82. **Storage-to-compute substitution requires exact reconstructability or an explicit approximation tolerance.**
83. **Automatic affine detection is a first-class exact representation transform.**
84. **Constant, affine, polynomial, piecewise-polynomial, low-rank, Chebyshev, wavelet, and procedural representations belong to one representation-selection framework.** Not all are required to be implemented in every release.
85. **Reconstruct -> consume -> discard/cache selectively.** Avoid materializing a huge logical field merely to use a small part of it.
86. **Temporary expansion is bounded.** Scratch windows have hard caps.
87. **Adaptive Partial Materialization is allowed.** Frequently reused hot tiles may be materialized while the cold majority stays procedural.
88. **Memory savings and bandwidth savings are benefits; recompute cost is a cost.** A profitability model decides after permission is proven.
89. **The user may express preference for memory or compute, but may not bypass correctness proof.**
90. **Matrix-free can be faster as well as smaller when arithmetic is cheaper than memory traffic.** Treat this as workload-dependent evidence, never as a universal law.
91. **Fallback materialization is a valid outcome.** It is not an optimizer failure.

---

## 9. CPU / GPU / Rendering Placement

92. **Procedural reconstruction is host-neutral.** It may execute on a CPU, Wasm VM, old-style graphics pipeline, modern shader, or another host when the ABI permits.
93. **OpenGL is a backend placement target, not the semantic definition of a field.**
94. **A procedural vertex/attribute field may eliminate a buffer when reconstruction is proven and profitable.**
95. **Do not claim GPU/OpenGL performance without a real driver/context measurement.** Code generation and runtime performance are separate claims.
96. **Old or conservative execution environments are legitimate targets.** A useful representation transform should not require a fashionable API merely to exist.
97. **Placement should eventually be automatic: CPU reconstruct, GPU reconstruct, or partial materialization, selected by evidence and cost.**

---

## 10. Memory and Runtime Discipline

98. **Avoid unpredictable GC on the critical path.** Prefer static, arena, region, frame, or otherwise bounded allocation strategies where possible.
99. **Cache locality matters.** Contiguous arrays, compact metadata, bitsets, and low pointer-chasing are preferred in hot paths.
100. **Do not insert runtime abstraction costs merely to make the source model look sophisticated.**
101. **Closures/dynamic dispatch/generics are allowed only with explicit cost semantics and optimizable lowering.**
102. **A feature may be expressive without being mandatory in the critical runtime.**

---

## 11. Language Completeness

103. **General-purpose status requires ordinary language structure:** functions, parameters, values, arrays/slices, structs, enums, loops/iteration, modules, error handling, memory semantics, and host capabilities.
104. **No workload-specific opcode should masquerade as language completeness.**
105. **Generic data structures and algorithms should lower through ordinary semantics, not benchmark-specific compiler branches.**
106. **Unbounded `while` on the strict main path is rejected unless a future semantics can prove/yield it safely.**
107. **Recursive cycles require a real termination argument; conservative rejection is preferable to an unsound acceptance.**
108. **Error handling must eventually carry temporal/resource semantics rather than turning into an unbounded exceptional slow path.**

---

## 12. Deployment

109. **Source may remain `.webchan`.**
110. **Browser delivery may be a single self-contained `.html` containing the compiled Wasm/runtime adapter.** This is packaging, not source-language identity.
111. **Non-browser delivery may be a raw `.wasm` module.**
112. **WASI is a host profile, not a mandatory dependency.**
113. **Browser-native direct `.webchan` opening is impossible without browser/OS support or an installed launcher; do not fake this by renaming source text to `.html`.**

---

## 13. Benchmark Doctrine

114. **Never call less work the same benchmark unless the reduction is the optimization being measured and semantic equivalence is verified.**
115. **Checksums/residuals/probes/error bounds must accompany structural speedups.**
116. **Warmup and compilation/JIT costs must be separated when the comparison calls for steady-state kernel timing.**
117. **Single-thread means single host execution thread under the stated benchmark; do not borrow hidden worker parallelism.**
118. **Failure-cliff search is mandatory for responsiveness, active working set, and overload behavior.**
119. **Negative tests are mandatory.** A proof optimizer must demonstrate that it refuses or falls back when its preconditions fail.
120. **Do not use specialized benchmark opcodes to manufacture a win.**
121. **Do not compare against a deliberately bad competitor implementation while calling it a language verdict.**
122. **Do not generalize one kernel result into universal language superiority.** Code shape and compiler lowering can dominate microbenchmarks.
123. **Structural speedups must state their baseline.** For example, earlier pre-release milestones proof-auto ratios are versus Webchan's own generic dense fallback, not MKL/LAPACK.
124. **Memory compression ratios must distinguish logical representation bytes from actual Wasm linear memory.**
125. **When a transform makes one axis worse to improve another, report the loss.** Memory-first piecewise representation may consume more ALU than dense loads; that is a legitimate trade, not a result to hide.

---

## 14. Core Slogans, in Technical Form

- **Do not reinvent serial execution. Govern it.**
- **Runtime is the last line of defense, not the first.**
- **Prove, then delete work.**
- **Prove it can be regenerated, then stop storing it.**
- **Smooth globally only when the structure is globally smooth; otherwise localize.**
- **Logical size must not force physical working-set size.**
- **No implicit barrier.**
- **No hidden application-specific optimizer.**
- **Fallback is a feature when proof or profitability fails.**
- **Webchan semantics first; C/LLVM lowering second.**

---

## 15. an earlier development milestone Historical Status Boundary

### Implemented and validated in an earlier development milestone

- causal DAG + ready-frontier scheduling;
- bounded internal `wc_step`;
- input-fair host scheduling pattern;
- progressive completion and no implicit barrier contract;
- ranked degradation metadata;
- sized arrays, structs, enums, bounded user functions;
- conservative termination/call-cycle checking;
- proof-directed banded Gaussian / Krylov-CG / Chebyshev eligibility;
- exact auto-affine/polynomial matrix-free fields;
- recompute/savings profitability gates;
- bounded temporary materialization;
- generic exact piecewise-polynomial fields;
- generic DAG incremental invalidation/change propagation;
- compiler-emitted procedural GLSL for compact representations;
- general Webchan IR structural capability graph;
- ordinary-function purity/affine/monotonicity proofs for the current bounded function IR;
- exact affine-function composition collapse plus same-module reference path;
- matrix proofs for diagonal/lower-triangular/upper-triangular/nonzero-diagonal/strict-DD/static-sparsity/matrix-free-action;
- proof-unlocked Jacobi, Gauss-Seidel, weighted Jacobi, forward/back substitution, and diagonal direct solve;
- profitability-based selection among all proved legal linear-algebra paths;
- zero-import portable Wasm core;
- browser and non-browser execution regression tests;
- negative proof/fallback/contract tests;
- exact finite-graph components, bridges, articulation points, Euler characteristic, cycle rank and graph homotopy/free-group rank;
- exact tree/simple-connectivity/contractibility proof for graph topology;
- exact GF(2) homology for finite simplicial 2-complexes (`beta0/beta1/beta2`);
- Euler-Poincare cross-check;
- elementary simplicial collapse-to-point certificates;
- signed `plan_rank` with minimax-rank then cost planning;
- topology-preserving terminal leaf pruning;
- exact graph homotopy words for emitted plans under a maximal-tree basis;
- topology/planning metadata exported through zero-import Wasm.

### Approved architecture, not falsely claimed as completed in an earlier development milestone

- arbitrary automatic discontinuity discovery from opaque functions;
- automatic piecewise Chebyshev construction for arbitrary smooth regions;
- wavelet runtime compression / sparse coefficient engine;
- arbitrary low-rank tensor/operator proof, Woodbury-like update, and representation;
- automatic CPU/GPU/partial-materialization placement;
- complete module/package/generic/error-handling ecosystem;
- full theorem-prover semantics;
- complete fundamental-group decision for arbitrary finite 2-complexes;
- general higher homotopy groups, homeomorphism recognition, persistent homology, and Morse theory;
- multi-representative homotopy-class planner for arbitrary dynamic graphs;
- universal absolute frame-rate guarantee.

The implementation boundary is part of the manifesto. A future version may extend it, but may not erase the distinction between **implemented**, **proved**, **benchmarked**, **approved**, and **speculative**.

---

## 16. Inverse Parallel Expansion and Wild-Project Independence (an earlier development milestone)

126. **Parallel structure is evidence, not baggage.** A parallel source organization carries dependence information, but worker/scheduler machinery is not automatically part of program meaning.
127. **Preserve dependence; erase orchestration.** When single-host-thread observational equivalence is proved, spawn/join/barrier bookkeeping should disappear before backend lowering.
128. **Do not serialize a parallel runtime when a native serial program can be synthesized.** `P=1` emulation is a fallback representation, not the target design.
129. **Inverse Parallel Expansion is semantic recompilation.** Recover the finite dependence graph, prove what is non-semantic on the target, then regenerate a serial IR.
130. **Causality precedes rank.** `plan_rank` may choose among ready nodes, never reorder across a proven dependence.
131. **Rank-guided re-linearization is a compiler capability.** The chosen linear extension should exploit priority, locality, live-memory pressure and future fusion opportunities when those facts are available.
132. **Parallel partition boundaries are removable only when proved non-semantic.** Contiguity, non-overlap, independence, same computation and compatible rank are current an earlier development milestone fusion gates.
133. **Worker multiplicity must not survive as replicated state without reason.** Proved-private nonescaping worker-local state collapses to the serial representation when workers disappear.
134. **Synchronization removal requires a proof, not a target assumption alone.** Observable races, external atomics, lock timing or host-visible worker identity are outside the current automatic erasure domain.
135. **IPE must compose with existing structural optimization.** After orchestration erasure, ordinary affine, matrix-free, incremental, topology and linear-algebra proofs may continue deleting work/storage/search.
136. **The project remains wild and independent.** Only textbook-level ideas may cross the project boundary; another project's source, scheduler, project-specific IR or optimization implementation is not Webchan's implementation material.
137. **Textbook ideas may move in both directions.** Webchan mechanisms must be explainable in general mathematics/compiler language rather than through dependence on a named external implementation.
138. **Toolchain use is not semantic inheritance.** C/LLVM, Node and Chromium may validate or lower Webchan, but none defines the language semantics.
139. **A migration benchmark must include the naive serialized parallel representation.** IPE performance is measured against preserving the same source semantics while retaining the parallel orchestration, not against an unrelated weak baseline.
140. **Granularity matters.** Scheduler-removal benefits should be measured across fine, medium and coarse task grain; a diminishing benefit at coarse grain is a valid failure-cliff result.
141. **No fake associativity.** Reduction-tree reshaping must respect exact arithmetic semantics or an explicit numerical/associative contract; an earlier development milestone does not silently reassociate arbitrary floating-point reductions.
142. **No fake concurrency proof.** Arbitrary racy shared-memory programs are not accepted merely because the destination has one host thread.
143. **The serial result should expose mature backend optimization opportunities.** Removing artificial worker partitions may enable LLVM to see larger natural loops, but Webchan must not claim LLVM's own local optimization as uniquely Webchan's work.
144. **Orchestration deletion is algorithmic work deletion.** Its value is not only instruction count; it also removes queues, task descriptors, worker-local replicas, barriers, joins and partition metadata from the semantic runtime path.
145. **IPE is a peer core doctrine beside temporal safety, structural algebra, structural topology and matrix-free representation.**

### an earlier development milestone implemented boundary

Implemented and validated:

- finite static fork-join `parallel_region` syntax;
- compute/barrier/join nodes and explicit parallel dependence edges;
- DAG rejection;
- purity-gated orchestration erasure;
- compiler-derived rank-guided linear extension;
- private worker-local scalarization proof;
- proof-gated contiguous equal-function partition fusion;
- Webchan IR IPE proof certificates and unlocks;
- zero-import Wasm IPE metadata/runtime validation API;
- same-semantic naive-serialized vs IPE benchmark witness;
- fine/medium/coarse task-grain benchmark sweep;
- heterogeneous region where fusion is correctly refused but rank re-linearization remains active;
- negative tests for cyclic parallel DAGs, unsafe worker-local declarations and wild-project policy violations;
- textbook-only wild-project compiler contract.

Explicitly not claimed in an earlier development milestone:

- arbitrary race freedom proof for shared mutable memory;
- automatic translation of pthread/OpenMP/CUDA/Java/browser-worker source syntax;
- lock/atomic elimination when synchronization itself is externally observable;
- arbitrary floating-point reduction reassociation without an explicit semantics contract;
- dynamic task graphs with unbounded creation;
- general effect/alias theorem proving for foreign code;
- automatic SIMD/vectorization beyond what the C/LLVM backend legally derives;
- importing or wrapping another project's parallel runtime.

The old doctrine remains unchanged: implementation, proof, benchmark, approved architecture and speculation are distinct statuses and must not be blurred.

**Wild project rule:** Webchan remains a wild project under a textbook-only idea boundary.


---

## 17. External Capability Interface and Interface Non-Reinvention (1.0.0)

146. **External capability interface is a core doctrine.** Webchan should not become a second operating system, network stack, GPU runtime or device-driver ecosystem.
147. **Do not reimplement an interface that already has an authority.** Standards bodies, operating systems, mature libraries and hardware vendors own their respective low-level interfaces.
148. **Capabilities are Webchan semantics; providers are replaceable.** Source code requests `network.tcp`, `gpu.compute`, `filesystem.read`, and similar abilities rather than hard-coding a provider name.
149. **C ABI first when a stable eligible C ABI exists.** Native provider resolution should prefer an existing stable C-callable interface rather than inventing a private Webchan ABI.
150. **Host standards are authoritative inside their host boundary.** Browser and WASI capabilities must respect browser/WASI sandbox and host semantics instead of pretending native driver access exists.
151. **Vendor APIs are legitimate when the capability genuinely requires them or no higher-authority generic provider is available.** CUDA Driver, NIC vendor paths and similar interfaces are not forbidden; they are not the default semantic identity of the capability.
152. **Vendor/driver fallback is explicit in the provider graph.** A low-level provider must not silently outrank a suitable standard/general provider.
153. **Webchan vendors metadata, not foreign implementations.** Provider catalogues may contain interface names, host masks, effect classes and priorities; external source/runtime code does not become Webchan code.
154. **Portable zero-import core and external-capability builds are different valid profiles.** Zero imports remain a property of pure-core builds, not a vanity constraint imposed on programs that actually need the outside world.
155. **External work must cross an explicit boundary.** A capability-enabled Wasm module may import a narrow host bridge; native builds may lower directly to an eligible C ABI.
156. **Potentially blocking foreign work may not silently enter the critical path.** Its operation boundary must be explicitly classified as blocking.
157. **Asynchronous foreign work may not masquerade as immediate direct work.** External effect classification participates in temporal safety before backend lowering.
158. **Effect information belongs to the semantic contract, not to library folklore.** Compiler decisions should use declared/proved operation effects rather than guesses based on provider names.
159. **Provider availability is not provider correctness.** Loading a shared library proves only interface detectability, not hardware presence, permissions, device context validity, or successful execution.
160. **A single-host-thread language may use massively parallel devices.** Host execution order and accelerator execution topology are separate concerns.
161. **IPE preserves useful device parallelism.** Inverse Parallel Expansion erases obsolete host orchestration only when proved unnecessary; CUDA/Vulkan/WebGPU/NIC internal parallelism may remain.
162. **FFI lifetime, ownership and alias facts must eventually become proof inputs.** Opaque foreign handles are not exempt from correctness merely because the ABI is mature.
163. **Error normalization should not erase provider information needed for diagnosis.** Webchan may expose a stable capability-level error category while preserving provider-specific detail behind it.
164. **Provider resolution is a capability-planning problem.** Eligibility, host, authority, availability, temporal effects and cost may all participate, but semantic compatibility comes first.
165. **The provider graph must fail closed.** A missing required capability is unavailable, not silently simulated by an unrelated provider.
166. **No browser sandbox fiction.** Browser Wasm cannot be treated as if it can directly invoke arbitrary native GPU, NIC or filesystem drivers.
167. **No device-name pollution in ordinary source.** Programs should not need to know whether a generic capability resolves to POSIX, WinSock, WASI, WebGPU, Vulkan, CUDA, DPDK or another eligible provider.
168. **Capability specificity is allowed when semantics differ.** If CUDA-only behavior is required, the correct future design is a more specific capability, not pretending CUDA and every generic GPU API are identical.
169. **Provider replacement must preserve the declared capability contract.** Swapping implementations is legal only within semantic/effect compatibility.
170. **External interfaces remain downstream of structural proof.** Webchan may simplify, fuse, delete, reorder or avoid work before an external call when proofs permit; the provider receives only the remaining necessary operation.
171. **External calls may also feed structural proof.** Stable immutability, monotonicity, deterministic-pure results, or shape metadata from an authority may unlock caching and work deletion when they are part of the interface contract.
172. **Interface non-reinvention protects project focus.** Webchan's distinctive work remains proof, structural collapse, temporal safety, matrix-free representation, topology, rank planning and semantic recompilation.
173. **The wild-project rule applies to interfaces.** Specifications and textbook ABI concepts may enter; another project's runtime implementation does not.
174. **C/LLVM remains a lowering tool, not an excuse to expose C as Webchan semantics.** Direct C ABI calls are internal provider lowering.
175. **External capability benchmarking must distinguish dispatch overhead from provider work.** A one-function Wasm bridge benchmark measures ECI crossing cost, not network or GPU throughput.
176. **Provider discovery must be honest about environment limitations.** Missing CUDA, DPDK, RDMA or physical devices are reported as unavailable rather than replaced by fake success.
177. **The authority-first rule may evolve only with evidence.** The default exists to avoid needless private interfaces, not to prohibit a demonstrably superior and semantically necessary provider.
178. **ECI composes with every existing doctrine.** Rank, causality, temporal safety, IPE, matrix-free, topology, structural linear algebra and incremental change propagation remain applicable around external boundaries.
179. **The outside world is a capability graph, not a pile of special cases.** Files, sockets, GPUs, NICs, audio, cameras, databases, compression, USB and future devices enter through the same structural mechanism.
180. **Do not reimplement the world. Prove what is needed, select its authority, and call it through the smallest honest boundary.**

### 1.0.0 implemented boundary

Implemented and validated:

- first-class `capability` declarations with required/optional status;
- first-class `external_op` declarations;
- immediate, asynchronous and potentially-blocking effect classes;
- direct/async/explicit-blocking boundary checking;
- compiler-owned authority/provider metadata catalogue;
- authority-first, C-ABI-preferred, replaceable-provider resolution;
- native POSIX, native Windows, browser and WASI host masks;
- standard/general, host-standard, vendor-C-ABI and explicit-driver provider classes;
- compiler-emitted `external_capabilities.json`;
- Webchan IR capability/provider/effect certificates;
- zero-import portable core retained;
- separate ECI Wasm build with one explicit `webchan_eci.dispatch` import;
- Node and Chromium host-dispatch validation;
- native C probe that performs real stdio/socket/monotonic-clock operations and probes optional shared C ABIs;
- provider selection regression for filesystem, TCP, browser WebGPU, WASI filesystem and vendor-driver fallback;
- negative tests for illegal blocking boundaries and unknown/unapproved capabilities.

Explicitly not claimed in 1.0.0:

- automatic parsing of arbitrary C headers or C++ APIs;
- complete native implementations for every provider in the metadata catalogue;
- proof that a loadable GPU/NIC library implies usable hardware;
- browser escape to native driver interfaces;
- automatic lifetime/ownership theorem proving for all opaque foreign handles;
- automatic conversion between providers with materially different semantics;
- performance superiority of generic C ABI providers over vendor APIs;
- complete WASI component-model binding generation;
- a Webchan-owned network stack, GPU runtime, SQL engine, compression engine or device driver.

The historical doctrine remains unchanged: **implemented, proved, benchmarked, approved architecture and speculative work are different statuses.**

---

## 18. Structural Iteration Algebra (1.0.0 root-structure upgrade)

223. **Finite iteration is structure, not syntax sugar.** Repeated indexed work has a domain, access relation, dependence relation, locality and stage order that must be available to proof.
224. **Do not add transform-specific opcodes when a general index relation explains the work.** FFT, sorting, stencil, graph and wavelet labels are not compiler capabilities.
225. **Linear algebra is an indexed-operator library.** Sparse, banded, diagonal, triangular and matrix-free properties may feed the shared finite-index capability graph.
226. **Topology is a computation-structure library as well as a planning library.** Adjacency, components, cuts, DAG order and collapses may feed legality and pruning proofs.
227. **IPE is the dependence-theory branch of the same structure.** Range fusion and legal re-linearization are loop/dependence transformations after orchestration is removed.
228. **Proof precedes loop transformation.** Fusion, interchange, tiling, vectorization, pruning, scalar replacement and bounds elimination are illegal until dependence/alias/bounds requirements are established.
229. **Numerical semantics survive structural optimization.** Floating-point reductions are not silently reassociated merely because a tree reduction would be faster.
188. **The shared operator graph must fail back exactly.** Missing proof removes a transform; it does not justify an approximation or guessed independence.
189. **A benchmark is a probe, not a feature request.** When one workload exposes a missing structural class, the repair should cover the class rather than the workload.
190. **SIA composes with temporal safety.** A finite iteration proof establishes total work; temporal scheduling still controls continuous occupation and host responsiveness.
191. **SIA composes with matrix-free memory.** An operator action may be generated from index relations without materializing a global matrix or dense relation.
192. **SIA composes with External Capability Interface.** Structural deletion and fusion happen before remaining external work crosses provider boundaries whenever semantics permit.
193. **Backend vectorization is not a Webchan proof.** Webchan proves larger structural legality; LLVM may exploit that legality at instruction level.
194. **The generic index kernel source surface is implemented in 1.0.0/Webchan IR.** Ordinary finite indexed computation lowers into SIA rather than bypassing it.
195. **Bounded nested for is the ordinary iteration surface.** Bounds and positive steps must be statically proved and counted against the declared effect bound.
196. **Gather and scatter are access relations, not privileged instructions.** Every indexed read/write requires a range proof; missing alias/disjointness proof removes unsafe transforms.
197. **Reduction and scan are dependence classes, not automatic reassociation licenses.** Recognition may expose structure while floating-point order remains protected unless semantics explicitly permit change.
198. **Bitwise index maps belong to the same index algebra as arithmetic maps.** A permutation, shift or mask does not justify a workload-named opcode.
199. **The executable kernel boundary remains finite and auditable.** Unbounded loops, opaque pointer mutation and unproved external side effects are not smuggled through SIA.
200. **The root target is one structural optimizer.** Algebra, topology, dependence and index-space reasoning are peer proof libraries over the same finite computation structure.


---

## 19. Structural Data Layout Algebra (1.0.0 / Webchan IR)

201. **Logical arrays are semantic objects; physical layout is a compiler decision.** A source array keeps its identity, element type and extent even when storage is co-located with another array.
202. **Data topology is a first-class optimization dimension.** Operator topology, iteration topology and data topology are optimized together rather than treating memory order as a fixed afterthought.
203. **Layout transformations require proof before profitability.** Same element type, same logical extent, bounded indexed access and distinct logical-array semantics are legality conditions, not heuristics.
204. **Profitability is not proof.** Matched-index reuse may choose interleaving or tiling, but a weak score leaves storage separate without changing semantics.
205. **No workload name is a layout certificate.** `complex`, FFT, particle, RGB, FEM, graph, audio or image labels do not unlock a physical representation.
206. **Element interleaving is a generic locality transform.** It is legal for proved co-accessed fields regardless of the application that produced the relation.
207. **Tiled interleaving is the middle ground between full SoA and full AoS.** This tiled layout preserves bounded contiguous field runs while reducing cross-field reuse distance. It preserves bounded contiguous field runs while reducing cross-field reuse distance.
208. **Separate storage remains the universal fallback.** A missing or unprofitable layout proof cannot make a program invalid and cannot justify speculative packing.
209. **Scalar replacement belongs to the same data-topology family.** A bounded local value whose lifetime does not require memory may remain scalar rather than materializing an array slot.
210. **Matrix-free reconstruction is the zero-materialization endpoint.** Exact reconstructability can remove stored data entirely when the existing recomputation/savings policy approves it.
211. **Physical relayout must be ABI-transparent at the logical-array interface.** `wc_array_get/set` and compiler-generated solver/kernel paths observe the same logical values before and after relayout.
212. **Bounds proof occurs in logical index space.** Physical address arithmetic is generated only after a logical access has passed range proof.
213. **Shared backing storage does not create source aliasing.** Distinct Webchan arrays remain semantically non-aliasing even when the compiler maps them into one internal allocation.
214. **External raw pointers are a separate proof problem.** SDLA does not silently relayout memory whose external ABI exposes raw storage addresses.
215. **The compiler must expose its choice.** Webchan IR records layout kind, group, lane, tile and profitability score so a benchmark can audit what was actually generated.
216. **Layout optimization must survive the same no-sandbag doctrine.** A benchmark-specific manual interleaving is evidence for a missing general transform, not a permanent benchmark exception.
217. **A legal relayout is not guaranteed faster.** Cache models are imperfect; a future cost model may revise a decision while keeping source semantics stable.
218. **No profile result may become a hidden workload branch.** Future profile-guided evidence may feed generic locality costs, but it may not introduce named-kernel recognition.
219. **Structural non-materialization reduces both traffic and recoverable intermediate state.** This is an attack-surface reduction property, not cryptographic encryption.
220. **The root target remains one structural optimizer.** Linear algebra, topology, iteration, dependence, materialization and physical layout are proof libraries over one compiled computation structure.

### Webchan IR implemented boundary

Implemented and validated:

- automatic access-relation collection from generic kernel array references;
- same-type/same-extent/distinct-logical-array legality gates;
- separate physical storage fallback;
- element-interleaved physical storage rewrite;
- tiled-interleaved physical storage rewrite with element-width-scaled textbook block size;
- stable logical array IDs and get/set ABI across rewrites;
- solver and generic-kernel accesses lowered through the same physical mapping;
- runtime/Webchan IR layout introspection;
- scalarized and matrix-free/non-materialized bridge endpoints;
- no workload-specific compiler trigger.

Explicitly not claimed:

- perfect cache or prefetch modeling;
- arbitrary heterogeneous-type object packing;
- relayout of externally exposed raw-pointer memory;
- general pointer alias theorem proving;
- profile-guided layout selection;
- guaranteed speedup for every legal layout.


## 20. General Application Semantics (1.0.1)

195. **General application semantics must reuse the existing proof and temporal machinery.** A second hidden application scheduler/interpreter is forbidden.
196. **Workload/application opcodes are forbidden.** A compiler primitive must survive removal of the motivating application and still be justified as a general type, control-flow, resource, effect, capability or proof mechanism.
197. **Automatic specialization is permitted; hand-written workload recognition is not.** A generic parser, state machine or data structure may collapse after proof, but the compiler may not branch on a product, provider, protocol, model, website or benchmark name.
198. **Bounded ordinary state is first-class.** Regions, text bytes, vectors, maps, result storage, future pools and opaque handles use compile-time finite capacity in 1.0.1.
199. **Stale external/resource identities must fail closed.** Future and handle reuse is protected by generation tokens.
200. **Exact integer lanes must remain exact.** `u64` must not be silently routed through `f64`; bit-preserving ABI paths are required where exactness matters.
201. **General control flow remains structurally bounded.** `while` requires an explicit finite maximum, and blocking ECI calls do not enter bounded kernels.
202. **Imports are compile-time structure, not a runtime loader.** Import cycles are rejected and generated IR must not capture build-machine absolute paths.


## 21. Access-Phase Profitability (1.0.2)

206. **Legality never implies profitability.** A proved physical rewrite may still be rejected when its generic access cost is worse than contiguous logical storage.
207. **Execution phase is optimization evidence.** Co-access inside one operation, short adjacent reuse, phase coverage and independent phases are distinct facts and must not collapse into one undifferentiated locality score.
208. **Protect long contiguous streams.** Large unit-stride working sets retain contiguous storage unless tighter reuse evidence pays for relayout and address work.
209. **Do not solve a bad heuristic with a workload switch.** A motivating application, protocol, browser, benchmark or algorithm name may not enter the compiler decision. Improve the general proof/cost model instead.
210. **Keep accepted layouts cheap to address.** Power-of-two tiled mappings should lower to shift/mask arithmetic when semantics permit it.
211. **Rejected candidates are evidence, not failure.** Webchan IR should expose why a legal transform was declined so the optimizer can be audited without source-level physical-layout hints.


## 22. Optimization Provenance and Adaptive Wasm Profiles (1.0.3)

212. **Webchan admits exactly two optimization classes: Housekeeping Optimization and Luxury Optimization.** There is no third import lane for distinctive external advanced optimizers.
213. **Housekeeping Optimization is deliberately ordinary.** Only classical, broadly taught compiler mechanisms may enter this class: constant/data-flow simplification, dead-work removal, ordinary loop optimization, standard auto-vectorization/SIMD lowering, basic locality costing, and target-feature selection with exact fallback.
214. **Luxury Optimization must be Webchan-original.** A distinctive optimization from another language, paper family, research compiler, framework or benchmark may not be copied, renamed, translated or reimplemented as a Webchan luxury mechanism.
215. **Benchmarks are probes, never teachers.** A single case may reveal a missing general structure; its identity, names, constants and competitive context may not become optimizer predicates.
216. **Probe-triggered admission requires three witnesses.** Keep the origin probe, add a cross-domain witness, and add a negative witness that must reject/fall back. A change that explains only the motivating case is not general enough.
217. **SIMD128 is Housekeeping Optimization.** Webchan source remains scalar/structural; classic vectorization legality and LLVM may lower legal regular work to standard Wasm SIMD128 without creating Webchan SIMD syntax or a luxury claim.
218. **Portable does not mean permanently scalar.** The portable Wasm target may publish a scalar baseline and stronger standards-based variants. The host selects the strongest module it can actually validate/compile and falls back to a semantically equivalent baseline when an optional feature is unavailable.
219. **Feature selection uses capability evidence, not user-agent identity.** Browser names, CPU brands, competitor names and workload names are not target-profile predicates.
220. **Scalar fallback is a correctness path, not a slow-path excuse.** It remains continuously regression-tested and must preserve the same source semantics and public ABI as the optional SIMD128 profile.
221. **A backend feature does not become a Webchan luxury optimization merely because it is fast.** Registers, instruction scheduling, standard SIMD, ordinary vectorization and target lowering remain housekeeping/backend responsibilities.
222. **The optimization ancestry boundary is testable release policy.** The release ships a machine-readable provenance manifest and regression gates for probe evidence, target-profile parity and specialization leakage.


---

## 23. Scalar Loop Housekeeping (1.0.4)

223. **Derived induction variables are ordinary housekeeping.** When a loop counter feeds a proved affine, loop-invariant u32 base relation, the compiler may eliminate the redundant counter using classical induction-variable simplification.
224. **Modulo-u32 sentinel induction requires proof.** For unit-stride `[0,N)` with `0 < N < 2^32`, `i=base; end=base+N; i!=end; ++i` is an exact modulo-u32 representation even across wraparound. If the proof does not hold, preserve the exact original loop or use a separately proved classic versioned fallback.
225. **Non-affine index maps are negative witnesses.** Gray-code, data-dependent, mutating-base, alias-sensitive or otherwise unproved relations must not be forced into the canonical form.
226. **Inlining is profitability-gated.** Tiny transformed kernels stay eligible for inlining; medium loop-heavy transformed kernels may be selectively outlined when the call cost is amortized; giant kernels are not blanket-outlined.
227. **No blanket `noinline`.** Outlining is a code-shape/cost decision, never a language semantic and never a benchmark switch.
228. **The trigger workload does not survive the probe.** Compiler rules may mention only types, dependence, affine structure, mutation, trip bounds and profitability.
229. **This entire section is Housekeeping Optimization.** It adds no Luxury Optimization and imports no distinctive external optimizer.


## Surface discipline

**Top-level source keeps program meaning. Derivable information is resolved by the compiler.**

Source brevity must never be purchased with hidden runtime work. A concise form is acceptable only when it lowers to the same resolved semantics as its explicit form. For release-grade zero-cost surface features, normalized IR and generated backend artifacts are compared directly; where exact byte equality is possible, byte equality is required.

In short: **top-level information may disappear; IR information may not.**

---

## 1.0.6 Structural Web Runtime Unification

151. **Structure, not spelling, grants optimization.** A source form may enter a stronger proof domain only through a verified structural passport.
152. **Proof namespaces are typed.** Generic iteration facts, linear-operator facts, topology facts, dependence facts, temporal facts and storage facts may share evidence only through explicit sound bridges.
153. **Cross-domain evidence is one-way unless the theorem is reversible.** A graph Laplacian inherits linearity, symmetry, sparsity and matrix-free action from finite topology, but an ungrounded Laplacian is not silently declared SPD.
154. **A failed passport is a normal fallback.** Unknown, nonlinear, aliased or runtime-opaque structure remains on the generic path.
155. **The synchronous fast path is not taxed for responsiveness.** Resumable execution is a companion ABI for eligible kernels, not a mandatory wrapper around every `wc_kernel_run`.
156. **Finite is not equivalent to responsive.** Long finite work must have compiler-defined resume boundaries before the browser host can enforce cooperative occupation budgets.
157. **Wall-clock budgets are observed at resume boundaries.** Webchan does not claim impossible mid-instruction preemption of WebAssembly; finer guarantees require finer compiler resume granularity.
158. **Async effects complete through tokens, not hidden blocking.** Host completion, failure and cancellation must preserve Future generation identity.
159. **Backpressure is part of correctness for bounded web execution.** A faster producer may not create an unbounded queue ahead of a slower consumer.
160. **Host events enter bounded state.** Event ingress must respect the active-working-set limit and expose overflow rather than allocate indefinitely.
161. **Repeated unobserved DOM writes may collapse.** Coalescing is legal only when intermediate writes have no required observable boundary before commit.
162. **Deferred repair coalesces invalidations before recomputation.** Repeated changes may delete obsolete repair work while preserving the final observable state.
163. **Worker placement is optional acceleration.** The main-thread design must already be resumable and bounded; Worker availability cannot excuse a blocking default path.
164. **No heavy-web workload gets a private optimizer.** AI, chat, editor, simulation, browser benchmark and product names are forbidden as optimization permissions.
