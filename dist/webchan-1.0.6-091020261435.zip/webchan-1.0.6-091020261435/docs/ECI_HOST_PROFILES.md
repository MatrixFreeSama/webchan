# ECI Host Profiles

## Portable core

No external capability is required. `webchan_core.wasm` remains zero-import.

## Browser

External operations cross the explicit `webchan_eci.dispatch` import. A host adapter may implement capabilities using browser APIs such as Fetch, WebSocket, WebGPU, WebAudio or media capture. Browser sandbox rules remain authoritative.

## WASI

The resolver can select WASI-owned filesystem, HTTP, socket and clock providers when those interfaces are supplied by the host. ECI does not assume a WASI capability exists merely because the module is Wasm.

## Native POSIX / Windows

The default preference is a stable C ABI or platform C-callable interface. The generated provider catalogue can be combined with direct native adapters. Vendor SDKs and drivers remain replaceable fallbacks or capability-specific choices.

## Accelerator parallelism

Webchan's single-host-thread model does not require accelerator execution to be serial. CUDA, Vulkan, WebGPU or a NIC may execute internally in parallel. IPE only erases host-side orchestration that has been proved unnecessary; useful device parallelism is preserved.
