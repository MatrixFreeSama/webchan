# Webchan 1.0.6 Architecture

## 1.0.6 unification layer

The source category is no longer the sole route to a structural optimizer. Ordinary kernels first receive generic iteration analysis and may additionally receive a typed Structural Passport. Existing linear-algebra, topology, matrix-free, SDLA, IPE and temporal capabilities consume only proofs that belong to their namespaces.

The browser runtime adds a parallel execution surface rather than replacing the old fast path: synchronous `wc_kernel_run()` remains available, while compiler-resumable kernels can be driven through adaptive slices. Async ECI, bounded streams, the event mailbox, DOM mutation batching and deferred repair share bounded resource state.

Worker placement is optional. Main-thread correctness and responsiveness do not depend on Worker availability.


```text
.webchan source
   |
   v
Parser + ordinary type/sized checks
   |
   +--> generic bounded index-kernel parsing / range proof
   +--> termination / call-graph checks
   +--> causal DAG construction
   +--> temporal metadata validation
   +--> structural proof discovery
   +--> representation discovery
   +--> exact piecewise-domain validation
   |
   v
Webchan IR: host-neutral semantic IR
   |
   +--> Proof-Directed Algorithm Optimizer
   |      band -> Gaussian specialization
   |      SPD -> Krylov-CG permission
   |      spectrum -> Chebyshev permission
   |
   +--> Proof-Guided Memory Optimizer
   |      constant/affine/polynomial
   |      piecewise-polynomial
   |      bounded scratch materialization
   |
   +--> General Adaptive Structure Engine
          dependency-cone invalidation
          exact domain partition
          local representation selection
   |
   v
Generated internal C
   |
   v
Clang / LLVM
   |
   v
Portable Wasm profiles
   |
   +--> scalar baseline
   +--> standard SIMD128 optional profile
   +--> capability-based strongest-supported selector
   |
   +--> Browser adapter
   +--> Node / standalone Wasm host
   +--> future WASI/desktop/game/embed profiles
   +--> compiler-emitted GLSL helpers where useful
```

The adaptive engine has no AI-chat-specific branch. Browser rendering is one possible projection of the same generic dependency/locality semantics.

## an earlier development milestone General Structural Proof Layer

Between semantic checking and C lowering, Webchan IR carries a property/capability graph. The graph is shared by ordinary functions, fields, dependency DAGs and numerical operators. Linear-algebra properties currently form the richest implemented library, but no application name is part of the optimizer contract.

The key architectural rule is:

`structure -> proof -> capability -> profitability -> rewrite -> fallback`

This layer owns algorithm changes and work deletion. LLVM remains responsible for instruction-level optimization after the high-level structure has been selected.


## Structural proof domains in an earlier development milestone

`General Structural Proof Optimizer` now has peer libraries for Structural Linear Algebra and Structural Topology. Both lower into Webchan IR capabilities before C generation. Topological planning is therefore not a host-side helper or JavaScript wrapper; graph/complex declarations are parsed, validated, proved and compiled by `webchanc`, and the resulting proof metadata/plans are exported from the same zero-import Wasm core.

---

## an earlier development milestone Inverse Parallel Expansion placement

```text
parallel-shaped .webchan source
        |
        v
finite fork-join region IR
        |
        +--> dependence DAG proof
        +--> ordinary function purity proof
        +--> private worker-local proof
        |
        v
orchestration quotient
(spawn/barrier/join erased when proved nonsemantic)
        |
        v
rank-guided legal linear extension
        |
        +--> optional contiguous partition fusion
        |
        v
ordinary Webchan IR
        |
        +--> Structural Algebra
        +--> Structural Topology
        +--> Matrix-Free / Incremental / Temporal passes
        |
        v
internal C -> LLVM -> Wasm
```

IPE is upstream of backend lowering. No worker scheduler is linked into the portable core to implement the optimized representation.

## 1.0.0 External Capability Interface placement

```text
.webchan capability declarations
        |
        +--> capability/effect validation
        +--> authoritative provider catalogue lookup
        +--> direct/async/explicit-blocking boundary proof
        |
        v
Webchan IR external capability nodes
        |
        +--> portable core profile: no provider imports
        |
        +--> Wasm ECI profile: explicit webchan_eci.dispatch import
        |
        +--> native profile: generated C provider catalogue / direct C ABI adapter
```

ECI is downstream of Webchan semantics and upstream of host ABI binding. Provider implementations are not copied into the compiler or runtime.

## Structural Iteration Algebra placement (Webchan IR)

```text
ordinary proved structures
   |-- generic bounded index kernels
   |-- static matrices
   |-- finite topology relations
   |-- IPE dependence/range regions
   v
Structural Iteration Algebra
   finite index domain
   access/locality relation
   dependence/stage relation
   proof-gated transform capabilities
   |
   +--> Structural Linear Algebra
   +--> Structural Topology
   +--> IPE fusion/re-linearization
   +--> Matrix-Free / sparsity / scalar replacement
   v
internal C -> LLVM
```

SIA is a shared structural IR layer, not an algorithm library. Webchan IR accepts an ordinary generic finite indexed-kernel surface and contains no FFT, butterfly, sort, stencil or other workload-specific opcode. Bounded nested loops and proved mutable indexed access lower into the same graph as matrices, topology and IPE. Unbounded loops, opaque alias mutation and unproved dependence remain explicit implementation boundaries.


## Structural Data Layout Algebra placement (Webchan IR)

```text
source arrays
  -> logical index/bounds/dependence proof
  -> SIA access topology
  -> SDLA legality + locality profitability
  -> separate / interleaved / tiled / scalarized / non-materialized endpoint
  -> compiler-generated physical lvalue mapping
  -> C / LLVM
```

The physical mapping is used by generic kernels, solver paths and the logical array ABI. This prevents a source-level benchmark from claiming a layout optimization that the compiler did not actually perform.
