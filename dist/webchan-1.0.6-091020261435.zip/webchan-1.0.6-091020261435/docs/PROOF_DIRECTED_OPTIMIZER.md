# Proof-Directed Optimizer

## Principle

Webchan does not prove propositions for display. A proof is useful when it grants the optimizer permission to replace a more general computation with a cheaper one.

```text
candidate structure
 -> derive property
 -> validate proof preconditions
 -> estimate benefit
 -> unlock transformation
 -> retain exact fallback
```

The core rule is:

> Prove only what can delete work.

A proof and an optimization are separate objects. A property may be proved even when the associated transformation is not profitable. `proof_policy profitable_only` controls selection, not mathematical truth.

## Trusted boundary

Source assertions are not proof certificates. `proof spd A true` is rejected. In an earlier development milestone certificates are emitted only by compiler proof procedures from source-level constructions.

## Current proof permissions

For a static band matrix, Webchan can derive:

- `banded`: nonzero offsets are finite and known;
- `symmetric`: every off-diagonal band is constructed symmetrically;
- `strict_diagonal_dominance`: diagonal magnitude exceeds a conservative row-sum bound;
- `spd`: symmetry + positive Gershgorin lower bound;
- `spectrum_bound`: a positive interval containing all eigenvalues;
- sized RHS/output equality.

The corresponding permissions are:

- SPD + bandwidth -> banded Gaussian without pivot search;
- SPD -> Krylov-CG;
- positive spectral interval -> Chebyshev semi-iteration and precomputed coefficients;
- sized dimension equality -> internal bounds-check elision.

## Fallback

If a required fact is unproved, the transformation is unavailable. The program remains legal when a generic exact path exists. For linear solve an earlier development milestone falls back to dense Gaussian.

This is intentionally different from a proof assistant: lack of proof normally means **less optimization**, not rejection of an otherwise meaningful program.
