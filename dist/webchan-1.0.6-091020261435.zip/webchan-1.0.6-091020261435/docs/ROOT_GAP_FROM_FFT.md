# Root Gap Exposed by a Staged Indexed Transform

## Finding

A staged indexed transform exposed a missing **structural class**, not a missing algorithm library.

The old compiler could already prove:

- properties of a static linear operator;
- properties of a finite graph/complex;
- properties of a finite fork-join dependence DAG;
- bounded scalar repetition.

What it could not represent as one first-class structure was:

`finite index domain + mutable indexed state + index maps + local interactions + stage dependence + repeated operator composition`

That class is now named **Structural Iteration Algebra (SIA)**.

## Why this matters beyond one transform

The same structural class appears in:

- stencil and finite-difference sweeps;
- finite-element local assembly;
- sparse gather/scatter;
- graph-neighborhood updates;
- tree reductions;
- scans/prefix operations;
- sorting/selection networks;
- wavelet and multiresolution transforms;
- multigrid transfers and smoothers;
- block/tiled linear algebra;
- tensor contractions;
- repeated nonlinear/Jacobian local actions.

Adding a dedicated opcode for any one member would leave the root gap intact.

## Mathematical merge

### Linear algebra supplies operator structure

- sparse/band support;
- diagonal/block structure;
- permutation operators;
- operator products;
- tensor/Kronecker factorizations;
- matrix-free actions;
- spectral and convergence certificates.

### Topology supplies relation/dependence structure

- adjacency/local neighborhoods;
- connected components;
- cuts and articulation;
- DAG/topological order;
- matchings/color classes for conflict-free local work;
- collapse/quotient structure.

### Compiler iteration theory supplies schedule legality

- finite induction domains;
- dependence analysis;
- alias/disjointness;
- fusion/fission;
- interchange;
- tiling/strip mining;
- unrolling;
- vectorization legality;
- invariant hoisting;
- reduction/scan recognition.

SIA is the bridge where these three textbook families meet.

## Current implementation

Webchan IR now emits one shared finite-index operator graph from:

- ordinary generic bounded index kernels;
- Structural Linear Algebra matrices;
- Structural Topology graphs;
- IPE dependence regions.

The ordinary kernel path implements bounded nested `for`, mutable proved indexed reads/writes, loop-carried scalars, arithmetic/affine and bitwise index maps, gather/scatter-shaped access, and reduction/scan dependence recognition. Generated code exports both `wc_user_kernel_*` execution/proof metadata and `wc_user_sia_*` unified operator metadata.

The regression suite runs unrelated elementwise, neighborhood, prefix-state, permutation and tiled-loop probes plus a staged radix-2 transform through this same path. The compiler contains no workload-specific opcode or workload-labelled lowering branch.

## Honest remaining boundary

The root executable gap is closed for the finite structural class above, but this is not a claim of unrestricted imperative iteration. Remaining boundaries include:

- no unbounded or data-dependent `while` in generic kernels;
- no arbitrary pointer/opaque alias mutation;
- no automatic floating-point reassociation without explicit semantic permission;
- conservative fallback when injectivity/disjointness or dependence cannot be proved;
- no claim that every symbolic loop nest has a complete polyhedral transform solution;
- no workload-named optimization path.

The next optimizer growth should therefore deepen general dependence, injectivity, tiling/vectorization and numerical-semantic proofs rather than add benchmark-specific syntax.

## Anti-benchmark-specialization rule

A benchmark may reveal a missing structural class. It may not authorize a benchmark-named compiler branch.

Repair policy:

`benchmark symptom -> identify mathematical/compiler class -> implement the class -> regression-test unrelated members of the class -> rerun benchmark`

This is the intended root-level upgrade path for Webchan.

## Second root gap: data topology

After SIA made the transform expressible, a second failure appeared: two semantically equivalent layouts could have materially different single-thread cost. Writing two logical fields as separate arrays and manually rewriting them into one interleaved array changed performance even though the algorithm and dependence graph were unchanged.

That exposed another structural class:

`logical arrays + matched-index co-access + element type/extent compatibility + alias/lifetime legality + physical storage topology`

Webchan IR closes this gap with **Structural Data Layout Algebra (SDLA)**. The source is allowed to remain as ordinary independent arrays. The compiler derives co-access evidence, keeps weakly related streams separate, selects tiled storage for moderate locality, and selects element interleaving for high locality. Existing scalar replacement and matrix-free non-materialization are the lower-storage endpoints of the same framework.

The benchmark repair therefore follows the same anti-specialization rule:

`manual layout win -> identify generic locality relation -> prove legality -> compiler-owned physical rewrite -> validate unrelated arrays and ABI transparency -> rerun probe`

No transform, complex-number or benchmark name enters the compiler decision.
