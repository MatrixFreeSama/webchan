# Linear Algebra Proofs retained in an earlier development milestone

Consider a real symmetric band matrix whose main diagonal is `d` and whose symmetric off-diagonal bands have constants `c_k`.

For any row, Webchan uses the conservative radius

`R = 2 * sum_k |c_k|`.

Boundary rows contain fewer off-diagonal entries, so this is a valid global upper bound.

If `d > R > = 0`, every Gershgorin interval lies inside

`[d - R, d + R]`.

Because the matrix is real symmetric, all eigenvalues are real. If `d - R > 0`, every eigenvalue is positive, therefore the matrix is SPD. an earlier development milestone records

`lambda_min = d - R`

and

`lambda_max = d + R`.

For the shipped example, `d=4`, `c_1=-1`, so `R=2` and the certified enclosure is `[2,6]`.

## Why this unlocks algorithms

### Gaussian family

Generic dense Gaussian elimination must consider an `n x n` matrix and pivoting. A proved narrow band lets the compiler restrict elimination to the band. SPD guarantees positive leading principal minors in exact arithmetic, so the no-pivot path is admissible for this generated family.

### Krylov-CG

Conjugate gradient requires SPD. Without an SPD certificate, an earlier development milestone does not expose CG to `proof_auto`.

### Chebyshev semi-iteration

Given a positive spectral enclosure `[a,b]`, the compiler precomputes relaxation parameters from shifted Chebyshev roots. The standard minimax error polynomial gives a convergence factor governed by

`q = (sqrt(kappa)-1)/(sqrt(kappa)+1)`, `kappa=b/a`.

The compiler chooses the number of Chebyshev steps from the requested tolerance, capped by `max_iter`, then emits the coefficients into the generated Wasm program. No runtime trigonometric library is required.

## Floating-point boundary

The structural proofs are mathematical facts about the declared real matrix family. Floating-point implementations still have rounding error. Therefore validation checks both residual and agreement against the dense reference path. an earlier development milestone does not claim bitwise equivalence for iterative methods.

## an earlier development milestone additions: stationary iterations and structural collapse

The proof library now derives strict diagonal dominance independently of symmetry. For the implemented band family this gives a sound convergence permission for Jacobi. Gauss-Seidel is unlocked from strict diagonal dominance, SPD, or triangular structure. Positive normalized spectrum bounds additionally permit compiler-derived weighted Jacobi.

Triangular and diagonal proofs are stronger than convergence proofs: they collapse the problem to finite direct forms. Lower triangular operators use forward substitution, upper triangular operators use back substitution, and diagonal operators use independent division. `proof_auto` compares estimated work across all proved-legal methods.

Static sparsity and exact compact operator action are also emitted as reusable capabilities. They are intended to support repeated symbolic-assembly reuse and matrix-free actions in future nonlinear/global-assembly pipelines without introducing a Newton-specific optimizer keyword.
