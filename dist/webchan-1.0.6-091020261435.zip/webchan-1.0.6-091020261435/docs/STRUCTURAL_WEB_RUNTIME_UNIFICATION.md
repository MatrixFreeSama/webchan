# Structural Web Runtime Unification

Release: Webchan 1.0.6

## Rule

**Structure, not syntax, grants optimization. Bounded host occupation, not eventual completion, governs web execution.**

The compiler and runtime therefore use two related certificates:

1. structural passports describe properties that may unlock legal transforms;
2. resumable/async resource state describes where execution may yield, resume, cancel or backpressure without changing program semantics.

## Structural passport

The ordinary-kernel linear passport currently records conservative properties including:

- linear operator;
- diagonal or banded structure;
- symmetry;
- strict diagonal dominance;
- SPD when proved;
- positive spectrum bound when proved;
- static sparsity;
- matrix-free action;
- source/destination array identity;
- operator bandwidth;
- solver capability mask.

A property is absent when the compiler cannot prove it. Absence is not treated as false mathematical knowledge; it simply does not grant an optimization permission.

### Cross-representation equivalence

A declared matrix and an ordinary indexed kernel may reach the same solver capability mask when they prove the same structure. The source category is not itself permission.

The current positive probes include diagonal scaling and a symmetric three-point stencil. The nonlinear negative witness `y[i] = x[i] * x[i] + 1` receives no linear passport.

### Topology to linear algebra

For a supported finite undirected graph, the graph Laplacian is constructed conceptually from the same topology evidence. Its typed linear passport records:

- linear;
- symmetric;
- static sparsity;
- matrix-free action;
- positive semidefinite;
- nullity equal to the number of connected components.

The ungrounded Laplacian is not marked SPD and receives no solver unlock solely from these facts. A stronger solver permission requires additional proof such as a grounded/restricted domain and compatible right-hand side.

## Responsive kernel execution

`wc_kernel_run()` remains the synchronous throughput path.

Eligible kernels also receive continuation state and the resumable ABI:

```text
wc_kernel_resume_reset(id)
wc_kernel_resume(id, work_budget)
wc_kernel_resume_done(id)
wc_kernel_resume_cursor(id)
```

The host returns to the event loop after generated slices. The browser runtime observes each slice duration and adjusts the next work-unit budget toward `slice_budget_ms`, while `max_continuous_ms` acts as a host-side ceiling check at resume boundaries.

This is not arbitrary preemption. WebAssembly cannot be interrupted safely in the middle of an indivisible generated operation by this runtime. The temporal guarantee is therefore bounded by compiler-inserted resume granularity.

## Async ECI and cancellation

The generic ECI imports are limited to the explicit bridge family:

```text
dispatch
async_start
async_cancel
```

An async start carries the external operation, Future pool, generation token and arguments. The host owns a request record and an `AbortController`. Completion writes into the Future only if the generation token is still valid. Cancellation aborts the provider and terminalizes the Future. A late completion cannot resurrect cancelled state.

## Bounded streams

Streams have fixed capacity and explicit state. The host writes only through exported contiguous spans and commits the number of bytes actually written. Consumers likewise read/consume bounded spans.

High/low watermarks provide backpressure. This prevents a faster producer from creating an unbounded queue ahead of a slower parser or renderer.

## Event mailbox

DOM events, Future completion/failure and other host events may enter the same bounded FIFO mailbox. The mailbox does not allocate without bound and exposes overflow explicitly.

## DOM commit

The browser host batches text, attribute and property changes. The queue key is the target plus mutation kind/property name, so repeated writes to the same location collapse to the last observable write before commit.

## Deferred repair

`wc_defer_invalidate(root)` marks the affected dependency cone dirty without immediately discarding completed state. Repeated invalidations coalesce. `wc_apply_deferred_repairs()` commits each dirty task once, then the existing causal scheduler recomputes only reopened work.

## Boundaries

1.0.6 does not infer hidden structure from opaque runtime values. A runtime-created adjacency buffer is not automatically declared a topology unless the compiler has static evidence sufficient to prove that relation.

Likewise, task DAGs are not blindly treated as IPE partition regions. IPE requires the stronger independence, range and locality evidence needed for orchestration erasure.

These are deliberate proof boundaries, not application-specific exceptions.
