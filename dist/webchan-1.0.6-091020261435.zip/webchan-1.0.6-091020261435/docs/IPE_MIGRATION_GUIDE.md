# IPE Migration Guide

When importing the semantics of a parallel algorithm into Webchan, do not begin by emulating its worker API.

1. Express bounded compute regions and their true dependencies as a finite `parallel_region` DAG.
2. Express worker-private temporary state as `worker_local ... private` only when it is genuinely private and nonescaping.
3. Preserve dependencies that affect results. Do not encode thread IDs, queue IDs or barrier numbers as application state unless they are truly observable semantics.
4. Attach `plan_rank` only as a preference among causally legal compute nodes.
5. Let the compiler decide whether orchestration is erasable.
6. Let partition fusion occur only after the exact contiguity/independence/same-function proof.
7. Validate the migrated result against the naive serialized representation with semantic checksum/probes before making a performance claim.

The migration target is not "parallel code running on one thread". It is a new serial program synthesized from the same dependence semantics.
