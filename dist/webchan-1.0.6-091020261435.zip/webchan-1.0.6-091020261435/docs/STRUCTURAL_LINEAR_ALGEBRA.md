# Structural Linear Algebra in Webchan earlier release

Webchan uses linear algebra as a proof-to-optimization library rather than as a closed numerical DSL.

## Capability lattice

A matrix/operator may simultaneously prove several properties:

`static sparsity -> assembly/index reuse`

`matrix-free action -> no global dense assembly`

`symmetry + strict positive DD -> SPD -> CG`

`SPD + spectrum interval -> Chebyshev / weighted Jacobi`

`strict DD -> Jacobi + Gauss-Seidel`

`lower triangular -> forward substitution`

`upper triangular -> back substitution`

`diagonal -> scalar division`

The optimizer chooses the cheapest **legal** path, not the most fashionable method.

## Jacobi

For the current supported matrix family, strict diagonal dominance is used as a sufficient convergence certificate. If the certificate is unavailable, method 5 is not callable through the proof-unlocked ABI.

## Gauss-Seidel

Gauss-Seidel is unlocked by a sufficient convergence proof: strict diagonal dominance, SPD, or triangular structure. A lower-triangular system is a special finite-collapse case: a Gauss-Seidel sweep is equivalent to forward substitution, so `proof_auto` selects the cheaper direct structural form.

## Weighted Jacobi

When the compiler also knows a positive spectrum interval and the diagonal is a scalar multiple of identity in the current band family, it derives an optimal relaxation parameter for the bounded interval. The interval is a proof input; the weight is compiler-generated, not hand tuned.

## Gaussian, Krylov and Chebyshev

The existing earlier pre-release milestones proof paths remain. Dense Gaussian is the generic fallback. Banded structure deletes global zero work. SPD enables CG. Positive spectral bounds enable Chebyshev. All residuals are checked in release tests.

## Global assembly

The band representation itself is an exact compact operator description. The compiler therefore records `static_sparsity` and `matrix_free_action`. Iterative methods operate through the exact `A*x` action and do not need a separately materialized dense global operator.

This is the basis for later repeated nonlinear assembly optimization: if a changing Jacobian preserves the same proved topology, symbolic assembly can be reused while only numeric state is updated.

## Structural Iteration Algebra bridge

The matrix capability graph is now also projected into Webchan IR's Structural Iteration Algebra. A proved matrix is a finite indexed linear operator with an extent, locality relation, sparsity relation and optional matrix-free action. This does not replace linear-algebra proofs; it gives them a common execution-structure language shared with topology and IPE.

Consequences already represented in the shared capability graph include static-sparsity pruning/reuse, matrix-free action and direct diagonal/triangular collapse. Future ordinary bounded indexed loops may lower to the same operator form and inherit these proofs without an algorithm-specific opcode.
