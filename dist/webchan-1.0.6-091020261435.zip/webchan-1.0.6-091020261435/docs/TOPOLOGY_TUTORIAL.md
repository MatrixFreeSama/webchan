# Structural Topology Tutorial

## A. Graph proofs

```text
topology loop_space nodes 4
edge 0 1 cost 0.2 plan_rank 5
edge 1 3 cost 0.2 plan_rank 5
edge 0 2 cost 1.0 plan_rank -5
edge 2 3 cost 1.0 plan_rank -5
endtopology

plan route topology loop_space start 0 goal 3 objective rank_then_cost
```

The compiler derives:

- `beta0 = 1`: connected;
- `beta1 = 1`: one independent graph cycle;
- `chi = 0`;
- `pi1 = F1`, the free group on one generator;
- the cheaper route has worse rank `5`;
- the rank-first route has rank `-5`, cost `2.0`;
- its homotopy word is generator `1` in the selected maximal-tree basis.

This demonstrates that rank is a semantic planning priority, not a post-hoc sorting label.

## B. Tree proof

A connected graph with `V-1` edges and no cycle has `beta1=0`. For a graph this proves the realization is a tree, hence contractible and simply connected.

## C. Simplicial homology

```text
complex filled_triangle vertices 3
simplex1 0 1
simplex1 1 2
simplex1 0 2
simplex2 0 1 2
endcomplex
```

The compiler forms the boundary maps over GF(2). The result is:

`(beta0,beta1,beta2) = (1,0,0)`, `chi=1`.

The free-edge / free-face sequence collapses the triangle to a point, giving a constructive contractibility certificate.

## D. Why `H1=0` is not enough

The boundary of a tetrahedron has:

`(beta0,beta1,beta2) = (1,0,1)`.

`beta1=0` does not by itself justify `simply_connected=true` in the general 2-complex engine. an earlier development milestone therefore leaves that property unproved unless it has a stronger certificate.

The policy is conservative by design: false negatives are acceptable for optimization eligibility; false mathematical claims are not.
