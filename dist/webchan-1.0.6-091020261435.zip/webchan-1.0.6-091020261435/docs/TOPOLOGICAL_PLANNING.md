# Webchan earlier release Topological Structural Planning

## 1. Planning is property-driven

The planner does not recognize maps, robots, games, chats, or workflows. It consumes a graph-like state topology and a rank/cost contract.

The ordering is:

1. topology validity / reachability;
2. causal and safety constraints;
3. `plan_rank`;
4. numerical cost.

Rank never creates an edge, crosses a disconnected component, or overrides a safety/cause constraint.

## 2. Rank Family

Webchan has two distinct rank channels with the same ordering convention: lower means more protected / more preferred.

- `shed_rank`: temporal overload policy. Higher values are easier to shed or defer.
- `plan_rank`: structural planning policy. Lower values are preferred.

They are not interchangeable fields because one controls execution degradation and the other controls route/state selection.

### Path aggregation

an earlier development milestone minimizes the worst edge rank on a path:

`R(path) = max_e plan_rank(e)`

Then it minimizes ordinary cost among paths with equal `R`.

This minimax form is deliberate. Signed ranks are legal, including strongly preferred negative ranks, without introducing negative-cycle pathologies. The path objective is:

`min lexicographically ( max plan_rank, sum cost )`

## 3. Topological pruning

Before Dijkstra-like rank/cost search, the compiler may prove that some vertices cannot lie on any simple start-goal route. an earlier development milestone implements exact terminal-preserving leaf pruning:

- retain start and goal;
- repeatedly remove any other active vertex of degree <= 1;
- continue until fixed point.

For nonnegative edge costs and rank-first simple-route planning, these removed dead branches cannot improve a valid terminal path.

The remaining graph is a smaller exact search space, not an approximation.

## 4. Homotopy-aware planning

For graph topology, each emitted path carries a reduced free-group word under a compiler-selected maximal-tree basis.

This permits future policies such as:

- one representative per homotopy class;
- rank the classes before local optimization;
- preserve a protected class during incremental replanning;
- invalidate only classes touched by a topology change.

an earlier development milestone emits exact graph homotopy words but does not yet run a multi-class K-representative planner.

## 5. Automatic planning output

A source declaration:

```text
plan route topology G start 0 goal 9 objective rank_then_cost
```

is compiled into:

- exact planned path;
- worst `plan_rank`;
- total cost;
- full-search expansion count;
- topology-pruned expansion count;
- number of pruned vertices;
- reduced graph-homotopy word.

The same proof metadata is exported through the portable Wasm ABI for validation and host use.
