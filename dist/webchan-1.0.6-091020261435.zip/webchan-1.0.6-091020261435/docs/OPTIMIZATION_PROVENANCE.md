# Webchan Optimization Provenance Doctrine

Webchan 1.0.6 retains exactly two admitted optimization classes. The optimizer inventory remains the same 20 Housekeeping entries and 8 Luxury entries established by the earlier releases. Version 1.0.6 does not add a third class or a new Luxury name; it broadens proof flow across equivalent structures and makes bounded web-runtime mechanisms executable.

## Housekeeping Optimization

**Housekeeping Optimization（管家优化）** is ordinary compiler maintenance: old, broadly taught, textbook-level mechanisms whose purpose is to prevent avoidable low-level waste. These mechanisms do not define Webchan's technical identity.

Admitted examples include constant folding/propagation, dead-code elimination, common-subexpression elimination, copy propagation, strength reduction, loop-invariant code motion, basic inlining, tail-call elimination, SSA/data-flow analysis, liveness/basic alias analysis, classic loop unrolling, ordinary auto-vectorization, standard SIMD lowering, basic cache-locality costing, escape analysis, basic devirtualization, peephole optimization, and target-feature detection with semantically equivalent fallback.

A mechanism is not admitted merely because it is old or published. The threshold is deliberately stricter: it should be explainable as common compiler-textbook infrastructure without importing a distinctive modern project, paper, language, scheduler, or optimizer implementation.


### 1.0.4 loop housekeeping

The 1.0.4 probe repair remains entirely inside Housekeeping Optimization. It may recognize a proved affine derived induction variable, eliminate the redundant counter when modulo-u32 sentinel iteration is exact, and keep a transformed medium-size loop out of an overgrown dispatcher only when a generic profitability gate says call overhead is amortized. Tiny and very large witnesses remain inline; non-affine or mutating-base witnesses remain untransformed.

These are classical induction-variable simplification and inlining/outlining profitability mechanisms. No workload, competitor, browser, provider, or benchmark identity is admissible in the decision.

## Luxury Optimization

**Luxury Optimization（奢侈优化）** is the part that may create Webchan-specific technical peaks. Luxury Optimization is admitted only when it originates inside Webchan's own design line. It must not be copied, renamed, or reimplemented from a distinctive external advanced optimizer.

Current Webchan-origin examples include temporal safety/bounded host occupation, causal ready-frontier execution, rank-guided execution, active working sets, structural work deletion, matrix-free storage-to-compute substitution, Inverse Parallel Expansion, progressive completion/deferred repair, and Webchan's own structural-algebra unification.

Housekeeping keeps the compiler from wasting ordinary machine opportunities. Luxury Optimization is what makes the language Webchan.

## Probe doctrine

**Benchmarks are probes, never teachers.** A benchmark may reveal that a general structure is missing or misclassified, but the benchmark identity is forbidden from entering the optimizer.

Before a probe-triggered change becomes a general optimization, it must have three witnesses:

1. **origin probe**: the workload that exposed the problem;
2. **cross-domain witness**: a materially different workload exhibiting the same structural rule;
3. **negative witness**: a similar-looking case where the transform must be rejected or fall back.

The resulting compiler condition must be stated entirely in generic semantic, dependence, locality, cost, type, resource, or target-feature terms.

## Forbidden third class

There is no "useful external advanced optimization" admission lane. A distinctive optimization from another language, research system, paper family, compiler project, or benchmark solution is rejected unless it has become truly commonplace textbook housekeeping at the strict threshold above.

Toolchains remain usable. LLVM, system libraries, browser engines, operating-system ABIs, and standard Wasm features can execute housekeeping work below Webchan semantics. Toolchain use is not optimization ancestry.

## 1.0.6 structural/runtime expansion

The 1.0.6 Structural Passport is not admitted as a new optimization category. It is a proof-routing layer for the existing structural-algebra Luxury mechanism. An ordinary kernel may inherit linear-algebra permissions only when its arithmetic/index relation proves the same properties. Nonlinear and insufficient-evidence witnesses remain generic.

Likewise, resumable kernels, bounded streams, event mailboxes, async ECI completion/cancellation, DOM coalescing and deferred-repair scheduling are runtime realizations of the existing temporal-safety, active-working-set and progressive-completion/deferred-repair design line. They do not authorize workload-specific optimizer predicates.

Graph Laplacians demonstrate cross-domain proof reuse: topology proves component count and graph structure; the linear namespace receives only the properties that follow soundly. The ungrounded Laplacian is not promoted to SPD and does not receive a solver unlock without additional proof.
