# Webchan earlier release General Structural Proof Optimizer

## Purpose

Webchan earlier release treats proof as an optimization-permission system. The compiler does not ask “is this a Newton program?” or “is this a renderer?”. It asks which semantic properties are derivable from the program and what transformations those properties legally unlock.

The central object is a **capability graph**:

`source/IR structure -> proof certificate -> legal optimization capabilities -> profitability model -> transformed Webchan IR -> exact fallback`

The first mature knowledge library is numerical linear algebra because its preconditions and algorithmic consequences are unusually crisp. The same property system is intentionally reusable by ordinary functions, dataflow tasks, fields, memory representations, and future operators.

## Implemented property families

### Ordinary bounded functions

Current function IR can prove:

- purity (all current primitive function instructions are side-effect free);
- affine composition;
- monotonicity for an affine map with non-negative slope.

If an affine chain is proved, Webchan IR can collapse repeated affine operations to one `A*x+B` map. A same-module reference path is kept for validation. On the shipped benchmark LLVM already optimizes the reference path almost equally well, so an earlier development milestone records semantic/IR collapse without claiming a unique runtime speedup.

### Static matrix/operator structure

For the current band-constructible matrix family, the compiler derives:

- bandedness;
- static sparsity;
- exact matrix-free operator action;
- symmetry;
- diagonal structure;
- lower/upper triangular structure;
- non-zero diagonal;
- strict diagonal dominance;
- SPD as a sufficient consequence of symmetry + positive strict diagonal dominance;
- Gershgorin-style positive spectral bounds for the supported SPD family;
- Jacobi convergence permission;
- Gauss-Seidel convergence permission.

No source directive can simply assert `proof spd true` or `proof jacobi_converges true`.

## Implemented optimization unlocks

| Proof | Legal capability |
|---|---|
| static sparsity | symbolic assembly/index reuse |
| exact operator action | global assembly elision / matrix-free action |
| safe band structure | banded Gaussian |
| SPD | Krylov-CG |
| positive spectrum bound | Chebyshev semi-iteration |
| strict diagonal dominance | Jacobi |
| strict DD / SPD / triangular | Gauss-Seidel |
| normalized spectral interval | weighted Jacobi |
| lower triangular | forward substitution |
| upper triangular | back substitution |
| diagonal | direct scalar division |
| sized arrays | bounds-check elision in proved loops |

Proof does not force a method. `proof_auto` compares estimated work after all legal methods are known.

## Newton-Raphson and global assembly

Newton-Raphson is deliberately **not** a special optimizer opcode. In a future nonlinear operator pipeline, a Jacobian receives acceleration only if ordinary structural analysis proves reusable properties such as:

- unchanged sparsity topology between nonlinear iterations;
- exact local-to-global operator action;
- symmetry/SPD in a valid state region;
- low-rank numerical change;
- reusable symbolic factor structure;
- bounded spectral region.

Thus the acceleration belongs to the structure, not to the algorithm name.

## Generalization beyond numerical code

The same capability mechanism is intended to power ordinary programs:

- pure function -> reorder/speculate/share/memoize;
- affine state update -> composition collapse / representation collapse;
- monotone transform -> future search/filter collapse;
- local dependency cone -> incremental recompute;
- reconstructable field -> matrix-free memory;
- piecewise structure -> local exact representation;
- commutative/associative transforms -> future fusion/reassociation;
- no-alias/lifetime + matched-index locality proof -> automatic physical data-layout rewrite (separate, interleaved or tiled) while preserving logical-array semantics.

## Soundness policy

1. Exact transformation requires exact proof.
2. Approximate transformation requires an explicit tolerance/error certificate.
3. Proof failure normally falls back to exact generic execution.
4. Proof cost and execution benefit are both part of profitability.
5. Backend overlap is not counted as an independent Webchan speedup.
6. No application label may substitute for a property proof.

## an earlier development milestone implementation boundary

Implemented: the property families and solver unlocks listed above, plus inherited temporal safety, matrix-free memory, incremental change propagation, and exact piecewise fields.

Not yet implemented: arbitrary low-rank discovery, equality saturation for arbitrary user code, general alias/effect inference, arbitrary Newton basin proof, automatic sparse factorization reuse across dynamic matrix families, and wavelet runtime compression.


## an earlier development milestone Structural Topology Capability Branch

The same capability graph now accepts finite graph and simplicial-complex evidence. Graph properties include components, bridges, articulation points, cycle rank, graph homotopy/free-group rank and contractibility of trees. Simplicial-complex properties include GF(2) Betti numbers and elementary-collapse certificates. Planning consumes these properties through topology pruning and rank-first minimax route selection.

The topology branch follows the same rule as linear algebra: **property first, algorithm second**. A source object is not accelerated because it is called a map or workflow; it is accelerated because a proof establishes a reusable structural property.
