# Webchan earlier release Structural Topology Proof Engine

## Purpose

Structural Topology is a peer proof domain to Structural Linear Algebra. It is not a map, robotics, UI, or simulation subsystem. The compiler consumes finite combinatorial structure and derives topological properties that can remove search, state, storage, or planning work.

Core rule:

`discover topology -> derive certificate -> unlock collapse/pruning/planning -> exact fallback`

## 1. Supported exact graph topology

For a finite undirected graph regarded as a 1-dimensional CW complex, an earlier development milestone derives:

- connected components and `beta0`;
- bridges;
- articulation vertices;
- Euler characteristic `chi = V - E`;
- cycle-space / first Betti number `beta1 = E - V + beta0`;
- exact graph homotopy type after spanning-forest contraction;
- for a connected graph, `pi_1` is the free group `F_beta1`;
- simply-connected / contractible exactly when a connected graph is a tree;
- a maximal-tree generator assignment for path homotopy words.

A connected finite graph has homotopy type of a wedge of `beta1` circles. This is a theorem used by the compiler, not a heuristic.

## 2. Finite simplicial complexes

an earlier development milestone supports finite complexes with vertices, 1-simplices and 2-simplices. Homology is computed exactly over GF(2):

- boundary map `d1 : C1 -> C0`;
- boundary map `d2 : C2 -> C1`;
- Gaussian elimination over GF(2) gives `rank(d1)` and `rank(d2)`;
- `beta0 = dim C0 - rank(d1)`;
- `beta1 = dim C1 - rank(d1) - rank(d2)`;
- `beta2 = dim C2 - rank(d2)`;
- Euler-Poincare is checked: `chi = beta0 - beta1 + beta2`.

## 3. Sound simple-connectivity policy

`H1 = 0` is not treated as a proof of simple connectivity for a general 2-complex.

an earlier development milestone marks a finite 2-complex `contractible=verified` and `simply_connected=verified` only when it finds an elementary simplicial collapse sequence to a point. Each elementary collapse is a certificate-preserving deformation retraction step.

This deliberately leaves some true statements unproved. Example: the tetrahedral boundary has Betti numbers `(1,0,1)`. Its `H1` vanishes, but an earlier development milestone does not infer simple connectivity from homology alone.

## 4. Homotopy words for graphs

For a connected graph, Webchan selects a spanning tree. Tree edges collapse to the identity. Every non-tree edge becomes a free generator.

A planned path is projected to a word in those generators. Adjacent inverse letters cancel. The reduced word is an exact graph-homotopy-class representative relative to the fixed spanning-tree convention.

This is stronger than a mere cycle-bit signature. The current implementation does not claim a general fundamental-group decision procedure for arbitrary finite 2-complexes.

## 5. Proof capabilities emitted to Webchan IR

Typical capabilities:

- `spanning-forest-collapse`
- `cycle-space-proof`
- `bridge-cut-proof`
- `articulation-proof`
- `graph-homotopy-wedge-of-circles`
- `homology-gf2`
- `euler-poincare`
- `deformation-retract-to-point`
- `topology-pruned-planning`

## 6. Non-goals / current boundary

Not falsely claimed in an earlier development milestone:

- complete fundamental-group decision for arbitrary finite 2-complexes;
- general higher homotopy groups `pi_n`;
- arbitrary manifold recognition;
- arbitrary homeomorphism recognition;
- persistent homology;
- Morse theory;
- automatic geometry-to-complex meshing.

These may become proof libraries later, but only after real implementation and validation.

## Structural Iteration Algebra bridge

Finite graph adjacency is now projected into Webchan IR as a finite indexed relation. The compiler exports the vertex extent, local-degree metadata and sparse-relation proof beside the existing Betti/cut/homotopy certificates.

This is intentionally broader than path planning. Graph-neighborhood computation, sparse gather/scatter kernels and conflict-free local updates can consume the same topology evidence through the implemented generic indexed-kernel surface. No graph algorithm name is used as an optimization trigger.
