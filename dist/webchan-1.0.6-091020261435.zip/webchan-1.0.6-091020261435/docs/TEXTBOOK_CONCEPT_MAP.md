# Textbook Concept Map for an earlier development milestone

Webchan earlier release intentionally keeps conceptual ancestry at the level of broadly taught mathematics and compiler theory.

| Webchan mechanism | Textbook-level idea |
|---|---|
| causal task core | directed acyclic graphs, topological ordering |
| IPE dependence recovery | dependence analysis, partial orders |
| spawn/join/barrier erasure | redundant synchronization elimination under proven ordering |
| rank-guided re-linearization | priority topological scheduling |
| partition fusion | loop fusion / coarsening after independence proof |
| worker-local scalarization | scalar replacement / privatization collapse |
| Structural Linear Algebra | symmetry, SPD, diagonal dominance, triangular/banded structure, spectral bounds |
| Chebyshev path | polynomial approximation / semi-iteration |
| Structural Topology | graph connectivity, cycle space, homology, elementary collapse |
| topological planning | graph pruning and equivalence-class reasoning |
| Matrix-Free Memory | procedural representation / recomputation-vs-storage trade |
| Incremental Change Propagation | dependency-cone recomputation |

The table records ideas, not imported implementations. No row implies source-code inheritance from a named compiler, runtime or framework.
| Structural Iteration Algebra | finite index sets, dependence relations, sparse/local operators |
| indexed transformation planning | loop dependence analysis, fusion, legal reordering, scalar replacement |
| matrix-to-iteration bridge | sparse/banded operator action as a finite index relation |
| topology-to-iteration bridge | graph adjacency and DAG order as computation structure |
