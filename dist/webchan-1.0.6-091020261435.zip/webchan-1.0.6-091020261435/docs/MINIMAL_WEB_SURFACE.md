# Minimal Web Surface

Webchan 1.0.5 introduces a source-only simplification layer. Its contract is:

> **Top-level source keeps program meaning. Derivable information is resolved by the compiler.**

The surface is not a second runtime, wrapper, transpiler service, JavaScript shim, or alternative optimizer. It feeds the same parser data structures, proofs, IR emitter, generated C, runtime, and Wasm toolchain already used by the explicit surface.

## Design boundary

The 1.0.5 surface may:

- omit established defaults;
- infer a finite bound already provable by the existing analyzers;
- replace verbose syntax with a shorter spelling that denotes exactly the same construct;
- insert standard task metadata only through the explicit `entry` shorthand.

It may not:

- weaken a proof obligation;
- create an unbounded loop;
- add a hidden allocation;
- add a host call;
- change data layout;
- alter optimization profitability;
- introduce a runtime type;
- change scalar/SIMD selection;
- add an optimizer rule.

## Standard contract

When omitted, the frontend begins from the standard portable single-host-thread contract. Explicit directives remain overrides. The resolved values are still emitted to `program.webir` and generated headers.

There is therefore no semantic distinction between "implicit" and "deleted". The contract is implicit in source, explicit after resolution.

## Bound inference

`kernel name` temporarily carries an inference marker only inside the frontend. The unchanged kernel analyzer computes the finite bound. After proof, the frontend writes that exact computed value into `declared_bound` before emission. If analysis fails, compilation fails as before.

`fn name` follows the same rule with the existing call-graph termination/bound analysis. Inferred function bounds must fit the existing `u32` bound field.

## Desugaring

The short forms are syntactic identities:

```text
for i in a..b          -> for i from a to b step 1
for i in a..b by s     -> for i from a to b step s
let T x = e            -> local T x = e
lhs = rhs              -> set lhs = rhs
end                     -> existing context-specific terminator
```

No new IR opcode exists for any of these forms.

`entry f` is the only convenience form that supplies metadata rather than merely renaming syntax. It resolves to the existing task representation:

```text
task main shed_rank 0 cost 1 deadline_ms <current frame budget> class visible fn f
```

Use an explicit task declaration when those defaults are not the intended program meaning.

## Equivalence gate

`tests/surface_equivalence.sh` compiles `tests/surface/explicit.webchan` and `tests/surface/minimal.webchan`, then requires byte equality across seven generated files and both Wasm profiles.

The same test also verifies the SHA-256 freeze list for the inherited lower layer.

This gate makes source brevity a frontend property rather than a performance tradeoff.
