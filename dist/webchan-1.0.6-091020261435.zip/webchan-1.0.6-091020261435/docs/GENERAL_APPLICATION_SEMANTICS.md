# Webchan General Application Semantics (introduced in 1.0.1, extended in 1.0.6)

## Purpose

This layer widens Webchan from structural/numerical kernels into bounded ordinary application state while preserving the existing language doctrine: prove finite work, delete inactive work, keep external authority replaceable, and never add a workload-specific compiler path merely because one application exposed a missing feature.

## General source forms

```text
region scratch bytes 4096
text input capacity 2048
vector ids u64 capacity 256
map index key u32 value u64 capacity 256
result parse_result ok u64 err i32
future_pool requests value u64 error i32 capacity 32
handle_pool connection capability network.http capacity 8
```

All capacities are compile-time finite. The generated C owns fixed storage; these constructs do not secretly delegate their semantics to JavaScript arrays, maps, promises or strings.

### Text and bytes

`text` is bounded byte storage with UTF-8 validation. Byte append, copy, indexing, bounded resize, byte search and primitive little-endian cursor operations are available. 1.0.1 does not claim a complete Unicode normalization/grapheme library.

### Vectors and maps

Vectors operate over their active length. Maps use bounded open addressing and operate over their active table state. Map keys are currently discrete scalar keys (`u32`, `i32`, `u8`, `bool`); values may use the scalar value types. Exact `u64` operations use bit-preserving ABI lanes rather than conversion through `f64`.

### Result, future, and handles

Result storage is tagged. Future pools have `free`, `pending`, `ready`, `failed`, and `cancelled` states. Future and opaque-handle tokens include generations so released slots cannot be reused through stale references. External raw handle values never become Webchan pointers.

### Deterministic state machines

```text
state_machine Request initial idle
state idle
state pending
state done
transition idle event begin to pending
transition pending event finish to done
endstate_machine
```

For a given `(state,event)` pair, at most one transition is legal. The compiler lowers the machine to direct finite switch code; it does not install a generic interpreter.

### Bounded general control flow

Inside generic kernels, 1.0.1 includes `if/else`, bounded `while ... max N`, `break`, `continue`, and conditional return. `while` without an explicit finite maximum remains forbidden. This reuses the existing Structural Iteration Algebra proof boundary instead of creating a second sequential execution engine.

### Compile-time imports

`import "relative/path.webchan"` recursively expands declaration fragments once at compile time. Import cycles are rejected. There is no runtime module loader. Webchan IR records the logical source spelling, not the build machine's absolute path.

### External operations

Application code uses semantic ECI capabilities. Bounded kernels may issue immediate/asynchronous operations allowed by the temporal checker. `explicit_blocking` operations are rejected in that bounded path. Opaque handles are capability-associated but provider-neutral.

## Reuse of existing acceleration regions

1. **Structural Iteration Algebra** supplies finite-domain and control-flow bounds.
2. **Active working sets** limit vector/map work to live state.
3. **Structural collapse** lowers deterministic state machines directly instead of interpreting them.
4. **Temporal safety** controls future/cancellation and external-effect boundaries.
5. **ECI authority resolution** continues to choose eligible host providers without embedding vendor/application names into source semantics.
6. **IPE and no-implicit-barrier doctrine** are unchanged and remain available to structural regions; 1.0.1 does not insert a hidden serialized scheduler underneath the new surface.

## Non-specialization gate

The compiler must reject design proposals whose only justification is a particular model, website, protocol, benchmark or application. A new primitive must be defensible independently as a general type, data structure, control-flow form, resource/effect rule, capability abstraction or compiler proof. Automatic specialization from general rules is allowed; hand-written workload recognition is not.

## Honest boundary

1.0.1 is not yet a mature replacement for a full JavaScript/Rust/C++ application ecosystem. It does not claim an unbounded heap, borrowed slices, GC, Unicode normalization/grapheme segmentation, arbitrary recursive ADTs, full generics/traits, a general parser-combinator/JSON standard library, source-level `async/await` syntax, or a complete package manager. The release establishes bounded general primitives on which those can be built without an application-specific shortcut.
