# ECI Provider Catalogue

The 1.0.0 compiler carries a small **metadata catalogue**, not provider implementations. Each entry records:

`capability, provider name, provider kind, eligible host mask, authority priority`

The generated `external_capabilities.json` is the machine-readable release artifact for the declarations actually used by a program.

## Provider kinds

| Kind | Meaning |
|---|---|
| `c_abi` | Stable/general C-callable interface |
| `host_standard` | Browser/WASI/platform-owned capability |
| `vendor_c_abi` | Vendor-controlled C ABI such as the CUDA Driver interface |
| `driver` | Explicit low-level/vendor fallback |

Provider replacement is legal when the replacement implements the same Webchan capability contract and effect boundary.

## Important rule

Provider names do not become Webchan semantics. `network.tcp` is a semantic capability. `posix_sockets`, `winsock2`, `wasi_sockets`, and `browser_websocket` are replaceable realizations.
