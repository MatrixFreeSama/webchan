#version 400 core
// Generated from Webchan IR. Generic compact field helpers; no trusted source assertions.
double wc_field_vertex_x(uint i){double x=double(i);return 3.2000000000000002*x+7;}
double wc_field_vertex_y(uint i){double x=double(i);double y=9.9999999999999995e-07;y=y*x+0.5;y=y*x+1;return y;}
// field expensive_field requires materialized host storage under the selected budget.
double wc_piecewise_discontinuous_profile(uint i){double x=double(i);if(i<1000000u){return 1.0000000000000001e-05*x+1;}else if(i<2000000u){return -2.0000000000000002e-05*x+100;}else if(i<3000000u){double y=3.0000000000000001e-06;y=y*x+0;y=y*x+-40;return y;}else if(i<4000000u){return 7;}return 0.0;}
