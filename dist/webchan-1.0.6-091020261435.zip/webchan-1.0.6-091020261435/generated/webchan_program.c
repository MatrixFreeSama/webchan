#include "webchan_program.h"
#include <stdint.h>
typedef struct {double x;double y;double weight;} wc_struct_Point;
typedef enum {WC_Phase_idle=0,WC_Phase_running=1,WC_Phase_done=2} wc_enum_Phase;
static double wc_array_0[1024];
static uint32_t wc_array_1[256];
static double wc_array_2[256];
static double wc_array_3[256];
static double wc_array_6[1024];
static double wc_array_7[1024];
static double wc_layout_group_1[2048];
static double wc_layout_group_2[2048];
static double wc_layout_group_0[2048];
#define WC_AREF_0(i) wc_array_0[(uint32_t)(i)]
#define WC_AREF_1(i) wc_array_1[(uint32_t)(i)]
#define WC_AREF_2(i) wc_array_2[(uint32_t)(i)]
#define WC_AREF_3(i) wc_array_3[(uint32_t)(i)]
#define WC_AREF_4(i) wc_layout_group_1[((((uint32_t)(i))>>4u)*32u)+0u+(((uint32_t)(i))&15u)]
#define WC_AREF_5(i) wc_layout_group_1[((((uint32_t)(i))>>4u)*32u)+16u+(((uint32_t)(i))&15u)]
#define WC_AREF_6(i) wc_array_6[(uint32_t)(i)]
#define WC_AREF_7(i) wc_array_7[(uint32_t)(i)]
#define WC_AREF_8(i) wc_layout_group_2[((((uint32_t)(i))>>4u)*32u)+0u+(((uint32_t)(i))&15u)]
#define WC_AREF_9(i) wc_layout_group_2[((((uint32_t)(i))>>4u)*32u)+16u+(((uint32_t)(i))&15u)]
#define WC_AREF_10(i) wc_layout_group_0[((uint32_t)(i))*2u+0u]
#define WC_AREF_11(i) wc_layout_group_0[((uint32_t)(i))*2u+1u]
/* General Application Semantics: bounded storage, no hidden host heap, no protocol-specific code. */
static uint64_t wc_f64_bits(double v){union{double d;uint64_t u;}q;q.d=v;return q.u;}static double wc_bits_f64(uint64_t v){union{double d;uint64_t u;}q;q.u=v;return q.d;}
uint32_t wc_user_region_count(void){return 0u;}
uint32_t wc_user_region_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_region_used(uint32_t id){switch(id){default:return 0;}}
void wc_user_region_reset(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_region_alloc(uint32_t id,uint32_t n,uint32_t align){if(!align)align=1u;if(align&(align-1u))return 0xffffffffu;switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_region_read8(uint32_t id,uint32_t off){switch(id){default:return 0;}}
uint32_t wc_user_region_write8(uint32_t id,uint32_t off,uint32_t v){switch(id){default:return 0;}}
uint64_t wc_user_region_ptr(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_text_count(void){return 0u;}
uint32_t wc_user_text_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_text_len(uint32_t id){switch(id){default:return 0;}}
void wc_user_text_clear(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_text_resize(uint32_t id,uint32_t n){switch(id){default:return 0;}}
uint32_t wc_user_text_get(uint32_t id,uint32_t off){switch(id){default:return 0;}}
uint32_t wc_user_text_set(uint32_t id,uint32_t off,uint32_t v){switch(id){default:return 0;}}
uint32_t wc_user_text_append_byte(uint32_t id,uint32_t v){switch(id){default:return 0;}}
uint32_t wc_user_text_append_text(uint32_t dst,uint32_t src){if(dst==src)return 0;switch(dst){default:return 0;}}
static uint32_t wc_utf8_valid_buf(const uint8_t*s,uint32_t n){uint32_t i=0;while(i<n){uint32_t c=s[i++];if(c<0x80u)continue;uint32_t need=0,min=0;if((c&0xe0u)==0xc0u){need=1;min=0x80u;c&=0x1fu;}else if((c&0xf0u)==0xe0u){need=2;min=0x800u;c&=0x0fu;}else if((c&0xf8u)==0xf0u){need=3;min=0x10000u;c&=0x07u;}else return 0;if(i+need>n)return 0;for(uint32_t k=0;k<need;k++){uint32_t d=s[i++];if((d&0xc0u)!=0x80u)return 0;c=(c<<6)|(d&0x3fu);}if(c<min||c>0x10ffffu||(c>=0xd800u&&c<=0xdfffu))return 0;}return 1u;}
uint32_t wc_user_text_utf8_valid(uint32_t id){switch(id){default:return 0;}}
int32_t wc_user_text_find_byte(uint32_t id,uint32_t start,uint32_t b){switch(id){default:return -1;}}
uint64_t wc_user_text_ptr(uint32_t id){switch(id){default:return 0;}}
static uint32_t wc_text_bounds(uint32_t id,uint32_t off,uint32_t n){uint32_t len=wc_user_text_len(id);return off<=len&&n<=len-off;}
uint32_t wc_user_text_write_u32_le(uint32_t id,uint32_t off,uint32_t v){if(!wc_text_bounds(id,off,4u))return 0;switch(id){default:return 0;}}
uint32_t wc_user_text_read_u32_le(uint32_t id,uint32_t off,uint32_t*out){if(!out||!wc_text_bounds(id,off,4u))return 0;switch(id){default:return 0;}}
uint32_t wc_user_text_write_f64_le(uint32_t id,uint32_t off,double v){if(!wc_text_bounds(id,off,8u))return 0;union{double d;uint64_t u;}q;q.d=v;switch(id){default:return 0;}}
uint32_t wc_user_text_read_f64_le(uint32_t id,uint32_t off,double*out){if(!out||!wc_text_bounds(id,off,8u))return 0;union{double d;uint64_t u;}q;q.u=0;switch(id){default:return 0;}}
uint32_t wc_user_vector_count(void){return 0u;}
uint32_t wc_user_vector_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_vector_len(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_vector_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
void wc_user_vector_clear(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_vector_push(uint32_t id,double v){switch(id){default:return 0;}}
uint32_t wc_user_vector_pop(uint32_t id,double*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_vector_set(uint32_t id,uint32_t idx,double v){switch(id){default:return 0;}}
double wc_user_vector_get(uint32_t id,uint32_t idx){switch(id){default:return 0.0;}}
uint32_t wc_user_vector_push_bits(uint32_t id,uint64_t v){switch(id){default:return 0;}}
uint32_t wc_user_vector_pop_bits(uint32_t id,uint64_t*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_vector_set_bits(uint32_t id,uint32_t idx,uint64_t v){switch(id){default:return 0;}}
uint64_t wc_user_vector_get_bits(uint32_t id,uint32_t idx){switch(id){default:return 0;}}
static uint64_t wc_map_hash(uint64_t x){x^=x>>30;x*=0xbf58476d1ce4e5b9ull;x^=x>>27;x*=0x94d049bb133111ebull;return x^(x>>31);}
uint32_t wc_user_map_count(void){return 0u;}
uint32_t wc_user_map_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_map_size(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_map_key_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_map_value_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
void wc_user_map_clear(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_map_put(uint32_t id,double kd,double vd){switch(id){default:return 0;}}
uint32_t wc_user_map_get(uint32_t id,double kd,double*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_map_remove(uint32_t id,double kd){switch(id){default:return 0;}}
uint32_t wc_user_map_put_bits(uint32_t id,uint64_t key,uint64_t vb){switch(id){default:return 0;}}
uint32_t wc_user_map_get_bits(uint32_t id,uint64_t key,uint64_t*out){if(!out)return 0;switch(id){default:return 0;}}
uint32_t wc_user_map_remove_bits(uint32_t id,uint64_t key){switch(id){default:return 0;}}
uint32_t wc_user_result_count(void){return 0u;}
uint32_t wc_user_result_ok_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_result_err_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_result_tag(uint32_t id){switch(id){default:return 0;}}
void wc_user_result_clear(uint32_t id){switch(id){default:break;}}
void wc_user_result_set_ok(uint32_t id,double v){switch(id){default:break;}}
void wc_user_result_set_err(uint32_t id,double v){switch(id){default:break;}}
double wc_user_result_value(uint32_t id){switch(id){default:return 0.0;}}
void wc_user_result_set_ok_bits(uint32_t id,uint64_t v){switch(id){default:break;}}
void wc_user_result_set_err_bits(uint32_t id,uint64_t v){switch(id){default:break;}}
uint64_t wc_user_result_value_bits(uint32_t id){switch(id){default:return 0;}}
static uint32_t wc_tok_idx(uint64_t t){return (uint32_t)t;}static uint32_t wc_tok_gen(uint64_t t){return (uint32_t)(t>>32);}static uint64_t wc_tok_make(uint32_t i,uint32_t g){return ((uint64_t)g<<32)|i;}
uint32_t wc_user_future_pool_count(void){return 0u;}
uint32_t wc_user_future_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_future_value_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint32_t wc_user_future_error_type(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint64_t wc_user_future_create(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_future_state(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_resolve(uint32_t id,uint64_t tok,double v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_fail(uint32_t id,uint64_t tok,double v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_cancel(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_release(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
double wc_user_future_value(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0.0;}}
double wc_user_future_error(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0.0;}}
uint32_t wc_user_future_resolve_bits(uint32_t id,uint64_t tok,uint64_t v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_future_fail_bits(uint32_t id,uint64_t tok,uint64_t v){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint64_t wc_user_future_value_bits(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint64_t wc_user_future_error_bits(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_handle_pool_count(void){return 0u;}
uint32_t wc_user_handle_capacity(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_handle_capability(uint32_t id){switch(id){default:return 0xffffffffu;}}
uint64_t wc_user_handle_acquire(uint32_t id,uint64_t raw){switch(id){default:return 0;}}
uint64_t wc_user_handle_value(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_handle_release(uint32_t id,uint64_t tok){uint32_t i=wc_tok_idx(tok),g=wc_tok_gen(tok);switch(id){default:return 0;}}
uint32_t wc_user_state_machine_count(void){return 0u;}
uint32_t wc_user_state_machine_states(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_state_machine_events(uint32_t id){switch(id){default:return 0;}}
uint32_t wc_user_state_machine_state(uint32_t id){switch(id){default:return 0xffffffffu;}}
void wc_user_state_machine_reset(uint32_t id){switch(id){default:break;}}
uint32_t wc_user_state_machine_dispatch(uint32_t id,uint32_t ev){switch(id){default:return 0xffffffffu;}}
static uint32_t wc_bitreverse32(uint32_t x){return __builtin_bitreverse32(x);}
static double wc_fabs(double x){return x<0.0?-x:x;} static double wc_sin_poly(double x){double x2=x*x;return x*(1.0+x2*(-0.16666666666666665741+x2*(0.0083333333333333297482+x2*(-0.00019841269841269616281+x2*(0.0000027557319223985892511+x2*(-0.000000025052108385441718776+x2*0.00000000016059043836821614599))))));} static double wc_cos_poly(double x){double x2=x*x;return 1.0+x2*(-0.5+x2*(0.041666666666666664354+x2*(-0.0013888888888888872994+x2*(0.000024801587301587003346+x2*(-0.00000027557319223985890653+x2*0.0000000020876756987868098979)))));} static double wc_reduce_angle(double x){const double tp=6.28318530717958647692528676655900576;double q=x/tp;int64_t k=(int64_t)(q+(q>=0.0?0.5:-0.5));return x-(double)k*tp;} static double wc_sin(double x){x=wc_reduce_angle(x);const double hp=1.57079632679489661923132169163975144;if(x>hp)x=3.14159265358979323846264338327950288-x;else if(x<-hp)x=-3.14159265358979323846264338327950288-x;return wc_sin_poly(x);} static double wc_cos(double x){return wc_sin(x+1.57079632679489661923132169163975144);}
static void wc_kernel_0(void){for(uint32_t i=(uint32_t)(0);i<(uint32_t)(1024u);i+=(uint32_t)(1)){WC_AREF_5(i)=(double)(1.75 * WC_AREF_4(i) + 0.25);}}
static uint32_t wc_kernel_cursor_0=0u;static uint8_t wc_kernel_done_0=0u;
static void wc_kernel_resume_reset_0(void){wc_kernel_cursor_0=0u;wc_kernel_done_0=0u;}
static uint32_t wc_kernel_resume_done_0(void){return wc_kernel_done_0;}
static uint32_t wc_kernel_resume_cursor_0(void){return wc_kernel_cursor_0;}
static uint32_t wc_kernel_resume_0(uint32_t budget){if(wc_kernel_done_0)return 0u;if(!budget)budget=1u;uint32_t used=0u;for(;used<budget&&wc_kernel_cursor_0<1024u;used++){uint32_t i=wc_kernel_cursor_0;WC_AREF_5(i)=(double)(1.75 * WC_AREF_4(i) + 0.25);wc_kernel_cursor_0+=1u;}if(wc_kernel_cursor_0>=1024u)wc_kernel_done_0=1u;return used;}
static void wc_kernel_1(void){for(uint32_t i=(uint32_t)(1);i<(uint32_t)(1023);i+=(uint32_t)(1)){WC_AREF_5(i)=(double)(0.25 * WC_AREF_4(i - 1) + 0.5 * WC_AREF_4(i) + 0.25 * WC_AREF_4(i + 1));}}
static uint32_t wc_kernel_cursor_1=1u;static uint8_t wc_kernel_done_1=0u;
static void wc_kernel_resume_reset_1(void){wc_kernel_cursor_1=1u;wc_kernel_done_1=0u;}
static uint32_t wc_kernel_resume_done_1(void){return wc_kernel_done_1;}
static uint32_t wc_kernel_resume_cursor_1(void){return wc_kernel_cursor_1;}
static uint32_t wc_kernel_resume_1(uint32_t budget){if(wc_kernel_done_1)return 0u;if(!budget)budget=1u;uint32_t used=0u;for(;used<budget&&wc_kernel_cursor_1<1023u;used++){uint32_t i=wc_kernel_cursor_1;WC_AREF_5(i)=(double)(0.25 * WC_AREF_4(i - 1) + 0.5 * WC_AREF_4(i) + 0.25 * WC_AREF_4(i + 1));wc_kernel_cursor_1+=1u;}if(wc_kernel_cursor_1>=1023u)wc_kernel_done_1=1u;return used;}
static void wc_kernel_2(void){double acc=(double)(0.0);for(uint32_t i=(uint32_t)(0);i<(uint32_t)(1024u);i+=(uint32_t)(1)){acc=acc + WC_AREF_4(i);WC_AREF_6(i)=(double)(acc);}}
static void wc_kernel_resume_reset_2(void){}
static uint32_t wc_kernel_resume_2(uint32_t budget){(void)budget;return 0xffffffffu;}
static uint32_t wc_kernel_resume_done_2(void){return 0u;}
static uint32_t wc_kernel_resume_cursor_2(void){return 0u;}
static void wc_kernel_3(void){for(uint32_t i=(uint32_t)(0);i<(uint32_t)(1024u);i+=(uint32_t)(1)){WC_AREF_7(wc_bitreverse32(i) >> 22)=(double)(WC_AREF_4(i));}}
static uint32_t wc_kernel_cursor_3=0u;static uint8_t wc_kernel_done_3=0u;
static void wc_kernel_resume_reset_3(void){wc_kernel_cursor_3=0u;wc_kernel_done_3=0u;}
static uint32_t wc_kernel_resume_done_3(void){return wc_kernel_done_3;}
static uint32_t wc_kernel_resume_cursor_3(void){return wc_kernel_cursor_3;}
static uint32_t wc_kernel_resume_3(uint32_t budget){if(wc_kernel_done_3)return 0u;if(!budget)budget=1u;uint32_t used=0u;for(;used<budget&&wc_kernel_cursor_3<1024u;used++){uint32_t i=wc_kernel_cursor_3;WC_AREF_7(wc_bitreverse32(i) >> 22)=(double)(WC_AREF_4(i));wc_kernel_cursor_3+=1u;}if(wc_kernel_cursor_3>=1024u)wc_kernel_done_3=1u;return used;}
static void wc_kernel_4(void){for(uint32_t block=(uint32_t)(0);block<(uint32_t)(1024u);block+=(uint32_t)(32)){for(uint32_t lane=(uint32_t)(0);lane<(uint32_t)(32);lane+=(uint32_t)(1)){WC_AREF_5(block + lane)=(double)(WC_AREF_4(block + lane));}}}
static void wc_kernel_resume_reset_4(void){}
static uint32_t wc_kernel_resume_4(uint32_t budget){(void)budget;return 0xffffffffu;}
static uint32_t wc_kernel_resume_done_4(void){return 0u;}
static uint32_t wc_kernel_resume_cursor_4(void){return 0u;}
static void wc_kernel_5(void){for(uint32_t i=(uint32_t)(0);i<(uint32_t)(1024u);i+=(uint32_t)(1)){WC_AREF_10(wc_bitreverse32(i) >> 22)=(double)(WC_AREF_8(i));WC_AREF_11(wc_bitreverse32(i) >> 22)=(double)(WC_AREF_9(i));}for(uint32_t stage=(uint32_t)(1);stage<(uint32_t)(11);stage+=(uint32_t)(1)){uint32_t half=(uint32_t)(1 << (stage - 1));double angle=(double)(-2.0 * 3.14159265358979323846264338327950288 / (1 << stage));for(uint32_t pair=(uint32_t)(0);pair<(uint32_t)(512);pair+=(uint32_t)(1)){uint32_t j=(uint32_t)(pair & (half - 1));uint32_t block=(uint32_t)((pair >> (stage - 1)) << stage);uint32_t a=(uint32_t)((block + j) & 1023);uint32_t b=(uint32_t)((a + half) & 1023);double wr=(double)(wc_cos(angle * j));double wi=(double)(wc_sin(angle * j));double ur=(double)(WC_AREF_10(a));double ui=(double)(WC_AREF_11(a));double vr=(double)(wr * WC_AREF_10(b) - wi * WC_AREF_11(b));double vi=(double)(wr * WC_AREF_11(b) + wi * WC_AREF_10(b));WC_AREF_10(a)=(double)(ur + vr);WC_AREF_11(a)=(double)(ui + vi);WC_AREF_10(b)=(double)(ur - vr);WC_AREF_11(b)=(double)(ui - vi);}}}
static void wc_kernel_resume_reset_5(void){}
static uint32_t wc_kernel_resume_5(uint32_t budget){(void)budget;return 0xffffffffu;}
static uint32_t wc_kernel_resume_done_5(void){return 0u;}
static uint32_t wc_kernel_resume_cursor_5(void){return 0u;}
uint32_t wc_user_kernel_count(void){return 6u;}
uint64_t wc_user_kernel_bound(uint32_t id){switch(id){case 0:return 1024u;case 1:return 1022u;case 2:return 2049u;case 3:return 1024u;case 4:return 1024u;case 5:return 73748u;default:return 0;}}
uint64_t wc_user_kernel_extent(uint32_t id){switch(id){case 0:return 1024u;case 1:return 1022u;case 2:return 1024u;case 3:return 1024u;case 4:return 1024u;case 5:return 5120u;default:return 0;}}
uint32_t wc_user_kernel_depth(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;case 3:return 1u;case 4:return 2u;case 5:return 2u;default:return 0;}}
uint32_t wc_user_kernel_proof_bits(uint32_t id){switch(id){case 0:return 1539u;case 1:return 1547u;case 2:return 1827u;case 3:return 1555u;case 4:return 3615u;case 5:return 7839u;default:return 0;}}
uint32_t wc_user_kernel_transform_bits(uint32_t id){switch(id){case 0:return 24u;case 1:return 24u;case 2:return 12u;case 3:return 8u;case 4:return 8u;case 5:return 204u;default:return 0;}}
void wc_user_kernel_run(uint32_t id,uint32_t reps){for(uint32_t r=0;r<reps;r++){switch(id){case 0:wc_kernel_0();break;case 1:wc_kernel_1();break;case 2:wc_kernel_2();break;case 3:wc_kernel_3();break;case 4:wc_kernel_4();break;case 5:wc_kernel_5();break;default:return;}}}
uint32_t wc_user_kernel_resumable(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 0u;case 3:return 1u;case 4:return 0u;case 5:return 0u;default:return 0;}}
void wc_user_kernel_resume_reset(uint32_t id){switch(id){case 0:wc_kernel_resume_reset_0();break;case 1:wc_kernel_resume_reset_1();break;case 2:wc_kernel_resume_reset_2();break;case 3:wc_kernel_resume_reset_3();break;case 4:wc_kernel_resume_reset_4();break;case 5:wc_kernel_resume_reset_5();break;default:break;}}
uint32_t wc_user_kernel_resume(uint32_t id,uint32_t budget){switch(id){case 0:return wc_kernel_resume_0(budget);case 1:return wc_kernel_resume_1(budget);case 2:return wc_kernel_resume_2(budget);case 3:return wc_kernel_resume_3(budget);case 4:return wc_kernel_resume_4(budget);case 5:return wc_kernel_resume_5(budget);default:return 0xffffffffu;}}
uint32_t wc_user_kernel_resume_done(uint32_t id){switch(id){case 0:return wc_kernel_resume_done_0();case 1:return wc_kernel_resume_done_1();case 2:return wc_kernel_resume_done_2();case 3:return wc_kernel_resume_done_3();case 4:return wc_kernel_resume_done_4();case 5:return wc_kernel_resume_done_5();default:return 0u;}}
uint32_t wc_user_kernel_resume_cursor(uint32_t id){switch(id){case 0:return wc_kernel_resume_cursor_0();case 1:return wc_kernel_resume_cursor_1();case 2:return wc_kernel_resume_cursor_2();case 3:return wc_kernel_resume_cursor_3();case 4:return wc_kernel_resume_cursor_4();case 5:return wc_kernel_resume_cursor_5();default:return 0u;}}
uint32_t wc_user_kernel_structural_bits(uint32_t id){switch(id){case 0:return 0u;case 1:return 397u;case 2:return 0u;case 3:return 0u;case 4:return 0u;case 5:return 0u;default:return 0;}}
uint32_t wc_user_kernel_operator_bandwidth(uint32_t id){switch(id){case 0:return 0u;case 1:return 1u;case 2:return 0u;case 3:return 0u;case 4:return 0u;case 5:return 0u;default:return 0;}}
uint32_t wc_user_kernel_operator_src(uint32_t id){switch(id){case 0:return 4294967295u;case 1:return 4u;case 2:return 4294967295u;case 3:return 4294967295u;case 4:return 4294967295u;case 5:return 4294967295u;default:return 0xffffffffu;}}
uint32_t wc_user_kernel_operator_dst(uint32_t id){switch(id){case 0:return 4294967295u;case 1:return 5u;case 2:return 4294967295u;case 3:return 4294967295u;case 4:return 4294967295u;case 5:return 4294967295u;default:return 0xffffffffu;}}
uint32_t wc_user_kernel_solver_unlock_bits(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 0u;case 5:return 0u;default:return 0;}}
typedef struct{uint16_t u,v;double cost;int32_t rank;} wc_topo_edge_rt;
static const wc_topo_edge_rt wc_topo_0[65]={{0u,1u,1,0},{1u,2u,1,0},{2u,3u,1,0},{3u,4u,1,0},{4u,5u,1,0},{5u,6u,1,0},{6u,7u,1,0},{7u,8u,1,0},{8u,9u,1,0},{2u,10u,0.34999999999999998,1},{10u,11u,0.34999999999999998,1},{11u,12u,0.34999999999999998,1},{12u,5u,0.34999999999999998,1},{5u,13u,0.29999999999999999,1},{13u,14u,0.29999999999999999,1},{14u,8u,0.29999999999999999,1},{1u,15u,0.050000000000000003,0},{15u,16u,0.050000000000000003,0},{16u,17u,0.050000000000000003,0},{17u,18u,0.050000000000000003,0},{18u,19u,0.050000000000000003,0},{19u,20u,0.050000000000000003,0},{20u,21u,0.050000000000000003,0},{21u,22u,0.050000000000000003,0},{22u,23u,0.050000000000000003,0},{23u,24u,0.050000000000000003,0},{24u,25u,0.050000000000000003,0},{25u,26u,0.050000000000000003,0},{26u,27u,0.050000000000000003,0},{27u,28u,0.050000000000000003,0},{28u,29u,0.050000000000000003,0},{29u,30u,0.050000000000000003,0},{30u,31u,0.050000000000000003,0},{31u,32u,0.050000000000000003,0},{32u,33u,0.050000000000000003,0},{33u,34u,0.050000000000000003,0},{34u,35u,0.050000000000000003,0},{35u,36u,0.050000000000000003,0},{36u,37u,0.050000000000000003,0},{37u,38u,0.050000000000000003,0},{38u,39u,0.050000000000000003,0},{39u,40u,0.050000000000000003,0},{40u,41u,0.050000000000000003,0},{41u,42u,0.050000000000000003,0},{42u,43u,0.050000000000000003,0},{43u,44u,0.050000000000000003,0},{44u,45u,0.050000000000000003,0},{45u,46u,0.050000000000000003,0},{46u,47u,0.050000000000000003,0},{47u,48u,0.050000000000000003,0},{48u,49u,0.050000000000000003,0},{49u,50u,0.050000000000000003,0},{50u,51u,0.050000000000000003,0},{51u,52u,0.050000000000000003,0},{52u,53u,0.050000000000000003,0},{53u,54u,0.050000000000000003,0},{54u,55u,0.050000000000000003,0},{55u,56u,0.050000000000000003,0},{56u,57u,0.050000000000000003,0},{57u,58u,0.050000000000000003,0},{58u,59u,0.050000000000000003,0},{59u,60u,0.050000000000000003,0},{60u,61u,0.050000000000000003,0},{61u,62u,0.050000000000000003,0},{62u,63u,0.050000000000000003,0}};
static const wc_topo_edge_rt wc_topo_1[4]={{0u,1u,1,-100},{1u,2u,1,-100},{1u,3u,1,0},{3u,4u,1,0}};
static const wc_topo_edge_rt wc_topo_2[4]={{0u,1u,0.20000000000000001,5},{1u,3u,0.20000000000000001,5},{0u,2u,1,-5},{2u,3u,1,-5}};
static const uint8_t wc_plan_active_0[64]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const uint8_t wc_plan_active_1[4]={1,1,1,1};
static uint64_t wc_plan_rt(const wc_topo_edge_rt*e,uint32_t ne,uint32_t nv,uint32_t st,uint32_t go,const uint8_t*active,uint32_t reps){uint64_t checksum=0;for(uint32_t rep=0;rep<reps;rep++){int32_t rr[128];double cc[128];uint8_t used[128];for(uint32_t i=0;i<nv;i++){rr[i]=2147483647;cc[i]=1e300;used[i]=0;}rr[st]=(-2147483647-1);cc[st]=0.0;uint32_t expansions=0;for(uint32_t it=0;it<nv;it++){int32_t u=-1;for(uint32_t v=0;v<nv;v++)if((!active||active[v])&&!used[v]&&rr[v]!=2147483647&&(u<0||rr[v]<rr[u]||(rr[v]==rr[u]&&cc[v]<cc[u])))u=(int32_t)v;if(u<0)break;used[u]=1;expansions++;if((uint32_t)u==go)break;for(uint32_t k=0;k<ne;k++){uint32_t v=0xffffffffu;if(e[k].u==(uint32_t)u)v=e[k].v;else if(e[k].v==(uint32_t)u)v=e[k].u;if(v>=nv||(active&&!active[v]))continue;int32_t nr=rr[u]>e[k].rank?rr[u]:e[k].rank;double nc=cc[u]+e[k].cost;if(rr[v]==2147483647||nr<rr[v]||(nr==rr[v]&&nc<cc[v])){rr[v]=nr;cc[v]=nc;}}}checksum+=(((uint64_t)(uint32_t)rr[go]<<32)^(uint64_t)(cc[go]*1000000.0))+(uint64_t)rep+1u;}return checksum;}
static double wc_fn_ref_0(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_0(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_ref_1(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_1(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_ref_2(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_2(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_ref_3(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_3(double x,double t,uint32_t i,uint32_t task);
static double wc_fn_ref_0(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<60u;r++)v=v*1.0000001192092896+3.7e-07;return v;}
static double wc_fn_0(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;return 1.0000071525825263*v+2.2200078070343651e-05;}
static double wc_fn_ref_1(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<32u;r++)v=(v+1.3e-06*v*v+6.9999999999999997e-07)*0.99999970000000005;for(uint32_t r=0;r<1u;r++)v=wc_fn_ref_0(v,t,i,task);return v;}
static double wc_fn_1(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<32u;r++)v=(v+1.3e-06*v*v+6.9999999999999997e-07)*0.99999970000000005;for(uint32_t r=0;r<1u;r++)v=wc_fn_0(v,t,i,task);return v;}
static double wc_fn_ref_2(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<1u;r++)v=wc_fn_ref_1(v,t,i,task);for(uint32_t r=0;r<60u;r++)v=v*0.99999990999999999+1.9000000000000001e-07;return v;}
static double wc_fn_2(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<1u;r++)v=wc_fn_1(v,t,i,task);for(uint32_t r=0;r<60u;r++)v=v*0.99999990999999999+1.9000000000000001e-07;return v;}
static double wc_fn_ref_3(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<24u;r++)v=(v+7.9999999999999996e-07*v*v+2.9999999999999999e-07)*0.99999990000000005;for(uint32_t r=0;r<20u;r++)v=v*1.00000003+1.1000000000000001e-07;return v;}
static double wc_fn_3(double x,double t,uint32_t i,uint32_t task){double v=x + t*0.000001 + (double)(i&255u)*0.00000001 + (double)(task+1u)*0.0000001;for(uint32_t r=0;r<24u;r++)v=(v+7.9999999999999996e-07*v*v+2.9999999999999999e-07)*0.99999990000000005;for(uint32_t r=0;r<20u;r++)v=v*1.00000003+1.1000000000000001e-07;return v;}
double wc_user_call(uint8_t id,double x,double t,uint32_t i,uint32_t task){switch(id){case 0:return wc_fn_0(x,t,i,task);case 1:return wc_fn_1(x,t,i,task);case 2:return wc_fn_2(x,t,i,task);case 3:return wc_fn_3(x,t,i,task);default:return x;}}
double wc_user_call_reference(uint8_t id,double x,double t,uint32_t i,uint32_t task){switch(id){case 0:return wc_fn_ref_0(x,t,i,task);case 1:return wc_fn_ref_1(x,t,i,task);case 2:return wc_fn_ref_2(x,t,i,task);case 3:return wc_fn_ref_3(x,t,i,task);default:return x;}}
uint32_t wc_user_fn_structural_bits(uint32_t id){switch(id){case 0:return 7u;case 1:return 1u;case 2:return 1u;case 3:return 1u;default:return 0;}}
uint64_t wc_user_fn_original_ops(uint32_t id){switch(id){case 0:return 120u;case 1:return 345u;case 2:return 466u;case 3:return 208u;default:return 0;}}
uint64_t wc_user_fn_collapsed_ops(uint32_t id){switch(id){case 0:return 2u;case 1:return 345u;case 2:return 466u;case 3:return 208u;default:return 0;}}
uint32_t wc_user_fn_bound(uint32_t id){switch(id){case 0:return 120u;case 1:return 345u;case 2:return 466u;case 3:return 208u;default:return 0;}}
uint32_t wc_user_array_count(void){return 12u;}
uint32_t wc_user_array_len(uint32_t id){switch(id){case 0:return 1024u;case 1:return 256u;case 2:return 256u;case 3:return 256u;case 4:return 1024u;case 5:return 1024u;case 6:return 1024u;case 7:return 1024u;case 8:return 1024u;case 9:return 1024u;case 10:return 1024u;case 11:return 1024u;default:return 0;}}
uint32_t wc_user_array_type(uint32_t id){switch(id){case 0:return 0u;case 1:return 1u;case 2:return 0u;case 3:return 0u;case 4:return 0u;case 5:return 0u;case 6:return 0u;case 7:return 0u;case 8:return 0u;case 9:return 0u;case 10:return 0u;case 11:return 0u;default:return 255u;}}
uint32_t wc_user_array_layout_kind(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 2u;case 5:return 2u;case 6:return 0u;case 7:return 0u;case 8:return 2u;case 9:return 2u;case 10:return 1u;case 11:return 1u;default:return 255u;}}
uint32_t wc_user_array_layout_group(uint32_t id){switch(id){case 0:return 255u;case 1:return 255u;case 2:return 255u;case 3:return 255u;case 4:return 1u;case 5:return 1u;case 6:return 255u;case 7:return 255u;case 8:return 2u;case 9:return 2u;case 10:return 0u;case 11:return 0u;default:return 255u;}}
uint32_t wc_user_array_layout_lane(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 0u;case 5:return 1u;case 6:return 0u;case 7:return 0u;case 8:return 0u;case 9:return 1u;case 10:return 0u;case 11:return 1u;default:return 0u;}}
uint32_t wc_user_array_layout_lanes(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;case 3:return 1u;case 4:return 2u;case 5:return 2u;case 6:return 1u;case 7:return 1u;case 8:return 2u;case 9:return 2u;case 10:return 2u;case 11:return 2u;default:return 1u;}}
uint32_t wc_user_array_layout_tile(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 16u;case 5:return 16u;case 6:return 0u;case 7:return 0u;case 8:return 16u;case 9:return 16u;case 10:return 1u;case 11:return 1u;default:return 0u;}}
uint32_t wc_user_array_layout_score(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 24u;case 5:return 24u;case 6:return 8u;case 7:return 0u;case 8:return 8u;case 9:return 8u;case 10:return 64u;case 11:return 64u;default:return 0u;}}
int32_t wc_user_array_layout_profit(uint32_t id){switch(id){case 0:return 0;case 1:return 0;case 2:return 0;case 3:return 0;case 4:return 7;case 5:return 7;case 6:return -22;case 7:return 0;case 8:return 6;case 9:return 6;case 10:return 58;case 11:return 58;default:return 0;}}
uint32_t wc_user_array_layout_phase_coverage(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 600u;case 5:return 600u;case 6:return 200u;case 7:return 0u;case 8:return 1000u;case 9:return 1000u;case 10:return 1000u;case 11:return 1000u;default:return 0u;}}
uint32_t wc_user_array_layout_stream_ratio(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 1000u;case 5:return 1000u;case 6:return 1000u;case 7:return 0u;case 8:return 1000u;case 9:return 1000u;case 10:return 0u;case 11:return 0u;default:return 0u;}}
uint32_t wc_user_array_layout_reason_bits(uint32_t id){switch(id){case 0:return 0u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 175u;case 5:return 175u;case 6:return 299u;case 7:return 0u;case 8:return 139u;case 9:return 139u;case 10:return 71u;case 11:return 71u;default:return 0u;}}
uint64_t wc_user_array_logical_bytes(uint32_t id){switch(id){case 0:return 8192u;case 1:return 1024u;case 2:return 2048u;case 3:return 2048u;case 4:return 8192u;case 5:return 8192u;case 6:return 8192u;case 7:return 8192u;case 8:return 8192u;case 9:return 8192u;case 10:return 8192u;case 11:return 8192u;default:return 0u;}}
uint64_t wc_user_array_physical_share_bytes(uint32_t id){switch(id){case 0:return 8192u;case 1:return 1024u;case 2:return 2048u;case 3:return 2048u;case 4:return 8192u;case 5:return 8192u;case 6:return 8192u;case 7:return 8192u;case 8:return 8192u;case 9:return 8192u;case 10:return 8192u;case 11:return 8192u;default:return 0u;}}
double wc_user_array_get(uint32_t id,uint32_t idx){switch(id){case 0:return idx<1024u?(double)WC_AREF_0(idx):0.0;case 1:return idx<256u?(double)WC_AREF_1(idx):0.0;case 2:return idx<256u?(double)WC_AREF_2(idx):0.0;case 3:return idx<256u?(double)WC_AREF_3(idx):0.0;case 4:return idx<1024u?(double)WC_AREF_4(idx):0.0;case 5:return idx<1024u?(double)WC_AREF_5(idx):0.0;case 6:return idx<1024u?(double)WC_AREF_6(idx):0.0;case 7:return idx<1024u?(double)WC_AREF_7(idx):0.0;case 8:return idx<1024u?(double)WC_AREF_8(idx):0.0;case 9:return idx<1024u?(double)WC_AREF_9(idx):0.0;case 10:return idx<1024u?(double)WC_AREF_10(idx):0.0;case 11:return idx<1024u?(double)WC_AREF_11(idx):0.0;default:return 0.0;}}
void wc_user_array_set(uint32_t id,uint32_t idx,double v){switch(id){case 0:if(idx<1024u)WC_AREF_0(idx)=(double)v;break;case 1:if(idx<256u)WC_AREF_1(idx)=(uint32_t)v;break;case 2:if(idx<256u)WC_AREF_2(idx)=(double)v;break;case 3:if(idx<256u)WC_AREF_3(idx)=(double)v;break;case 4:if(idx<1024u)WC_AREF_4(idx)=(double)v;break;case 5:if(idx<1024u)WC_AREF_5(idx)=(double)v;break;case 6:if(idx<1024u)WC_AREF_6(idx)=(double)v;break;case 7:if(idx<1024u)WC_AREF_7(idx)=(double)v;break;case 8:if(idx<1024u)WC_AREF_8(idx)=(double)v;break;case 9:if(idx<1024u)WC_AREF_9(idx)=(double)v;break;case 10:if(idx<1024u)WC_AREF_10(idx)=(double)v;break;case 11:if(idx<1024u)WC_AREF_11(idx)=(double)v;break;default:break;}}
uint64_t wc_user_array_get_bits(uint32_t id,uint32_t idx){switch(id){case 0:return idx<1024u?wc_f64_bits(WC_AREF_0(idx)):0;case 1:return idx<256u?(uint64_t)WC_AREF_1(idx):0;case 2:return idx<256u?wc_f64_bits(WC_AREF_2(idx)):0;case 3:return idx<256u?wc_f64_bits(WC_AREF_3(idx)):0;case 4:return idx<1024u?wc_f64_bits(WC_AREF_4(idx)):0;case 5:return idx<1024u?wc_f64_bits(WC_AREF_5(idx)):0;case 6:return idx<1024u?wc_f64_bits(WC_AREF_6(idx)):0;case 7:return idx<1024u?wc_f64_bits(WC_AREF_7(idx)):0;case 8:return idx<1024u?wc_f64_bits(WC_AREF_8(idx)):0;case 9:return idx<1024u?wc_f64_bits(WC_AREF_9(idx)):0;case 10:return idx<1024u?wc_f64_bits(WC_AREF_10(idx)):0;case 11:return idx<1024u?wc_f64_bits(WC_AREF_11(idx)):0;default:return 0;}}
void wc_user_array_set_bits(uint32_t id,uint32_t idx,uint64_t v){switch(id){case 0:if(idx<1024u)WC_AREF_0(idx)=wc_bits_f64(v);break;case 1:if(idx<256u)WC_AREF_1(idx)=(uint32_t)v;break;case 2:if(idx<256u)WC_AREF_2(idx)=wc_bits_f64(v);break;case 3:if(idx<256u)WC_AREF_3(idx)=wc_bits_f64(v);break;case 4:if(idx<1024u)WC_AREF_4(idx)=wc_bits_f64(v);break;case 5:if(idx<1024u)WC_AREF_5(idx)=wc_bits_f64(v);break;case 6:if(idx<1024u)WC_AREF_6(idx)=wc_bits_f64(v);break;case 7:if(idx<1024u)WC_AREF_7(idx)=wc_bits_f64(v);break;case 8:if(idx<1024u)WC_AREF_8(idx)=wc_bits_f64(v);break;case 9:if(idx<1024u)WC_AREF_9(idx)=wc_bits_f64(v);break;case 10:if(idx<1024u)WC_AREF_10(idx)=wc_bits_f64(v);break;case 11:if(idx<1024u)WC_AREF_11(idx)=wc_bits_f64(v);break;default:break;}}
static double wc_vfield_2[1000000];
static double wc_vfield_eval_0(uint32_t i){double x=(double)i;return 3.2000000000000002*x+7;}
static double wc_vfield_eval_1(uint32_t i){double x=(double)i;double y=9.9999999999999995e-07;y=y*x+0.5;y=y*x+1;return y;}
static double wc_vfield_eval_2(uint32_t i){double x=(double)i;double y=1e-10;y=y*x+1e-08;y=y*x+9.9999999999999995e-07;y=y*x+0.0001;y=y*x+0.01;y=y*x+1;return y;}
static uint8_t wc_memory_initialized;
static double wc_field_scratch[4096u];
void wc_user_memory_init(void){if(wc_memory_initialized)return;for(uint32_t i=0;i<1000000u;i++)wc_vfield_2[i]=wc_vfield_eval_2(i);wc_memory_initialized=1;}
uint32_t wc_user_memory_mode(void){return 1u;}
uint32_t wc_user_field_count(void){return 3u;}
uint32_t wc_user_field_len(uint32_t id){switch(id){case 0:return 4000000u;case 1:return 4000000u;case 2:return 1000000u;default:return 0;}}
uint32_t wc_user_field_repr(uint32_t id){switch(id){case 0:return 2u;case 1:return 3u;case 2:return 0u;default:return 255u;}}
uint32_t wc_user_field_proof_bits(uint32_t id){return id<3u?1u:0u;}
uint32_t wc_user_field_reconstruct_ops(uint32_t id){switch(id){case 0:return 2u;case 1:return 4u;case 2:return 10u;default:return 0;}}
uint64_t wc_user_field_logical_bytes(uint32_t id){switch(id){case 0:return 32000000u;case 1:return 32000000u;case 2:return 8000000u;default:return 0;}}
uint64_t wc_user_field_stored_bytes(uint32_t id){switch(id){case 0:return 16u;case 1:return 24u;case 2:return 8000000u;default:return 0;}}
uint64_t wc_user_field_saved_bytes(uint32_t id){switch(id){case 0:return 31999984u;case 1:return 31999976u;case 2:return 0u;default:return 0;}}
double wc_user_field_get(uint32_t id,uint32_t idx){switch(id){case 0:return idx<4000000u?wc_vfield_eval_0(idx):0.0;case 1:return idx<4000000u?wc_vfield_eval_1(idx):0.0;case 2:wc_user_memory_init();return idx<1000000u?wc_vfield_2[idx]:0.0;default:return 0.0;}}
double wc_user_field_checksum(uint32_t id,uint32_t stride){if(!stride)stride=1;double s=0.0;uint32_t n=wc_user_field_len(id);for(uint32_t i=0;i<n;i+=stride)s+=wc_user_field_get(id,i);return s;}
double wc_user_field_pair_checksum(uint32_t a,uint32_t b,uint32_t count){uint32_t na=wc_user_field_len(a),nb=wc_user_field_len(b);uint32_t n=count;if(n>na)n=na;if(n>nb)n=nb;double s=0.0;for(uint32_t i=0;i<n;i++){double x=wc_user_field_get(a,i),y=wc_user_field_get(b,i);s+=x*0.625+y*0.375;}return s;}
uint32_t wc_user_field_materialize(uint32_t id,uint32_t start,uint32_t count){uint32_t n=wc_user_field_len(id);if(start>=n)return 0;if(count>4096u)count=4096u;if(count>n-start)count=n-start;for(uint32_t k=0;k<count;k++)wc_field_scratch[k]=wc_user_field_get(id,start+k);return count;}
double wc_user_field_scratch_get(uint32_t i){return i<4096u?wc_field_scratch[i]:0.0;}
static double wc_pwfield_eval_0(uint32_t i){double x=(double)i;if(i<1000000u){return 1.0000000000000001e-05*x+1;}else if(i<2000000u){return -2.0000000000000002e-05*x+100;}else if(i<3000000u){double y=3.0000000000000001e-06;y=y*x+0;y=y*x+-40;return y;}else if(i<4000000u){return 7;}return 0.0;}
static uint8_t wc_pw_memory_initialized;
void wc_user_pw_memory_init(void){if(wc_pw_memory_initialized)return;wc_pw_memory_initialized=1;}
uint32_t wc_user_pwfield_count(void){return 1u;}
uint32_t wc_user_pwfield_len(uint32_t id){switch(id){case 0:return 4000000u;default:return 0;}}
uint32_t wc_user_pwfield_repr(uint32_t id){switch(id){case 0:return 1u;default:return 255u;}}
uint32_t wc_user_pwfield_segments(uint32_t id){switch(id){case 0:return 4u;default:return 0;}}
uint64_t wc_user_pwfield_logical_bytes(uint32_t id){switch(id){case 0:return 32000000u;default:return 0;}}
uint64_t wc_user_pwfield_stored_bytes(uint32_t id){switch(id){case 0:return 96u;default:return 0;}}
uint64_t wc_user_pwfield_saved_bytes(uint32_t id){switch(id){case 0:return 31999904u;default:return 0;}}
double wc_user_pwfield_get(uint32_t id,uint32_t idx){switch(id){case 0:return idx<4000000u?wc_pwfield_eval_0(idx):0.0;default:return 0.0;}}
double wc_user_pwfield_checksum(uint32_t id,uint32_t stride){if(!stride)stride=1;double s=0.0;uint32_t n=wc_user_pwfield_len(id);for(uint32_t i=0;i<n;i+=stride)s+=wc_user_pwfield_get(id,i);return s;}
#define WC_SOLVER_MAX_N 256u
static double wc_s_dense[WC_SOLVER_MAX_N*WC_SOLVER_MAX_N],wc_s_b[WC_SOLVER_MAX_N],wc_s_x[WC_SOLVER_MAX_N],wc_s_r[WC_SOLVER_MAX_N],wc_s_p[WC_SOLVER_MAX_N],wc_s_ap[WC_SOLVER_MAX_N];
static double wc_s_last_res[4];
static const double wc_cheb_omega_0[15]={0.49727587074920288,0.47667010450745212,0.44092698519760604,0.39781830885162739,0.35405380152817328,0.3138213138631718,0.27900410791037311,0.25000000000000006,0.22645833258612422,0.20775019212779422,0.19321541443868223,0.18227254914001276,0.17445763018700944,0.16943084527154881,0.16697156256341508};
static const double wc_cheb_omega_1[1]={0.0};
static const double wc_cheb_omega_2[1]={0.0};
static const double wc_cheb_omega_3[1]={0.5};
static double wc_absd(double x){return x<0?-x:x;}
static uint32_t wc_mat_n(uint32_t id){switch(id){case 0:return 256u;case 1:return 256u;case 2:return 256u;case 3:return 256u;default:return 0;}}
static uint32_t wc_mat_bw(uint32_t id){switch(id){case 0:return 1u;case 1:return 2u;case 2:return 1u;case 3:return 0u;default:return 0;}}
static double wc_mat_get(uint32_t id,uint32_t i,uint32_t j){switch(id){case 0:{if(i>=256u||j>=256u)return 0.0;if(i==j)return 4;if((i>j?i-j:j-i)==1u)return -1;return 0.0;}case 1:{if(i>=256u||j>=256u)return 0.0;if(i==j)return 4;if(i>j&&i-j==1u)return -1;if(j>i&&j-i==2u)return -0.25;return 0.0;}case 2:{if(i>=256u||j>=256u)return 0.0;if(i==j)return 3;if(i>j&&i-j==1u)return -0.5;return 0.0;}case 3:{if(i>=256u||j>=256u)return 0.0;if(i==j)return 2;return 0.0;}default:return 0.0;}}
static uint32_t wc_s_mid(uint32_t s){switch(s){case 0:return 0u;case 1:return 1u;case 2:return 2u;case 3:return 3u;default:return 0;}}
static uint32_t wc_s_rhs(uint32_t s){switch(s){case 0:return 2u;case 1:return 2u;case 2:return 2u;case 3:return 2u;default:return 0;}}
static uint32_t wc_s_out(uint32_t s){switch(s){case 0:return 3u;case 1:return 3u;case 2:return 3u;case 3:return 3u;default:return 0;}}
static double wc_s_rhs_direct(uint32_t s,uint32_t i){switch(s){case 0:return (double)WC_AREF_2(i);case 1:return (double)WC_AREF_2(i);case 2:return (double)WC_AREF_2(i);case 3:return (double)WC_AREF_2(i);default:return 0.0;}}
static void wc_s_out_direct(uint32_t s,uint32_t i,double v){switch(s){case 0:WC_AREF_3(i)=(double)v;break;case 1:WC_AREF_3(i)=(double)v;break;case 2:WC_AREF_3(i)=(double)v;break;case 3:WC_AREF_3(i)=(double)v;break;default:break;}}
static uint32_t wc_s_maxiter(uint32_t s){switch(s){case 0:return 64u;case 1:return 96u;case 2:return 64u;case 3:return 16u;default:return 0;}}
static double wc_s_tol(uint32_t s){switch(s){case 0:return 1e-08;case 1:return 1e-08;case 2:return 1e-10;case 3:return 9.9999999999999998e-13;default:return 1e-8;}}
static uint32_t wc_s_cheb_steps(uint32_t s){switch(s){case 0:return 15u;case 1:return 0u;case 2:return 0u;case 3:return 1u;default:return 0;}}
static double wc_s_cheb_omega(uint32_t s,uint32_t k){switch(s){case 0:return k<15u?wc_cheb_omega_0[k]:0.0;case 1:return k<0u?wc_cheb_omega_1[k]:0.0;case 2:return k<0u?wc_cheb_omega_2[k]:0.0;case 3:return k<1u?wc_cheb_omega_3[k]:0.0;default:return 0.0;}}
static void wc_matvec(uint32_t mid,const double*x,double*y){uint32_t n=wc_mat_n(mid),w=wc_mat_bw(mid);for(uint32_t i=0;i<n;i++){double z=0.0;uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)z+=wc_mat_get(mid,i,j)*x[j];y[i]=z;}}
static void wc_load_rhs(uint32_t sid){uint32_t n=wc_mat_n(wc_s_mid(sid));for(uint32_t i=0;i<n;i++){wc_s_b[i]=wc_s_rhs_direct(sid,i);wc_s_x[i]=0.0;}}
static void wc_store_x(uint32_t sid){uint32_t n=wc_mat_n(wc_s_mid(sid));for(uint32_t i=0;i<n;i++)wc_s_out_direct(sid,i,wc_s_x[i]);}
static double wc_residual(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_matvec(mid,wc_s_x,wc_s_ap);double mx=0.0;for(uint32_t i=0;i<n;i++){double z=wc_absd(wc_s_rhs_direct(sid,i)-wc_s_ap[i]);if(z>mx)mx=z;}return mx;}
static uint32_t wc_dense_gauss(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++)for(uint32_t j=0;j<n;j++)wc_s_dense[i*n+j]=wc_mat_get(mid,i,j);for(uint32_t k=0;k<n;k++){uint32_t p=k;double best=wc_absd(wc_s_dense[k*n+k]);for(uint32_t i=k+1;i<n;i++){double z=wc_absd(wc_s_dense[i*n+k]);if(z>best){best=z;p=i;}}if(best<1e-30)return 0;if(p!=k){for(uint32_t j=k;j<n;j++){double z=wc_s_dense[k*n+j];wc_s_dense[k*n+j]=wc_s_dense[p*n+j];wc_s_dense[p*n+j]=z;}double z=wc_s_b[k];wc_s_b[k]=wc_s_b[p];wc_s_b[p]=z;}for(uint32_t i=k+1;i<n;i++){double f=wc_s_dense[i*n+k]/wc_s_dense[k*n+k];wc_s_dense[i*n+k]=0.0;for(uint32_t j=k+1;j<n;j++)wc_s_dense[i*n+j]-=f*wc_s_dense[k*n+j];wc_s_b[i]-=f*wc_s_b[k];}}for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];for(uint32_t j=ii+1;j<n;j++)z-=wc_s_dense[ii*n+j]*wc_s_x[j];wc_s_x[ii]=z/wc_s_dense[ii*n+ii];}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_banded_gauss(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)wc_s_dense[i*n+j]=wc_mat_get(mid,i,j);}for(uint32_t k=0;k<n;k++){double piv=wc_s_dense[k*n+k];if(wc_absd(piv)<1e-30)return 0;uint32_t im=k+w+1<n?k+w+1:n,jm=k+w+1<n?k+w+1:n;for(uint32_t i=k+1;i<im;i++){double f=wc_s_dense[i*n+k]/piv;wc_s_dense[i*n+k]=0.0;for(uint32_t j=k+1;j<jm;j++)wc_s_dense[i*n+j]-=f*wc_s_dense[k*n+j];wc_s_b[i]-=f*wc_s_b[k];}}for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];uint32_t jm=ii+w+1<n?ii+w+1:n;for(uint32_t j=ii+1;j<jm;j++)z-=wc_s_dense[ii*n+j]*wc_s_x[j];wc_s_x[ii]=z/wc_s_dense[ii*n+ii];}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_cg(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);double rs=0.0,bn=0.0;for(uint32_t i=0;i<n;i++){wc_s_r[i]=wc_s_b[i];wc_s_p[i]=wc_s_r[i];rs+=wc_s_r[i]*wc_s_r[i];bn+=wc_s_b[i]*wc_s_b[i];}double target=tol*tol;uint32_t it=0;for(;it<mi&&rs>target;it++){wc_matvec(mid,wc_s_p,wc_s_ap);double den=0.0;for(uint32_t i=0;i<n;i++)den+=wc_s_p[i]*wc_s_ap[i];if(den<=1e-30)break;double a=rs/den;double rs2=0.0;for(uint32_t i=0;i<n;i++){wc_s_x[i]+=a*wc_s_p[i];wc_s_r[i]-=a*wc_s_ap[i];rs2+=wc_s_r[i]*wc_s_r[i];}if(rs2<=target){rs=rs2;it++;break;}double beta=rs2/rs;for(uint32_t i=0;i<n;i++)wc_s_p[i]=wc_s_r[i]+beta*wc_s_p[i];rs=rs2;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static uint32_t wc_cheb(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),steps=wc_s_cheb_steps(sid);wc_load_rhs(sid);for(uint32_t k=0;k<steps;k++){wc_matvec(mid,wc_s_x,wc_s_ap);double om=wc_s_cheb_omega(sid,k);for(uint32_t i=0;i<n;i++)wc_s_x[i]+=om*(wc_s_b[i]-wc_s_ap[i]);}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return steps;}
static uint32_t wc_jacobi(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];wc_s_ap[i]=z/d;}for(uint32_t i=0;i<n;i++)wc_s_x[i]=wc_s_ap[i];if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static uint32_t wc_gs(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];wc_s_x[i]=z/d;}if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static double wc_s_weighted_omega(uint32_t s){switch(s){case 0:return 1;case 1:return 0;case 2:return 0;case 3:return 1;default:return 1.0;}}
static uint32_t wc_wjacobi(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid),mi=wc_s_maxiter(sid);double tol=wc_s_tol(sid),om=wc_s_weighted_omega(sid);wc_load_rhs(sid);uint32_t it=0;for(;it<mi;it++){for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i),z=wc_s_b[i];uint32_t j0=i>w?i-w:0,j1=i+w+1<n?i+w+1:n;for(uint32_t j=j0;j<j1;j++)if(j!=i)z-=wc_mat_get(mid,i,j)*wc_s_x[j];double target=z/d;wc_s_ap[i]=wc_s_x[i]+om*(target-wc_s_x[i]);}for(uint32_t i=0;i<n;i++)wc_s_x[i]=wc_s_ap[i];if(wc_residual(sid)<tol){it++;break;}}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return it;}
static uint32_t wc_forward(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){double z=wc_s_b[i];uint32_t j0=i>w?i-w:0;for(uint32_t j=j0;j<i;j++)z-=wc_mat_get(mid,i,j)*wc_s_x[j];double d=wc_mat_get(mid,i,i);if(wc_absd(d)<1e-30)return 0;wc_s_x[i]=z/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_back(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid),w=wc_mat_bw(mid);wc_load_rhs(sid);for(uint32_t ii=n;ii-->0;){double z=wc_s_b[ii];uint32_t j1=ii+w+1<n?ii+w+1:n;for(uint32_t j=ii+1;j<j1;j++)z-=wc_mat_get(mid,ii,j)*wc_s_x[j];double d=wc_mat_get(mid,ii,ii);if(wc_absd(d)<1e-30)return 0;wc_s_x[ii]=z/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
static uint32_t wc_diagonal(uint32_t sid){uint32_t mid=wc_s_mid(sid),n=wc_mat_n(mid);wc_load_rhs(sid);for(uint32_t i=0;i<n;i++){double d=wc_mat_get(mid,i,i);if(wc_absd(d)<1e-30)return 0;wc_s_x[i]=wc_s_b[i]/d;}wc_store_x(sid);wc_s_last_res[sid]=wc_residual(sid);return n;}
uint32_t wc_user_solve_count(void){return 4u;}
uint32_t wc_user_solve_proof_bits(uint32_t s){switch(s){case 0:return 63u;case 1:return 25u;case 2:return 89u;case 3:return 511u;default:return 0;}}
uint32_t wc_user_solve_chosen(uint32_t s){switch(s){case 0:return 2u;case 1:return 2u;case 2:return 8u;case 3:return 10u;default:return 0;}}
uint64_t wc_user_solve_estimated(uint32_t s,uint32_t method){switch(s){case 0:switch(method){case 1:return 5657941u;case 2:return 3328u;case 3:return 69120u;case 4:return 53760u;case 5:return 69120u;case 6:return 43008u;case 7:return 76032u;case 8:return 18446744073709551615u;case 9:return 18446744073709551615u;case 10:return 18446744073709551615u;default:return 0;}case 1:switch(method){case 1:return 5657941u;case 2:return 6144u;case 3:return 18446744073709551615u;case 4:return 18446744073709551615u;case 5:return 57344u;case 6:return 32768u;case 7:return 18446744073709551615u;case 8:return 18446744073709551615u;case 9:return 18446744073709551615u;case 10:return 18446744073709551615u;default:return 0;}case 2:switch(method){case 1:return 5657941u;case 2:return 3328u;case 3:return 18446744073709551615u;case 4:return 18446744073709551615u;case 5:return 33280u;case 6:return 21504u;case 7:return 18446744073709551615u;case 8:return 1280u;case 9:return 18446744073709551615u;case 10:return 18446744073709551615u;default:return 0;}case 3:switch(method){case 1:return 5657941u;case 2:return 1536u;case 3:return 3584u;case 4:return 2560u;case 5:return 1536u;case 6:return 2048u;case 7:return 1792u;case 8:return 768u;case 9:return 768u;case 10:return 512u;default:return 0;}default:return 0;}}
double wc_user_solve_residual(uint32_t s){return s<4u?wc_s_last_res[s]:0.0;}
uint32_t wc_user_solve(uint32_t s,uint32_t method){if(s>=4u)return 0;if(method==0)method=wc_user_solve_chosen(s);uint32_t bits=wc_user_solve_proof_bits(s);if(method==1)return wc_dense_gauss(s);if(method==2&&(bits&1u))return wc_banded_gauss(s);if(method==3&&(bits&2u))return wc_cg(s);if(method==4&&(bits&4u))return wc_cheb(s);if(method==5&&(bits&8u))return wc_jacobi(s);if(method==6&&(bits&16u))return wc_gs(s);if(method==7&&(bits&32u))return wc_wjacobi(s);if(method==8&&(bits&64u))return wc_forward(s);if(method==9&&(bits&128u))return wc_back(s);if(method==10&&(bits&256u))return wc_diagonal(s);return 0;}
enum{WC_SIA_LINEAR_OPERATOR=1u,WC_SIA_TOPOLOGY_RELATION=2u,WC_SIA_DEPENDENCE_REGION=3u,WC_SIA_INDEX_KERNEL=4u};
uint32_t wc_user_sia_count(void){return 17u;}
uint32_t wc_user_sia_kind(uint32_t id){if(id<4u)return WC_SIA_LINEAR_OPERATOR;id-=4u;if(id<3u)return WC_SIA_TOPOLOGY_RELATION;id-=3u;if(id<4u)return WC_SIA_DEPENDENCE_REGION;id-=4u;if(id<6u){switch(id){case 0:return WC_SIA_INDEX_KERNEL;case 1:return WC_SIA_LINEAR_OPERATOR;case 2:return WC_SIA_INDEX_KERNEL;case 3:return WC_SIA_INDEX_KERNEL;case 4:return WC_SIA_INDEX_KERNEL;case 5:return WC_SIA_INDEX_KERNEL;default:return 0;}}return 0;}
uint32_t wc_user_sia_extent(uint32_t id){switch(id){case 0:return 256u;case 1:return 256u;case 2:return 256u;case 3:return 256u;case 4:return 64u;case 5:return 5u;case 6:return 4u;case 7:return 248u;case 8:return 15872u;case 9:return 253952u;case 10:return 768u;case 11:return 1024u;case 12:return 1022u;case 13:return 1024u;case 14:return 1024u;case 15:return 1024u;case 16:return 5120u;default:return 0;}}
uint32_t wc_user_sia_stages(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;case 3:return 1u;case 4:return 1u;case 5:return 1u;case 6:return 1u;case 7:return 62u;case 8:return 62u;case 9:return 62u;case 10:return 3u;case 11:return 1u;case 12:return 1u;case 13:return 1u;case 14:return 1u;case 15:return 2u;case 16:return 2u;default:return 0;}}
uint32_t wc_user_sia_locality(uint32_t id){switch(id){case 0:return 1u;case 1:return 2u;case 2:return 1u;case 3:return 0u;case 4:return 4u;case 5:return 3u;case 6:return 2u;case 7:return 1u;case 8:return 1u;case 9:return 1u;case 10:return 0u;case 11:return 0u;case 12:return 1u;case 13:return 0u;case 14:return 1u;case 15:return 1u;case 16:return 1u;default:return 0;}}
uint32_t wc_user_sia_proof_bits(uint32_t id){switch(id){case 0:return 1567u;case 1:return 1567u;case 2:return 1567u;case 3:return 1567u;case 4:return 1295u;case 5:return 1295u;case 6:return 1295u;case 7:return 3299u;case 8:return 3299u;case 9:return 3299u;case 10:return 3107u;case 11:return 1027u;case 12:return 1567u;case 13:return 1027u;case 14:return 1031u;case 15:return 1031u;case 16:return 1031u;default:return 0;}}
uint32_t wc_user_sia_transform_bits(uint32_t id){switch(id){case 0:return 24u;case 1:return 24u;case 2:return 88u;case 3:return 88u;case 4:return 32u;case 5:return 32u;case 6:return 32u;case 7:return 7u;case 8:return 7u;case 9:return 7u;case 10:return 6u;case 11:return 0u;case 12:return 24u;case 13:return 0u;case 14:return 0u;case 15:return 0u;case 16:return 0u;default:return 0;}}
#ifdef WC_IPE_BENCHMARK
typedef struct{uint16_t node;uint8_t fn;uint32_t begin,end;int32_t rank;} wc_ipe_desc;
static volatile uint64_t wc_ipe_sched_state;
static uint64_t wc_ipe_hash(double d,uint32_t i){int64_t q=(int64_t)(d*1000000000000.0);uint64_t z=(uint64_t)q^((uint64_t)i*0x9e3779b97f4a7c15ull);z^=z>>30;z*=0xbf58476d1ce4e5b9ull;z^=z>>27;z*=0x94d049bb133111ebull;return z^(z>>31);}
__attribute__((noinline)) static double wc_ipe_eval(uint8_t fn,uint32_t i){return wc_user_call(fn,(double)(i+1u)*0.000001,0.375,i,0u);}
static const wc_ipe_desc wc_ipe_desc_0[62]={{0u,0u,0u,4u,0},{1u,0u,4u,8u,0},{2u,0u,8u,12u,0},{3u,0u,12u,16u,0},{4u,0u,16u,20u,0},{5u,0u,20u,24u,0},{6u,0u,24u,28u,0},{7u,0u,28u,32u,0},{8u,0u,32u,36u,0},{9u,0u,36u,40u,0},{10u,0u,40u,44u,0},{11u,0u,44u,48u,0},{12u,0u,48u,52u,0},{13u,0u,52u,56u,0},{14u,0u,56u,60u,0},{15u,0u,60u,64u,0},{16u,0u,64u,68u,0},{17u,0u,68u,72u,0},{18u,0u,72u,76u,0},{19u,0u,76u,80u,0},{20u,0u,80u,84u,0},{21u,0u,84u,88u,0},{22u,0u,88u,92u,0},{23u,0u,92u,96u,0},{24u,0u,96u,100u,0},{25u,0u,100u,104u,0},{26u,0u,104u,108u,0},{27u,0u,108u,112u,0},{28u,0u,112u,116u,0},{29u,0u,116u,120u,0},{30u,0u,120u,124u,0},{31u,0u,124u,128u,0},{32u,0u,128u,132u,0},{33u,0u,132u,136u,0},{34u,0u,136u,140u,0},{35u,0u,140u,144u,0},{36u,0u,144u,148u,0},{37u,0u,148u,152u,0},{38u,0u,152u,156u,0},{39u,0u,156u,160u,0},{40u,0u,160u,164u,0},{41u,0u,164u,168u,0},{42u,0u,168u,172u,0},{43u,0u,172u,176u,0},{44u,0u,176u,180u,0},{45u,0u,180u,184u,0},{46u,0u,184u,188u,0},{47u,0u,188u,192u,0},{48u,0u,192u,196u,0},{49u,0u,196u,200u,0},{50u,0u,200u,204u,0},{51u,0u,204u,208u,0},{52u,0u,208u,212u,0},{53u,0u,212u,216u,0},{54u,0u,216u,220u,0},{55u,0u,220u,224u,0},{56u,0u,224u,228u,0},{57u,0u,228u,232u,0},{58u,0u,232u,236u,0},{59u,0u,236u,240u,0},{60u,0u,240u,244u,0},{61u,0u,244u,248u,0}};
static const wc_ipe_desc wc_ipe_desc_1[62]={{0u,0u,0u,256u,0},{1u,0u,256u,512u,0},{2u,0u,512u,768u,0},{3u,0u,768u,1024u,0},{4u,0u,1024u,1280u,0},{5u,0u,1280u,1536u,0},{6u,0u,1536u,1792u,0},{7u,0u,1792u,2048u,0},{8u,0u,2048u,2304u,0},{9u,0u,2304u,2560u,0},{10u,0u,2560u,2816u,0},{11u,0u,2816u,3072u,0},{12u,0u,3072u,3328u,0},{13u,0u,3328u,3584u,0},{14u,0u,3584u,3840u,0},{15u,0u,3840u,4096u,0},{16u,0u,4096u,4352u,0},{17u,0u,4352u,4608u,0},{18u,0u,4608u,4864u,0},{19u,0u,4864u,5120u,0},{20u,0u,5120u,5376u,0},{21u,0u,5376u,5632u,0},{22u,0u,5632u,5888u,0},{23u,0u,5888u,6144u,0},{24u,0u,6144u,6400u,0},{25u,0u,6400u,6656u,0},{26u,0u,6656u,6912u,0},{27u,0u,6912u,7168u,0},{28u,0u,7168u,7424u,0},{29u,0u,7424u,7680u,0},{30u,0u,7680u,7936u,0},{31u,0u,7936u,8192u,0},{32u,0u,8192u,8448u,0},{33u,0u,8448u,8704u,0},{34u,0u,8704u,8960u,0},{35u,0u,8960u,9216u,0},{36u,0u,9216u,9472u,0},{37u,0u,9472u,9728u,0},{38u,0u,9728u,9984u,0},{39u,0u,9984u,10240u,0},{40u,0u,10240u,10496u,0},{41u,0u,10496u,10752u,0},{42u,0u,10752u,11008u,0},{43u,0u,11008u,11264u,0},{44u,0u,11264u,11520u,0},{45u,0u,11520u,11776u,0},{46u,0u,11776u,12032u,0},{47u,0u,12032u,12288u,0},{48u,0u,12288u,12544u,0},{49u,0u,12544u,12800u,0},{50u,0u,12800u,13056u,0},{51u,0u,13056u,13312u,0},{52u,0u,13312u,13568u,0},{53u,0u,13568u,13824u,0},{54u,0u,13824u,14080u,0},{55u,0u,14080u,14336u,0},{56u,0u,14336u,14592u,0},{57u,0u,14592u,14848u,0},{58u,0u,14848u,15104u,0},{59u,0u,15104u,15360u,0},{60u,0u,15360u,15616u,0},{61u,0u,15616u,15872u,0}};
static const wc_ipe_desc wc_ipe_desc_2[62]={{0u,0u,0u,4096u,0},{1u,0u,4096u,8192u,0},{2u,0u,8192u,12288u,0},{3u,0u,12288u,16384u,0},{4u,0u,16384u,20480u,0},{5u,0u,20480u,24576u,0},{6u,0u,24576u,28672u,0},{7u,0u,28672u,32768u,0},{8u,0u,32768u,36864u,0},{9u,0u,36864u,40960u,0},{10u,0u,40960u,45056u,0},{11u,0u,45056u,49152u,0},{12u,0u,49152u,53248u,0},{13u,0u,53248u,57344u,0},{14u,0u,57344u,61440u,0},{15u,0u,61440u,65536u,0},{16u,0u,65536u,69632u,0},{17u,0u,69632u,73728u,0},{18u,0u,73728u,77824u,0},{19u,0u,77824u,81920u,0},{20u,0u,81920u,86016u,0},{21u,0u,86016u,90112u,0},{22u,0u,90112u,94208u,0},{23u,0u,94208u,98304u,0},{24u,0u,98304u,102400u,0},{25u,0u,102400u,106496u,0},{26u,0u,106496u,110592u,0},{27u,0u,110592u,114688u,0},{28u,0u,114688u,118784u,0},{29u,0u,118784u,122880u,0},{30u,0u,122880u,126976u,0},{31u,0u,126976u,131072u,0},{32u,0u,131072u,135168u,0},{33u,0u,135168u,139264u,0},{34u,0u,139264u,143360u,0},{35u,0u,143360u,147456u,0},{36u,0u,147456u,151552u,0},{37u,0u,151552u,155648u,0},{38u,0u,155648u,159744u,0},{39u,0u,159744u,163840u,0},{40u,0u,163840u,167936u,0},{41u,0u,167936u,172032u,0},{42u,0u,172032u,176128u,0},{43u,0u,176128u,180224u,0},{44u,0u,180224u,184320u,0},{45u,0u,184320u,188416u,0},{46u,0u,188416u,192512u,0},{47u,0u,192512u,196608u,0},{48u,0u,196608u,200704u,0},{49u,0u,200704u,204800u,0},{50u,0u,204800u,208896u,0},{51u,0u,208896u,212992u,0},{52u,0u,212992u,217088u,0},{53u,0u,217088u,221184u,0},{54u,0u,221184u,225280u,0},{55u,0u,225280u,229376u,0},{56u,0u,229376u,233472u,0},{57u,0u,233472u,237568u,0},{58u,0u,237568u,241664u,0},{59u,0u,241664u,245760u,0},{60u,0u,245760u,249856u,0},{61u,0u,249856u,253952u,0}};
static const wc_ipe_desc wc_ipe_desc_3[3]={{0u,3u,0u,256u,50},{1u,0u,256u,512u,-50},{2u,1u,512u,768u,0}};
#endif
uint32_t wc_user_ipe_count(void){return 4u;}
uint32_t wc_user_ipe_proof_bits(uint32_t id){switch(id){case 0:return 63u;case 1:return 63u;case 2:return 63u;case 3:return 47u;default:return 0;}}
uint32_t wc_user_ipe_original_nodes(uint32_t id){switch(id){case 0:return 126u;case 1:return 126u;case 2:return 126u;case 3:return 8u;default:return 0;}}
uint32_t wc_user_ipe_serial_nodes(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;case 3:return 3u;default:return 0;}}
uint32_t wc_user_ipe_eliminated_orchestration(uint32_t id){switch(id){case 0:return 64u;case 1:return 64u;case 2:return 64u;case 3:return 5u;default:return 0;}}
uint32_t wc_user_ipe_scalarized_worker_slots(uint32_t id){switch(id){case 0:return 61u;case 1:return 61u;case 2:return 61u;case 3:return 3u;default:return 0;}}
uint32_t wc_user_ipe_fused_partitions(uint32_t id){switch(id){case 0:return 62u;case 1:return 62u;case 2:return 62u;case 3:return 0u;default:return 0;}}
uint32_t wc_user_ipe_partition_boundaries_removed(uint32_t id){switch(id){case 0:return 61u;case 1:return 61u;case 2:return 61u;case 3:return 0u;default:return 0;}}
uint32_t wc_user_ipe_schedule_node(uint32_t id,uint32_t k){switch(id){case 0:switch(k){case 0:return 0u;case 1:return 1u;case 2:return 2u;case 3:return 3u;case 4:return 4u;case 5:return 5u;case 6:return 6u;case 7:return 7u;case 8:return 8u;case 9:return 9u;case 10:return 10u;case 11:return 11u;case 12:return 12u;case 13:return 13u;case 14:return 14u;case 15:return 15u;case 16:return 16u;case 17:return 17u;case 18:return 18u;case 19:return 19u;case 20:return 20u;case 21:return 21u;case 22:return 22u;case 23:return 23u;case 24:return 24u;case 25:return 25u;case 26:return 26u;case 27:return 27u;case 28:return 28u;case 29:return 29u;case 30:return 30u;case 31:return 31u;case 32:return 32u;case 33:return 33u;case 34:return 34u;case 35:return 35u;case 36:return 36u;case 37:return 37u;case 38:return 38u;case 39:return 39u;case 40:return 40u;case 41:return 41u;case 42:return 42u;case 43:return 43u;case 44:return 44u;case 45:return 45u;case 46:return 46u;case 47:return 47u;case 48:return 48u;case 49:return 49u;case 50:return 50u;case 51:return 51u;case 52:return 52u;case 53:return 53u;case 54:return 54u;case 55:return 55u;case 56:return 56u;case 57:return 57u;case 58:return 58u;case 59:return 59u;case 60:return 60u;case 61:return 61u;default:return 0xffffffffu;}case 1:switch(k){case 0:return 0u;case 1:return 1u;case 2:return 2u;case 3:return 3u;case 4:return 4u;case 5:return 5u;case 6:return 6u;case 7:return 7u;case 8:return 8u;case 9:return 9u;case 10:return 10u;case 11:return 11u;case 12:return 12u;case 13:return 13u;case 14:return 14u;case 15:return 15u;case 16:return 16u;case 17:return 17u;case 18:return 18u;case 19:return 19u;case 20:return 20u;case 21:return 21u;case 22:return 22u;case 23:return 23u;case 24:return 24u;case 25:return 25u;case 26:return 26u;case 27:return 27u;case 28:return 28u;case 29:return 29u;case 30:return 30u;case 31:return 31u;case 32:return 32u;case 33:return 33u;case 34:return 34u;case 35:return 35u;case 36:return 36u;case 37:return 37u;case 38:return 38u;case 39:return 39u;case 40:return 40u;case 41:return 41u;case 42:return 42u;case 43:return 43u;case 44:return 44u;case 45:return 45u;case 46:return 46u;case 47:return 47u;case 48:return 48u;case 49:return 49u;case 50:return 50u;case 51:return 51u;case 52:return 52u;case 53:return 53u;case 54:return 54u;case 55:return 55u;case 56:return 56u;case 57:return 57u;case 58:return 58u;case 59:return 59u;case 60:return 60u;case 61:return 61u;default:return 0xffffffffu;}case 2:switch(k){case 0:return 0u;case 1:return 1u;case 2:return 2u;case 3:return 3u;case 4:return 4u;case 5:return 5u;case 6:return 6u;case 7:return 7u;case 8:return 8u;case 9:return 9u;case 10:return 10u;case 11:return 11u;case 12:return 12u;case 13:return 13u;case 14:return 14u;case 15:return 15u;case 16:return 16u;case 17:return 17u;case 18:return 18u;case 19:return 19u;case 20:return 20u;case 21:return 21u;case 22:return 22u;case 23:return 23u;case 24:return 24u;case 25:return 25u;case 26:return 26u;case 27:return 27u;case 28:return 28u;case 29:return 29u;case 30:return 30u;case 31:return 31u;case 32:return 32u;case 33:return 33u;case 34:return 34u;case 35:return 35u;case 36:return 36u;case 37:return 37u;case 38:return 38u;case 39:return 39u;case 40:return 40u;case 41:return 41u;case 42:return 42u;case 43:return 43u;case 44:return 44u;case 45:return 45u;case 46:return 46u;case 47:return 47u;case 48:return 48u;case 49:return 49u;case 50:return 50u;case 51:return 51u;case 52:return 52u;case 53:return 53u;case 54:return 54u;case 55:return 55u;case 56:return 56u;case 57:return 57u;case 58:return 58u;case 59:return 59u;case 60:return 60u;case 61:return 61u;default:return 0xffffffffu;}case 3:switch(k){case 0:return 1u;case 1:return 2u;case 2:return 0u;default:return 0xffffffffu;}default:return 0xffffffffu;}}
#ifdef WC_IPE_BENCHMARK
uint64_t wc_user_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){uint64_t total=0;switch(id){case 0:for(uint32_t rep=0;rep<reps;rep++){uint64_t h=0;if(optimized){for(uint32_t i=0u;i<248u;i++){double v=wc_ipe_eval(0u,i);h^=wc_ipe_hash(v,i);}}else{for(uint32_t q=0;q<62u;q++){const wc_ipe_desc*d=&wc_ipe_desc_0[q];wc_ipe_sched_state^=((uint64_t)d->node<<32)^q;for(uint32_t i=d->begin;i<d->end;i++){double v=wc_ipe_eval(d->fn,i);h^=wc_ipe_hash(v,i);}wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}wc_ipe_sched_state^=2u;}total^=h+((uint64_t)rep*0x517cc1b727220a95ull);}return total;case 1:for(uint32_t rep=0;rep<reps;rep++){uint64_t h=0;if(optimized){for(uint32_t i=0u;i<15872u;i++){double v=wc_ipe_eval(0u,i);h^=wc_ipe_hash(v,i);}}else{for(uint32_t q=0;q<62u;q++){const wc_ipe_desc*d=&wc_ipe_desc_1[q];wc_ipe_sched_state^=((uint64_t)d->node<<32)^q;for(uint32_t i=d->begin;i<d->end;i++){double v=wc_ipe_eval(d->fn,i);h^=wc_ipe_hash(v,i);}wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}wc_ipe_sched_state^=2u;}total^=h+((uint64_t)rep*0x517cc1b727220a95ull);}return total;case 2:for(uint32_t rep=0;rep<reps;rep++){uint64_t h=0;if(optimized){for(uint32_t i=0u;i<253952u;i++){double v=wc_ipe_eval(0u,i);h^=wc_ipe_hash(v,i);}}else{for(uint32_t q=0;q<62u;q++){const wc_ipe_desc*d=&wc_ipe_desc_2[q];wc_ipe_sched_state^=((uint64_t)d->node<<32)^q;for(uint32_t i=d->begin;i<d->end;i++){double v=wc_ipe_eval(d->fn,i);h^=wc_ipe_hash(v,i);}wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}wc_ipe_sched_state^=2u;}total^=h+((uint64_t)rep*0x517cc1b727220a95ull);}return total;case 3:for(uint32_t rep=0;rep<reps;rep++){uint64_t h=0;if(!optimized)wc_ipe_sched_state^=((uint64_t)3u<<48)^rep;if(!optimized){wc_ipe_sched_state^=((uint64_t)1u<<32)^0u;wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}for(uint32_t i=256u;i<512u;i++){double v=wc_ipe_eval(0u,i);h^=wc_ipe_hash(v,i);}if(!optimized){wc_ipe_sched_state^=((uint64_t)2u<<32)^1u;wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}for(uint32_t i=512u;i<768u;i++){double v=wc_ipe_eval(1u,i);h^=wc_ipe_hash(v,i);}if(!optimized){wc_ipe_sched_state^=((uint64_t)0u<<32)^2u;wc_ipe_sched_state+=0x9e3779b97f4a7c15ull;}for(uint32_t i=0u;i<256u;i++){double v=wc_ipe_eval(3u,i);h^=wc_ipe_hash(v,i);}if(!optimized)wc_ipe_sched_state^=2u;total^=h+((uint64_t)rep*0x517cc1b727220a95ull);}return total;default:return 0;}}
#else
uint64_t wc_user_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){(void)id;(void)optimized;(void)reps;return 0;}
#endif
#ifdef WC_ECI_IMPORTS
__attribute__((import_module("webchan_eci"),import_name("dispatch"))) extern uint64_t wc_eci_host_dispatch(uint32_t,uint32_t,uint64_t,uint64_t);
__attribute__((import_module("webchan_eci"),import_name("async_start"))) extern uint64_t wc_eci_host_async_start(uint32_t,uint32_t,uint32_t,uint64_t,uint64_t,uint64_t);
__attribute__((import_module("webchan_eci"),import_name("async_cancel"))) extern uint32_t wc_eci_host_async_cancel(uint64_t);
#endif
uint32_t wc_user_eci_capability_count(void){return 12u;}
uint32_t wc_user_eci_op_count(void){return 12u;}
uint32_t wc_user_eci_capability_effect(uint32_t id){switch(id){case 0:return 2u;case 1:return 2u;case 2:return 1u;case 3:return 1u;case 4:return 1u;case 5:return 2u;case 6:return 2u;case 7:return 0u;case 8:return 2u;case 9:return 1u;case 10:return 1u;case 11:return 0u;default:return 255u;}}
uint32_t wc_user_eci_capability_required(uint32_t id){switch(id){case 0:return 1u;case 1:return 0u;case 2:return 0u;case 3:return 0u;case 4:return 0u;case 5:return 0u;case 6:return 0u;case 7:return 0u;case 8:return 0u;case 9:return 0u;case 10:return 0u;case 11:return 1u;default:return 0u;}}
static uint32_t wc_eci_local_provider_global(uint32_t cap,uint32_t k){switch(cap){case 0:switch(k){case 0:return 0u;case 1:return 1u;case 2:return 2u;default:return 0xffffffffu;}case 1:switch(k){case 0:return 3u;case 1:return 4u;case 2:return 5u;case 3:return 6u;default:return 0xffffffffu;}case 2:switch(k){case 0:return 7u;case 1:return 8u;case 2:return 9u;default:return 0xffffffffu;}case 3:switch(k){case 0:return 10u;case 1:return 11u;case 2:return 12u;default:return 0xffffffffu;}case 4:switch(k){case 0:return 13u;case 1:return 14u;case 2:return 15u;default:return 0xffffffffu;}case 5:switch(k){case 0:return 16u;case 1:return 17u;case 2:return 18u;case 3:return 19u;default:return 0xffffffffu;}case 6:switch(k){case 0:return 20u;default:return 0xffffffffu;}case 7:switch(k){case 0:return 21u;default:return 0xffffffffu;}case 8:switch(k){case 0:return 22u;default:return 0xffffffffu;}case 9:switch(k){case 0:return 23u;case 1:return 24u;case 2:return 25u;default:return 0xffffffffu;}case 10:switch(k){case 0:return 26u;case 1:return 27u;case 2:return 28u;default:return 0xffffffffu;}case 11:switch(k){case 0:return 29u;case 1:return 30u;case 2:return 31u;default:return 0xffffffffu;}default:return 0xffffffffu;}}
uint32_t wc_user_eci_provider_count(uint32_t cap){switch(cap){case 0:return 3u;case 1:return 4u;case 2:return 3u;case 3:return 3u;case 4:return 3u;case 5:return 4u;case 6:return 1u;case 7:return 1u;case 8:return 1u;case 9:return 3u;case 10:return 3u;case 11:return 3u;default:return 0;}}
uint32_t wc_user_eci_provider_global_id(uint32_t cap,uint32_t k){return wc_eci_local_provider_global(cap,k);}
uint32_t wc_user_eci_provider_kind(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){case 0:return 0u;case 1:return 1u;case 2:return 1u;case 3:return 0u;case 4:return 0u;case 5:return 1u;case 6:return 1u;case 7:return 0u;case 8:return 1u;case 9:return 1u;case 10:return 2u;case 11:return 0u;case 12:return 1u;case 13:return 0u;case 14:return 0u;case 15:return 1u;case 16:return 0u;case 17:return 0u;case 18:return 0u;case 19:return 3u;case 20:return 0u;case 21:return 0u;case 22:return 0u;case 23:return 0u;case 24:return 1u;case 25:return 1u;case 26:return 0u;case 27:return 1u;case 28:return 1u;case 29:return 0u;case 30:return 1u;case 31:return 1u;case 32:return 1u;case 33:return 1u;case 34:return 1u;case 35:return 1u;case 36:return 1u;case 37:return 1u;case 38:return 1u;case 39:return 1u;case 40:return 1u;case 41:return 0u;case 42:return 1u;case 43:return 1u;case 44:return 1u;default:return 255u;}}
uint32_t wc_user_eci_provider_hosts(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){case 0:return 3u;case 1:return 8u;case 2:return 4u;case 3:return 1u;case 4:return 2u;case 5:return 8u;case 6:return 4u;case 7:return 3u;case 8:return 8u;case 9:return 4u;case 10:return 3u;case 11:return 3u;case 12:return 12u;case 13:return 3u;case 14:return 3u;case 15:return 12u;case 16:return 1u;case 17:return 1u;case 18:return 1u;case 19:return 3u;case 20:return 3u;case 21:return 3u;case 22:return 3u;case 23:return 1u;case 24:return 2u;case 25:return 4u;case 26:return 1u;case 27:return 2u;case 28:return 4u;case 29:return 1u;case 30:return 4u;case 31:return 8u;case 32:return 4u;case 33:return 4u;case 34:return 4u;case 35:return 4u;case 36:return 4u;case 37:return 4u;case 38:return 4u;case 39:return 4u;case 40:return 4u;case 41:return 1u;case 42:return 2u;case 43:return 4u;case 44:return 8u;default:return 0u;}}
uint32_t wc_user_eci_provider_priority(uint32_t cap,uint32_t k){uint32_t g=wc_eci_local_provider_global(cap,k);switch(g){case 0:return 0u;case 1:return 10u;case 2:return 10u;case 3:return 0u;case 4:return 0u;case 5:return 10u;case 6:return 10u;case 7:return 0u;case 8:return 10u;case 9:return 10u;case 10:return 0u;case 11:return 5u;case 12:return 10u;case 13:return 0u;case 14:return 5u;case 15:return 10u;case 16:return 0u;case 17:return 5u;case 18:return 10u;case 19:return 100u;case 20:return 0u;case 21:return 0u;case 22:return 0u;case 23:return 0u;case 24:return 5u;case 25:return 10u;case 26:return 0u;case 27:return 5u;case 28:return 10u;case 29:return 0u;case 30:return 10u;case 31:return 10u;case 32:return 10u;case 33:return 10u;case 34:return 10u;case 35:return 10u;case 36:return 10u;case 37:return 10u;case 38:return 10u;case 39:return 10u;case 40:return 10u;case 41:return 0u;case 42:return 5u;case 43:return 10u;case 44:return 10u;default:return 0xffffffffu;}}
uint32_t wc_user_eci_select(uint32_t cap,uint32_t host,uint32_t alo,uint32_t ahi){uint32_t n=wc_user_eci_provider_count(cap),best=0xffffffffu,bp=0xffffffffu,bk=0xffffffffu;for(uint32_t k=0;k<n;k++){uint32_t g=wc_user_eci_provider_global_id(cap,k);if(g==0xffffffffu)continue;uint32_t av=g<32?((alo>>g)&1u):((ahi>>(g-32))&1u);if(!av||!(wc_user_eci_provider_hosts(cap,k)&host))continue;uint32_t kind=wc_user_eci_provider_kind(cap,k),pri=wc_user_eci_provider_priority(cap,k);uint32_t authority=(kind==0u?0u:(kind==1u?1u:(kind==2u?2u:3u)));if(authority<bk||(authority==bk&&pri<bp)){bk=authority;bp=pri;best=g;}}return best;}
uint32_t wc_user_eci_op_capability(uint32_t id){switch(id){case 0:return 0u;case 1:return 1u;case 2:return 2u;case 3:return 3u;case 4:return 4u;case 5:return 5u;case 6:return 6u;case 7:return 7u;case 8:return 8u;case 9:return 9u;case 10:return 10u;case 11:return 11u;default:return 0xffffffffu;}}
uint32_t wc_user_eci_op_boundary(uint32_t id){switch(id){case 0:return 2u;case 1:return 2u;case 2:return 1u;case 3:return 1u;case 4:return 1u;case 5:return 2u;case 6:return 2u;case 7:return 0u;case 8:return 2u;case 9:return 1u;case 10:return 1u;case 11:return 0u;default:return 255u;}}
uint32_t wc_user_eci_op_opcode(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;case 3:return 1u;case 4:return 1u;case 5:return 1u;case 6:return 1u;case 7:return 1u;case 8:return 1u;case 9:return 1u;case 10:return 1u;case 11:return 1u;default:return 0u;}}
uint64_t wc_user_eci_call(uint32_t op,uint64_t a0,uint64_t a1){if(op>=12u)return 0xffffffffffffffffull;
#ifdef WC_ECI_IMPORTS
return wc_eci_host_dispatch(op,wc_user_eci_op_opcode(op),a0,a1);
#else
(void)a0;(void)a1;return 0xffffffffffffffffull;
#endif
}
uint64_t wc_user_eci_async_begin(uint32_t op,uint32_t pool,uint64_t tok,uint64_t a0,uint64_t a1){if(op>=12u||wc_user_eci_op_boundary(op)!=1u||wc_user_future_state(pool,tok)!=1u)return 0;
#ifdef WC_ECI_IMPORTS
return wc_eci_host_async_start(op,wc_user_eci_op_opcode(op),pool,tok,a0,a1);
#else
(void)pool;(void)tok;(void)a0;(void)a1;return 0;
#endif
}
uint32_t wc_user_eci_async_cancel(uint64_t req){if(!req)return 0;
#ifdef WC_ECI_IMPORTS
return wc_eci_host_async_cancel(req);
#else
(void)req;return 0;
#endif
}
const int32_t wc_task_ranks[WC_TASK_COUNT]={-8888,-1800,-900,-600,-500,100,300,700,1200,2600,8888};
const uint32_t wc_task_costs[WC_TASK_COUNT]={30000u,66000u,126000u,195000u,255000u,330000u,420000u,480000u,570000u,660000u,750000u};
const double wc_task_deadlines[WC_TASK_COUNT]={4,8,12,16,16,50,33,120,250,1000,1000};
const uint8_t wc_task_classes[WC_TASK_COUNT]={0,1,1,2,2,1,4,4,3,3,4};
const uint8_t wc_task_fn[WC_TASK_COUNT]={3,0,1,3,0,1,2,0,3,1,2};
const uint32_t wc_task_pred_lo[WC_TASK_COUNT]={0u,1u,2u,4u,8u,2u,4u,4u,2u,2u,16u};
const uint32_t wc_task_pred_hi[WC_TASK_COUNT]={0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u};
const uint32_t wc_task_pred_x[WC_TASK_COUNT]={0u,0u,0u,0u,0u,0u,0u,0u,0u,0u,0u};
uint32_t wc_user_topology_count(void){return 3u;}
uint32_t wc_user_topology_vertices(uint32_t id){switch(id){case 0:return 64u;case 1:return 5u;case 2:return 4u;default:return 0;}}
uint32_t wc_user_topology_edges(uint32_t id){switch(id){case 0:return 65u;case 1:return 4u;case 2:return 4u;default:return 0;}}
uint32_t wc_user_topology_beta0(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;default:return 0;}}
uint32_t wc_user_topology_beta1(uint32_t id){switch(id){case 0:return 2u;case 1:return 0u;case 2:return 1u;default:return 0;}}
int32_t wc_user_topology_euler(uint32_t id){switch(id){case 0:return -1;case 1:return 1;case 2:return 0;default:return 0;}}
uint32_t wc_user_topology_proof_bits(uint32_t id){switch(id){case 0:return 9u;case 1:return 15u;case 2:return 9u;default:return 0;}}
uint32_t wc_user_topology_bridges(uint32_t id){switch(id){case 0:return 52u;case 1:return 4u;case 2:return 0u;default:return 0;}}
uint32_t wc_user_topology_articulations(uint32_t id){switch(id){case 0:return 52u;case 1:return 2u;case 2:return 0u;default:return 0;}}
uint32_t wc_user_topology_free_group_rank(uint32_t id){switch(id){case 0:return 2u;case 1:return 0u;case 2:return 1u;default:return 0;}}
uint32_t wc_user_topology_incidence_rank(uint32_t id){switch(id){case 0:return 63u;case 1:return 4u;case 2:return 3u;default:return 0;}}
uint32_t wc_user_topology_laplacian_nullity(uint32_t id){switch(id){case 0:return 1u;case 1:return 1u;case 2:return 1u;default:return 0;}}
uint32_t wc_user_topology_laplacian_proof_bits(uint32_t id){return id<3u?7u:0u;}
uint32_t wc_user_topology_laplacian_linear_bits(uint32_t id){return id<3u?(1u|8u|128u|256u):0u;}
uint32_t wc_user_plan_count(void){return 2u;}
uint32_t wc_user_plan_path_len(uint32_t id){switch(id){case 0:return 10u;case 1:return 3u;default:return 0;}}
uint32_t wc_user_plan_path_vertex(uint32_t id,uint32_t k){switch(id){case 0:switch(k){case 0:return 0u;case 1:return 1u;case 2:return 2u;case 3:return 3u;case 4:return 4u;case 5:return 5u;case 6:return 6u;case 7:return 7u;case 8:return 8u;case 9:return 9u;default:return 0xffffffffu;}case 1:switch(k){case 0:return 0u;case 1:return 2u;case 2:return 3u;default:return 0xffffffffu;}default:return 0xffffffffu;}}
int32_t wc_user_plan_rank(uint32_t id){switch(id){case 0:return 0;case 1:return -5;default:return 0xffffffffu;}}
double wc_user_plan_cost(uint32_t id){switch(id){case 0:return 9;case 1:return 2;default:return 0.0;}}
uint32_t wc_user_plan_full_expansions(uint32_t id){switch(id){case 0:return 59u;case 1:return 3u;default:return 0;}}
uint32_t wc_user_plan_topo_expansions(uint32_t id){switch(id){case 0:return 10u;case 1:return 3u;default:return 0;}}
uint32_t wc_user_plan_pruned_vertices(uint32_t id){switch(id){case 0:return 49u;case 1:return 0u;default:return 0;}}
uint32_t wc_user_plan_homotopy_word_len(uint32_t id){switch(id){case 0:return 0u;case 1:return 1u;default:return 0;}}
int32_t wc_user_plan_homotopy_letter(uint32_t id,uint32_t k){switch(id){case 0:switch(k){default:return 0;}case 1:switch(k){case 0:return 1;default:return 0;}default:return 0;}}
uint64_t wc_user_plan_bench(uint32_t id,uint32_t pruned,uint32_t reps){switch(id){case 0:return wc_plan_rt(wc_topo_0,65u,64u,0u,9u,pruned?wc_plan_active_0:(const uint8_t*)0,reps);case 1:return wc_plan_rt(wc_topo_2,4u,4u,0u,3u,pruned?wc_plan_active_1:(const uint8_t*)0,reps);default:return 0;}}
uint32_t wc_user_complex_count(void){return 3u;}
uint32_t wc_user_complex_beta(uint32_t id,uint32_t dim){switch(id){case 0:return dim==0?1u:(dim==1?0u:(dim==2?0u:0u));case 1:return dim==0?1u:(dim==1?1u:(dim==2?0u:0u));case 2:return dim==0?1u:(dim==1?0u:(dim==2?1u:0u));default:return 0;}}
int32_t wc_user_complex_euler(uint32_t id){switch(id){case 0:return 1;case 1:return 0;case 2:return 2;default:return 0;}}
uint32_t wc_user_complex_proof_bits(uint32_t id){switch(id){case 0:return 15u;case 1:return 9u;case 2:return 9u;default:return 0;}}
uint32_t wc_user_complex_collapse_steps(uint32_t id){switch(id){case 0:return 3u;case 1:return 0u;case 2:return 0u;default:return 0;}}
