#version 400 core
// Generated from Webchan IR. Generic compact field helpers; no trusted source assertions.
// field vertex_x requires materialized host storage under the selected budget.
// field vertex_y requires materialized host storage under the selected budget.
// field expensive_field requires materialized host storage under the selected budget.
// piecewise field discontinuous_profile requires materialized host storage under selected budget.
