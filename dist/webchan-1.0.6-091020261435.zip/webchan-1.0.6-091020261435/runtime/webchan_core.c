#include <stdint.h>
#include "webchan_program.h"
#define WC_EXPORT(name) __attribute__((export_name(name)))
#define WC_STATUS_BLOCKED 0u
#define WC_STATUS_READY 1u
#define WC_STATUS_DONE 2u
static uint32_t wc_status[WC_TASK_COUNT],wc_progress[WC_TASK_COUNT],wc_done_count_v,wc_seed_v,wc_last_invalidated_v;static double wc_accum_v,wc_task_accum[WC_TASK_COUNT];
static uint8_t wc_deferred_dirty[WC_TASK_COUNT];static uint32_t wc_deferred_dirty_count_v;
static int pred_done(uint32_t task){uint32_t lo=wc_task_pred_lo[task],hi=wc_task_pred_hi[task],xx=wc_task_pred_x[task];for(uint32_t i=0;i<WC_TASK_COUNT;i++){uint32_t bit=i<32?((lo>>i)&1u):(i<64?((hi>>(i-32))&1u):((xx>>(i-64))&1u));if(bit&&wc_status[i]!=WC_STATUS_DONE)return 0;}return 1;}
static void refresh_ready(void){for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(wc_status[i]==WC_STATUS_BLOCKED&&pred_done(i))wc_status[i]=WC_STATUS_READY;}
static int better(uint32_t a,uint32_t b){if(wc_task_classes[a]!=wc_task_classes[b])return wc_task_classes[a]<wc_task_classes[b];if(wc_task_deadlines[a]!=wc_task_deadlines[b])return wc_task_deadlines[a]<wc_task_deadlines[b];if(wc_task_ranks[a]!=wc_task_ranks[b])return wc_task_ranks[a]<wc_task_ranks[b];return a<b;}
static int pick_ready(void){int best=-1;for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(wc_status[i]==WC_STATUS_READY&&(best<0||better(i,(uint32_t)best)))best=(int)i;return best;}
WC_EXPORT("wc_reset") void wc_reset(uint32_t seed){wc_seed_v=seed?seed:1u;wc_accum_v=0.0;wc_done_count_v=0;wc_last_invalidated_v=0;wc_deferred_dirty_count_v=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++){wc_deferred_dirty[i]=0;wc_status[i]=WC_STATUS_BLOCKED;wc_progress[i]=0;wc_task_accum[i]=0.0;}refresh_ready();}
static int direct_dep(uint32_t child,uint32_t parent){if(child>=WC_TASK_COUNT||parent>=WC_TASK_COUNT)return 0;if(parent<32)return (wc_task_pred_lo[child]>>parent)&1u;if(parent<64)return (wc_task_pred_hi[child]>>(parent-32))&1u;return (wc_task_pred_x[child]>>(parent-64))&1u;}
WC_EXPORT("wc_invalidate") uint32_t wc_invalidate(uint32_t root){if(root>=WC_TASK_COUNT)return 0;uint8_t mark[WC_TASK_COUNT];for(uint32_t i=0;i<WC_TASK_COUNT;i++)mark[i]=0;mark[root]=1;for(uint32_t pass=0;pass<WC_TASK_COUNT;pass++){int changed=0;for(uint32_t c=0;c<WC_TASK_COUNT;c++)if(!mark[c])for(uint32_t p=0;p<WC_TASK_COUNT;p++)if(mark[p]&&direct_dep(c,p)){mark[c]=1;changed=1;break;}if(!changed)break;}uint32_t n=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(mark[i]){n++;if(wc_status[i]==WC_STATUS_DONE&&wc_done_count_v)wc_done_count_v--;wc_accum_v-=wc_task_accum[i];wc_task_accum[i]=0.0;wc_progress[i]=0;wc_status[i]=WC_STATUS_BLOCKED;}wc_last_invalidated_v=n;refresh_ready();return n;}
WC_EXPORT("wc_last_invalidated_count") uint32_t wc_last_invalidated_count(void){return wc_last_invalidated_v;}
/* Deferred repair: repeated invalidations are coalesced before any completed
   state is discarded. This turns the 1.0.5 contract word into executable state. */
WC_EXPORT("wc_defer_invalidate") uint32_t wc_defer_invalidate(uint32_t root){if(root>=WC_TASK_COUNT)return 0;uint8_t mark[WC_TASK_COUNT];for(uint32_t i=0;i<WC_TASK_COUNT;i++)mark[i]=0;mark[root]=1;for(uint32_t pass=0;pass<WC_TASK_COUNT;pass++){int changed=0;for(uint32_t c=0;c<WC_TASK_COUNT;c++)if(!mark[c])for(uint32_t p=0;p<WC_TASK_COUNT;p++)if(mark[p]&&direct_dep(c,p)){mark[c]=1;changed=1;break;}if(!changed)break;}uint32_t added=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(mark[i]&&!wc_deferred_dirty[i]){wc_deferred_dirty[i]=1;wc_deferred_dirty_count_v++;added++;}return added;}
WC_EXPORT("wc_deferred_dirty_count") uint32_t wc_deferred_dirty_count(void){return wc_deferred_dirty_count_v;}
WC_EXPORT("wc_apply_deferred_repairs") uint32_t wc_apply_deferred_repairs(void){uint32_t n=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++)if(wc_deferred_dirty[i]){wc_deferred_dirty[i]=0;n++;if(wc_status[i]==WC_STATUS_DONE&&wc_done_count_v)wc_done_count_v--;wc_accum_v-=wc_task_accum[i];wc_task_accum[i]=0.0;wc_progress[i]=0;wc_status[i]=WC_STATUS_BLOCKED;}wc_deferred_dirty_count_v=0;wc_last_invalidated_v=n;refresh_ready();return n;}
WC_EXPORT("wc_remaining_work") uint64_t wc_remaining_work(void){uint64_t r=0;for(uint32_t i=0;i<WC_TASK_COUNT;i++)r+=(uint64_t)(wc_task_costs[i]-wc_progress[i]);return r;}
static uint32_t step_internal(uint32_t budget,double t,int clamp){if(clamp&&budget>WC_MAX_STEP_UNITS)budget=WC_MAX_STEP_UNITS;if(!budget)budget=1;uint32_t used=0;while(used<budget&&wc_done_count_v<WC_TASK_COUNT){refresh_ready();int p=pick_ready();if(p<0)break;uint32_t task=(uint32_t)p,left=wc_task_costs[task]-wc_progress[task],n=budget-used;if(n>left)n=left;uint32_t start=wc_progress[task];double local=0.0;for(uint32_t j=0;j<n;j++){uint32_t idx=start+j;double x=(double)(idx+1u)/(double)(wc_task_costs[task]+1u)+(double)(wc_seed_v&255u)*0.000001;local+=wc_user_call(wc_task_fn[task],x,t,idx,task);}wc_accum_v+=local;wc_task_accum[task]+=local;wc_progress[task]+=n;used+=n;if(wc_progress[task]>=wc_task_costs[task]){wc_status[task]=WC_STATUS_DONE;wc_done_count_v++;refresh_ready();}}return used;}
WC_EXPORT("wc_step") uint32_t wc_step(uint32_t budget,double t){return step_internal(budget,t,1);}WC_EXPORT("wc_done") uint32_t wc_done(void){return wc_done_count_v==WC_TASK_COUNT;}WC_EXPORT("wc_done_count") uint32_t wc_done_count(void){return wc_done_count_v;}WC_EXPORT("wc_task_count") uint32_t wc_task_count(void){return WC_TASK_COUNT;}WC_EXPORT("wc_task_status") uint32_t wc_task_status(uint32_t i){return i<WC_TASK_COUNT?wc_status[i]:255u;}WC_EXPORT("wc_task_progress") uint32_t wc_task_progress(uint32_t i){return i<WC_TASK_COUNT?wc_progress[i]:0u;}WC_EXPORT("wc_task_cost") uint32_t wc_task_cost_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_costs[i]:0u;}WC_EXPORT("wc_task_rank") int32_t wc_task_rank_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_ranks[i]:2147483647;}WC_EXPORT("wc_task_class") uint32_t wc_task_class_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_classes[i]:255u;}WC_EXPORT("wc_task_fn") uint32_t wc_task_fn_export(uint32_t i){return i<WC_TASK_COUNT?wc_task_fn[i]:255u;}WC_EXPORT("wc_fn_bound") uint32_t wc_fn_bound_export(uint32_t i){return wc_user_fn_bound(i);}WC_EXPORT("wc_eval_fn") double wc_eval_fn(uint32_t id,double x,double t,uint32_t i,uint32_t task){return wc_user_call((uint8_t)id,x,t,i,task);}WC_EXPORT("wc_eval_fn_reference") double wc_eval_fn_reference(uint32_t id,double x,double t,uint32_t i,uint32_t task){return wc_user_call_reference((uint8_t)id,x,t,i,task);}WC_EXPORT("wc_fn_structural_bits") uint32_t wc_fn_structural_bits(uint32_t id){return wc_user_fn_structural_bits(id);}WC_EXPORT("wc_fn_original_ops") uint64_t wc_fn_original_ops(uint32_t id){return wc_user_fn_original_ops(id);}WC_EXPORT("wc_fn_collapsed_ops") uint64_t wc_fn_collapsed_ops(uint32_t id){return wc_user_fn_collapsed_ops(id);}WC_EXPORT("wc_accumulator") double wc_accumulator(void){return wc_accum_v;}WC_EXPORT("wc_max_step_units") uint32_t wc_max_step_units(void){return WC_MAX_STEP_UNITS;}WC_EXPORT("wc_default_step_units") uint32_t wc_default_step_units(void){return WC_DEFAULT_STEP_UNITS;}WC_EXPORT("wc_active_set_cap") uint32_t wc_active_set_cap(void){return WC_ACTIVE_SET_CAP;}WC_EXPORT("wc_version") uint32_t wc_version(void){return ((WC_VERSION_MAJOR&0xffu)<<16)|((WC_VERSION_MINOR&0xffu)<<8)|(WC_VERSION_PATCH&0xffu);}WC_EXPORT("wc_contract_bits") uint32_t wc_contract_bits(void){return 0x00ffffffu;}
WC_EXPORT("wc_array_count") uint32_t wc_array_count(void){return wc_user_array_count();}WC_EXPORT("wc_array_len") uint32_t wc_array_len(uint32_t id){return wc_user_array_len(id);}WC_EXPORT("wc_array_type") uint32_t wc_array_type(uint32_t id){return wc_user_array_type(id);}WC_EXPORT("wc_array_layout_kind") uint32_t wc_array_layout_kind(uint32_t id){return wc_user_array_layout_kind(id);}WC_EXPORT("wc_array_layout_group") uint32_t wc_array_layout_group(uint32_t id){return wc_user_array_layout_group(id);}WC_EXPORT("wc_array_layout_lane") uint32_t wc_array_layout_lane(uint32_t id){return wc_user_array_layout_lane(id);}WC_EXPORT("wc_array_layout_lanes") uint32_t wc_array_layout_lanes(uint32_t id){return wc_user_array_layout_lanes(id);}WC_EXPORT("wc_array_layout_tile") uint32_t wc_array_layout_tile(uint32_t id){return wc_user_array_layout_tile(id);}WC_EXPORT("wc_array_layout_score") uint32_t wc_array_layout_score(uint32_t id){return wc_user_array_layout_score(id);}WC_EXPORT("wc_array_layout_profit") int32_t wc_array_layout_profit(uint32_t id){return wc_user_array_layout_profit(id);}WC_EXPORT("wc_array_layout_phase_coverage") uint32_t wc_array_layout_phase_coverage(uint32_t id){return wc_user_array_layout_phase_coverage(id);}WC_EXPORT("wc_array_layout_stream_ratio") uint32_t wc_array_layout_stream_ratio(uint32_t id){return wc_user_array_layout_stream_ratio(id);}WC_EXPORT("wc_array_layout_reason_bits") uint32_t wc_array_layout_reason_bits(uint32_t id){return wc_user_array_layout_reason_bits(id);}WC_EXPORT("wc_array_logical_bytes") uint64_t wc_array_logical_bytes(uint32_t id){return wc_user_array_logical_bytes(id);}WC_EXPORT("wc_array_physical_share_bytes") uint64_t wc_array_physical_share_bytes(uint32_t id){return wc_user_array_physical_share_bytes(id);}WC_EXPORT("wc_array_get") double wc_array_get(uint32_t id,uint32_t idx){return wc_user_array_get(id,idx);}WC_EXPORT("wc_array_set") void wc_array_set(uint32_t id,uint32_t idx,double v){wc_user_array_set(id,idx,v);}WC_EXPORT("wc_array_get_bits") uint64_t wc_array_get_bits(uint32_t id,uint32_t idx){return wc_user_array_get_bits(id,idx);}WC_EXPORT("wc_array_set_bits") void wc_array_set_bits(uint32_t id,uint32_t idx,uint64_t v){wc_user_array_set_bits(id,idx,v);}

/* Webchan 1.0.4 retains the 1.0.1 General Application Semantics ABI and adds target-profile selection outside language semantics. These are direct exports of
   compiler-generated bounded storage/state operations; no JavaScript data model is hidden here. */
WC_EXPORT("wc_application_contract_bits") uint32_t wc_application_contract_bits(void){return 0x000001ffu;}
WC_EXPORT("wc_region_count") uint32_t wc_region_count(void){return wc_user_region_count();}
WC_EXPORT("wc_region_capacity") uint32_t wc_region_capacity(uint32_t id){return wc_user_region_capacity(id);}
WC_EXPORT("wc_region_used") uint32_t wc_region_used(uint32_t id){return wc_user_region_used(id);}
WC_EXPORT("wc_region_reset") void wc_region_reset(uint32_t id){wc_user_region_reset(id);}
WC_EXPORT("wc_region_alloc") uint32_t wc_region_alloc(uint32_t id,uint32_t n,uint32_t a){return wc_user_region_alloc(id,n,a);}
WC_EXPORT("wc_region_read8") uint32_t wc_region_read8(uint32_t id,uint32_t o){return wc_user_region_read8(id,o);}
WC_EXPORT("wc_region_write8") uint32_t wc_region_write8(uint32_t id,uint32_t o,uint32_t v){return wc_user_region_write8(id,o,v);}
WC_EXPORT("wc_region_ptr") uint64_t wc_region_ptr(uint32_t id){return wc_user_region_ptr(id);}

WC_EXPORT("wc_text_count") uint32_t wc_text_count(void){return wc_user_text_count();}
WC_EXPORT("wc_text_capacity") uint32_t wc_text_capacity(uint32_t id){return wc_user_text_capacity(id);}
WC_EXPORT("wc_text_len") uint32_t wc_text_len(uint32_t id){return wc_user_text_len(id);}
WC_EXPORT("wc_text_clear") void wc_text_clear(uint32_t id){wc_user_text_clear(id);}
WC_EXPORT("wc_text_resize") uint32_t wc_text_resize(uint32_t id,uint32_t n){return wc_user_text_resize(id,n);}
WC_EXPORT("wc_text_get") uint32_t wc_text_get(uint32_t id,uint32_t o){return wc_user_text_get(id,o);}
WC_EXPORT("wc_text_set") uint32_t wc_text_set(uint32_t id,uint32_t o,uint32_t v){return wc_user_text_set(id,o,v);}
WC_EXPORT("wc_text_append_byte") uint32_t wc_text_append_byte(uint32_t id,uint32_t v){return wc_user_text_append_byte(id,v);}
WC_EXPORT("wc_text_append_text") uint32_t wc_text_append_text(uint32_t d,uint32_t s){return wc_user_text_append_text(d,s);}
WC_EXPORT("wc_text_utf8_valid") uint32_t wc_text_utf8_valid(uint32_t id){return wc_user_text_utf8_valid(id);}
WC_EXPORT("wc_text_find_byte") int32_t wc_text_find_byte(uint32_t id,uint32_t start,uint32_t b){return wc_user_text_find_byte(id,start,b);}
WC_EXPORT("wc_text_ptr") uint64_t wc_text_ptr(uint32_t id){return wc_user_text_ptr(id);}
WC_EXPORT("wc_text_write_u32_le") uint32_t wc_text_write_u32_le(uint32_t id,uint32_t o,uint32_t v){return wc_user_text_write_u32_le(id,o,v);}
WC_EXPORT("wc_text_read_u32_le") uint32_t wc_text_read_u32_le(uint32_t id,uint32_t o,uint32_t*out){return wc_user_text_read_u32_le(id,o,out);}
WC_EXPORT("wc_text_write_f64_le") uint32_t wc_text_write_f64_le(uint32_t id,uint32_t o,double v){return wc_user_text_write_f64_le(id,o,v);}
WC_EXPORT("wc_text_read_f64_le") uint32_t wc_text_read_f64_le(uint32_t id,uint32_t o,double*out){return wc_user_text_read_f64_le(id,o,out);}

WC_EXPORT("wc_vector_count") uint32_t wc_vector_count(void){return wc_user_vector_count();}
WC_EXPORT("wc_vector_capacity") uint32_t wc_vector_capacity(uint32_t id){return wc_user_vector_capacity(id);}
WC_EXPORT("wc_vector_len") uint32_t wc_vector_len(uint32_t id){return wc_user_vector_len(id);}
WC_EXPORT("wc_vector_type") uint32_t wc_vector_type(uint32_t id){return wc_user_vector_type(id);}
WC_EXPORT("wc_vector_clear") void wc_vector_clear(uint32_t id){wc_user_vector_clear(id);}
WC_EXPORT("wc_vector_push") uint32_t wc_vector_push(uint32_t id,double v){return wc_user_vector_push(id,v);}
WC_EXPORT("wc_vector_pop") uint32_t wc_vector_pop(uint32_t id,double*out){return wc_user_vector_pop(id,out);}
WC_EXPORT("wc_vector_set") uint32_t wc_vector_set(uint32_t id,uint32_t i,double v){return wc_user_vector_set(id,i,v);}
WC_EXPORT("wc_vector_get") double wc_vector_get(uint32_t id,uint32_t i){return wc_user_vector_get(id,i);}
WC_EXPORT("wc_vector_push_bits") uint32_t wc_vector_push_bits(uint32_t id,uint64_t v){return wc_user_vector_push_bits(id,v);}
WC_EXPORT("wc_vector_pop_bits") uint32_t wc_vector_pop_bits(uint32_t id,uint64_t*out){return wc_user_vector_pop_bits(id,out);}
WC_EXPORT("wc_vector_set_bits") uint32_t wc_vector_set_bits(uint32_t id,uint32_t i,uint64_t v){return wc_user_vector_set_bits(id,i,v);}
WC_EXPORT("wc_vector_get_bits") uint64_t wc_vector_get_bits(uint32_t id,uint32_t i){return wc_user_vector_get_bits(id,i);}

WC_EXPORT("wc_map_count") uint32_t wc_map_count(void){return wc_user_map_count();}
WC_EXPORT("wc_map_capacity") uint32_t wc_map_capacity(uint32_t id){return wc_user_map_capacity(id);}
WC_EXPORT("wc_map_size") uint32_t wc_map_size(uint32_t id){return wc_user_map_size(id);}
WC_EXPORT("wc_map_key_type") uint32_t wc_map_key_type(uint32_t id){return wc_user_map_key_type(id);}
WC_EXPORT("wc_map_value_type") uint32_t wc_map_value_type(uint32_t id){return wc_user_map_value_type(id);}
WC_EXPORT("wc_map_clear") void wc_map_clear(uint32_t id){wc_user_map_clear(id);}
WC_EXPORT("wc_map_put") uint32_t wc_map_put(uint32_t id,double k,double v){return wc_user_map_put(id,k,v);}
WC_EXPORT("wc_map_get") uint32_t wc_map_get(uint32_t id,double k,double*out){return wc_user_map_get(id,k,out);}
WC_EXPORT("wc_map_remove") uint32_t wc_map_remove(uint32_t id,double k){return wc_user_map_remove(id,k);}
WC_EXPORT("wc_map_put_bits") uint32_t wc_map_put_bits(uint32_t id,uint64_t k,uint64_t v){return wc_user_map_put_bits(id,k,v);}
WC_EXPORT("wc_map_get_bits") uint32_t wc_map_get_bits(uint32_t id,uint64_t k,uint64_t*out){return wc_user_map_get_bits(id,k,out);}
WC_EXPORT("wc_map_remove_bits") uint32_t wc_map_remove_bits(uint32_t id,uint64_t k){return wc_user_map_remove_bits(id,k);}

WC_EXPORT("wc_result_count") uint32_t wc_result_count(void){return wc_user_result_count();}
WC_EXPORT("wc_result_ok_type") uint32_t wc_result_ok_type(uint32_t id){return wc_user_result_ok_type(id);}
WC_EXPORT("wc_result_err_type") uint32_t wc_result_err_type(uint32_t id){return wc_user_result_err_type(id);}
WC_EXPORT("wc_result_tag") uint32_t wc_result_tag(uint32_t id){return wc_user_result_tag(id);}
WC_EXPORT("wc_result_clear") void wc_result_clear(uint32_t id){wc_user_result_clear(id);}
WC_EXPORT("wc_result_set_ok") void wc_result_set_ok(uint32_t id,double v){wc_user_result_set_ok(id,v);}
WC_EXPORT("wc_result_set_err") void wc_result_set_err(uint32_t id,double v){wc_user_result_set_err(id,v);}
WC_EXPORT("wc_result_value") double wc_result_value(uint32_t id){return wc_user_result_value(id);}
WC_EXPORT("wc_result_set_ok_bits") void wc_result_set_ok_bits(uint32_t id,uint64_t v){wc_user_result_set_ok_bits(id,v);}
WC_EXPORT("wc_result_set_err_bits") void wc_result_set_err_bits(uint32_t id,uint64_t v){wc_user_result_set_err_bits(id,v);}
WC_EXPORT("wc_result_value_bits") uint64_t wc_result_value_bits(uint32_t id){return wc_user_result_value_bits(id);}

WC_EXPORT("wc_future_pool_count") uint32_t wc_future_pool_count(void){return wc_user_future_pool_count();}
WC_EXPORT("wc_future_capacity") uint32_t wc_future_capacity(uint32_t id){return wc_user_future_capacity(id);}
WC_EXPORT("wc_future_value_type") uint32_t wc_future_value_type(uint32_t id){return wc_user_future_value_type(id);}
WC_EXPORT("wc_future_error_type") uint32_t wc_future_error_type(uint32_t id){return wc_user_future_error_type(id);}
WC_EXPORT("wc_future_create") uint64_t wc_future_create(uint32_t id){return wc_user_future_create(id);}
WC_EXPORT("wc_future_state") uint32_t wc_future_state(uint32_t id,uint64_t t){return wc_user_future_state(id,t);}
WC_EXPORT("wc_future_resolve") uint32_t wc_future_resolve(uint32_t id,uint64_t t,double v){return wc_user_future_resolve(id,t,v);}
WC_EXPORT("wc_future_fail") uint32_t wc_future_fail(uint32_t id,uint64_t t,double v){return wc_user_future_fail(id,t,v);}
WC_EXPORT("wc_future_cancel") uint32_t wc_future_cancel(uint32_t id,uint64_t t){return wc_user_future_cancel(id,t);}
WC_EXPORT("wc_future_release") uint32_t wc_future_release(uint32_t id,uint64_t t){return wc_user_future_release(id,t);}
WC_EXPORT("wc_future_value") double wc_future_value(uint32_t id,uint64_t t){return wc_user_future_value(id,t);}
WC_EXPORT("wc_future_error") double wc_future_error(uint32_t id,uint64_t t){return wc_user_future_error(id,t);}
WC_EXPORT("wc_future_resolve_bits") uint32_t wc_future_resolve_bits(uint32_t id,uint64_t t,uint64_t v){return wc_user_future_resolve_bits(id,t,v);}
WC_EXPORT("wc_future_fail_bits") uint32_t wc_future_fail_bits(uint32_t id,uint64_t t,uint64_t v){return wc_user_future_fail_bits(id,t,v);}
WC_EXPORT("wc_future_value_bits") uint64_t wc_future_value_bits(uint32_t id,uint64_t t){return wc_user_future_value_bits(id,t);}
WC_EXPORT("wc_future_error_bits") uint64_t wc_future_error_bits(uint32_t id,uint64_t t){return wc_user_future_error_bits(id,t);}

WC_EXPORT("wc_handle_pool_count") uint32_t wc_handle_pool_count(void){return wc_user_handle_pool_count();}
WC_EXPORT("wc_handle_capacity") uint32_t wc_handle_capacity(uint32_t id){return wc_user_handle_capacity(id);}
WC_EXPORT("wc_handle_capability") uint32_t wc_handle_capability(uint32_t id){return wc_user_handle_capability(id);}
WC_EXPORT("wc_handle_acquire") uint64_t wc_handle_acquire(uint32_t id,uint64_t raw){return wc_user_handle_acquire(id,raw);}
WC_EXPORT("wc_handle_value") uint64_t wc_handle_value(uint32_t id,uint64_t t){return wc_user_handle_value(id,t);}
WC_EXPORT("wc_handle_release") uint32_t wc_handle_release(uint32_t id,uint64_t t){return wc_user_handle_release(id,t);}

WC_EXPORT("wc_state_machine_count") uint32_t wc_state_machine_count(void){return wc_user_state_machine_count();}
WC_EXPORT("wc_state_machine_states") uint32_t wc_state_machine_states(uint32_t id){return wc_user_state_machine_states(id);}
WC_EXPORT("wc_state_machine_events") uint32_t wc_state_machine_events(uint32_t id){return wc_user_state_machine_events(id);}
WC_EXPORT("wc_state_machine_state") uint32_t wc_state_machine_state(uint32_t id){return wc_user_state_machine_state(id);}
WC_EXPORT("wc_state_machine_reset") void wc_state_machine_reset(uint32_t id){wc_user_state_machine_reset(id);}
WC_EXPORT("wc_state_machine_dispatch") uint32_t wc_state_machine_dispatch(uint32_t id,uint32_t ev){return wc_user_state_machine_dispatch(id,ev);}

#ifdef WC_BENCHMARK_UNSAFE
WC_EXPORT("wc_benchmark_blocking_all") double wc_benchmark_blocking_all(uint32_t seed,double t){wc_reset(seed);while(!wc_done())step_internal(0xffffffffu,t,0);return wc_accum_v;}
#endif

WC_EXPORT("wc_bench_fn_chain") double wc_bench_fn_chain(uint32_t id,uint32_t reference,uint32_t reps){double v=0.125;for(uint32_t r=0;r<reps;r++){if(reference)v=wc_user_call_reference((uint8_t)id,v,0.375,r&255u,3u);else v=wc_user_call((uint8_t)id,v,0.375,r&255u,3u);}return v;}
WC_EXPORT("wc_solve_count") uint32_t wc_solve_count(void){return wc_user_solve_count();}
WC_EXPORT("wc_solve") uint32_t wc_solve(uint32_t sid,uint32_t method){return wc_user_solve(sid,method);}
WC_EXPORT("wc_solve_residual") double wc_solve_residual(uint32_t sid){return wc_user_solve_residual(sid);}
WC_EXPORT("wc_solve_proof_bits") uint32_t wc_solve_proof_bits(uint32_t sid){return wc_user_solve_proof_bits(sid);}
WC_EXPORT("wc_solve_chosen") uint32_t wc_solve_chosen(uint32_t sid){return wc_user_solve_chosen(sid);}
WC_EXPORT("wc_solve_estimated") uint64_t wc_solve_estimated(uint32_t sid,uint32_t method){return wc_user_solve_estimated(sid,method);}
WC_EXPORT("wc_memory_mode") uint32_t wc_memory_mode(void){return wc_user_memory_mode();}
WC_EXPORT("wc_memory_init") void wc_memory_init(void){wc_user_memory_init();}
WC_EXPORT("wc_field_count") uint32_t wc_field_count(void){return wc_user_field_count();}
WC_EXPORT("wc_field_len") uint32_t wc_field_len(uint32_t id){return wc_user_field_len(id);}
WC_EXPORT("wc_field_repr") uint32_t wc_field_repr(uint32_t id){return wc_user_field_repr(id);}
WC_EXPORT("wc_field_proof_bits") uint32_t wc_field_proof_bits(uint32_t id){return wc_user_field_proof_bits(id);}
WC_EXPORT("wc_field_reconstruct_ops") uint32_t wc_field_reconstruct_ops(uint32_t id){return wc_user_field_reconstruct_ops(id);}
WC_EXPORT("wc_field_logical_bytes") uint64_t wc_field_logical_bytes(uint32_t id){return wc_user_field_logical_bytes(id);}
WC_EXPORT("wc_field_stored_bytes") uint64_t wc_field_stored_bytes(uint32_t id){return wc_user_field_stored_bytes(id);}
WC_EXPORT("wc_field_saved_bytes") uint64_t wc_field_saved_bytes(uint32_t id){return wc_user_field_saved_bytes(id);}
WC_EXPORT("wc_field_get") double wc_field_get(uint32_t id,uint32_t idx){return wc_user_field_get(id,idx);}
WC_EXPORT("wc_field_checksum") double wc_field_checksum(uint32_t id,uint32_t stride){return wc_user_field_checksum(id,stride);}
WC_EXPORT("wc_field_materialize") uint32_t wc_field_materialize(uint32_t id,uint32_t start,uint32_t count){return wc_user_field_materialize(id,start,count);}
WC_EXPORT("wc_field_scratch_get") double wc_field_scratch_get(uint32_t i){return wc_user_field_scratch_get(i);}

WC_EXPORT("wc_field_pair_checksum") double wc_field_pair_checksum(uint32_t a,uint32_t b,uint32_t count){return wc_user_field_pair_checksum(a,b,count);}

WC_EXPORT("wc_piecewise_field_count") uint32_t wc_piecewise_field_count(void){return wc_user_pwfield_count();}
WC_EXPORT("wc_piecewise_field_len") uint32_t wc_piecewise_field_len(uint32_t id){return wc_user_pwfield_len(id);}
WC_EXPORT("wc_piecewise_field_repr") uint32_t wc_piecewise_field_repr(uint32_t id){return wc_user_pwfield_repr(id);}
WC_EXPORT("wc_piecewise_field_segments") uint32_t wc_piecewise_field_segments(uint32_t id){return wc_user_pwfield_segments(id);}
WC_EXPORT("wc_piecewise_field_logical_bytes") uint64_t wc_piecewise_field_logical_bytes(uint32_t id){return wc_user_pwfield_logical_bytes(id);}
WC_EXPORT("wc_piecewise_field_stored_bytes") uint64_t wc_piecewise_field_stored_bytes(uint32_t id){return wc_user_pwfield_stored_bytes(id);}
WC_EXPORT("wc_piecewise_field_saved_bytes") uint64_t wc_piecewise_field_saved_bytes(uint32_t id){return wc_user_pwfield_saved_bytes(id);}
WC_EXPORT("wc_piecewise_field_get") double wc_piecewise_field_get(uint32_t id,uint32_t i){return wc_user_pwfield_get(id,i);}
WC_EXPORT("wc_piecewise_field_checksum") double wc_piecewise_field_checksum(uint32_t id,uint32_t stride){return wc_user_pwfield_checksum(id,stride);}


WC_EXPORT("wc_topology_count") uint32_t wc_topology_count(void){return wc_user_topology_count();}
WC_EXPORT("wc_topology_vertices") uint32_t wc_topology_vertices(uint32_t id){return wc_user_topology_vertices(id);}
WC_EXPORT("wc_topology_edges") uint32_t wc_topology_edges(uint32_t id){return wc_user_topology_edges(id);}
WC_EXPORT("wc_topology_beta0") uint32_t wc_topology_beta0(uint32_t id){return wc_user_topology_beta0(id);}
WC_EXPORT("wc_topology_beta1") uint32_t wc_topology_beta1(uint32_t id){return wc_user_topology_beta1(id);}
WC_EXPORT("wc_topology_euler") int32_t wc_topology_euler(uint32_t id){return wc_user_topology_euler(id);}
WC_EXPORT("wc_topology_proof_bits") uint32_t wc_topology_proof_bits(uint32_t id){return wc_user_topology_proof_bits(id);}
WC_EXPORT("wc_topology_bridges") uint32_t wc_topology_bridges(uint32_t id){return wc_user_topology_bridges(id);}
WC_EXPORT("wc_topology_articulations") uint32_t wc_topology_articulations(uint32_t id){return wc_user_topology_articulations(id);}
WC_EXPORT("wc_topology_free_group_rank") uint32_t wc_topology_free_group_rank(uint32_t id){return wc_user_topology_free_group_rank(id);}
WC_EXPORT("wc_topology_incidence_rank") uint32_t wc_topology_incidence_rank(uint32_t id){return wc_user_topology_incidence_rank(id);}
WC_EXPORT("wc_topology_laplacian_nullity") uint32_t wc_topology_laplacian_nullity(uint32_t id){return wc_user_topology_laplacian_nullity(id);}
WC_EXPORT("wc_topology_laplacian_proof_bits") uint32_t wc_topology_laplacian_proof_bits(uint32_t id){return wc_user_topology_laplacian_proof_bits(id);}
WC_EXPORT("wc_topology_laplacian_linear_bits") uint32_t wc_topology_laplacian_linear_bits(uint32_t id){return wc_user_topology_laplacian_linear_bits(id);}
WC_EXPORT("wc_plan_count") uint32_t wc_plan_count(void){return wc_user_plan_count();}
WC_EXPORT("wc_plan_path_len") uint32_t wc_plan_path_len(uint32_t id){return wc_user_plan_path_len(id);}
WC_EXPORT("wc_plan_path_vertex") uint32_t wc_plan_path_vertex(uint32_t id,uint32_t k){return wc_user_plan_path_vertex(id,k);}
WC_EXPORT("wc_plan_rank") int32_t wc_plan_rank(uint32_t id){return wc_user_plan_rank(id);}
WC_EXPORT("wc_plan_cost") double wc_plan_cost(uint32_t id){return wc_user_plan_cost(id);}
WC_EXPORT("wc_plan_full_expansions") uint32_t wc_plan_full_expansions(uint32_t id){return wc_user_plan_full_expansions(id);}
WC_EXPORT("wc_plan_topo_expansions") uint32_t wc_plan_topo_expansions(uint32_t id){return wc_user_plan_topo_expansions(id);}
WC_EXPORT("wc_plan_pruned_vertices") uint32_t wc_plan_pruned_vertices(uint32_t id){return wc_user_plan_pruned_vertices(id);}
WC_EXPORT("wc_plan_homotopy_word_len") uint32_t wc_plan_homotopy_word_len(uint32_t id){return wc_user_plan_homotopy_word_len(id);}
WC_EXPORT("wc_plan_homotopy_letter") int32_t wc_plan_homotopy_letter(uint32_t id,uint32_t k){return wc_user_plan_homotopy_letter(id,k);}
WC_EXPORT("wc_plan_bench") uint64_t wc_plan_bench(uint32_t id,uint32_t pruned,uint32_t reps){return wc_user_plan_bench(id,pruned,reps);}
WC_EXPORT("wc_complex_count") uint32_t wc_complex_count(void){return wc_user_complex_count();}
WC_EXPORT("wc_complex_beta") uint32_t wc_complex_beta(uint32_t id,uint32_t dim){return wc_user_complex_beta(id,dim);}
WC_EXPORT("wc_complex_euler") int32_t wc_complex_euler(uint32_t id){return wc_user_complex_euler(id);}
WC_EXPORT("wc_complex_proof_bits") uint32_t wc_complex_proof_bits(uint32_t id){return wc_user_complex_proof_bits(id);}
WC_EXPORT("wc_complex_collapse_steps") uint32_t wc_complex_collapse_steps(uint32_t id){return wc_user_complex_collapse_steps(id);}

WC_EXPORT("wc_ipe_count") uint32_t wc_ipe_count(void){return wc_user_ipe_count();}
WC_EXPORT("wc_ipe_proof_bits") uint32_t wc_ipe_proof_bits(uint32_t id){return wc_user_ipe_proof_bits(id);}
WC_EXPORT("wc_ipe_original_nodes") uint32_t wc_ipe_original_nodes(uint32_t id){return wc_user_ipe_original_nodes(id);}
WC_EXPORT("wc_ipe_serial_nodes") uint32_t wc_ipe_serial_nodes(uint32_t id){return wc_user_ipe_serial_nodes(id);}
WC_EXPORT("wc_ipe_eliminated_orchestration") uint32_t wc_ipe_eliminated_orchestration(uint32_t id){return wc_user_ipe_eliminated_orchestration(id);}
WC_EXPORT("wc_ipe_scalarized_worker_slots") uint32_t wc_ipe_scalarized_worker_slots(uint32_t id){return wc_user_ipe_scalarized_worker_slots(id);}
WC_EXPORT("wc_ipe_fused_partitions") uint32_t wc_ipe_fused_partitions(uint32_t id){return wc_user_ipe_fused_partitions(id);}
WC_EXPORT("wc_ipe_partition_boundaries_removed") uint32_t wc_ipe_partition_boundaries_removed(uint32_t id){return wc_user_ipe_partition_boundaries_removed(id);}
WC_EXPORT("wc_ipe_schedule_node") uint32_t wc_ipe_schedule_node(uint32_t id,uint32_t k){return wc_user_ipe_schedule_node(id,k);}
WC_EXPORT("wc_ipe_bench") uint64_t wc_ipe_bench(uint32_t id,uint32_t optimized,uint32_t reps){return wc_user_ipe_bench(id,optimized,reps);}

WC_EXPORT("wc_kernel_count") uint32_t wc_kernel_count(void){return wc_user_kernel_count();}
WC_EXPORT("wc_kernel_bound") uint64_t wc_kernel_bound(uint32_t id){return wc_user_kernel_bound(id);}
WC_EXPORT("wc_kernel_extent") uint64_t wc_kernel_extent(uint32_t id){return wc_user_kernel_extent(id);}
WC_EXPORT("wc_kernel_depth") uint32_t wc_kernel_depth(uint32_t id){return wc_user_kernel_depth(id);}
WC_EXPORT("wc_kernel_proof_bits") uint32_t wc_kernel_proof_bits(uint32_t id){return wc_user_kernel_proof_bits(id);}
WC_EXPORT("wc_kernel_transform_bits") uint32_t wc_kernel_transform_bits(uint32_t id){return wc_user_kernel_transform_bits(id);}
WC_EXPORT("wc_kernel_run") void wc_kernel_run(uint32_t id,uint32_t reps){wc_user_kernel_run(id,reps);}

/* Typed Structural Iteration Algebra introspection. */
WC_EXPORT("wc_sia_count") uint32_t wc_sia_count(void){return wc_user_sia_count();}
WC_EXPORT("wc_sia_kind") uint32_t wc_sia_kind(uint32_t id){return wc_user_sia_kind(id);}
WC_EXPORT("wc_sia_extent") uint32_t wc_sia_extent(uint32_t id){return wc_user_sia_extent(id);}
WC_EXPORT("wc_sia_stages") uint32_t wc_sia_stages(uint32_t id){return wc_user_sia_stages(id);}
WC_EXPORT("wc_sia_locality") uint32_t wc_sia_locality(uint32_t id){return wc_user_sia_locality(id);}
WC_EXPORT("wc_sia_proof_bits") uint32_t wc_sia_proof_bits(uint32_t id){return wc_user_sia_proof_bits(id);}
WC_EXPORT("wc_sia_transform_bits") uint32_t wc_sia_transform_bits(uint32_t id){return wc_user_sia_transform_bits(id);}

WC_EXPORT("wc_eci_capability_count") uint32_t wc_eci_capability_count(void){return wc_user_eci_capability_count();}
WC_EXPORT("wc_eci_op_count") uint32_t wc_eci_op_count(void){return wc_user_eci_op_count();}
WC_EXPORT("wc_eci_capability_effect") uint32_t wc_eci_capability_effect(uint32_t id){return wc_user_eci_capability_effect(id);}
WC_EXPORT("wc_eci_capability_required") uint32_t wc_eci_capability_required(uint32_t id){return wc_user_eci_capability_required(id);}
WC_EXPORT("wc_eci_provider_count") uint32_t wc_eci_provider_count(uint32_t id){return wc_user_eci_provider_count(id);}
WC_EXPORT("wc_eci_provider_kind") uint32_t wc_eci_provider_kind(uint32_t id,uint32_t k){return wc_user_eci_provider_kind(id,k);}
WC_EXPORT("wc_eci_provider_hosts") uint32_t wc_eci_provider_hosts(uint32_t id,uint32_t k){return wc_user_eci_provider_hosts(id,k);}
WC_EXPORT("wc_eci_provider_priority") uint32_t wc_eci_provider_priority(uint32_t id,uint32_t k){return wc_user_eci_provider_priority(id,k);}
WC_EXPORT("wc_eci_provider_global_id") uint32_t wc_eci_provider_global_id(uint32_t id,uint32_t k){return wc_user_eci_provider_global_id(id,k);}
WC_EXPORT("wc_eci_select") uint32_t wc_eci_select(uint32_t cap,uint32_t host,uint32_t alo,uint32_t ahi){return wc_user_eci_select(cap,host,alo,ahi);}
WC_EXPORT("wc_eci_op_capability") uint32_t wc_eci_op_capability(uint32_t id){return wc_user_eci_op_capability(id);}
WC_EXPORT("wc_eci_op_boundary") uint32_t wc_eci_op_boundary(uint32_t id){return wc_user_eci_op_boundary(id);}
WC_EXPORT("wc_eci_op_opcode") uint32_t wc_eci_op_opcode(uint32_t id){return wc_user_eci_op_opcode(id);}
WC_EXPORT("wc_eci_call") uint64_t wc_eci_call(uint32_t op,uint64_t a0,uint64_t a1){return wc_user_eci_call(op,a0,a1);}

/* Webchan 1.0.6: structural passport + resumable kernel ABI. */
WC_EXPORT("wc_kernel_resumable") uint32_t wc_kernel_resumable(uint32_t id){return wc_user_kernel_resumable(id);}
WC_EXPORT("wc_kernel_resume_reset") void wc_kernel_resume_reset(uint32_t id){wc_user_kernel_resume_reset(id);}
WC_EXPORT("wc_kernel_resume") uint32_t wc_kernel_resume(uint32_t id,uint32_t budget){if(budget>WC_MAX_STEP_UNITS)budget=WC_MAX_STEP_UNITS;return wc_user_kernel_resume(id,budget?budget:1u);}
WC_EXPORT("wc_kernel_resume_done") uint32_t wc_kernel_resume_done(uint32_t id){return wc_user_kernel_resume_done(id);}
WC_EXPORT("wc_kernel_resume_cursor") uint32_t wc_kernel_resume_cursor(uint32_t id){return wc_user_kernel_resume_cursor(id);}
WC_EXPORT("wc_kernel_structural_bits") uint32_t wc_kernel_structural_bits(uint32_t id){return wc_user_kernel_structural_bits(id);}
WC_EXPORT("wc_kernel_operator_bandwidth") uint32_t wc_kernel_operator_bandwidth(uint32_t id){return wc_user_kernel_operator_bandwidth(id);}
WC_EXPORT("wc_kernel_operator_src") uint32_t wc_kernel_operator_src(uint32_t id){return wc_user_kernel_operator_src(id);}
WC_EXPORT("wc_kernel_operator_dst") uint32_t wc_kernel_operator_dst(uint32_t id){return wc_user_kernel_operator_dst(id);}
WC_EXPORT("wc_kernel_solver_unlock_bits") uint32_t wc_kernel_solver_unlock_bits(uint32_t id){return wc_user_kernel_solver_unlock_bits(id);}
WC_EXPORT("wc_frame_budget_ms_x1000") uint32_t wc_frame_budget_ms_x1000(void){return (uint32_t)(WC_FRAME_BUDGET_MS*1000.0+0.5);}
WC_EXPORT("wc_slice_budget_ms_x1000") uint32_t wc_slice_budget_ms_x1000(void){return (uint32_t)(WC_SLICE_BUDGET_MS*1000.0+0.5);}
WC_EXPORT("wc_max_continuous_ms_x1000") uint32_t wc_max_continuous_ms_x1000(void){return (uint32_t)(WC_MAX_CONTINUOUS_MS*1000.0+0.5);}

/* Bounded byte streams. The host receives direct contiguous spans in Wasm
   memory and commits/consumes them. No host heap allocation is required by the
   core and backpressure is represented by fixed watermarks. */
static uint8_t wc_stream_data[WC_STREAM_COUNT][WC_STREAM_CAPACITY];
static uint32_t wc_stream_head[WC_STREAM_COUNT],wc_stream_tail[WC_STREAM_COUNT],wc_stream_size_v[WC_STREAM_COUNT];
static uint8_t wc_stream_state_v[WC_STREAM_COUNT]; /* 0=open,1=closed,2=failed,3=cancelled */
WC_EXPORT("wc_stream_count") uint32_t wc_stream_count(void){return WC_STREAM_COUNT;}
WC_EXPORT("wc_stream_capacity") uint32_t wc_stream_capacity(uint32_t id){return id<WC_STREAM_COUNT?WC_STREAM_CAPACITY:0u;}
WC_EXPORT("wc_stream_size") uint32_t wc_stream_size(uint32_t id){return id<WC_STREAM_COUNT?wc_stream_size_v[id]:0u;}
WC_EXPORT("wc_stream_space") uint32_t wc_stream_space(uint32_t id){return id<WC_STREAM_COUNT?WC_STREAM_CAPACITY-wc_stream_size_v[id]:0u;}
WC_EXPORT("wc_stream_state") uint32_t wc_stream_state(uint32_t id){return id<WC_STREAM_COUNT?wc_stream_state_v[id]:255u;}
WC_EXPORT("wc_stream_high_watermark") uint32_t wc_stream_high_watermark(void){return WC_STREAM_HIGH_WATERMARK;}
WC_EXPORT("wc_stream_low_watermark") uint32_t wc_stream_low_watermark(void){return WC_STREAM_LOW_WATERMARK;}
WC_EXPORT("wc_stream_backpressured") uint32_t wc_stream_backpressured(uint32_t id){return id<WC_STREAM_COUNT&&wc_stream_size_v[id]>=WC_STREAM_HIGH_WATERMARK;}
WC_EXPORT("wc_stream_reset") void wc_stream_reset(uint32_t id){if(id<WC_STREAM_COUNT){wc_stream_head[id]=wc_stream_tail[id]=wc_stream_size_v[id]=0u;wc_stream_state_v[id]=0u;}}
WC_EXPORT("wc_stream_close") uint32_t wc_stream_close(uint32_t id){if(id>=WC_STREAM_COUNT||wc_stream_state_v[id])return 0u;wc_stream_state_v[id]=1u;return 1u;}
WC_EXPORT("wc_stream_fail") uint32_t wc_stream_fail(uint32_t id){if(id>=WC_STREAM_COUNT||wc_stream_state_v[id])return 0u;wc_stream_state_v[id]=2u;return 1u;}
WC_EXPORT("wc_stream_cancel") uint32_t wc_stream_cancel(uint32_t id){if(id>=WC_STREAM_COUNT)return 0u;wc_stream_state_v[id]=3u;return 1u;}
WC_EXPORT("wc_stream_write_ptr") uint64_t wc_stream_write_ptr(uint32_t id){if(id>=WC_STREAM_COUNT||wc_stream_state_v[id])return 0u;return (uint64_t)(uintptr_t)&wc_stream_data[id][wc_stream_tail[id]];}
WC_EXPORT("wc_stream_write_span") uint32_t wc_stream_write_span(uint32_t id){if(id>=WC_STREAM_COUNT||wc_stream_state_v[id])return 0u;uint32_t free=WC_STREAM_CAPACITY-wc_stream_size_v[id],to_end=WC_STREAM_CAPACITY-wc_stream_tail[id];return free<to_end?free:to_end;}
WC_EXPORT("wc_stream_write_commit") uint32_t wc_stream_write_commit(uint32_t id,uint32_t n){if(id>=WC_STREAM_COUNT||wc_stream_state_v[id])return 0u;uint32_t span=wc_stream_write_span(id);if(n>span)return 0u;wc_stream_tail[id]=(wc_stream_tail[id]+n)%WC_STREAM_CAPACITY;wc_stream_size_v[id]+=n;return 1u;}
WC_EXPORT("wc_stream_read_ptr") uint64_t wc_stream_read_ptr(uint32_t id){if(id>=WC_STREAM_COUNT||!wc_stream_size_v[id])return 0u;return (uint64_t)(uintptr_t)&wc_stream_data[id][wc_stream_head[id]];}
WC_EXPORT("wc_stream_read_span") uint32_t wc_stream_read_span(uint32_t id){if(id>=WC_STREAM_COUNT)return 0u;uint32_t n=wc_stream_size_v[id],to_end=WC_STREAM_CAPACITY-wc_stream_head[id];return n<to_end?n:to_end;}
WC_EXPORT("wc_stream_read_consume") uint32_t wc_stream_read_consume(uint32_t id,uint32_t n){if(id>=WC_STREAM_COUNT||n>wc_stream_read_span(id))return 0u;wc_stream_head[id]=(wc_stream_head[id]+n)%WC_STREAM_CAPACITY;wc_stream_size_v[id]-=n;return 1u;}
WC_EXPORT("wc_stream_push_byte") uint32_t wc_stream_push_byte(uint32_t id,uint32_t b){if(id>=WC_STREAM_COUNT||wc_stream_state_v[id]||wc_stream_size_v[id]>=WC_STREAM_CAPACITY)return 0u;wc_stream_data[id][wc_stream_tail[id]]=(uint8_t)b;wc_stream_tail[id]=(wc_stream_tail[id]+1u)%WC_STREAM_CAPACITY;wc_stream_size_v[id]++;return 1u;}
WC_EXPORT("wc_stream_pop_byte") uint32_t wc_stream_pop_byte(uint32_t id){if(id>=WC_STREAM_COUNT||!wc_stream_size_v[id])return 0xffffffffu;uint32_t b=wc_stream_data[id][wc_stream_head[id]];wc_stream_head[id]=(wc_stream_head[id]+1u)%WC_STREAM_CAPACITY;wc_stream_size_v[id]--;return b;}

/* Generic bounded event mailbox. DOM, timers, network completions, workers and
   user-defined providers all share this causal ingress instead of defining
   separate hidden event loops. */
static uint32_t wc_event_type_q[WC_EVENT_MAILBOX_CAP],wc_event_head_v,wc_event_tail_v,wc_event_count_v,wc_event_dropped_v;
static uint64_t wc_event_a0_q[WC_EVENT_MAILBOX_CAP],wc_event_a1_q[WC_EVENT_MAILBOX_CAP];
WC_EXPORT("wc_event_capacity") uint32_t wc_event_capacity(void){return WC_EVENT_MAILBOX_CAP;}
WC_EXPORT("wc_event_count") uint32_t wc_event_count(void){return wc_event_count_v;}
WC_EXPORT("wc_event_dropped") uint32_t wc_event_dropped(void){return wc_event_dropped_v;}
WC_EXPORT("wc_event_reset") void wc_event_reset(void){wc_event_head_v=wc_event_tail_v=wc_event_count_v=wc_event_dropped_v=0u;}
WC_EXPORT("wc_event_push") uint32_t wc_event_push(uint32_t type,uint64_t a0,uint64_t a1){uint32_t limit=WC_EVENT_MAILBOX_CAP<WC_ACTIVE_SET_CAP?WC_EVENT_MAILBOX_CAP:WC_ACTIVE_SET_CAP;if(wc_event_count_v>=limit){wc_event_dropped_v++;return 0u;}wc_event_type_q[wc_event_tail_v]=type;wc_event_a0_q[wc_event_tail_v]=a0;wc_event_a1_q[wc_event_tail_v]=a1;wc_event_tail_v=(wc_event_tail_v+1u)%WC_EVENT_MAILBOX_CAP;wc_event_count_v++;return 1u;}
WC_EXPORT("wc_event_peek_type") uint32_t wc_event_peek_type(void){return wc_event_count_v?wc_event_type_q[wc_event_head_v]:0xffffffffu;}
WC_EXPORT("wc_event_peek_a0") uint64_t wc_event_peek_a0(void){return wc_event_count_v?wc_event_a0_q[wc_event_head_v]:0u;}
WC_EXPORT("wc_event_peek_a1") uint64_t wc_event_peek_a1(void){return wc_event_count_v?wc_event_a1_q[wc_event_head_v]:0u;}
WC_EXPORT("wc_event_consume") uint32_t wc_event_consume(void){if(!wc_event_count_v)return 0u;wc_event_head_v=(wc_event_head_v+1u)%WC_EVENT_MAILBOX_CAP;wc_event_count_v--;return 1u;}
WC_EXPORT("wc_active_set_used") uint32_t wc_active_set_used(void){uint32_t n=wc_event_count_v;for(uint32_t i=0;i<WC_STREAM_COUNT;i++)if(wc_stream_size_v[i]||wc_stream_state_v[i])n++;for(uint32_t i=0;i<WC_KERNEL_COUNT;i++)if(wc_user_kernel_resumable(i)&&!wc_user_kernel_resume_done(i)&&wc_user_kernel_resume_cursor(i))n++;return n;}

/* True async ECI lifecycle. A pending Future token is passed to the host;
   completion returns through the already generated future_resolve/fail ABI. */
WC_EXPORT("wc_eci_async_begin") uint64_t wc_eci_async_begin(uint32_t op,uint32_t future_pool,uint64_t future_token,uint64_t a0,uint64_t a1){return wc_user_eci_async_begin(op,future_pool,future_token,a0,a1);}
WC_EXPORT("wc_eci_async_cancel") uint32_t wc_eci_async_cancel(uint64_t request_id){return wc_user_eci_async_cancel(request_id);}
