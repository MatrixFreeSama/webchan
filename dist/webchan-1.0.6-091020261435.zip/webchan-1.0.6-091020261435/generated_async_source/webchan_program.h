#ifndef WEBCHAN_PROGRAM_H
#define WEBCHAN_PROGRAM_H
#include <stdint.h>
#define WC_VERSION_MAJOR 1
#define WC_VERSION_MINOR 0
#define WC_VERSION_PATCH 6
#define WC_BUILD_ID "091020261435"
#define WC_MODULE_NAME "async_source"
#define WC_TASK_COUNT 1
#define WC_FN_COUNT 1
#define WC_ARRAY_COUNT 1
#define WC_STRUCT_COUNT 0
#define WC_ENUM_COUNT 0
#define WC_MATRIX_COUNT 0
#define WC_SOLVE_COUNT 0
#define WC_VFIELD_COUNT 0
#define WC_PWFIELD_COUNT 0
#define WC_TOPOLOGY_COUNT 0
#define WC_PLAN_COUNT 0
#define WC_COMPLEX_COUNT 0
#define WC_IPE_REGION_COUNT 0
#define WC_KERNEL_COUNT 2
#define WC_ECI_CAPABILITY_COUNT 1
#define WC_ECI_OP_COUNT 1
#define WC_FRAME_BUDGET_MS 16.667000000000002
#define WC_SLICE_BUDGET_MS 2
#define WC_MAX_CONTINUOUS_MS 4
#define WC_MAX_STEP_UNITS 2048u
#define WC_DEFAULT_STEP_UNITS 512u
#define WC_ACTIVE_SET_CAP 96u
#define WC_CHEB_ORDER 32
#define WC_CHEB_TOL 1e-08
#define WC_TEMPORAL_SAFETY_STRICT 1
#define WC_PROGRESSIVE_DEFAULT 1
#define WC_IMPLICIT_BARRIER_FORBIDDEN 1
#define WC_CAUSAL_DAG_COMPILED 1
#define WC_INPUT_FAIR_HOST_YIELD 1
#define WC_C_BACKEND_AUTHORITATIVE 1
#define WC_HOST_ABI_PORTABLE 1
#define WC_GENERATED_C_INTERNAL_ONLY 1
#define WC_TERMINATION_CHECKED 1
#define WC_SIZED_TYPES 1
#define WC_TEMPORAL_EFFECTS 1
#define WC_PROOF_DIRECTED_OPT 1
#define WC_PROFITABLE_PROOFS_ONLY 1
#define WC_STATIC_MATRIX_PROOFS 1
#define WC_PROOF_GUIDED_MATRIX_FREE 1
#define WC_AUTO_AFFINE_DISCOVERY 1
#define WC_BOUNDED_TEMP_MATERIALIZATION 1
#define WC_INCREMENTAL_CHANGE_PROPAGATION 1
#define WC_ADAPTIVE_PARTITION 1
#define WC_EXACT_PIECEWISE_FIELDS 1
#define WC_GENERAL_STRUCTURAL_PROOF 1
#define WC_LINEAR_ALGEBRA_CAPABILITY_GRAPH 1
#define WC_AFFINE_FUNCTION_COLLAPSE 1
#define WC_JACOBI_PROOF_UNLOCK 1
#define WC_GAUSS_SEIDEL_PROOF_UNLOCK 1
#define WC_TRIANGULAR_SOLVE_COLLAPSE 1
#define WC_STRUCTURAL_TOPOLOGY_PROOF 1
#define WC_STRUCTURAL_ITERATION_ALGEBRA 1
#define WC_FINITE_INDEX_SPACE_PROOF 1
#define WC_DEPENDENCE_TOPOLOGY_BRIDGE 1
#define WC_LOOP_TRANSFORM_PROOF_GATE 1
#define WC_GENERIC_INDEX_KERNELS 1
#define WC_BOUNDED_NESTED_FOR 1
#define WC_PROVED_GATHER_SCATTER 1
#define WC_LOOP_CARRIED_SCALARS 1
#define WC_REDUCTION_SCAN_FOUNDATION 1
#define WC_BITWISE_INDEX_MAPS 1
#define WC_STRUCTURAL_DATA_LAYOUT_ALGEBRA 1
#define WC_AUTO_LAYOUT_SELECTION 1
#define WC_LOGICAL_PHYSICAL_ARRAY_SEPARATION 1
#define WC_INTERLEAVED_LAYOUT_REWRITE 1
#define WC_TILED_LAYOUT_REWRITE 1
#define WC_SDLA_ACCESS_PHASE_COST_MODEL 1
#define WC_SDLA_CONTIGUOUS_STREAM_GUARD 1
#define WC_SDLA_SHIFT_MASK_TILE_ADDRESSING 1
#define WC_WASM_PROFILE_ADAPTIVE 1
#define WC_WASM_SCALAR_FALLBACK 1
#define WC_WASM_SIMD128_OPTIONAL 1
#define WC_WASM_PROFILE_SEMANTIC_PARITY_REQUIRED 1
#define WC_OPTIMIZATION_PROVENANCE_HOUSEKEEPING_LUXURY 1
#define WC_PROBE_IDENTITY_FORBIDDEN_IN_OPTIMIZER 1
#define WC_HOUSEKEEPING_IV_CANONICALIZATION 1
#define WC_MODULAR_SENTINEL_IV 1
#define WC_SELECTIVE_KERNEL_OUTLINING 1
#define WC_STRUCTURAL_PASSPORTS 1
#define WC_TYPED_PROOF_NAMESPACES 1
#define WC_RESUMABLE_KERNELS 1
#define WC_BOUNDED_BYTE_STREAM 1
#define WC_EVENT_MAILBOX 1
#define WC_ASYNC_ECI_COMPLETION 1
#define WC_DOM_BATCH_HOST 1
#define WC_INCREMENTAL_UTF8_HOST 1
#define WC_TOPOLOGICAL_PLANNING 1
#define WC_HOMOLOGY_GF2 1
#define WC_GRAPH_FUNDAMENTAL_GROUP 1
#define WC_PLAN_RANK 1
#define WC_INVERSE_PARALLEL_EXPANSION 1
#define WC_PARALLEL_ORCHESTRATION_ERASURE 1
#define WC_RANK_GUIDED_RELINEARIZATION 1
#define WC_PARTITION_FUSION 1
#define WC_WILD_PROJECT_TEXTBOOK_ONLY 1
#define WC_EXTERNAL_CAPABILITY_INTERFACE 1
#define WC_ECI_C_ABI_FIRST 1
#define WC_ECI_REPLACEABLE_PROVIDERS 1
#define WC_ECI_TEMPORAL_EFFECT_CHECKING 1
#define WC_ECI_VENDOR_FALLBACK_ONLY 1
#define WC_MEMORY_MODE 0
#define WC_MEMORY_RECOMPUTE_BUDGET 6
#define WC_MEMORY_MIN_SAVINGS 4096u
#define WC_FIELD_SCRATCH_CAP 4096
#define WC_STREAM_COUNT 4u
#define WC_STREAM_CAPACITY 65536u
#define WC_STREAM_HIGH_WATERMARK 49152u
#define WC_STREAM_LOW_WATERMARK 16384u
#define WC_EVENT_MAILBOX_CAP 256u
extern const int32_t wc_task_ranks[WC_TASK_COUNT];
extern const uint32_t wc_task_costs[WC_TASK_COUNT];
extern const double wc_task_deadlines[WC_TASK_COUNT];
extern const uint8_t wc_task_classes[WC_TASK_COUNT];
extern const uint8_t wc_task_fn[WC_TASK_COUNT];
extern const uint32_t wc_task_pred_lo[WC_TASK_COUNT],wc_task_pred_hi[WC_TASK_COUNT],wc_task_pred_x[WC_TASK_COUNT];
double wc_user_call(uint8_t,double,double,uint32_t,uint32_t);
double wc_user_call_reference(uint8_t,double,double,uint32_t,uint32_t);
uint32_t wc_user_fn_structural_bits(uint32_t);
uint64_t wc_user_fn_original_ops(uint32_t);
uint64_t wc_user_fn_collapsed_ops(uint32_t);
uint32_t wc_user_fn_bound(uint32_t);
uint32_t wc_user_array_count(void);
uint32_t wc_user_array_len(uint32_t);
uint32_t wc_user_array_type(uint32_t);
uint32_t wc_user_array_layout_kind(uint32_t);
uint32_t wc_user_array_layout_group(uint32_t);
uint32_t wc_user_array_layout_lane(uint32_t);
uint32_t wc_user_array_layout_lanes(uint32_t);
uint32_t wc_user_array_layout_tile(uint32_t);
uint32_t wc_user_array_layout_score(uint32_t);
int32_t wc_user_array_layout_profit(uint32_t);
uint32_t wc_user_array_layout_phase_coverage(uint32_t);
uint32_t wc_user_array_layout_stream_ratio(uint32_t);
uint32_t wc_user_array_layout_reason_bits(uint32_t);
uint64_t wc_user_array_logical_bytes(uint32_t);
uint64_t wc_user_array_physical_share_bytes(uint32_t);
double wc_user_array_get(uint32_t,uint32_t);
void wc_user_array_set(uint32_t,uint32_t,double);
uint64_t wc_user_array_get_bits(uint32_t,uint32_t);
void wc_user_array_set_bits(uint32_t,uint32_t,uint64_t);
uint32_t wc_user_solve_count(void);
uint32_t wc_user_solve(uint32_t,uint32_t);
double wc_user_solve_residual(uint32_t);
uint32_t wc_user_solve_proof_bits(uint32_t);
uint32_t wc_user_solve_chosen(uint32_t);
uint64_t wc_user_solve_estimated(uint32_t,uint32_t);
uint32_t wc_user_memory_mode(void);
void wc_user_memory_init(void);
uint32_t wc_user_field_count(void);
uint32_t wc_user_field_len(uint32_t);
uint32_t wc_user_field_repr(uint32_t);
uint32_t wc_user_field_proof_bits(uint32_t);
uint32_t wc_user_field_reconstruct_ops(uint32_t);
uint64_t wc_user_field_logical_bytes(uint32_t);
uint64_t wc_user_field_stored_bytes(uint32_t);
uint64_t wc_user_field_saved_bytes(uint32_t);
double wc_user_field_get(uint32_t,uint32_t);
double wc_user_field_checksum(uint32_t,uint32_t);
double wc_user_field_pair_checksum(uint32_t,uint32_t,uint32_t);
uint32_t wc_user_field_materialize(uint32_t,uint32_t,uint32_t);
double wc_user_field_scratch_get(uint32_t);
uint32_t wc_user_pwfield_count(void);
uint32_t wc_user_pwfield_len(uint32_t);
uint32_t wc_user_pwfield_repr(uint32_t);
uint32_t wc_user_pwfield_segments(uint32_t);
uint64_t wc_user_pwfield_logical_bytes(uint32_t);
uint64_t wc_user_pwfield_stored_bytes(uint32_t);
uint64_t wc_user_pwfield_saved_bytes(uint32_t);
double wc_user_pwfield_get(uint32_t,uint32_t);
double wc_user_pwfield_checksum(uint32_t,uint32_t);
uint32_t wc_user_topology_count(void);
uint32_t wc_user_topology_vertices(uint32_t);
uint32_t wc_user_topology_edges(uint32_t);
uint32_t wc_user_topology_beta0(uint32_t);
uint32_t wc_user_topology_beta1(uint32_t);
int32_t wc_user_topology_euler(uint32_t);
uint32_t wc_user_topology_proof_bits(uint32_t);
uint32_t wc_user_topology_bridges(uint32_t);
uint32_t wc_user_topology_articulations(uint32_t);
uint32_t wc_user_topology_free_group_rank(uint32_t);
uint32_t wc_user_topology_incidence_rank(uint32_t);
uint32_t wc_user_topology_laplacian_nullity(uint32_t);
uint32_t wc_user_topology_laplacian_proof_bits(uint32_t);
uint32_t wc_user_topology_laplacian_linear_bits(uint32_t);
uint32_t wc_user_plan_count(void);
uint32_t wc_user_plan_path_len(uint32_t);
uint32_t wc_user_plan_path_vertex(uint32_t,uint32_t);
int32_t wc_user_plan_rank(uint32_t);
double wc_user_plan_cost(uint32_t);
uint32_t wc_user_plan_full_expansions(uint32_t);
uint32_t wc_user_plan_topo_expansions(uint32_t);
uint32_t wc_user_plan_pruned_vertices(uint32_t);
uint32_t wc_user_plan_homotopy_word_len(uint32_t);
int32_t wc_user_plan_homotopy_letter(uint32_t,uint32_t);
uint64_t wc_user_plan_bench(uint32_t,uint32_t,uint32_t);
uint32_t wc_user_complex_count(void);
uint32_t wc_user_complex_beta(uint32_t,uint32_t);
int32_t wc_user_complex_euler(uint32_t);
uint32_t wc_user_complex_proof_bits(uint32_t);
uint32_t wc_user_complex_collapse_steps(uint32_t);
uint32_t wc_user_ipe_count(void);
uint32_t wc_user_ipe_proof_bits(uint32_t);
uint32_t wc_user_ipe_original_nodes(uint32_t);
uint32_t wc_user_ipe_serial_nodes(uint32_t);
uint32_t wc_user_ipe_eliminated_orchestration(uint32_t);
uint32_t wc_user_ipe_scalarized_worker_slots(uint32_t);
uint32_t wc_user_ipe_fused_partitions(uint32_t);
uint32_t wc_user_ipe_partition_boundaries_removed(uint32_t);
uint32_t wc_user_ipe_schedule_node(uint32_t,uint32_t);
uint64_t wc_user_ipe_bench(uint32_t,uint32_t,uint32_t);
uint32_t wc_user_kernel_count(void);
uint64_t wc_user_kernel_bound(uint32_t);
uint64_t wc_user_kernel_extent(uint32_t);
uint32_t wc_user_kernel_depth(uint32_t);
uint32_t wc_user_kernel_proof_bits(uint32_t);
uint32_t wc_user_kernel_transform_bits(uint32_t);
void wc_user_kernel_run(uint32_t,uint32_t);
uint32_t wc_user_kernel_resumable(uint32_t);
void wc_user_kernel_resume_reset(uint32_t);
uint32_t wc_user_kernel_resume(uint32_t,uint32_t);
uint32_t wc_user_kernel_resume_done(uint32_t);
uint32_t wc_user_kernel_resume_cursor(uint32_t);
uint32_t wc_user_kernel_structural_bits(uint32_t);
uint32_t wc_user_kernel_operator_bandwidth(uint32_t);
uint32_t wc_user_kernel_operator_src(uint32_t);
uint32_t wc_user_kernel_operator_dst(uint32_t);
uint32_t wc_user_kernel_solver_unlock_bits(uint32_t);
uint32_t wc_user_sia_count(void);
uint32_t wc_user_sia_kind(uint32_t);
uint32_t wc_user_sia_extent(uint32_t);
uint32_t wc_user_sia_stages(uint32_t);
uint32_t wc_user_sia_locality(uint32_t);
uint32_t wc_user_sia_proof_bits(uint32_t);
uint32_t wc_user_sia_transform_bits(uint32_t);
uint32_t wc_user_eci_capability_count(void);
uint32_t wc_user_eci_op_count(void);
uint32_t wc_user_eci_capability_effect(uint32_t);
uint32_t wc_user_eci_capability_required(uint32_t);
uint32_t wc_user_eci_provider_count(uint32_t);
uint32_t wc_user_eci_provider_kind(uint32_t,uint32_t);
uint32_t wc_user_eci_provider_hosts(uint32_t,uint32_t);
uint32_t wc_user_eci_provider_priority(uint32_t,uint32_t);
uint32_t wc_user_eci_provider_global_id(uint32_t,uint32_t);
uint32_t wc_user_eci_select(uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t wc_user_eci_op_capability(uint32_t);
uint32_t wc_user_eci_op_boundary(uint32_t);
uint32_t wc_user_eci_op_opcode(uint32_t);
uint64_t wc_user_eci_call(uint32_t,uint64_t,uint64_t);
uint64_t wc_user_eci_async_begin(uint32_t,uint32_t,uint64_t,uint64_t,uint64_t);
uint32_t wc_user_eci_async_cancel(uint64_t);
#define WC_GENERAL_APPLICATION_SEMANTICS 1
#define WC_BOUNDED_UTF8_TEXT 1
#define WC_BOUNDED_REGIONS 1
#define WC_BOUNDED_DYNAMIC_CONTAINERS 1
#define WC_RESULT_VALUES 1
#define WC_CANCELLABLE_FUTURES 1
#define WC_OPAQUE_CAPABILITY_HANDLES 1
#define WC_FINITE_STATE_MACHINES 1
#define WC_BINARY_CURSOR_CODEC 1
#define WC_REGION_COUNT 0
#define WC_TEXT_COUNT 0
#define WC_VECTOR_COUNT 0
#define WC_MAP_COUNT 0
#define WC_RESULT_COUNT 0
#define WC_FUTURE_POOL_COUNT 1
#define WC_HANDLE_POOL_COUNT 0
#define WC_STATE_MACHINE_COUNT 0
#define WC_IMPORT_COUNT 0
uint32_t wc_user_region_count(void);uint32_t wc_user_region_capacity(uint32_t);uint32_t wc_user_region_used(uint32_t);void wc_user_region_reset(uint32_t);uint32_t wc_user_region_alloc(uint32_t,uint32_t,uint32_t);uint32_t wc_user_region_read8(uint32_t,uint32_t);uint32_t wc_user_region_write8(uint32_t,uint32_t,uint32_t);uint64_t wc_user_region_ptr(uint32_t);
uint32_t wc_user_text_count(void);uint32_t wc_user_text_capacity(uint32_t);uint32_t wc_user_text_len(uint32_t);void wc_user_text_clear(uint32_t);uint32_t wc_user_text_resize(uint32_t,uint32_t);uint32_t wc_user_text_get(uint32_t,uint32_t);uint32_t wc_user_text_set(uint32_t,uint32_t,uint32_t);uint32_t wc_user_text_append_byte(uint32_t,uint32_t);uint32_t wc_user_text_append_text(uint32_t,uint32_t);uint32_t wc_user_text_utf8_valid(uint32_t);int32_t wc_user_text_find_byte(uint32_t,uint32_t,uint32_t);uint64_t wc_user_text_ptr(uint32_t);uint32_t wc_user_text_write_u32_le(uint32_t,uint32_t,uint32_t);uint32_t wc_user_text_read_u32_le(uint32_t,uint32_t,uint32_t*);uint32_t wc_user_text_write_f64_le(uint32_t,uint32_t,double);uint32_t wc_user_text_read_f64_le(uint32_t,uint32_t,double*);
uint32_t wc_user_vector_count(void);uint32_t wc_user_vector_capacity(uint32_t);uint32_t wc_user_vector_len(uint32_t);uint32_t wc_user_vector_type(uint32_t);void wc_user_vector_clear(uint32_t);uint32_t wc_user_vector_push(uint32_t,double);uint32_t wc_user_vector_pop(uint32_t,double*);uint32_t wc_user_vector_set(uint32_t,uint32_t,double);double wc_user_vector_get(uint32_t,uint32_t);uint32_t wc_user_vector_push_bits(uint32_t,uint64_t);uint32_t wc_user_vector_pop_bits(uint32_t,uint64_t*);uint32_t wc_user_vector_set_bits(uint32_t,uint32_t,uint64_t);uint64_t wc_user_vector_get_bits(uint32_t,uint32_t);
uint32_t wc_user_map_count(void);uint32_t wc_user_map_capacity(uint32_t);uint32_t wc_user_map_size(uint32_t);uint32_t wc_user_map_key_type(uint32_t);uint32_t wc_user_map_value_type(uint32_t);void wc_user_map_clear(uint32_t);uint32_t wc_user_map_put(uint32_t,double,double);uint32_t wc_user_map_get(uint32_t,double,double*);uint32_t wc_user_map_remove(uint32_t,double);uint32_t wc_user_map_put_bits(uint32_t,uint64_t,uint64_t);uint32_t wc_user_map_get_bits(uint32_t,uint64_t,uint64_t*);uint32_t wc_user_map_remove_bits(uint32_t,uint64_t);
uint32_t wc_user_result_count(void);uint32_t wc_user_result_ok_type(uint32_t);uint32_t wc_user_result_err_type(uint32_t);uint32_t wc_user_result_tag(uint32_t);void wc_user_result_clear(uint32_t);void wc_user_result_set_ok(uint32_t,double);void wc_user_result_set_err(uint32_t,double);double wc_user_result_value(uint32_t);void wc_user_result_set_ok_bits(uint32_t,uint64_t);void wc_user_result_set_err_bits(uint32_t,uint64_t);uint64_t wc_user_result_value_bits(uint32_t);
uint32_t wc_user_future_pool_count(void);uint32_t wc_user_future_capacity(uint32_t);uint32_t wc_user_future_value_type(uint32_t);uint32_t wc_user_future_error_type(uint32_t);uint64_t wc_user_future_create(uint32_t);uint32_t wc_user_future_state(uint32_t,uint64_t);uint32_t wc_user_future_resolve(uint32_t,uint64_t,double);uint32_t wc_user_future_fail(uint32_t,uint64_t,double);uint32_t wc_user_future_cancel(uint32_t,uint64_t);uint32_t wc_user_future_release(uint32_t,uint64_t);double wc_user_future_value(uint32_t,uint64_t);double wc_user_future_error(uint32_t,uint64_t);uint32_t wc_user_future_resolve_bits(uint32_t,uint64_t,uint64_t);uint32_t wc_user_future_fail_bits(uint32_t,uint64_t,uint64_t);uint64_t wc_user_future_value_bits(uint32_t,uint64_t);uint64_t wc_user_future_error_bits(uint32_t,uint64_t);
uint32_t wc_user_handle_pool_count(void);uint32_t wc_user_handle_capacity(uint32_t);uint32_t wc_user_handle_capability(uint32_t);uint64_t wc_user_handle_acquire(uint32_t,uint64_t);uint64_t wc_user_handle_value(uint32_t,uint64_t);uint32_t wc_user_handle_release(uint32_t,uint64_t);
uint32_t wc_user_state_machine_count(void);uint32_t wc_user_state_machine_states(uint32_t);uint32_t wc_user_state_machine_events(uint32_t);uint32_t wc_user_state_machine_state(uint32_t);void wc_user_state_machine_reset(uint32_t);uint32_t wc_user_state_machine_dispatch(uint32_t,uint32_t);
#endif
