import fs from 'node:fs';

const wasmPath = process.argv[2];
if (!wasmPath) throw new Error('usage: node general_application.mjs <wasm>');
const bytes = fs.readFileSync(wasmPath);
let dispatchCount = 0;
let lastDispatch = null;
const mod = await WebAssembly.compile(bytes);
const imports = WebAssembly.Module.imports(mod);
const instance = await WebAssembly.instantiate(mod, {
  webchan_eci: {
    dispatch(op, opcode, a0, a1) {
      dispatchCount++;
      lastDispatch = {op, opcode, a0: a0.toString(), a1: a1.toString()};
      return 0x123456789abcdef0n;
    },
    async_start(){ return 0n; },
    async_cancel(){ return 0; }
  }
});
const e = instance.exports;
const checks = {};
const check = (name, cond, detail = '') => {
  checks[name] = {pass: !!cond, detail: String(detail)};
  if (!cond) throw new Error(`${name}: ${detail}`);
};

check('three generic ECI imports', imports.length === 3 && imports.every(x=>x.module === 'webchan_eci') && ['dispatch','async_start','async_cancel'].every(n=>imports.some(x=>x.name===n)), JSON.stringify(imports));
check('version 1.0.6', e.wc_version() === 0x010006, `0x${e.wc_version().toString(16)}`);
check('general application contract', e.wc_application_contract_bits() === 0x1ff, `0x${e.wc_application_contract_bits().toString(16)}`);

// Region: bounded storage, alignment and hard OOB rejection.
e.wc_region_reset(0);
check('region capacity', e.wc_region_capacity(0) === 512, e.wc_region_capacity(0));
const r0 = e.wc_region_alloc(0, 3, 1);
const r1 = e.wc_region_alloc(0, 8, 8);
check('region first allocation', r0 === 0, r0);
check('region aligned allocation', r1 === 8, r1);
check('region write in bounds', e.wc_region_write8(0, r1, 0xa5) === 1, 'write failed');
check('region read in bounds', e.wc_region_read8(0, r1) === 0xa5, e.wc_region_read8(0, r1));
check('region OOB write rejected', e.wc_region_write8(0, 512, 1) === 0, e.wc_region_write8(0, 512, 1));
check('region exhausted allocation rejected', (e.wc_region_alloc(0, 10000, 1) >>> 0) === 0xffffffff, e.wc_region_alloc(0, 10000, 1));

// UTF-8 text: valid sequence accepted, malformed sequence detected.
e.wc_text_clear(0);
for (const b of [0x41, 0xe2, 0x82, 0xac]) check(`append byte ${b}`, e.wc_text_append_byte(0, b) === 1);
check('UTF-8 valid', e.wc_text_utf8_valid(0) === 1, 'expected valid A+euro');
check('text find byte', e.wc_text_find_byte(0, 0, 0xe2) === 1, e.wc_text_find_byte(0, 0, 0xe2));
check('text capacity bound', e.wc_text_resize(0, 257) === 0, e.wc_text_resize(0, 257));
e.wc_text_clear(0);
e.wc_text_append_byte(0, 0xc0);
check('malformed UTF-8 rejected', e.wc_text_utf8_valid(0) === 0, 'overlong lead accepted');

// Binary cursor/codec uses the same bounded text storage.
e.wc_text_clear(1);
check('text resize for binary codec', e.wc_text_resize(1, 8) === 1);
check('u32 little-endian write', e.wc_text_write_u32_le(1, 0, 0x11223344) === 1);
const p = Number(e.wc_text_ptr(1));
const mem = new Uint8Array(e.memory.buffer, p, 8);
check('u32 little-endian bytes', mem[0] === 0x44 && mem[1] === 0x33 && mem[2] === 0x22 && mem[3] === 0x11, Array.from(mem.slice(0,4)));
check('binary write OOB rejected', e.wc_text_write_u32_le(1, 6, 1) === 0);

const exact = 9007199254740993n; // 2^53 + 1: catches accidental double paths.
// Vector exact-bit lane.
e.wc_vector_clear(0);
check('vector exact push', e.wc_vector_push_bits(0, exact) === 1);
check('vector exact u64 survives', e.wc_vector_get_bits(0, 0) === exact, e.wc_vector_get_bits(0, 0));
check('vector length', e.wc_vector_len(0) === 1, e.wc_vector_len(0));
check('vector OOB set rejected', e.wc_vector_set_bits(0, 1, 7n) === 0);
for (let i = 1; i < 8; i++) check(`vector fill ${i}`, e.wc_vector_push_bits(0, BigInt(i)) === 1);
check('vector capacity bound', e.wc_vector_push_bits(0, 99n) === 0);
e.wc_vector_clear(0);

// Bounded generic map, exact value lane and tombstone reuse.
e.wc_map_clear(0);
check('map put exact', e.wc_map_put_bits(0, 7n, exact) === 1);
check('map size one', e.wc_map_size(0) === 1, e.wc_map_size(0));
const outPtr = Number(e.wc_region_ptr(0)) + 32;
check('map get exact', e.wc_map_get_bits(0, 7n, outPtr) === 1);
const dv = new DataView(e.memory.buffer);
check('map exact u64 survives', dv.getBigUint64(outPtr, true) === exact, dv.getBigUint64(outPtr, true));
check('map update exact', e.wc_map_put_bits(0, 7n, exact + 1n) === 1 && e.wc_map_size(0) === 1);
check('map remove', e.wc_map_remove_bits(0, 7n) === 1);
check('map tombstone size zero', e.wc_map_size(0) === 0, e.wc_map_size(0));
check('map missing remove rejected', e.wc_map_remove_bits(0, 7n) === 0);

// Result exact-bit tagged union.
e.wc_result_clear(0);
e.wc_result_set_ok_bits(0, exact);
check('result ok tag', e.wc_result_tag(0) === 1, e.wc_result_tag(0));
check('result exact ok value', e.wc_result_value_bits(0) === exact, e.wc_result_value_bits(0));
e.wc_result_set_err_bits(0, 0xffffffffn);
check('result err tag', e.wc_result_tag(0) === 2, e.wc_result_tag(0));
check('result signed-error bits stable', e.wc_result_value_bits(0) === 0xffffffffn, e.wc_result_value_bits(0));

// Future tokens: generation protects stale references; cancellation is terminal.
const f1 = e.wc_future_create(0);
check('future token created', f1 !== 0n, f1);
check('future pending', e.wc_future_state(0, f1) === 1, e.wc_future_state(0, f1));
check('future exact resolve', e.wc_future_resolve_bits(0, f1, exact) === 1);
check('future ready', e.wc_future_state(0, f1) === 2, e.wc_future_state(0, f1));
check('future exact value', e.wc_future_value_bits(0, f1) === exact, e.wc_future_value_bits(0, f1));
check('future cannot resolve twice', e.wc_future_resolve_bits(0, f1, 4n) === 0);
check('future release terminal', e.wc_future_release(0, f1) === 1);
check('released future stale', e.wc_future_state(0, f1) === 0, e.wc_future_state(0, f1));
const f2 = e.wc_future_create(0);
check('future generation changes token', f2 !== 0n && f2 !== f1, `${f1} -> ${f2}`);
check('old token remains stale', e.wc_future_state(0, f1) === 0);
check('future cancel', e.wc_future_cancel(0, f2) === 1);
check('future cancelled state', e.wc_future_state(0, f2) === 4, e.wc_future_state(0, f2));
check('cancel blocks resolve', e.wc_future_resolve_bits(0, f2, 8n) === 0);
check('cancelled future release', e.wc_future_release(0, f2) === 1);

// Opaque capability handles: raw host identity never becomes a language pointer.
const raw = 0xf123456789abcden;
const h1 = e.wc_handle_acquire(0, raw);
check('handle token created', h1 !== 0n, h1);
check('handle raw exact', e.wc_handle_value(0, h1) === raw, e.wc_handle_value(0, h1));
check('handle release', e.wc_handle_release(0, h1) === 1);
check('stale handle rejected', e.wc_handle_value(0, h1) === 0n, e.wc_handle_value(0, h1));
check('double handle release rejected', e.wc_handle_release(0, h1) === 0);

// Finite state machine generated as direct switch code.
e.wc_state_machine_reset(0);
check('state machine initial', e.wc_state_machine_state(0) === 0, e.wc_state_machine_state(0));
check('state dispatch begin', e.wc_state_machine_dispatch(0, 0) === 1, e.wc_state_machine_state(0));
check('state dispatch succeed', e.wc_state_machine_dispatch(0, 1) === 2, e.wc_state_machine_state(0));
check('unknown event preserves state', e.wc_state_machine_dispatch(0, 99) === 2 && e.wc_state_machine_state(0) === 2, e.wc_state_machine_state(0));
e.wc_state_machine_reset(0);

// Run the Webchan-owned application kernel. This checks bounded while lowering,
// exact u64 through vector -> map -> Result/Future, and async ECI dispatch.
e.wc_vector_clear(0);
e.wc_map_clear(0);
e.wc_result_clear(0);
e.wc_text_clear(0);
e.wc_text_clear(1);
e.wc_state_machine_reset(0);
dispatchCount = 0;
e.wc_kernel_run(0, 1);
check('application kernel dispatched ECI once', dispatchCount === 1, dispatchCount);
check('kernel exact u64 survived generic containers', e.wc_result_tag(0) === 1 && e.wc_result_value_bits(0) === exact, `${e.wc_result_tag(0)} / ${e.wc_result_value_bits(0)}`);
check('kernel finite while terminated', e.wc_vector_len(0) === 1, e.wc_vector_len(0));
check('kernel text byte path', e.wc_text_len(0) === 1 && e.wc_text_get(0, 0) === 65 && e.wc_text_utf8_valid(0) === 1);
check('kernel binary codec bytes', e.wc_text_len(1) === 8 && e.wc_text_get(1,0) === 0x44 && e.wc_text_get(1,3) === 0x11);
check('kernel state transition', e.wc_state_machine_state(0) === 1, e.wc_state_machine_state(0));
const kf1=e.wc_future_create(0), kf2=e.wc_future_create(0), kf3=e.wc_future_create(0), kf4=e.wc_future_create(0);
check('kernel future occupies one resolved slot', kf1!==0n && kf2!==0n && kf3!==0n && kf4===0n, `${kf1},${kf2},${kf3},${kf4}`);
e.wc_future_cancel(0,kf1); e.wc_future_release(0,kf1);
e.wc_future_cancel(0,kf2); e.wc_future_release(0,kf2);
e.wc_future_cancel(0,kf3); e.wc_future_release(0,kf3);
check('generic ECI result is opaque i64', lastDispatch && lastDispatch.op === 0 && lastDispatch.opcode === 1, JSON.stringify(lastDispatch));

const output = {
  pass: true,
  version: e.wc_version(),
  contract_bits: e.wc_application_contract_bits(),
  imports,
  dispatch_count: dispatchCount,
  last_dispatch: lastDispatch,
  exact_u64: exact.toString(),
  checks
};
console.log(JSON.stringify(output));
