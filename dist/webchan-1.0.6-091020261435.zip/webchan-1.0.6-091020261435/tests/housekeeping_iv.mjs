import fs from 'fs';
const [,, wasmPath, irPath, cPath] = process.argv;
if (!wasmPath || !irPath || !cPath) throw new Error('usage: housekeeping_iv.mjs wasm ir c');
const {instance}=await WebAssembly.instantiate(fs.readFileSync(wasmPath),{});
const e=instance.exports, ir=fs.readFileSync(irPath,'utf8'), c=fs.readFileSync(cPath,'utf8');
const checks=[]; function ck(name,ok,detail=''){checks.push({name,ok:!!ok,detail});if(!ok)throw new Error(`${name}: ${detail}`)}
const T_IV=2048, T_SENT=4096, T_OUT=8192;
const bits=Array.from({length:6},(_,i)=>e.wc_kernel_transform_bits(i)>>>0);
ck('medium gains IV canonicalization',!!(bits[0]&T_IV),bits[0]);
ck('medium gains modular sentinel',!!(bits[0]&T_SENT),bits[0]);
ck('medium passes selective outlining profitability',!!(bits[0]&T_OUT),bits[0]);
ck('tiny canonicalizes but stays inline',!!(bits[1]&T_IV)&&!!(bits[1]&T_SENT)&&!(bits[1]&T_OUT),bits[1]);
ck('large canonicalizes but avoids blanket outlining',!!(bits[2]&T_IV)&&!!(bits[2]&T_SENT)&&!(bits[2]&T_OUT),bits[2]);
ck('non-affine witness is not rewritten',!(bits[3]&T_IV),bits[3]);
ck('mutating-base witness is not rewritten',!(bits[4]&T_IV),bits[4]);
ck('local-limit proof-scope witness is conservatively not rewritten',!(bits[5]&T_IV),bits[5]);
function u32(x){return x>>>0}
function refMedium(base){let sum=0>>>0;for(let j=0;j<262144;j++){let i=(base+j)>>>0;let x=(Math.imul((i^0xa5a5a5a5)>>>0,1103515245)+12345)>>>0;sum=(sum+((x^(x>>>13))>>>0))>>>0;}return sum>>>0}
function refTiny(base){let sum=0>>>0;for(let j=0;j<64;j++){let i=(base+j)>>>0;sum=(sum+((i^21930)>>>0))>>>0;}return sum>>>0}
function refGray(base){let sum=0>>>0;for(let j=0;j<262144;j++){let i=(base+((j^(j>>>1))>>>0))>>>0;sum=(sum+((i^4660)>>>0))>>>0;}return sum>>>0}
function refMut(base){let sum=0>>>0;for(let j=0;j<262144;j++){let i=(base+j)>>>0;sum=(sum+i)>>>0;base=(base+1)>>>0;}return sum>>>0}
function refLocalLimit(base){let sum=0>>>0;for(let j=0;j<64;j++){let i=(base+j)>>>0;sum=(sum+((i^3855)>>>0))>>>0;}return sum>>>0}
const starts=[0,17,399000000,0xfff0bdc0,0xfff85ee0,0xfffffffe,0xffffffff];
for(const base0 of starts){const base=base0>>>0;e.wc_array_set(0,0,base);e.wc_kernel_run(0,1);const got=e.wc_array_get(1,0)>>>0,want=refMedium(base);ck(`medium exact at ${base}`,got===want,`${got}/${want}`)}
for(const [id,idx,ref,name] of [[1,1,refTiny,'tiny'],[3,3,refGray,'nonaffine'],[4,4,refMut,'mutating'],[5,5,refLocalLimit,'local-limit']]){for(const base of [0,0xffffffff]){e.wc_array_set(0,0,base);e.wc_kernel_run(id,1);const got=e.wc_array_get(1,idx)>>>0,want=ref(base>>>0);ck(`${name} exact at ${base>>>0}`,got===want,`${got}/${want}`)}}
const kernelLines=ir.split(/\n/).filter(x=>x.startsWith('kernel '));
ck('IR exposes all five probe kernels',kernelLines.length===6,kernelLines.length);
ck('generated medium uses sentinel inequality',/wc_kernel_0\(void\).*?!=__wc_iv_end_/s.test(c));
ck('generated medium is selectively outlined',/__attribute__\(\(noinline\)\) static void wc_kernel_0/.test(c));
ck('generated tiny remains inline',/\nstatic void wc_kernel_1/.test(c)&&!/__attribute__\(\(noinline\)\) static void wc_kernel_1/.test(c));
ck('generated non-affine preserves original loop IV',/wc_kernel_3\(void\).*?for\(uint32_t j=/s.test(c));
ck('generated mutating-base preserves original loop IV',/wc_kernel_4\(void\).*?for\(uint32_t j=/s.test(c));
ck('generated local-limit witness preserves original loop IV',/wc_kernel_5\(void\).*?for\(uint32_t j=/s.test(c));
console.log(JSON.stringify({checks:checks.length,passed:checks.filter(x=>x.ok).length,transform_bits:bits,wrap_starts:starts.map(u32)},null,2));
