import json, pathlib
root=pathlib.Path(__file__).resolve().parents[1]
def J(name): return json.loads((root/'results'/name).read_text())
val=(root/'results/VALIDATION.txt').read_text().splitlines()
passed=sum(x.startswith('PASS') for x in val); failed=sum(x.startswith('FAIL') for x in val)
surf=J('surface_equivalence.json'); sp=J('structural_passport_106.json'); wr=J('web_runtime_106.json'); dr=J('deferred_repair_106.json'); tl=J('topology_linear_bridge_106.json'); br=J('browser_runtime_106.json'); bw=J('browser_worker_106.json'); prov=J('optimization_provenance.json'); hk=J('housekeeping_iv.json')
text=f'''# Webchan 1.0.6 Fresh Validation Report

Build: `091020261435`

## Summary

- Validation: **{passed} PASS / {failed} FAIL**
- Negative compiler gates: **30/30**
- Housekeeping Optimization entries: **{prov.get('housekeepingCount')}**
- Luxury Optimization entries: **{prov.get('luxuryCount')}**
- Housekeeping IV probes: **{hk.get('passed')}/{hk.get('checks')}**

## Minimal Web Surface retained

The 1.0.5 concise and explicit forms remain equivalent in 1.0.6: **{surf.get('generated_files_byte_identical')}/7 generated files byte-identical**, scalar Wasm byte-identical = **{surf.get('scalar_wasm_byte_identical')}**, SIMD128 Wasm byte-identical = **{surf.get('simd128_wasm_byte_identical')}**. Source shrinks from {surf.get('explicit_nonblank_lines')} to {surf.get('minimal_nonblank_lines')} nonblank lines in the reference pair.

## Structural Passport

- Diagonal ordinary-kernel bits: `0x{sp.get('diagonalBits',0):x}`
- Stencil ordinary-kernel bits: `0x{sp.get('stencilBits',0):x}`
- Nonlinear negative bits: `0x{sp.get('nonlinearBits',0):x}`
- Resumable parity probe: {sp.get('resumeCalls')} calls for {sp.get('resumeUnits')} work units, exact-bit output parity verified.

Declared and ordinary forms receive the same solver permissions only when their proved properties match. The nonlinear witness receives no linear passport.

## Topology to linear proof bridge

All release graph Laplacians export typed linear bits `0x189` (linear + symmetric + static sparsity + matrix-free action). Their nullity equals topology `beta0`. SPD, strict diagonal dominance, positive-spectrum and solver permissions remain ungranted for the ungrounded Laplacian.

## Bounded web runtime

The stream stress probe transfers 200,000 bytes with a capacity of {wr.get('streamCapacity')} bytes. Peak occupancy is **{wr.get('maxStreamSize')} bytes** and backpressure waits = **{wr.get('stats',{}).get('backpressureWaits')}**.

Async start/completion/cancellation, stale-completion rejection, split UTF-8 decoding, incremental SSE framing and active-set-bounded FIFO event ingress all pass.

Deferred repair: first invalidation adds {dr.get('added1')} dirty task(s), a repeated invalidation adds {dr.get('added2')}, and repair restores the previous result with relative error **{dr.get('relativeError'):.3e}**.

## Chromium

Responsive heavy kernel:

- total units: {br.get('totalUnits')}
- slices: {br.get('slices')}
- maximum measured slice: {br.get('maxSliceMs'):.3f} ms
- responsive event-gap probe: {br.get('maxEventGapMs'):.3f} ms
- direct synchronous event-gap probe: {br.get('directEventGapMs'):.3f} ms
- DOM writes queued: {br.get('domQueued')}
- DOM writes committed after coalescing: {br.get('domCommitted')}

Optional Worker profile:

- total units: {bw.get('result',{}).get('totalUnits')}
- slices: {bw.get('result',{}).get('slices')}
- main-page timer ticks while Worker ran: {bw.get('ticks')}
- main-page maximum measured gap: {bw.get('maxGap'):.3f} ms

## Boundary

The responsive host measures time at compiler-generated resume boundaries. It is cooperative, not arbitrary preemptive interruption of a Wasm instruction. Opaque runtime data is not guessed into stronger mathematical structure. Proof failure remains an exact generic fallback.
'''
(root/'results/REPORT.md').write_text(text)
print(text)
