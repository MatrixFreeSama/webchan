import fs from 'fs';
import {performance} from 'perf_hooks';
const root=new URL('..',import.meta.url).pathname;
const wasmPath=process.argv[2]||`${root}/build/webchan_core.wasm`;
const bytes=fs.readFileSync(wasmPath),mod=await WebAssembly.compile(bytes);
const imports=WebAssembly.Module.imports(mod); if(imports.length)throw new Error('unexpected imports');
const {exports:e}=await WebAssembly.instantiate(mod,{});
function median(a){a=[...a].sort((x,y)=>x-y);return a[Math.floor(a.length/2)];}
function bench(fn,warm=3,samples=9){for(let i=0;i<warm;i++)fn();const a=[];for(let i=0;i<samples;i++){const t=performance.now();fn();a.push(performance.now()-t);}return {medianMs:median(a),minMs:Math.min(...a),maxMs:Math.max(...a)};}
const fnId=0, reps=500000;
const oneOpt=e.wc_eval_fn(fnId,.25,.375,7,2), oneRef=e.wc_eval_fn_reference(fnId,.25,.375,7,2);
const opt=bench(()=>e.wc_bench_fn_chain(fnId,0,reps));
const ref=bench(()=>e.wc_bench_fn_chain(fnId,1,reps));
const functionCollapse={id:fnId,bits:e.wc_fn_structural_bits(fnId),originalOps:e.wc_fn_original_ops(fnId).toString(),collapsedOps:e.wc_fn_collapsed_ops(fnId).toString(),oneCallAbsDiff:Math.abs(oneOpt-oneRef),reps,optimized:opt,reference:ref,speedup:ref.medianMs/opt.medianMs};
const n=e.wc_array_len(2);function fill(){for(let i=0;i<n;i++)e.wc_array_set(2,i,1+(i%17)*0.01);}
const methodNames={1:'dense-gaussian',2:'banded-gaussian',3:'krylov-cg',4:'chebyshev',5:'jacobi',6:'gauss-seidel',7:'weighted-jacobi',8:'forward-substitution',9:'back-substitution',10:'diagonal-direct'};
const bitFor={2:1,3:2,4:4,5:8,6:16,7:32,8:64,9:128,10:256};
function solverBench(sid,methods,reps=20){const out={proofBits:e.wc_solve_proof_bits(sid),chosen:e.wc_solve_chosen(sid),methods:{}};for(const m of methods){if(m!==1 && !(out.proofBits&bitFor[m]))continue;fill();for(let k=0;k<3;k++)e.wc_solve(sid,m);const b=bench(()=>{for(let r=0;r<reps;r++)e.wc_solve(sid,m);},0,7);fill();const it=e.wc_solve(sid,m),res=e.wc_solve_residual(sid);out.methods[methodNames[m]]={...b,perSolveMs:b.medianMs/reps,iters:it,residual:res,estimated:e.wc_solve_estimated(sid,m).toString()};}return out;}
const solvers={
  spd:solverBench(0,[1,2,3,4,5,6,7,0].filter(x=>x!==0),20),
  nonsymmetricDD:solverBench(1,[1,2,5,6],20),
  lowerTriangular:solverBench(2,[1,2,5,6,8],20),
  diagonal:solverBench(3,[1,2,5,6,8,9,10],20)
};
for(const v of Object.values(solvers)){const chosenName=methodNames[v.chosen];if(chosenName&&v.methods[chosenName])v.autoVsDenseSpeedup=v.methods['dense-gaussian'].perSolveMs/v.methods[chosenName].perSolveMs;}
console.log(JSON.stringify({imports:imports.length,functionCollapse,solvers},null,2));
