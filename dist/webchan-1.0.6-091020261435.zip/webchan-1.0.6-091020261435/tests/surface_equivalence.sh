#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EXP="$ROOT/generated_surface_explicit"
MIN="$ROOT/generated_surface_minimal"
rm -rf "$EXP" "$MIN" "$ROOT/build/surface_explicit"* "$ROOT/build/surface_minimal"*
mkdir -p "$EXP" "$MIN" "$ROOT/results"
"$ROOT/build/webchanc" "$ROOT/tests/surface/explicit.webchan" "$EXP"
"$ROOT/build/webchanc" "$ROOT/tests/surface/minimal.webchan" "$MIN"
FILES=(webchan_program.c webchan_program.h program.webir procedural_fields.glsl external_capabilities.json webchan_eci_native.c target_profiles.json)
for f in "${FILES[@]}"; do cmp "$EXP/$f" "$MIN/$f"; done
"$ROOT/tools/build_wasm_profiles.sh" "$EXP" "$ROOT/build/surface_explicit" core >/dev/null
"$ROOT/tools/build_wasm_profiles.sh" "$MIN" "$ROOT/build/surface_minimal" core >/dev/null
cmp "$ROOT/build/surface_explicit.scalar.wasm" "$ROOT/build/surface_minimal.scalar.wasm"
cmp "$ROOT/build/surface_explicit.simd128.wasm" "$ROOT/build/surface_minimal.simd128.wasm"
exp_lines=$(grep -cv '^[[:space:]]*$' "$ROOT/tests/surface/explicit.webchan")
min_lines=$(grep -cv '^[[:space:]]*$' "$ROOT/tests/surface/minimal.webchan")
exp_bytes=$(wc -c < "$ROOT/tests/surface/explicit.webchan")
min_bytes=$(wc -c < "$ROOT/tests/surface/minimal.webchan")
scalar_sha=$(sha256sum "$ROOT/build/surface_minimal.scalar.wasm" | awk '{print $1}')
simd_sha=$(sha256sum "$ROOT/build/surface_minimal.simd128.wasm" | awk '{print $1}')
printf '{"generated_files_byte_identical":7,"scalar_wasm_byte_identical":true,"simd128_wasm_byte_identical":true,"minimal_surface_equivalence_preserved":true,"explicit_nonblank_lines":%s,"minimal_nonblank_lines":%s,"explicit_bytes":%s,"minimal_bytes":%s,"scalar_sha256":"%s","simd128_sha256":"%s"}\n' "$exp_lines" "$min_lines" "$exp_bytes" "$min_bytes" "$scalar_sha" "$simd_sha" | tee "$ROOT/results/surface_equivalence.json"
