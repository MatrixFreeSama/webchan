import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
const p=process.argv[2];
const bytes=fs.readFileSync(p);const mod=await WebAssembly.compile(bytes);const {exports:e}=await WebAssembly.instantiate(mod,{});
const A={kernelIn:4,kernelOut:5,kernelScan:6,kernelPerm:7,re:8,im:9,tmpRe:10,tmpIm:11};
const N=1024;
for(let i=0;i<N;i++)e.wc_array_set(A.kernelIn,i,i+1);
e.wc_kernel_run(0,1);let elementwiseErr=0;for(let i=0;i<N;i++)elementwiseErr=Math.max(elementwiseErr,Math.abs(e.wc_array_get(A.kernelOut,i)-(1.75*(i+1)+0.25)));
e.wc_kernel_run(1,1);let neighborErr=0;for(let i=1;i<1023;i++){let want=.25*i+.5*(i+1)+.25*(i+2);neighborErr=Math.max(neighborErr,Math.abs(e.wc_array_get(A.kernelOut,i)-want));}
e.wc_kernel_run(2,1);const scanLast=e.wc_array_get(A.kernelScan,N-1),scanExpected=N*(N+1)/2;
e.wc_kernel_run(3,1);function rev32(x){x=(((x&0x55555555)<<1)|((x>>>1)&0x55555555))>>>0;x=(((x&0x33333333)<<2)|((x>>>2)&0x33333333))>>>0;x=(((x&0x0f0f0f0f)<<4)|((x>>>4)&0x0f0f0f0f))>>>0;x=(((x&0x00ff00ff)<<8)|((x>>>8)&0x00ff00ff))>>>0;return ((x<<16)|(x>>>16))>>>0;}let permErr=0;for(let i=0;i<N;i++)permErr=Math.max(permErr,Math.abs(e.wc_array_get(A.kernelPerm,rev32(i)>>>22)-(i+1)));
e.wc_kernel_run(4,1);let tileErr=0;for(let i=0;i<N;i++)tileErr=Math.max(tileErr,Math.abs(e.wc_array_get(A.kernelOut,i)-(i+1)));
// Generic staged radix-2 probe: impulse must transform to all ones.
for(let i=0;i<N;i++){e.wc_array_set(A.re,i,i===0?1:0);e.wc_array_set(A.im,i,0);e.wc_array_set(A.tmpRe,i,0);e.wc_array_set(A.tmpIm,i,0);}e.wc_kernel_run(5,1);let fftImpulseErr=0;for(let i=0;i<N;i++)fftImpulseErr=Math.max(fftImpulseErr,Math.abs(e.wc_array_get(A.tmpRe,i)-1),Math.abs(e.wc_array_get(A.tmpIm,i)));
// Complex tone gives one spectral spike. This also exercises zero-import sin/cos lowering.
const tone=7;for(let i=0;i<N;i++){let a=2*Math.PI*tone*i/N;e.wc_array_set(A.re,i,Math.cos(a));e.wc_array_set(A.im,i,Math.sin(a));e.wc_array_set(A.tmpRe,i,0);e.wc_array_set(A.tmpIm,i,0);}e.wc_kernel_run(5,1);let peakRe=e.wc_array_get(A.tmpRe,tone),peakIm=e.wc_array_get(A.tmpIm,tone),fftPeakErr=Math.hypot(peakRe-N,peakIm),fftMaxLeak=0;for(let i=0;i<N;i++)if(i!==tone)fftMaxLeak=Math.max(fftMaxLeak,Math.hypot(e.wc_array_get(A.tmpRe,i),e.wc_array_get(A.tmpIm,i)));
const meta=[];for(let id=0;id<e.wc_kernel_count();id++)meta.push({id,bound:String(e.wc_kernel_bound(id)),extent:String(e.wc_kernel_extent(id)),depth:e.wc_kernel_depth(id),proofBits:e.wc_kernel_proof_bits(id),transformBits:e.wc_kernel_transform_bits(id)});
for(let i=0;i<N;i++)e.wc_array_set(A.kernelIn,i,(i&31)*.125);for(let r=0;r<5;r++)e.wc_kernel_run(0,1);let ts=[];for(let r=0;r<21;r++){let t=performance.now();e.wc_kernel_run(0,2000);ts.push((performance.now()-t)/2000);}ts.sort((a,b)=>a-b);
const out={imports:WebAssembly.Module.imports(mod).length,count:e.wc_kernel_count(),meta,correctness:{elementwiseErr,neighborErr,scanLast,scanExpected,permErr,tileErr,fftImpulseErr,fftPeakErr,fftMaxLeak},elementwiseMedianMs:ts[Math.floor(ts.length/2)]};
console.log(JSON.stringify(out));
