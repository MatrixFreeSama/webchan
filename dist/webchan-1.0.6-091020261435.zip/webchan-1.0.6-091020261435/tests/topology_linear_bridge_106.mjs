import fs from 'node:fs';
const [wasmPath,irPath]=process.argv.slice(2);
const {instance}=await WebAssembly.instantiate(fs.readFileSync(wasmPath),{});
const e=instance.exports, ir=fs.readFileSync(irPath,'utf8'), checks={};
const ck=(name,ok,detail='')=>{checks[name]={pass:!!ok,detail:String(detail)};if(!ok)throw new Error(`${name}: ${detail}`)};
const REQUIRED=1|8|128|256; // linear, symmetric, static sparsity, matrix-free
const FORBIDDEN=2|4|16|32|64; // diagonal, banded, strict-DD, SPD, positive-spectrum
const rows=[];
for(let i=0;i<e.wc_topology_count();i++){
  const bits=e.wc_topology_laplacian_linear_bits(i), beta0=e.wc_topology_beta0(i), nullity=e.wc_topology_laplacian_nullity(i);
  rows.push({id:i,bits,beta0,nullity});
  ck(`topology ${i} Laplacian enters typed linear namespace`,(bits&REQUIRED)===REQUIRED,`bits=0x${bits.toString(16)}`);
  ck(`topology ${i} Laplacian does not overclaim SPD/solver preconditions`,(bits&FORBIDDEN)===0,`bits=0x${bits.toString(16)}`);
  ck(`topology ${i} Laplacian nullity reuses component proof`,nullity===beta0,`${nullity} vs ${beta0}`);
}
ck('invalid topology has no linear passport',e.wc_topology_laplacian_linear_bits(e.wc_topology_count()+7)===0,'invalid-id');
ck('IR records cross-domain linear passport',ir.includes('source=topology-laplacian'),'IR marker');
ck('IR keeps ungrounded Laplacian solver locked',ir.includes('source=topology-laplacian')&&ir.includes('spd=unproven')&&ir.includes('solver_unlock=0x0'),'no false solver grant');
console.log(JSON.stringify({checks,rows}));
