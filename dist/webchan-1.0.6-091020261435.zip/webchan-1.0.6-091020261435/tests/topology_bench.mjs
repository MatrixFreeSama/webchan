import fs from 'fs';
import {performance} from 'perf_hooks';
const wasmPath=process.argv[2]||new URL('../build/webchan_core.wasm',import.meta.url).pathname;
const bytes=fs.readFileSync(wasmPath),mod=await WebAssembly.compile(bytes);const {exports:e}=await WebAssembly.instantiate(mod,{});
function median(a){const b=[...a].sort((x,y)=>x-y);return b[(b.length/2)|0]}
function benchPlan(id,pruned,reps=8000){for(let i=0;i<4;i++)e.wc_plan_bench(id,pruned,200);const times=[];let checksum=0n;for(let s=0;s<13;s++){const t=performance.now();checksum=e.wc_plan_bench(id,pruned,reps);times.push(performance.now()-t);}return {medianMs:median(times),samplesMs:times,reps,checksum:checksum.toString()};}
const topologyCount=e.wc_topology_count();
const topologies=Array.from({length:topologyCount},(_,i)=>({id:i,vertices:e.wc_topology_vertices(i),edges:e.wc_topology_edges(i),beta0:e.wc_topology_beta0(i),beta1:e.wc_topology_beta1(i),euler:e.wc_topology_euler(i),proofBits:e.wc_topology_proof_bits(i),bridges:e.wc_topology_bridges(i),articulations:e.wc_topology_articulations(i),freeGroupRank:e.wc_topology_free_group_rank(i),incidenceRank:e.wc_topology_incidence_rank(i),laplacianNullity:e.wc_topology_laplacian_nullity(i),laplacianProofBits:e.wc_topology_laplacian_proof_bits(i)}));
const complexCount=e.wc_complex_count();
const complexes=Array.from({length:complexCount},(_,i)=>({id:i,beta:[0,1,2].map(d=>e.wc_complex_beta(i,d)),euler:e.wc_complex_euler(i),proofBits:e.wc_complex_proof_bits(i),collapseSteps:e.wc_complex_collapse_steps(i)}));
const planCount=e.wc_plan_count();
const plans=[];
for(let i=0;i<planCount;i++){
  const len=e.wc_plan_path_len(i); const wordLen=e.wc_plan_homotopy_word_len(i);
  plans.push({id:i,path:Array.from({length:len},(_,k)=>e.wc_plan_path_vertex(i,k)),rank:e.wc_plan_rank(i),cost:e.wc_plan_cost(i),fullExpansions:e.wc_plan_full_expansions(i),topoExpansions:e.wc_plan_topo_expansions(i),prunedVertices:e.wc_plan_pruned_vertices(i),homotopyWord:Array.from({length:wordLen},(_,k)=>e.wc_plan_homotopy_letter(i,k))});
}
const full=benchPlan(0,0),pruned=benchPlan(0,1);
const rankedFull=benchPlan(1,0,20000),rankedPruned=benchPlan(1,1,20000);
console.log(JSON.stringify({topologyCount,topologies,complexCount,complexes,planCount,plans,plannerBenchmark:{full,pruned,speedup:full.medianMs/pruned.medianMs,semanticChecksumEqual:full.checksum===pruned.checksum,expansionReduction:plans[0].fullExpansions/plans[0].topoExpansions},rankedHomotopyBenchmark:{full:rankedFull,pruned:rankedPruned,semanticChecksumEqual:rankedFull.checksum===rankedPruned.checksum}},null,2));
