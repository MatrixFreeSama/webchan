import json, pathlib, re
root=pathlib.Path(__file__).resolve().parents[1]
manifest=json.loads((root/'docs/OPTIMIZATION_PROVENANCE.json').read_text())
manifesto=(root/'docs/WEBCHAN_MANIFESTO.md').read_text().lower()
compiler=(root/'compiler/webchanc.c').read_text().lower()
ivopt=(root/'compiler/iteration_support.inc').read_text().lower()
errors=[]
if manifest.get('policy')!='housekeeping-or-webchan-original-luxury-only': errors.append('policy')
if not manifest.get('housekeeping'): errors.append('housekeeping-empty')
for item in ['induction-variable-canonicalization-and-elimination','modular-sentinel-induction-for-proved-u32-loops','profitability-gated-selective-kernel-outlining']:
    if item not in manifest.get('housekeeping',[]): errors.append('missing-housekeeping:'+item)
if not manifest.get('luxury'): errors.append('luxury-empty')
if manifest.get('external_distinctive_advanced_optimization')!='reject': errors.append('external-advanced-policy')
for phrase in ['housekeeping optimization','luxury optimization','benchmarks are probes, never teachers']:
    if phrase not in manifesto: errors.append('manifesto:'+phrase)
# Motivating product/opponent identities are forbidden in compiler logic.
for token in ['deepseek','moonbit','chatgpt','typedarray','onedrive','openai']:
    if token in compiler: errors.append('compiler-identity:'+token)
for token in ['deepseek','moonbit','javascript','typedarray','browser','benchmark','chunk_work','whole_work','openai','onedrive']:
    if token in ivopt: errors.append('iv-optimizer-identity:'+token)
# Probe admission must require independent witness + negative witness.
probe=manifest.get('probe_admission',{})
if probe.get('required_evidence') != ['origin_probe','cross_domain_witness','negative_witness']:
    errors.append('probe-evidence')
out={'ok':not errors,'errors':errors,'housekeepingCount':len(manifest.get('housekeeping',[])),'luxuryCount':len(manifest.get('luxury',[])),'compilerIdentityLeak':False if not errors else any(x.startswith('compiler-identity:') for x in errors)}
print(json.dumps(out))
if errors: raise SystemExit(1)
