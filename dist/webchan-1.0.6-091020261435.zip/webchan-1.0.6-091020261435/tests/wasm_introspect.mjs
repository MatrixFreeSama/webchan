import path from 'node:path';
import fs from 'fs';
const p=process.argv[2];const out=process.argv[3];const bytes=fs.readFileSync(p);const m=await WebAssembly.compile(bytes);
const obj={file:path.basename(p),bytes:bytes.length,imports:WebAssembly.Module.imports(m),exports:WebAssembly.Module.exports(m)};
fs.writeFileSync(out,JSON.stringify(obj,null,2));console.log(JSON.stringify(obj,null,2));
