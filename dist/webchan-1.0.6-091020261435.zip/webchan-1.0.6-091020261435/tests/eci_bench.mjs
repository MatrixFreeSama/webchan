import fs from 'node:fs';
const [,, wasmPath, manifestPath, nativePath] = process.argv;
const bytes=fs.readFileSync(wasmPath); const mod=new WebAssembly.Module(bytes);
let calls=[];
const inst=new WebAssembly.Instance(mod,{webchan_eci:{dispatch:(op,opcode,a0,a1)=>{calls.push([op,opcode,a0.toString(),a1.toString()]);return BigInt(opcode)+a0+a1;},async_start:()=>0n,async_cancel:()=>0}});
const e=inst.exports; const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8')); const native=JSON.parse(fs.readFileSync(nativePath,'utf8'));
const allLo=0xffffffff>>>0, allHi=0xffffffff>>>0;
const capId=name=>manifest.capabilities.find(x=>x.name===name).id;
const selected={
 nativeFilesystem:e.wc_eci_select(capId('filesystem.read'),1,allLo,allHi),
 nativeTcp:e.wc_eci_select(capId('network.tcp'),1,allLo,allHi),
 nativeGpu:e.wc_eci_select(capId('gpu.compute'),1,allLo,allHi),
 browserTcp:e.wc_eci_select(capId('network.tcp'),4,allLo,allHi),
 browserGpu:e.wc_eci_select(capId('gpu.compute'),4,allLo,allHi),
 wasiFilesystem:e.wc_eci_select(capId('filesystem.read'),8,allLo,allHi),
 nicDriverFallback:e.wc_eci_select(capId('nic.packet_io'),1,1<<(19),0)
};
const callResult=e.wc_eci_call(7,11n,13n);
const nativeRequired={};
for(const c of manifest.capabilities.filter(x=>x.required)) nativeRequired[c.name]=e.wc_eci_select(c.id,1,native.availableLo,native.availableHi);
const out={imports:WebAssembly.Module.imports(mod),exports:WebAssembly.Module.exports(mod).filter(x=>x.name.startsWith('wc_eci')).map(x=>x.name),capabilityCount:e.wc_eci_capability_count(),opCount:e.wc_eci_op_count(),selected,callResult:callResult.toString(),dispatchCalls:calls,native,nativeRequired};
console.log(JSON.stringify(out));
