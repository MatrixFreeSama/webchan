import fs from 'fs';
import {performance} from 'perf_hooks';
const root=new URL('..',import.meta.url).pathname;
const wasmPath=process.argv[2]||`${root}/build/webchan_core.wasm`;
const bytes=fs.readFileSync(wasmPath),mod=await WebAssembly.compile(bytes);
const imports=WebAssembly.Module.imports(mod); if(imports.length)throw new Error('unexpected imports');
const {exports:e}=await WebAssembly.instantiate(mod,{});
const sid=0,n=e.wc_array_len(2); if(n!==256)throw new Error(`unexpected solve size ${n}`);
function fill(){for(let i=0;i<n;i++)e.wc_array_set(2,i,1+(i%17)*0.01);}
function capture(){const a=new Float64Array(n);for(let i=0;i<n;i++)a[i]=e.wc_array_get(3,i);return a;}
function diff(a,b){let m=0;for(let i=0;i<a.length;i++)m=Math.max(m,Math.abs(a[i]-b[i]));return m;}
const methods=[['dense-gaussian',1],['banded-gaussian',2],['krylov-cg',3],['chebyshev-semi',4],['jacobi',5],['gauss-seidel',6],['weighted-jacobi',7],['proof-auto',0]];
let baseline=null;const out={imports:imports.length,n,proofBits:e.wc_solve_proof_bits(sid),chosen:e.wc_solve_chosen(sid),estimated:{}};
for(let m=1;m<=10;m++)out.estimated[m]=e.wc_solve_estimated(sid,m).toString();
out.methods={};
for(const [name,method] of methods){
  fill(); for(let w=0;w<4;w++)e.wc_solve(sid,method);
  const reps=method===1?20:50,samples=[];let iters=0;
  for(let s=0;s<9;s++){const t0=performance.now();for(let r=0;r<reps;r++)iters=e.wc_solve(sid,method);samples.push((performance.now()-t0)/reps);}
  samples.sort((a,b)=>a-b);const median=samples[4];
  fill();iters=e.wc_solve(sid,method);const residual=e.wc_solve_residual(sid),sol=capture();if(method===1)baseline=sol;
  out.methods[name]={medianMs:median,minMs:samples[0],maxMs:samples.at(-1),residual,iters,maxAbsDiffVsDense:baseline?diff(sol,baseline):0};
}
for(const k of ['banded-gaussian','krylov-cg','chebyshev-semi','jacobi','gauss-seidel','weighted-jacobi','proof-auto'])out['speedup_'+k]=out.methods['dense-gaussian'].medianMs/out.methods[k].medianMs;
console.log(JSON.stringify(out,null,2));
