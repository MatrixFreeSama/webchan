import fs from 'fs'; import {performance} from 'perf_hooks';
async function load(path){const bytes=fs.readFileSync(path),mod=await WebAssembly.compile(bytes);const {exports:e}=await WebAssembly.instantiate(mod,{});return {path,mod,e,imports:WebAssembly.Module.imports(mod).length};}
function med(a){const b=[...a].sort((x,y)=>x-y);return b[Math.floor(b.length/2)];}
function t(fn){const s=performance.now();const v=fn();return [performance.now()-s,v];}
function meta(o){const e=o.e,n=e.wc_field_count();return {imports:o.imports,memoryBytes:e.memory.buffer.byteLength,mode:e.wc_memory_mode(),fields:Array.from({length:n},(_,i)=>({len:e.wc_field_len(i),repr:e.wc_field_repr(i),proof:e.wc_field_proof_bits(i),ops:e.wc_field_reconstruct_ops(i),logical:Number(e.wc_field_logical_bytes(i)),stored:Number(e.wc_field_stored_bytes(i)),saved:Number(e.wc_field_saved_bytes(i))}))};}
const mf=await load(process.argv[2]), dense=await load(process.argv[3]);
let [mfInit]=t(()=>mf.e.wc_memory_init()), [denseInit]=t(()=>dense.e.wc_memory_init());
const probes=[];for(const i of [0,1,7,12345,3999999]){probes.push({i,mf0:mf.e.wc_field_get(0,i),dense0:dense.e.wc_field_get(0,i),mf1:mf.e.wc_field_get(1,i),dense1:dense.e.wc_field_get(1,i)});}
function samples(o,id,rounds=9){o.e.wc_field_checksum(id,1);let xs=[],last=0;for(let r=0;r<rounds;r++){let [dt,v]=t(()=>o.e.wc_field_checksum(id,1));xs.push(dt);last=v;}return {medianMs:med(xs),samples:xs,checksum:last};}
function pair(o,rounds=9){o.e.wc_field_pair_checksum(0,1,4000000);let xs=[],last=0;for(let r=0;r<rounds;r++){let [dt,v]=t(()=>o.e.wc_field_pair_checksum(0,1,4000000));xs.push(dt);last=v;}return {medianMs:med(xs),samples:xs,checksum:last};}
const mf0=samples(mf,0),d0=samples(dense,0),mf1=samples(mf,1),d1=samples(dense,1),mfp=pair(mf),dp=pair(dense);
const count=mf.e.wc_field_materialize(0,100000,4096);let maxScratchErr=0;for(let k=0;k<count;k++){let a=mf.e.wc_field_scratch_get(k),b=mf.e.wc_field_get(0,100000+k);maxScratchErr=Math.max(maxScratchErr,Math.abs(a-b));}
console.log(JSON.stringify({matrixFree:{...meta(mf),initMs:mfInit,field0:mf0,field1:mf1,pair:mfp},dense:{...meta(dense),initMs:denseInit,field0:d0,field1:d1,pair:dp},probes,maxScratchErr,memoryRatio:mf.e.memory.buffer.byteLength/dense.e.memory.buffer.byteLength,logicalStoredRatio:Number(mf.e.wc_field_stored_bytes(0)+mf.e.wc_field_stored_bytes(1)+mf.e.wc_field_stored_bytes(2))/Number(mf.e.wc_field_logical_bytes(0)+mf.e.wc_field_logical_bytes(1)+mf.e.wc_field_logical_bytes(2))},null,2));
