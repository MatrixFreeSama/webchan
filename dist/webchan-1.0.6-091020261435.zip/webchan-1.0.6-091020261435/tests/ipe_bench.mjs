import fs from 'fs';
import {performance} from 'perf_hooks';
const wasmPath=process.argv[2]||new URL('../build/webchan_core.wasm',import.meta.url).pathname;
const bytes=fs.readFileSync(wasmPath);const mod=await WebAssembly.compile(bytes);const {exports:e}=await WebAssembly.instantiate(mod,{});
function median(a){const b=[...a].sort((x,y)=>x-y);return b[(b.length/2)|0]}
function bench(id,opt,reps){for(let i=0;i<4;i++)e.wc_ipe_bench(id,opt,Math.max(1,Math.floor(reps/10)));const t=[];let checksum=0n;for(let s=0;s<11;s++){const a=performance.now();checksum=e.wc_ipe_bench(id,opt,reps);t.push(performance.now()-a);}return {medianMs:median(t),samplesMs:t,reps,checksum:checksum.toString()};}
const count=e.wc_ipe_count();
const meta=Array.from({length:count},(_,id)=>{const serial=e.wc_ipe_serial_nodes(id);return {id,proofBits:e.wc_ipe_proof_bits(id),originalNodes:e.wc_ipe_original_nodes(id),serialNodes:serial,eliminatedOrchestration:e.wc_ipe_eliminated_orchestration(id),scalarizedWorkerSlots:e.wc_ipe_scalarized_worker_slots(id),fusedPartitions:e.wc_ipe_fused_partitions(id),partitionBoundariesRemoved:e.wc_ipe_partition_boundaries_removed(id),schedule:Array.from({length:serial===1?0:serial},(_,k)=>e.wc_ipe_schedule_node(id,k))};});
const reps=[20000,300,20];const grainNames=['fine','medium','coarse'];const grains=[];
for(let id=0;id<Math.min(3,count);id++){
  const naive=bench(id,0,reps[id]),optimized=bench(id,1,reps[id]);
  grains.push({id,name:grainNames[id],naive,optimized,speedup:naive.medianMs/optimized.medianMs,semanticChecksumEqual:naive.checksum===optimized.checksum});
}
console.log(JSON.stringify({imports:WebAssembly.Module.imports(mod).length,count,meta,grains},null,2));
