import fs from 'fs';
const [scalarPath, simdPath, metaPath] = process.argv.slice(2);
const sb = fs.readFileSync(scalarPath), vb = fs.readFileSync(simdPath), meta = JSON.parse(fs.readFileSync(metaPath,'utf8'));
const scalar = (await WebAssembly.instantiate(sb,{})).instance.exports;
const simd = (await WebAssembly.instantiate(vb,{})).instance.exports;
function fill(e, seed){ for(let i=0;i<8192;i++) e.wc_array_set_bits(0,i,BigInt(((Math.imul(i+17,2654435761)>>>0)^seed)>>>0)); }
fill(scalar,0x13579bdf); fill(simd,0x13579bdf);
scalar.wc_kernel_run(0,7); simd.wc_kernel_run(0,7);
let mismatch=0, checksum=0n;
for(let i=0;i<8192;i++){
  const a=scalar.wc_array_get_bits(0,i), b=simd.wc_array_get_bits(0,i);
  if(a!==b) mismatch++;
  checksum=(checksum + (a ^ BigInt(i))) & 0xffffffffffffffffn;
}
const out={versionScalar:scalar.wc_version(),versionSimd:simd.wc_version(),mismatch,checksum:'0x'+checksum.toString(16),metadata:meta,scalarValid:WebAssembly.validate(sb),simdValid:WebAssembly.validate(vb)};
if(out.versionScalar!==0x010006 || out.versionSimd!==0x010006 || mismatch || !meta.source_semantics_identical || meta.variants?.[0]?.id!=='simd128' || meta.variants?.[1]?.id!=='scalar') throw new Error(JSON.stringify(out));
console.log(JSON.stringify(out));
