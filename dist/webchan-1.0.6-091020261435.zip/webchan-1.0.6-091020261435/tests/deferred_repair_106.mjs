import fs from 'node:fs';
const wasmPath=process.argv[2];
const {instance}=await WebAssembly.instantiate(fs.readFileSync(wasmPath),{});
const e=instance.exports, checks={};
const ck=(name,ok,detail='')=>{checks[name]={pass:!!ok,detail:String(detail)};if(!ok)throw new Error(`${name}: ${detail}`)};
e.wc_reset(12345);
let guard=0;while(!e.wc_done()){e.wc_step(e.wc_max_step_units(),0.25);if(++guard>1000000)throw new Error('initial run did not terminate');}
const before=e.wc_accumulator(), doneBefore=e.wc_done_count(), leaf=e.wc_task_count()-1;
const added1=e.wc_defer_invalidate(leaf), dirty1=e.wc_deferred_dirty_count();
const added2=e.wc_defer_invalidate(leaf), dirty2=e.wc_deferred_dirty_count();
ck('first deferred invalidation records affected cone',added1>0,`added=${added1}`);
ck('repeated invalidation is coalesced',added2===0&&dirty2===dirty1,`added2=${added2} dirty=${dirty1}->${dirty2}`);
ck('completed state is not destroyed before repair commit',e.wc_done()===1&&e.wc_done_count()===doneBefore,`${e.wc_done_count()}/${doneBefore}`);
const applied=e.wc_apply_deferred_repairs();
ck('repair commit applies each dirty task once',applied===dirty1,`applied=${applied} dirty=${dirty1}`);
ck('dirty set clears after repair commit',e.wc_deferred_dirty_count()===0,e.wc_deferred_dirty_count());
ck('committed repair reopens only affected work',e.wc_done()===0&&e.wc_done_count()===doneBefore-applied,`${e.wc_done_count()}/${doneBefore}`);
guard=0;while(!e.wc_done()){e.wc_step(e.wc_max_step_units(),0.25);if(++guard>1000000)throw new Error('repair rerun did not terminate');}
const after=e.wc_accumulator(), rel=Math.abs(after-before)/Math.max(1,Math.abs(before));
ck('deferred repair recomputation restores semantics',rel<1e-12,`relative=${rel}`);
console.log(JSON.stringify({checks,leaf,added1,added2,dirty1,applied,before,after,relativeError:rel}));
