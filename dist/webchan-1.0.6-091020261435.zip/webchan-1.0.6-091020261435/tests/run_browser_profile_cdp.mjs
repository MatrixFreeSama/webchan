import fs from 'fs'; import {spawn} from 'child_process'; import path from 'path';
const root=path.resolve(new URL('..',import.meta.url).pathname),port=9597,prof=fs.mkdtempSync('/tmp/webchan-profile-');
const chrome=spawn('/usr/bin/chromium',['--headless=new','--no-sandbox','--disable-gpu','--disable-background-timer-throttling','--disable-renderer-backgrounding',`--remote-debugging-port=${port}`,`--user-data-dir=${prof}`,'about:blank'],{stdio:['ignore','ignore','ignore']});
const delay=ms=>new Promise(r=>setTimeout(r,ms)); async function j(u){return(await fetch(u)).json()} async function wait(){for(let i=0;i<120;i++){try{return await j(`http://127.0.0.1:${port}/json`)}catch{} await delay(100)}throw Error('CDP unavailable')}
let ws; try{
 const page=(await wait()).find(x=>x.type==='page'); ws=new WebSocket(page.webSocketDebuggerUrl); await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j}); let id=0,p=new Map();
 ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&p.has(m.id)){const x=p.get(m.id);p.delete(m.id);m.error?x.j(m.error):x.r(m.result)}};
 const cdp=(method,params={})=>{const k=++id;ws.send(JSON.stringify({id:k,method,params}));return new Promise((r,j)=>p.set(k,{r,j}))};
 async function ev(expression,awaitPromise=true){const z=await cdp('Runtime.evaluate',{expression,awaitPromise,returnByValue:true});if(z.exceptionDetails)throw Error(JSON.stringify(z.exceptionDetails));return z.result.value}
 const loader=fs.readFileSync(path.join(root,'host/wasm_profile_loader.js'),'utf8');
 const sb64=fs.readFileSync(path.join(root,'build/webchan_profile_probe.scalar.wasm')).toString('base64');
 const vb64=fs.readFileSync(path.join(root,'build/webchan_profile_probe.simd128.wasm')).toString('base64');
 await ev(loader,false);
 const out=await ev(`(async()=>{const dec=s=>{const b=atob(s),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u};const s=dec(${JSON.stringify(sb64)}),v=dec(${JSON.stringify(vb64)});const best=await WebchanWasmProfiles.instantiateBestWebchanProfile({scalarBytes:s,simd128Bytes:v});const forced=await WebchanWasmProfiles.instantiateBestWebchanProfile({scalarBytes:s,simd128Bytes:v,forceScalar:true});const bad=v.slice();bad[1]=0;const fb=await WebchanWasmProfiles.instantiateBestWebchanProfile({scalarBytes:s,simd128Bytes:bad});return {best:best.profile,forced:forced.profile,fallback:fb.profile,fallbackUsed:fb.fallbackUsed,version:best.instance.exports.wc_version(),simdValid:WebAssembly.validate(v),scalarValid:WebAssembly.validate(s)}})()`);
 if(out.best!=='simd128'||out.forced!=='scalar'||out.fallback!=='scalar'||!out.fallbackUsed||out.version!==0x010006) throw Error(JSON.stringify(out));
 fs.writeFileSync(path.join(root,'results/browser_target_profile.json'),JSON.stringify(out,null,2)); console.log(JSON.stringify(out));
} finally {try{ws&&ws.close()}catch{} chrome.kill('SIGTERM')}
