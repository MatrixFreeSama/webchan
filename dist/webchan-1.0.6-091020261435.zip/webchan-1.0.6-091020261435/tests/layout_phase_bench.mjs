import fs from 'node:fs';
const bytes=fs.readFileSync(process.argv[2]);
const mod=await WebAssembly.compile(bytes);const {exports:e}=await WebAssembly.instantiate(mod,{});
const N=65536;
const meta=[];
for(let id=0;id<3;id++)meta.push({
  id,kind:e.wc_array_layout_kind(id),score:e.wc_array_layout_score(id),
  profit:e.wc_array_layout_profit(id),phaseCoverage:e.wc_array_layout_phase_coverage(id),
  streamRatio:e.wc_array_layout_stream_ratio(id),reasonBits:e.wc_array_layout_reason_bits(id)
});
for(let i=0;i<N;i++)e.wc_array_set(0,i,Math.sin(i*.001)*.5+i*1e-6);
e.wc_kernel_run(0,2);
const samples=[1,7,127,4096,32768,65534].map(i=>e.wc_array_get(0,i));
const ir=fs.readFileSync(process.argv[3],'utf8');
console.log(JSON.stringify({imports:WebAssembly.Module.imports(mod).length,meta,samples,irHasReject:ir.includes('layout_reject logical_array=stream_a')&&ir.includes('access-phase=enabled')&&ir.includes('contiguous-stream-penalty=enabled')}));
