import fs from 'fs';
import {performance} from 'perf_hooks';
const [mfPath,densePath]=process.argv.slice(2);
if(!mfPath||!densePath) throw new Error('usage: adaptive_bench.mjs <matrix-free.wasm> <dense.wasm>');
async function load(p){const bytes=fs.readFileSync(p),mod=await WebAssembly.compile(bytes);const imports=WebAssembly.Module.imports(mod);const {exports:e}=await WebAssembly.instantiate(mod,{});return {e,imports:imports.length,bytes:bytes.length};}
const mf=await load(mfPath),dn=await load(densePath);
function med(a){a=[...a].sort((x,y)=>x-y);return a[(a.length/2)|0];}
function complete(e,seed=12345,t=0.375){e.wc_reset(seed);let used=0,steps=0;const t0=performance.now();while(!e.wc_done()){used+=e.wc_step(e.wc_max_step_units(),t);steps++;}return {ms:performance.now()-t0,used,steps,acc:e.wc_accumulator()};}
// Warmup and incremental exact change propagation.
complete(mf.e);const full=[];const inc=[];let invalidated=0,remaining=0,accRel=0;let fullWork=0;for(let i=0;i<mf.e.wc_task_count();i++)fullWork+=mf.e.wc_task_cost(i);
for(let r=0;r<9;r++){
  const a=complete(mf.e,12345+r,0.375);full.push(a.ms);const before=a.acc;
  const t0=performance.now();invalidated=mf.e.wc_invalidate(3);remaining=Number(mf.e.wc_remaining_work());while(!mf.e.wc_done())mf.e.wc_step(mf.e.wc_max_step_units(),0.375);inc.push(performance.now()-t0);
  const after=mf.e.wc_accumulator();accRel=Math.max(accRel,Math.abs(after-before)/Math.max(1,Math.abs(before)));
}
// Generic piecewise exact field comparison.
for(const x of [mf,dn]) x.e.wc_memory_init();
const pid=0;
const meta=x=>({imports:x.imports,wasmBytes:x.bytes,memoryBytes:x.e.memory.buffer.byteLength,count:x.e.wc_piecewise_field_count(),len:x.e.wc_piecewise_field_len(pid),repr:x.e.wc_piecewise_field_repr(pid),segments:x.e.wc_piecewise_field_segments(pid),logical:Number(x.e.wc_piecewise_field_logical_bytes(pid)),stored:Number(x.e.wc_piecewise_field_stored_bytes(pid)),saved:Number(x.e.wc_piecewise_field_saved_bytes(pid))});
const probes=[0,999999,1000000,1999999,2000000,2999999,3000000,3999999].map(i=>({i,mf:mf.e.wc_piecewise_field_get(pid,i),dense:dn.e.wc_piecewise_field_get(pid,i)}));
function benchChecksum(x){const arr=[];let checksum=0;for(let r=0;r<7;r++){const t0=performance.now();checksum=x.e.wc_piecewise_field_checksum(pid,1);arr.push(performance.now()-t0);}return {medianMs:med(arr),samples:arr,checksum};}
const mp=benchChecksum(mf),dp=benchChecksum(dn);
const out={incremental:{rootTask:3,invalidated,fullWork,remainingWork:remaining,workFraction:remaining/fullWork,fullMedianMs:med(full),incrementalMedianMs:med(inc),speedup:med(full)/med(inc),accumulatorRelativeError:accRel,fullSamples:full,incrementalSamples:inc},piecewise:{matrixFree:{...meta(mf),...mp},dense:{...meta(dn),...dp},memoryRatio:mf.e.memory.buffer.byteLength/dn.e.memory.buffer.byteLength,storedRatio:Number(mf.e.wc_piecewise_field_stored_bytes(pid))/Number(dn.e.wc_piecewise_field_stored_bytes(pid)),speedup:dp.medianMs/mp.medianMs,probes,maxProbeError:Math.max(...probes.map(p=>Math.abs(p.mf-p.dense))),checksumError:Math.abs(mp.checksum-dp.checksum)}};
console.log(JSON.stringify(out,null,2));
