#version 400 core
// Generated from Webchan IR. Generic compact field helpers; no trusted source assertions.
